"use strict";
/* THE CHRONICLES OF NARADAK — Simulación de los monstruos del Mundo Abierto EN EL SERVIDOR.
   El servidor es el anfitrión: genera, mueve, hace atacar, cura y reaparece a los monstruos y reparte su estado a todos
   los jugadores que están en el lugar "mundo". Los clientes son solo "títeres" que interpolan lo que reciben.

   · El mapa (celdas bloqueadas, sectores, puertas, dificultad por sector) sale del MISMO archivo que usa el cliente
     (tilemap/js/mundo_mapa.js, hasta el marcador SIM_FIN), así servidor y clientes comparten el mundo exacto.
   · Simulación a 20 Hz; snapshots a 10 Hz con los monstruos a ≤ R_INT celdas de cada jugador; minimapa a 1 Hz.
   · Los golpes de los jugadores llegan como mon_hit (daño ya calculado por el cliente, validado y limitado aquí).
   · Los ataques de los monstruos se resuelven aquí (cono delante del monstruo) y se avisa a los jugadores alcanzados
     (mon_atq); cada cliente aplica su propia defensa/esquiva con su personaje.

   Mensajes cliente → servidor: mon_hit {id,d,kx,ky,stun,ex} · mon_fx {id,stun|dd|heal} · mon_est {mu}
   Mensajes servidor → cliente: mon_ini · mon_s {a,d,m} · mon_muere {id,by,x,y} · mon_atq {id,a,h,k,hl} · mon_mapa {m}

   JEFES DE SECTOR (JEFES en tilemap/js/mundo_mapa.js): héroe humano con las habilidades base de una clase. Viven en la zona más remota de su sector,
   no atacan hasta ser atacados, no persiguen fuera de su arena (al salir vuelven y se curan del todo) y al morir reparten el botín:
   una tirada (5 % legendario · 15 % épico · 30 % raro · 50 % oro) → el objeto va al líder del equipo (lo reparte por comercio); el oro se divide entre el equipo.
   IA DE COMPORTAMIENTOS (tilemap/js/mundo_ia.js, activable con IA_MUNDO_ACTIVA en servidor.js): navegación sin atascos (A*), tácticas por tipo de monstruo
   (flanqueo de manada, embestida, golpe y huida, combos de los alfa) y combos encadenados de los jefes. La fila de mon_s de un monstruo normal que está telegrafiando lleva 1 campo más: windMax.
   Mensajes extra: jefe_aviso {msg} · jefe_botin {jefe,xp,oro,item,rareza,clase,para,paraNombre} (la fila de mon_s del jefe lleva 3 campos más: k, windMax, buff) */
var fs=require("fs"),path=require("path"),vm=require("vm");

module.exports=function(ctx){
 var J=ctx.jugadores,enviar=ctx.wsEnviar,INICIO=ctx.INICIO,log=ctx.log,RAIZ=ctx.RAIZ,gDe=ctx.gDe||function(){return null;};
 var api={activo:false,entra:function(){},sale:function(){},mensaje:function(){},cuenta:function(){return 0;}};
 var MD;
 try{MD=cargarMundo();}catch(e){log("⚠ Simulación de monstruos en el servidor DESACTIVADA ("+e.message+"). Los clientes simulan en local.");return api;}

 var U=32,MIN_S=5.6,DT=.05,R_INT=50,R_REP=45,R_DORM=64,N=MD.N,W=MD.W,GN=MD.GN,S=MD.S,blk=MD.blk,sec=MD.sec,road=MD.road,TM=MD.TM,GATES=MD.GATES,CC=MD.CC,SPAWN=MD.SPAWN,OX=MD.OX;
 var JEFES=MD.JEFES||[],MON_BASE=MD.MON_BASE,MON_SEGURA=MD.MON_SEGURA,MON_RESP=MD.MON_RESP,MON_ALFA=MD.MON_ALFA,MON_MAX_SEC=MD.MON_MAX_SEC,MON_NOM=MD.MON_NOM,MON_PES=MD.MON_PES;
 var DX=[1,0,-1,0],DY=[0,1,0,-1];
 var STATS=cargarStats(),FORJA=cargarForja();
 var IA=null,NAV=null,NAVJ=null;
 if(ctx.iaActiva!==false){try{IA=require(path.join(RAIZ,"tilemap","js","mundo_ia.js"));}catch(e){IA=null;log("⚠ IA de comportamientos DESACTIVADA ("+e.message+"): se usa la IA básica.");}}
 /* dimensiones de los sprites de monstruo (CHARS_INFO) y escala, para el radio de golpe: igual que el cliente */
 var DIM={104:[32,48],106:[32,48],109:[32,48],114:[48,72],124:[48,52],126:[48,52],149:[61,61]},ESC={104:1.9,109:2.1,114:1.2};
 var SPR=[[/Slime/,104],[/Goblin|Duende/,114],[/Champi/,109],[/Lobo/,124],[/Ara[ñn]a/,149],[/Ent /,126],[/Bandido/,106]];
 function sprite(nb){for(var i=0;i<SPR.length;i++)if(SPR[i][0].test(nb))return SPR[i][1];return 124;}

 if(IA){NAV=IA.crearNav(MD.W,MD.W,monLibre);NAVJ=IA.crearNav(MD.W,MD.W,jLibre);}
 var mons=[],resp=[],NOMON=new Uint8Array(N),REACH=new Uint8Array(N),sigId=1,T=0,tick=0,activo=0,enMundo={};
 api.activo=true;

 /* ---------------- carga del mundo desde el archivo del cliente ---------------- */
 function cargarMundo(){
  var src=fs.readFileSync(path.join(RAIZ,"tilemap","js","mundo_mapa.js"),"utf8");
  var fin=src.indexOf("/*@SIM_FIN*/");if(fin<0)throw new Error("falta el marcador SIM_FIN en mundo_mapa.js");
  var pre=src.slice(0,fin),ini="\n(function(){\n";
  if(pre.indexOf(ini)<0)throw new Error("no se encontró el inicio del módulo");
  pre=pre.replace(ini,"\n__SIM=(function(){\n");
  pre+="\nreturn {W:W,H:H,N:N,S:S,GN:GN,blk:blk,sec:sec,road:road,TM:TM,GATES:GATES,CC:CC,SPAWN:SPAWN,OX:OX,MON_BASE:MON_BASE,MON_SEGURA:MON_SEGURA,MON_RESP:MON_RESP,MON_ALFA:MON_ALFA,MON_MAX_SEC:MON_MAX_SEC,MON_NOM:MON_NOM,MON_PES:MON_PES,JEFES:typeof JEFES===\"undefined\"?[]:JEFES};\n})();";
  var dummy=(function(){var f=function(){return p;},p=new Proxy(f,{get:function(t,k){if(k===Symbol.toPrimitive)return function(){return 0;};return p;},apply:function(){return p;},set:function(){return true;}});return p;})();
  var sb={document:dummy,window:{},innerWidth:1280,innerHeight:800,performance:{now:Date.now},__SIM:null,console:{log:function(){},warn:function(){},error:function(){}}};
  vm.runInNewContext(pre,sb,{timeout:30000,filename:"mundo_mapa.js"});
  if(!sb.__SIM)throw new Error("el mundo no se generó");
  return sb.__SIM;
 }
 function cargarForja(){
  try{var sb={};vm.runInNewContext(fs.readFileSync(path.join(RAIZ,"js","data","forja.js"),"utf8"),sb,{timeout:5000,filename:"forja.js"});
   if(!sb.RECETAS_FORJA||!sb.RECETAS_FORJA.length)throw new Error("sin RECETAS_FORJA");return sb.RECETAS_FORJA;}
  catch(e){log("⚠ Botín de jefes sin objetos de forja ("+e.message+"): solo oro.");return [];}
 }
 function cargarStats(){
  var sb={};vm.runInNewContext(fs.readFileSync(path.join(RAIZ,"js","data","mundo.js"),"utf8"),sb,{timeout:5000,filename:"mundo.js"});
  if(!sb.STATS_ENEM)throw new Error("sin STATS_ENEM");return sb.STATS_ENEM;
 }

 /* ---------------- utilidades ---------------- */
 function I(x,y){return y*W+x;}
 function inb(x,y){return x>=0&&y>=0&&x<W&&y<W;}
 function rnd(a,b){return a+Math.random()*(b-a);}
 function ri(n){return Math.floor(Math.random()*n);}
 function angd(a,b){var d=a-b;while(d>Math.PI)d-=2*Math.PI;while(d<-Math.PI)d+=2*Math.PI;return d;}
 function r2(v){return Math.round(v*100)/100;}
 function tmin(){return 480+(Date.now()-INICIO)/1000*MIN_S;}
 function noche(){var h=(tmin()/60)%24;return h<5||h>=21?1:h<7?(7-h)/2:h>=19?(h-19)/2:0;}
 function monNombre(){var t=0,k;for(k=0;k<MON_PES.length;k++)t+=MON_PES[k];var r=Math.random()*t;for(k=0;k<MON_PES.length;k++){r-=MON_PES[k];if(r<0)return MON_NOM[k];}return MON_NOM[0];}
 function stEnem(nb){for(var k in STATS)if(nb.toLowerCase().indexOf(k.toLowerCase())>=0)return STATS[k];return [1,1,1];}
 function seg(p){return Math.hypot(p.x-CC.x,p.y-CC.y)<MON_SEGURA-.5;}
 function jugadoresMundo(){var l=[];for(var id in enMundo){var p=J[id];if(p&&p.lugar==="mundo"&&isFinite(p.x)&&isFinite(p.y))l.push(p);}return l;}
 function validos(){return jugadoresMundo().filter(function(p){return !p.mu;});}

 /* ---------------- zonas prohibidas y celdas alcanzables (igual que monMapa del cliente) ---------------- */
 (function monMapa(){
  var x,y;
  for(y=Math.floor(CC.y-MON_SEGURA-1);y<=CC.y+MON_SEGURA+1;y++)for(x=Math.floor(CC.x-MON_SEGURA-1);x<=CC.x+MON_SEGURA+1;x++)if(inb(x,y)&&Math.hypot(x+.5-CC.x,y+.5-CC.y)<MON_SEGURA)NOMON[I(x,y)]=1;
  GATES.forEach(function(g){for(var b=-5;b<=5;b++)for(var a=-5;a<=5;a++){var X=g.x+a,Y=g.y+b;if(inb(X,Y)&&a*a+b*b<=25)NOMON[I(X,Y)]=1;}});
  for(var kb in TM){var bz=TM[kb].boss;if(!bz)continue;for(var b2=-bz.r-2;b2<=bz.r+2;b2++)for(var a2=-bz.r-2;a2<=bz.r+2;a2++){var X2=Math.floor(bz.x)+a2,Y2=Math.floor(bz.y)+b2;if(inb(X2,Y2)&&a2*a2+b2*b2<=(bz.r+2)*(bz.r+2))NOMON[I(X2,Y2)]=1;}}
  var q=new Int32Array(N),qh=0,qt=0,seeds=[{x:Math.floor(SPAWN.x),y:Math.floor(SPAWN.y)}];
  GATES.forEach(function(g){seeds.push(g.out);});
  seeds.forEach(function(s){if(!inb(s.x,s.y))return;var c=I(s.x,s.y);if(!blk[c]&&!REACH[c]){REACH[c]=1;q[qt++]=c;}});
  while(qh<qt){var c0=q[qh++],cx0=c0%W,cy0=(c0/W)|0;for(var k=0;k<4;k++){var X2=cx0+DX[k],Y2=cy0+DY[k];if(!inb(X2,Y2))continue;var j=I(X2,Y2);if(blk[j]||REACH[j])continue;REACH[j]=1;q[qt++]=j;}}
 })();
 function jLibre(x,y){var X=Math.floor(x),Y=Math.floor(y);if(!inb(X,Y))return false;var i=I(X,Y);return !blk[i]&&sec[i]>=0;}   /* el jefe sí puede pisar su propia zona (vetada a los monstruos) */
 function monLibre(x,y){var X=Math.floor(x),Y=Math.floor(y);if(!inb(X,Y))return false;var i=I(X,Y);return !blk[i]&&!NOMON[i]&&sec[i]>=0;}

 /* ---------------- creación de monstruos (mismas stats que el cliente: _normalEnemigo × multiplicadores del sector) ---------------- */
 function celdaSpawn(sk,minD){
  var T0=TM[sk],ox=OX(T0.c),oy=OX(T0.r),pl=minD?jugadoresMundo():[];
  for(var n=0;n<120;n++){var x=ox+4+Math.floor(Math.random()*(S-8)),y=oy+4+Math.floor(Math.random()*(S-8)),i=I(x,y);
   if(blk[i]||!REACH[i]||NOMON[i]||sec[i]!==sk)continue;
   if(road[i]&&Math.random()<.6)continue;
   if(minD&&pl.some(function(p){return Math.hypot(x+.5-p.x,y+.5-p.y)<minD;}))continue;
   return{x:x+.5,y:y+.5};}
  return null;}
 function crearMon(sk,x,y,nb,pack){
  var d=TM[sk].dif,pe=d.pe,alfa=Math.random()<MON_ALFA;nb=nb||monNombre();
  var st=stEnem(nb),multB=1.2,multP=Math.min(9,pe);
  var vida=Math.floor((80+multP*2+pe*1.2)*st[0]*multB*1.2),
      a0=Math.floor((15+multP+pe*0.28)*st[1]*multB*1.2*0.9),a1=Math.floor((15+multP+pe*0.28)*st[1]*multB*1.2*1.1),
      df=Math.floor((15+multP+pe*0.45)*st[2]*multB*1.15),xp=15+pe*2,oro=8+pe*2;
  vida=Math.floor(vida*1.75);
  var fv=d.vida*(alfa?2:1),fd=d.dano*(alfa?1.4:1);
  vida=Math.max(1,Math.floor(vida*fv));a0=Math.max(1,Math.floor(a0*fd));a1=Math.max(a0,Math.floor(a1*fd));
  df=Math.floor(df*(1+(d.vida-1)*.5)*(alfa?1.25:1));
  var c=sprite(nb),dm=DIM[c]||[48,52],esc=42*(ESC[c]||1)*(alfa?1.3:1)/dm[1];
  var m={id:sigId++,sk:sk,nb:nb,alfa:alfa,pack:pack||0,x:x,y:y,hx:x,hy:y,vida:vida,vm:vida,a0:a0,a1:a1,df:df,xp:xp,oro:oro,rec:d.rec*(alfa?2.5:1),
   spd:(2.9+(c===124?.9:0)+(c===104?-.6:0))*d.vel*(alfa?1.1:1),agro:6.5*d.agro,reach:1.1,r:Math.max(10,Math.min(26,dm[0]*esc*.3)),
   st:0,cd:.6+Math.random(),wt:Math.random()*3,wx:x,wy:y,mv:0,bias:Math.random()<.5?1:-1,stunT:0,kx:0,ky:0,wind:0,windA:0,tgt:0,dmin:0};
  if(IA)IA.initMon(m,nb);
  mons.push(m);return m;}
 function vivosSec(sk){var n=0;for(var i=0;i<mons.length;i++)if(mons[i].sk===sk&&!mons[i].jefe)n++;return n;}
 function objetivo(sk){return Math.min(MON_MAX_SEC,Math.round(MON_BASE*TM[sk].dif.cant));}
 function spawnManada(sk,tope){
  var c=celdaSpawn(sk,0);if(!c)return 0;
  var n=Math.min(tope||3,1+(Math.random()<.5?1:0)+(Math.random()<.2?1:0)),nb=Math.random()<.7?monNombre():null,pk=sigId++,k=0;
  for(var a=0;a<n*6&&k<n;a++){var x=Math.floor(c.x+(Math.random()-.5)*5),y=Math.floor(c.y+(Math.random()-.5)*5);
   if(!inb(x,y)||blk[I(x,y)]||!REACH[I(x,y)]||NOMON[I(x,y)]||sec[I(x,y)]!==sk)continue;
   crearMon(sk,x+.5,y+.5,nb,pk);k++;}
  return k;}
 function poblar(){for(var k=0;k<GN*GN;k++){if(!TM[k].built)continue;var obj=objetivo(k),g=0;while(vivosSec(k)<obj&&g++<80)spawnManada(k,obj-vivosSec(k));}}
 poblar();

 /* ---------------- JEFES DE SECTOR ---------------- */
 var JRESP=[],RARIDAD=["Común","Poco Común","Raro","Épico","Legendario"],CLASES6=["Guerrero","Mago","Arquero","Paladin","Asesino","Clérigo"];
 function habDe(m,k){for(var i=0;i<m.jd.habs.length;i++)if(m.jd.habs[i].k===k)return m.jd.habs[i];return null;}
 function skDeSector(id){for(var k=0;k<GN*GN;k++)if(TM[k].built&&TM[k].id===id)return k;return -1;}
 /* zona remota del sector: la celda alcanzable más lejana (por camino) de sus puertas, con espacio libre alrededor y lejos de los bordes */
 function arenaJefe(sk){
  var T0=TM[sk],ox=OX(T0.c),oy=OX(T0.r),dist=new Int32Array(N).fill(-1),q=[],i,x,y;
  var bs=1e9,bc=-1;   /* origen: la celda del sector más cercana al campamento (ya no hay puertas) */
  for(i=0;i<N;i++){if(sec[i]!==sk||blk[i]||!REACH[i])continue;var dd0=Math.hypot(i%W-CC.x,((i/W)|0)-CC.y);if(dd0<bs){bs=dd0;bc=i;}}
  if(bc>=0){dist[bc]=0;q.push(bc);}
  if(!q.length){var cs=I(ox+(S>>1),oy+(S>>1));if(!blk[cs]){dist[cs]=0;q.push(cs);}}
  for(var h=0;h<q.length;h++){var c0=q[h],cx0=c0%W,cy0=(c0/W)|0;for(var k=0;k<4;k++){var X=cx0+DX[k],Y=cy0+DY[k];if(!inb(X,Y))continue;var j=I(X,Y);if(blk[j]||dist[j]>=0||sec[j]!==sk)continue;dist[j]=dist[c0]+1;q.push(j);}}
  var mejor=null,md=-1;
  for(y=oy+12;y<oy+S-12;y++)for(x=ox+12;x<ox+S-12;x++){
   i=I(x,y);if(dist[i]<=md||!REACH[i]||NOMON[i]||road[i])continue;
   var mal=0;for(var b=-5;b<=5;b++)for(var a=-5;a<=5;a++){var jj=I(x+a,y+b);if(blk[jj]||sec[jj]!==sk)mal++;}
   if(mal>10)continue;
   md=dist[i];mejor={x:x+.5,y:y+.5};}
  return mejor;}
 /* stats = monstruo normal del sector (misma fórmula que crearMon) × multiplicadores del jefe (def.f) */
 function crearJefe(d,sk,x,y){
  var T0=TM[sk].dif,pe=d.nivel,multB=1.2,multP=Math.min(9,pe);   /* el nivel del jefe sustituye al piso equivalente del sector */
  var vida=Math.floor((80+multP*2+pe*1.2)*multB*1.2);vida=Math.floor(vida*1.75);
  var a0=Math.floor((15+multP+pe*0.28)*multB*1.2*0.9),a1=Math.floor((15+multP+pe*0.28)*multB*1.2*1.1),df=Math.floor((15+multP+pe*0.45)*multB*1.15);
  vida=Math.max(1,Math.floor(vida*T0.vida));a0=Math.max(1,Math.floor(a0*T0.dano));a1=Math.max(a0,Math.floor(a1*T0.dano));df=Math.floor(df*(1+(T0.vida-1)*.5));
  vida=Math.max(1,Math.floor(vida*d.f.vida));df=Math.floor(df*d.f.def);a0=Math.max(1,Math.floor(a0*d.f.dano));a1=Math.max(a0,Math.floor(a1*d.f.dano));
  df=Math.floor(df*(1+d.mod.defp));a0=Math.max(1,Math.floor(a0*(1+d.mod.dmg)));a1=Math.max(a0,Math.floor(a1*(1+d.mod.dmg)));   /* pasivos de la rama */
  var inf=DIMJ[d.c]||[48,72],hcd={};d.habs.forEach(function(h){hcd[h.k]=h.cd*.2;});
  var m={id:sigId++,sk:sk,nb:d.n,jefe:1,jd:d,alfa:false,pack:0,x:x,y:y,hx:x,hy:y,vida:vida,vm:vida,a0:a0,a1:a1,df:df,df0:df,dfB:df,xp:Math.floor((15+pe*2)*d.xp),oro:0,rec:T0.rec,
   spd:d.spd,agro:0,reach:d.reach||1.7,r:Math.max(14,Math.min(30,inf[0]*d.esc*.5)),st:0,cd:.8,wt:0,wx:x,wy:y,mv:0,bias:1,stunT:0,stunImm:0,kx:0,ky:0,wind:0,windA:0,windMax:.42,k:0,tgt:0,dmin:0,
   sh:0,hcd:hcd,buffT:0,thr:{},part:{},noT:0,cmb:null,imp:0,stt:0};
  mons.push(m);return m;}
 var DIMJ={72:[48,72],73:[48,72],74:[48,72],80:[48,72],81:[48,72],82:[48,72],83:[48,72],85:[48,72],87:[48,72]};
 function iniciarJefes(){
  JEFES.forEach(function(d){
   var sk=skDeSector(d.sec);if(sk<0){log("⚠ Jefe "+d.n+": el sector "+d.sec+" no está construido.");return;}
   var zb=TM[sk].boss,a=zb?{x:zb.x,y:zb.y}:arenaJefe(sk);if(!a){log("⚠ Jefe "+d.n+": no se encontró zona remota en el sector "+d.sec+".");return;}
   d._sk=sk;d._home=a;crearJefe(d,sk,a.x,a.y);
   d.avisos.forEach(function(av){log("⚠ Jefe "+d.n+": "+av);});
   log("Jefe de sector "+d.sec+": "+d.n+" Nv "+d.nivel+(d.rama?" · rama "+d.rama:"")+" en ("+Math.floor(a.x)+", "+Math.floor(a.y)+")");});}
 function aviso(msg){jugadoresMundo().forEach(function(p){enviar(p.sock,{t:"jefe_aviso",msg:msg});});}
 function resetJefe(m){
  m.st=0;m.x=m.hx;m.y=m.hy;m.vida=m.vm;m.df0=m.dfB;m.df=m.dfB;m.buffT=0;m.sh=0;m.wind=0;m.k=0;m.stunT=0;m.stunImm=0;m.kx=m.ky=0;m.mv=0;m.tgt=0;m.noT=0;m.cd=.8;m.thr={};m.part={};m.cmb=null;m.imp=0;if(IA)IA.olvida(m);
  m.jd.habs.forEach(function(h){m.hcd[h.k]=h.cd*.2;});m.fijo=null;m.swT=null;}
 function setDfJ(m){m.df=Math.floor(m.df0*(m.buffT>0&&m.dfA?1+m.dfA:1));}   /* dfA = DEF extra del refuerzo activo */
 function objetivoJefe(m,lista){
  var cand=lista.filter(function(p){return !seg(p)&&Math.hypot(p.x-m.hx,p.y-m.hy)<=m.jd.arena+2;});
  if(!cand.length)return null;
  if(m.fijo&&m.fijo.t>0){var fj=J[m.fijo.id];if(fj&&cand.indexOf(fj)>=0)return fj;}
  var act=J[m.tgt],ta=act&&cand.indexOf(act)>=0?act:null,mejor=null,bt=-1;
  cand.forEach(function(p){var t=(m.thr[p.id]||0)+(p===ta?m.vm*.01+50:0)-Math.hypot(p.x-m.x,p.y-m.y)*.5;if(t>bt){bt=t;mejor=p;}});
  if(ta&&(m.thr[mejor.id]||0)<(m.thr[ta.id]||0)*1.25+50)mejor=ta;
  return mejor;}
 function empezarHab(m,hb,tg,wm){
  var f=faseJ(m);
  m.k=hb?hb.k:0;m.windMax=m.wind=(hb?hb.wind:.42)*f.w*(wm||1);m.windA=Math.atan2(tg.y-m.y,tg.x-m.x);if(hb)m.hcd[hb.k]=hb.cd*f.c;}
 /* fases: por debajo del 50 % y del 25 % de vida el jefe se enfurece (más rápido, menos espera entre golpes y telegrafías más cortas) */
 function faseJ(m){var p=m.vida/m.vm,i=p<.25?2:p<.5?1:0;return{v:[1,1.15,1.3][i],c:[1,.8,.65][i],w:[1,.9,.8][i],i:i};}
 function alcanzados(m,h,tg,lista){
  var A=Math.atan2(tg.y-m.y,tg.x-m.x),rad=m.r+14+34+(h.r||0),ar=h.arc?h.arc*Math.PI:Math.PI*.55,n=0;
  lista.forEach(function(p){var dd=Math.hypot(p.x-m.x,p.y-m.y)*U,a2=Math.atan2(p.y-m.y,p.x-m.x);if(dd<=rad&&Math.abs(angd(a2,A))<=ar)n++;});
  return n;}
 /* elige la mejor habilidad lista: cura si está bajo, refuerzo al empezar o si le atacan, y ataques según a cuántos alcanzan */
 function elegirHab(m,d,tg,lista){
  var pct=m.vida/m.vm,mejor=null,bs=0;
  m.jd.habs.forEach(function(h){
   if(m.hcd[h.k]>0)return;var sc=0;
   if(!h.m){
    if(h.heal&&!h.df&&!h.shield&&!h.dm){if(pct>=.55)return;sc=100-pct*60;}
    else{if(m.buffT>0)return;sc=45+(1-pct)*30;}
   }else{
    if(d>(m.r+14+34+(h.r||0))/U-.3)return;
    var n=alcanzados(m,h,tg,lista);if(!n)return;
    sc=25+n*14+(h.m>=2?10:0)+(h.stun?8:0)+(h.robo&&pct<.85?18:0);}
   sc+=Math.random()*10;
   if(sc>bs){bs=sc;mejor=h;}});
  return mejor;}
 function resolverJefe(m){
  var k=m.k,hb=k?habDe(m,k):null,A=m.windA,hit=[],hl=0;
  m.k=0;
  if(hb&&!hb.m){if(hb.df||hb.shield||hb.dm){m.buffT=hb.dur;m.dfA=hb.df||0;m.dmA=hb.dm||0;setDfJ(m);}if(hb.shield)m.sh=Math.floor(m.vm*hb.shield);if(hb.heal){hl=Math.floor(m.vm*hb.heal);m.vida=Math.min(m.vm,m.vida+hl);}m.cd=.6;}
  else{
   var rad=m.r+14+34+(hb&&hb.r||0),ar=hb&&hb.arc?hb.arc*Math.PI:Math.PI*.55,mult=hb?hb.m:1;
   m.cd=hb?.45:(.7*(.9+Math.random()*.2))*faseJ(m).c;
   validos().forEach(function(p){var dd=Math.hypot(p.x-m.x,p.y-m.y)*U,a2=Math.atan2(p.y-m.y,p.x-m.x);if(dd<=rad&&Math.abs(angd(a2,A))<=ar)hit.push(p.id);});
   if(hb&&hb.robo&&hit.length){hl=Math.min(Math.floor(m.vm*.04),Math.floor((m.a0+m.a1)/2*mult*.6*hit.length*hb.robo));m.vida=Math.min(m.vm,m.vida+hl);}}
  if(m.cmb){   /* combo en curso: siguiente eslabón enseguida; al terminar, pausa de recuperación (ventana para contraatacar) */
   if(m.cmb.q.length)m.cd=CFGJ.GAP;
   else{if(m.cmb.att)m.cd=Math.max(m.cd,CFGJ.RECUP*faseJ(m).c);m.cmb=null;m.imp=0;}}
  var msg={t:"mon_atq",id:m.id,a:r2(A),h:hit,k:k};if(hl>0)msg.hl=hl;if(m.buffT>0&&m.dmA)msg.dm=r2(1+m.dmA);
  jugadoresMundo().forEach(function(p){if(vista(p,m.id)||hit.indexOf(p.id)>=0)enviar(p.sock,msg);});}
 var CFGJ=IA?{GAP:IA.CFG.J_GAP,RECUP:IA.CFG.J_RECUP,VENT:IA.CFG.J_VENT}:{GAP:.45,RECUP:1,VENT:1};
 function pasoJefe(m,dt,lista){
  var i;
  m.cd-=dt;for(var kk in m.hcd)m.hcd[kk]=Math.max(0,m.hcd[kk]-dt);
  if(m.fijo)m.fijo.t-=dt;
  if(m.buffT>0){m.buffT-=dt;if(m.buffT<=0){m.buffT=0;m.sh=0;setDfJ(m);}}
  if(m.stunImm>0)m.stunImm-=dt;
  if(m.kx||m.ky){if(Math.hypot(m.kx,m.ky)>.04){var kx2=m.x+m.kx*dt,ky2=m.y+m.ky*dt;if(jLibre(kx2,ky2)){m.x=kx2;m.y=ky2;}else{m.kx=0;m.ky=0;}var kf=Math.max(0,1-dt*9);m.kx*=kf;m.ky*=kf;}else{m.kx=0;m.ky=0;}}
  if(m.stunT>0){m.stunT-=dt;m.wind=0;m.k=0;m.mv=0;m.cmb=null;return;}
  if(m.st===0){m.mv=0;return;}
  var dh=Math.hypot(m.x-m.hx,m.y-m.hy);
  if(m.st===2){
   m.wind=0;m.k=0;m.vida=Math.min(m.vm,m.vida+m.vm*.25*dt);
   if(dh<.6){resetJefe(m);return;}
   paso(m,m.hx,m.hy,m.spd*1.4,dt);return;}
  /* en combate */
  var tg=objetivoJefe(m,lista);
  if(!tg){m.noT+=dt;if(m.noT>3||dh>m.jd.arena+3){m.st=2;m.wind=0;m.k=0;m.tgt=0;}else m.mv=0;if(m.wind<=0)return;}
  else{m.noT=0;m.tgt=tg.id;}
  if(dh>m.jd.arena+3){m.st=2;m.wind=0;m.k=0;m.tgt=0;return;}
  if(m.wind>0){m.wind-=dt;m.mv=0;if(m.wind<=0){m.wind=0;resolverJefe(m);}return;}
  if(!tg)return;
  var dx=tg.x-m.x,dy=tg.y-m.y,d=Math.hypot(dx,dy);
  var f=faseJ(m);
  /* ---- COMBOS (IA): refuerzo → apertura con control → ataque principal → remate; el jefe se acerca entre eslabones ---- */
  if(IA){
   m.imp=(m.imp||0)+dt;
   if(m.cmb){
    var cb=m.cmb,kc=cb.q[0],hc=kc!=null?habDe(m,kc):null;cb.t-=dt;
    if(!hc||m.hcd[kc]>0||cb.t<=0){if(cb.att)m.cd=Math.max(m.cd,CFGJ.RECUP*f.c);m.cmb=null;m.imp=0;}
    else if(!hc.m){cb.q.shift();empezarHab(m,hc,tg,cb.n>0?CFGJ.VENT:1);cb.n++;return;}
    else{
     var rgc=(m.r+14+34+(hc.r||0))/U-.3;
     if(d<=rgc){m.mv=0;if(m.cd<=0){cb.q.shift();cb.att++;empezarHab(m,hc,tg,cb.n>0?CFGJ.VENT:1);cb.n++;}}
     else paso(m,tg.x,tg.y,m.spd*f.v*1.5,dt);
     return;}
   }else if(m.cd<=0||m.jd.habs.some(function(h){return !h.m&&m.hcd[h.k]<=0;})){
    var plan=IA.jefe.planear(m,{fase:f,d:d,U:U,r0:m.r+14+34});
    if(plan){m.cmb={q:plan,t:6,n:0,att:0};m.imp=0;return;}
   }
  }
  var hb=(m.cd<=0||m.jd.habs.some(function(h){return !h.m&&m.hcd[h.k]<=0;}))?elegirHab(m,d,tg,lista):null;
  if(IA&&hb&&hb.m&&(m.imp||0)<IA.CFG.J_PACIENCIA&&m.jd.habs.some(function(h){return h.m&&h!==hb&&m.hcd[h.k]>0&&m.hcd[h.k]<=IA.CFG.J_ESPERA;}))hb=null;   /* no gasta sola una habilidad si va a poder encadenar otra enseguida */
  /* cada 8-12 s cambia a un objetivo al azar durante 5 s (no se queda siempre con el mismo) */
  m.swT=(m.swT==null?8+Math.random()*4:m.swT)-dt;
  if(m.swT<=0){m.swT=8+Math.random()*4;var otros=lista.filter(function(p){return p!==tg&&!seg(p)&&Math.hypot(p.x-m.hx,p.y-m.hy)<=m.jd.arena+2;});if(otros.length&&Math.random()<.6)m.fijo={id:otros[ri(otros.length)].id,t:5};}
  if(hb&&!hb.m){empezarHab(m,hb,tg);return;}
  var enRango=hb&&d<=(m.r+14+34+(hb.r||0))/U-.3;
  if(d>m.reach&&!enRango){paso(m,tg.x,tg.y,m.spd*f.v*(d>5?1.35:1),dt);return;}
  if(m.reach>3&&d<2.2&&m.cd>0&&!hb){paso(m,m.x-dx,m.y-dy,m.spd*.9,dt);return;}   /* los jefes a distancia se apartan */
  if(IA&&m.cd>.25&&d>.01){   /* mientras recarga no se queda clavado: rodea al objetivo (cuerpo a cuerpo) */
   m.stt-=dt;if(m.stt<=0){m.stt=1.4+Math.random()*1.6;if(Math.random()<.4)m.bias=-m.bias;}
   var ux=dx/d,uy=dy/d,rd=Math.max(-.4,Math.min(.4,(d-m.reach*.8)*.8));
   if(NAVJ.mueve(m,Math.atan2(ux*m.bias*.5+uy*rd,-uy*m.bias*.5+ux*rd),m.spd*.5,dt)&&Math.hypot(m.x-m.hx,m.y-m.hy)<=m.jd.arena)return;
   m.bias=-m.bias;}
  m.mv=0;
  if(m.cd<=0)empezarHab(m,hb,tg);}
 /* ---- botín ---- */
 function elegirItem(rar){
  if(!FORJA.length)return null;
  var cl=CLASES6.slice();
  while(cl.length){var c=cl.splice(ri(cl.length),1)[0],l=FORJA.filter(function(r){return r[8]===rar&&r[2]===c;});if(l.length){var r=l[ri(l.length)];return{n:r[0],clase:c,rareza:RARIDAD[rar]};}}
  return null;}
 function muereJefe(m,por){
  var d=m.jd,i=mons.indexOf(m);if(i>=0)mons.splice(i,1);
  JRESP.push({id:d.id,t:T+d.resp});
  var cerca=jugadoresMundo(),part={},ids=[];
  for(var id in m.part){var p=J[id];if(p&&p.lugar==="mundo")part[id]=p;}
  Object.keys(part).slice().forEach(function(id){var g=gDe(part[id]);if(!g)return;g.miembros.forEach(function(mid){var q=J[mid];if(q&&q.lugar==="mundo"&&!part[mid]&&Math.max(Math.abs(q.x-m.x),Math.abs(q.y-m.y))<=d.arena+30)part[mid]=q;});});
  for(var k in part)ids.push(part[k]);
  var msgM={t:"mon_muere",id:m.id,by:0,x:r2(m.x),y:r2(m.y)};
  cerca.forEach(function(p){if(vista(p,m.id)||part[p.id]){enviar(p.sock,msgM);if(p._vs)delete p._vs[m.id];}});
  aviso("☠ "+d.n+" ha caído ante "+(ids.length>1?"el equipo":ids.length?ids[0].nombre:"los héroes")+".");
  if(!ids.length)return;
  var L=d.loot,r=Math.random(),rar=r<L.leg?4:r<L.leg+L.epi?3:r<L.leg+L.epi+L.rar?2:0,item=rar?elegirItem(rar):null,oro=item?0:Math.floor(L.oroTotal/ids.length);
  var lider=por&&part[por.id]?por:ids[0],gl=gDe(lider);if(gl&&part[gl.lider])lider=part[gl.lider];
  var xp=Math.max(1,Math.floor(m.xp*m.rec));
  ids.forEach(function(p){enviar(p.sock,{t:"jefe_botin",jefe:d.n,xp:xp,oro:oro,item:item?item.n:null,rareza:item?item.rareza:null,clase:item?item.clase:null,para:lider.id,paraNombre:lider.nombre});});
  log("Jefe "+d.n+" derrotado ("+ids.length+" jugadores): "+(item?item.rareza+" "+item.n+" → "+lider.nombre:oro+" de oro c/u"));}
 function respJefes(){
  for(var i=JRESP.length-1;i>=0;i--){var rs=JRESP[i];if(T<rs.t)continue;
   var d=JEFES.filter(function(x){return x.id===rs.id;})[0];JRESP.splice(i,1);if(!d||!d._home)continue;
   crearJefe(d,d._sk,d._home.x,d._home.y);aviso("⚔ "+d.n+" ha regresado a "+TM[d._sk].n+".");}}
 iniciarJefes();

 /* ---------------- IA ---------------- */
 function paso(m,tx,ty,sp,dt){
  if(IA){(m.jefe?NAVJ:NAV).paso(m,tx,ty,sp*(m.aura>T?1.12:1),dt);return;}
  var dx=tx-m.x,dy=ty-m.y,d=Math.hypot(dx,dy);if(d<.05){m.mv=0;return;}
  var a0=Math.atan2(dy,dx),st=Math.min(d,sp*dt),angs=m.bias>0?[0,.7,-.7,1.4,-1.4]:[0,-.7,.7,-1.4,1.4];
  for(var k=0;k<5;k++){var a=a0+angs[k],nx=m.x+Math.cos(a)*st,ny=m.y+Math.sin(a)*st;
   if((m.jefe?jLibre:monLibre)(nx,ny)){m.x=nx;m.y=ny;m.mv=1;if(k)m.bias=angs[k]>0?1:-1;return;}}
  m.mv=0;}
 function alerta(m,p){
  if(m.st===1&&m.tgt===p.id)return;
  var nuevo=m.st!==1;m.st=1;m.tgt=p.id;m.cd=Math.max(m.cd,.45);
  if(nuevo&&m.pack){var gr=[m];for(var i=0;i<mons.length;i++){var o=mons[i];if(o.pack===m.pack&&o!==m&&o.st!==1&&Math.hypot(o.x-m.x,o.y-m.y)<8){o.st=1;o.tgt=p.id;o.cd=Math.max(o.cd,.45+Math.random()*.4);gr.push(o);}}if(IA)IA.slots(gr);}}
 function resolver(m){
  var A=m.windA,rad=m.r+14+34,hit=[];
  m.cd=IA?IA.trasGolpe(m):(.62*(.85+Math.random()*.35))/(m.spd>3.6?1.15:1);
  validos().forEach(function(p){var dd=Math.hypot(p.x-m.x,p.y-m.y)*U,a2=Math.atan2(p.y-m.y,p.x-m.x);if(dd<=rad&&Math.abs(angd(a2,A))<=Math.PI*.55)hit.push(p.id);});
  var msg={t:"mon_atq",id:m.id,a:r2(A),h:hit};
  jugadoresMundo().forEach(function(p){if(vista(p,m.id)||hit.indexOf(p.id)>=0)enviar(p.sock,msg);});}
 function vista(p,id){return !!(p._vs&&p._vs[id]);}
 function nearest(m,lista){var b=null,bd=1e9;lista.forEach(function(p){var d=Math.hypot(p.x-m.x,p.y-m.y);if(d<bd){bd=d;b=p;}});return b?{p:b,d:bd}:null;}
 function pasoMon(m,dt,lista,noc){
  if(m.kx||m.ky){if(Math.hypot(m.kx,m.ky)>.04){var kx2=m.x+m.kx*dt,ky2=m.y+m.ky*dt;if(monLibre(kx2,ky2)){m.x=kx2;m.y=ky2;}else{m.kx=0;m.ky=0;}var kf=Math.max(0,1-dt*9);m.kx*=kf;m.ky*=kf;}else{m.kx=0;m.ky=0;}}
  if(m.stunT>0){m.stunT-=dt;m.wind=0;m.mv=0;return;}
  var libres=lista.filter(function(p){return !seg(p);}),dh=Math.hypot(m.x-m.hx,m.y-m.hy),spd=m.spd,tg=null,d=1e9,dx=0,dy=0;
  m.cd-=dt;
  if(m.st===1){tg=J[m.tgt];if(!tg||tg.lugar!=="mundo"||tg.mu||seg(tg)){var nn=nearest(m,libres);tg=nn&&nn.d<m.agro*2.4?nn.p:null;if(tg)m.tgt=tg.id;}}
  if(tg){dx=tg.x-m.x;dy=tg.y-m.y;d=Math.hypot(dx,dy);}
  if(m.wind>0){m.wind-=dt;m.mv=0;if(m.wind<=0){m.wind=0;resolver(m);}return;}
  if(m.st===0){
   m.wt-=dt;
   if(m.wt<=0){m.wt=2+Math.random()*4;if(Math.random()<.6){var a=Math.random()*6.283,r=Math.random()*4.5;m.wx=m.hx+Math.cos(a)*r;m.wy=m.hy+Math.sin(a)*r;}else{m.wx=m.x;m.wy=m.y;}}
   if(Math.hypot(m.wx-m.x,m.wy-m.y)>.2)paso(m,m.wx,m.wy,spd*.35,dt);else m.mv=0;
   var nr=nearest(m,libres);if(nr&&nr.d<m.agro*(1+.25*noc))alerta(m,nr.p);
  }else if(m.st===1){
   if(!tg||d>m.agro*2.4||dh>24){m.st=2;m.tgt=0;if(IA)IA.olvida(m);}
   else if(IA){
    if(m.alfa&&m.pack&&(m.auraT=(m.auraT||0)-dt)<=0){m.auraT=.5;for(var ia=0;ia<mons.length;ia++){var oa=mons[ia];if(oa.pack===m.pack&&!oa.jefe&&Math.hypot(oa.x-m.x,oa.y-m.y)<9)oa.aura=T+.8;}}   /* el alfa enardece a su manada (+12 % velocidad) */
    var go=IA.chase(NAV,m,tg,d,dt,spd*(m.aura>T?1.12:1));
    if(go){m.windMax=m.wind=IA.ventana(m);m.windA=Math.atan2(dy,dx);}
    if(IA.sinCamino(m)){m.st=2;m.tgt=0;IA.olvida(m);}   /* objetivo inalcanzable: se rinde y vuelve a casa */
   }
   else if(d>m.reach)paso(m,tg.x,tg.y,spd,dt);
   else{m.mv=0;if(m.cd<=0){m.wind=.42*(m.alfa?.9:1);m.windA=Math.atan2(dy,dx);}}
  }else{
   m.vida=Math.min(m.vm,m.vida+m.vm*.12*dt);
   if(Math.hypot(m.hx-m.x,m.hy-m.y)<.6){m.st=0;m.mv=0;}else paso(m,m.hx,m.hy,spd*1.1,dt);
   var n2=nearest(m,libres);if(n2&&n2.d<m.agro*.7&&m.vida>m.vm*.5)alerta(m,n2.p);
  }}
 function reiniciarTodo(){for(var i=0;i<mons.length;i++){var m=mons[i];if(m.jefe){resetJefe(m);continue;}m.st=0;m.x=m.hx;m.y=m.hy;m.vida=m.vm;m.wind=0;m.stunT=0;m.kx=m.ky=0;m.mv=0;m.tgt=0;if(IA)IA.olvida(m);}}

 function paso20(){
  var lista=validos(),todos=jugadoresMundo(),i,m;
  if(!todos.length){if(activo){activo=0;reiniciarTodo();}return;}
  activo=1;T+=DT;
  if(IA){NAV.tick();NAVJ.tick();}
  var noc=noche();
  for(i=0;i<mons.length;i++){m=mons[i];
   var dm=1e9;for(var q=0;q<todos.length;q++){var dd=Math.max(Math.abs(todos[q].x-m.x),Math.abs(todos[q].y-m.y));if(dd<dm)dm=dd;}
   m.dmin=dm;if(dm>R_DORM)continue;
   if(m.jefe)pasoJefe(m,DT,lista);else pasoMon(m,DT,lista,noc);}
  for(i=0;i<mons.length;i++){var a1=mons[i];if(a1.dmin>R_DORM||a1.jefe)continue;for(var j=i+1;j<mons.length;j++){var b1=mons[j];if(b1.dmin>R_DORM||b1.jefe)continue;var ddx=b1.x-a1.x,ddy=b1.y-a1.y,dd2=ddx*ddx+ddy*ddy;
   if(dd2<.36&&dd2>1e-6){var l=Math.sqrt(dd2),pp=(.6-l)*.5;if(monLibre(a1.x-ddx/l*pp,a1.y-ddy/l*pp)){a1.x-=ddx/l*pp;a1.y-=ddy/l*pp;}if(monLibre(b1.x+ddx/l*pp,b1.y+ddy/l*pp)){b1.x+=ddx/l*pp;b1.y+=ddy/l*pp;}}}}
  for(i=resp.length-1;i>=0;i--){var rs=resp[i];if(T<rs.t)continue;
   if(vivosSec(rs.sk)>=objetivo(rs.sk)){resp.splice(i,1);continue;}
   var c=celdaSpawn(rs.sk,24);if(c){crearMon(rs.sk,c.x,c.y);resp.splice(i,1);}else rs.t=T+3;}
  respJefes();
  tick++;
  if(tick%2===0)snapshots(todos);
  if(tick%20===0)minimapa(todos);
 }

 /* ---------------- reparto de estado a los jugadores ---------------- */
 function spec(m){var o={id:m.id,sk:m.sk,nb:m.nb,alfa:m.alfa?1:0,pack:m.pack,x:r2(m.x),y:r2(m.y),hx:r2(m.hx),hy:r2(m.hy),vm:m.vm,a0:m.a0,a1:m.a1,df:m.df,xp:m.xp,oro:m.oro,rec:m.rec,spd:r2(m.spd),agro:r2(m.agro)};
  if(m.jefe){o.jf=1;o.jid=m.jd.id;o.tt=m.jd.t;o.c=m.jd.c;o.esc=m.jd.esc;o.r=m.r;o.cl=m.jd.clase;}return o;}
 function snapshots(todos){
  todos.forEach(function(p){
   var vs=p._vs||(p._vs={}),nuevo={},a=[],d=[],mm=[],i,m;
   for(i=0;i<mons.length;i++){m=mons[i];
    if(Math.abs(m.x-p.x)>R_INT||Math.abs(m.y-p.y)>R_INT)continue;
    nuevo[m.id]=1;if(!vs[m.id])a.push(spec(m));
    var fila=[m.id,r2(m.x),r2(m.y),Math.max(0,Math.floor(m.vida)),m.st,r2(m.wind),r2(m.windA),r2(Math.max(0,m.stunT)),m.df];
    if(m.jefe)fila.push(m.k,r2(m.windMax),m.buffT>0?1:0);else if(IA&&m.wind>0)fila.push(r2(m.windMax));
    mm.push(fila);}
   for(var id in vs)if(!nuevo[id])d.push(+id);
   p._vs=nuevo;
   if(!a.length&&!d.length&&!mm.length)return;
   var msg={t:"mon_s",m:mm};if(a.length)msg.a=a;if(d.length)msg.d=d;
   enviar(p.sock,msg);});}
 function minimapa(todos){
  var l=mons.map(function(m){return [Math.round(m.x),Math.round(m.y),m.jefe?2:m.alfa?1:0];}),msg={t:"mon_mapa",m:l};
  todos.forEach(function(p){enviar(p.sock,msg);});}

 /* ---------------- golpes y efectos que llegan de los jugadores ---------------- */
 function buscar(id){for(var i=0;i<mons.length;i++)if(mons[i].id===id)return mons[i];return null;}
 function matar(m,por){
  if(m.jefe){muereJefe(m,por);return;}
  var i=mons.indexOf(m);if(i>=0)mons.splice(i,1);
  resp.push({sk:m.sk,t:T+MON_RESP[0]+Math.random()*(MON_RESP[1]-MON_RESP[0])*(m.alfa?1.5:1)});
  /* recompensa de grupo: XP, oro y botín para el que mata y para los miembros de su grupo que estén en el mundo, vivos y cerca (R_REP celdas) */
  var eq={};if(por)eq[por.id]=1;
  var gq=por?gDe(por):null;if(gq)gq.miembros.forEach(function(id){var q=J[id];if(q&&q.lugar==="mundo"&&!q.mu&&Math.max(Math.abs(q.x-m.x),Math.abs(q.y-m.y))<=R_REP)eq[id]=1;});
  var msg={t:"mon_muere",id:m.id,by:por?por.id:0,x:r2(m.x),y:r2(m.y)},ids=Object.keys(eq).map(Number);if(ids.length>1)msg.eq=ids;
  jugadoresMundo().forEach(function(p){if(vista(p,m.id)||eq[p.id]){enviar(p.sock,msg);if(p._vs)delete p._vs[m.id];}});}
 function golpe(p,m){
  var tok=p._tok==null?60:p._tok,ahora=Date.now(),dt=(ahora-(p._tokT||ahora))/1000;p._tokT=ahora;tok=Math.min(60,tok+dt*60);
  if(tok<1){p._tok=tok;return false;}p._tok=tok-1;return true;}
 function num(v,min,max,def){v=Number(v);return isFinite(v)?Math.min(max,Math.max(min,v)):def;}
 function mensaje(p,m){
  if(!p||p.lugar!=="mundo")return;
  if(m.t==="mon_est"){p.mu=!!m.mu;return;}
  if(m.t!=="mon_hit"&&m.t!=="mon_fx")return;
  var mo=buscar(m.id|0);if(!mo)return;
  if(Math.max(Math.abs(mo.x-p.x),Math.abs(mo.y-p.y))>R_INT)return;
  if(mo.jefe&&mo.st===2)return;   /* el jefe que vuelve a casa es intocable */
  if(!golpe(p,mo))return;
  if(m.t==="mon_fx"){
   var st=num(m.stun,0,8,0),dd=num(m.dd,0,.9,0),he=num(m.heal,0,1e8,0);
   if(mo.jefe){
    if(st>0&&!(mo.stunImm>0)){var sj=Math.min(2,st);mo.stunT=Math.max(mo.stunT,sj);mo.stunImm=sj+4;}
    if(dd>0){mo.df0=Math.max(Math.floor(mo.dfB*.6),Math.floor(mo.df0*(1-dd*.5)));setDfJ(mo);}
    return;}
   if(st>0)mo.stunT=Math.max(mo.stunT,st);
   if(dd>0)mo.df=Math.floor(mo.df*(1-dd));
   if(he>0)mo.vida=Math.min(mo.vm,mo.vida+he);
   return;}
  /* mon_hit */
  if(m.ex){if(!mo.jefe&&mo.vida<mo.vm*.5)matar(mo,p);return;}
  var d=Math.floor(num(m.d,0,1e9,0));d=Math.min(d,mo.jefe?Math.floor(mo.vm*.06):mo.vm);
  if(mo.jefe&&mo.jd.mod&&mo.jd.mod.dr)d=Math.floor(d*(1-mo.jd.mod.dr));
  if(mo.jefe&&mo.sh>0){var ab=Math.min(mo.sh,d);mo.sh-=ab;d-=ab;}
  mo.vida-=d;
  var kx=num(m.kx,-20,20,0),ky=num(m.ky,-20,20,0),stn=num(m.stun,0,8,0);
  if(mo.jefe){
   kx*=.5;ky*=.5;if(d>0){mo.part[p.id]=1;mo.thr[p.id]=(mo.thr[p.id]||0)+d;}
   if(stn>0&&!(mo.stunImm>0)){var sj2=Math.min(2,stn);mo.stunT=Math.max(mo.stunT,sj2);mo.stunImm=sj2+4;}
   if(kx||ky){mo.kx+=kx;mo.ky+=ky;}
   if(mo.vida<=0){matar(mo,p);return;}
   if(mo.st===0){mo.st=1;mo.tgt=p.id;mo.noT=0;mo.cd=Math.max(mo.cd,.6);}
   return;}
  if(kx||ky){mo.kx+=kx;mo.ky+=ky;}
  if(stn>0)mo.stunT=Math.max(mo.stunT,stn);
  if(mo.vida<=0){matar(mo,p);return;}
  if(mo.st!==1||mo.tgt!==p.id)alerta(mo,p);
 }

 /* ---------------- entrada / salida de jugadores del mundo ---------------- */
 api.entra=function(p){
  enMundo[p.id]=1;p._vs={};p.mu=false;
  enviar(p.sock,{t:"mon_ini"});
 };
 api.sale=function(p){
  if(!p)return;delete enMundo[p.id];p._vs=null;
 };
 api.mensaje=mensaje;
 /* acceso de solo lectura para los BOTS (server/bots.js): mundo, alcance de visión y colisión del jugador */
 api.MD=MD;api.jLibre=jLibre;api.R_INT=R_INT;
 api.cuenta=function(){return mons.length;};
 setInterval(function(){try{paso20();}catch(e){log("⚠ Error en la simulación de monstruos: "+(e&&e.stack||e));}},DT*1000).unref();
 log("Monstruos del Mundo Abierto: "+mons.length+" simulados en el servidor");
 return api;
};
