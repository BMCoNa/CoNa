@echo off
cd /d "%~dp0.."
where node >nul 2>nul || (echo Instala Node.js desde nodejs.org y vuelve a abrir este archivo. & pause & exit /b)
node server\servidor.js %1
pause
