# Servidor local de Naradak (sin internet)

Requisito: Node.js 18+ en el equipo anfitrión. No hay que instalar paquetes.

1. Todos los equipos en la misma red (router, o punto de acceso/hotspot del anfitrión; no necesita internet).
2. Anfitrión: ejecutar `server/iniciar.bat` (Windows) o `sh server/iniciar.sh` (Linux/Mac). Puerto opcional: `node server/servidor.js 9000`.
3. La consola muestra las direcciones. Los jugadores abren en el navegador `http://IP_DEL_ANFITRION:8080`.
4. Si no conecta: permitir Node.js en el firewall (red privada).

- Estado: `http://IP:8080/api/estado`
- Servidor: sirve el juego, WebSocket `/ws` (presencia por lugar, posiciones, chat). Máx. 8 jugadores.
- Ciudad de Oakhaven (jugadores visibles entre sí): `http://IP:8080/tilemap/oakhaven_mapa.html?online=1` (sin `?online=1` se juega solo). Teclas: WASD/clic mover, Shift correr, E entrar/hablar, Enter chat, M minimapa, +/- zoom.
- Cada jugador guarda su partida en su propio navegador.
- EN DESARROLLO: Modo Online (cliente, `ONLINE_ACTIVO` en `js/online/online.js`) y misiones en grupo desde el Gremio (`MISIONES_GRUPO_ACTIVO` en `server/servidor.js`).
- Las fuentes Cinzel/Karla se cargan de Google solo si hay internet; sin internet se usan fuentes del sistema.

## Cuentas y partidas en el servidor
- Cada jugador crea una cuenta (usuario + contraseña) al entrar: `http://IP:8080` abre `login.html` si no hay sesión.
- **Las partidas se guardan en el servidor**, en `server/datos/` (nunca se sirve por HTTP):
  - `usuarios.json`: cuentas (contraseña con scrypt + sal, nunca en claro).
  - `jugadores/<id>.json`: partidas y ajustes (`naradak_*`) de cada usuario.
  - `secreto.key`: clave que firma las sesiones (30 días). **No la compartas**; si la borras, todos tendrán que volver a iniciar sesión.
- Haz copia de seguridad copiando la carpeta `server/datos/`.
- Cada jugador ve solo sus datos; al "Salir" (pastilla abajo a la izquierda) se vacía la copia local del dispositivo.
- Primer acceso con partidas antiguas guardadas en el navegador: el juego ofrece subirlas a la cuenta.
- Cerrar el registro de cuentas nuevas: `REGISTRO_ABIERTO=false` en `server/servidor.js`.
- Freno de fuerza bruta: 6 contraseñas erróneas por IP y usuario bloquean 10 minutos.
- API: `POST /api/registro`, `POST /api/login`, `GET/PUT /api/datos` (cabecera `Authorization: Bearer <token>`), `GET /api/yo`.
- Dos dispositivos con la misma cuenta a la vez: gana la última escritura de cada dato; recarga para ver lo del otro.

## Joystick táctil (Mundo Abierto)
- Interruptor en `server/servidor.js`: `var JOYSTICK_ACTIVO=true;` → `true` = joystick visible (Android/móvil) · `false` = oculto (PC con teclado/ratón). Reiniciar el servidor tras cambiarlo y recargar el juego.
- Sin editar el archivo: `JOYSTICK=0 node server/servidor.js` (PC) o `JOYSTICK=1 node server/servidor.js` (Android). Al arrancar la consola indica el modo; `/api/estado` incluye `joystick`.
- El joystick aparece encima y un poco a la derecha de la 5.ª habilidad. Mueve al personaje en 8 direcciones (cancela clic-para-mover y el objetivo automático, igual que WASD). Para probar en un navegador sin tocar el servidor: añade `?joystick=1` o `?joystick=0` a la URL de `tilemap/mundo_mapa.html`.

## IA de comportamientos (monstruos y jefes del Mundo Abierto)
- Módulo `tilemap/js/mundo_ia.js` (lo usan el servidor y, si simula en local, el cliente). Interruptor en `server/servidor.js`: `var IA_MUNDO_ACTIVA=true;` (o `IA=0 node server/servidor.js`). `false` = IA básica de antes. La consola indica el modo y `/api/estado` incluye `ia`.
- **Sin atascos**: los monstruos y jefes van recto si ven al objetivo y, si hay muros, árboles o ruinas de por medio, buscan camino (A*); detectan cuando no avanzan, replanifican y se despegan de las paredes. Si el objetivo es inalcanzable se rinden y vuelven a casa.
- **Tácticas por tipo**: Slime/Champiñón/Ent embisten de frente · Lobo/Bandido flanquean en abanico (la manada se reparte alrededor), dan vueltas mientras recargan y el Lobo se lanza en embestida · Araña rodea en arco y salta · Goblin/Duende golpean y se retiran. Los alfa y los merodeadores encadenan un 2.º golpe rápido (telegrafía más corta) y luego quedan expuestos; el alfa enardece a su manada (+12 % velocidad).
- **Jefes con combo**: encadenan refuerzo → control (aturdimiento) → ataque principal → remate con robo de vida (2 habilidades en fase normal, 3 al enfurecerse). Esperan a tener combo disponible, se acercan entre eslabones, rodean al objetivo mientras recargan y, al terminar el combo, hacen una pausa (ventana para contraatacar). Un aturdimiento cancela el combo.
- Ajustes (arriba de `mundo_ia.js`, objeto `CFG`): presupuesto de búsquedas, probabilidad de combo (`P_COMBO_ALFA`, `P_COMBO_MERO`), espera/pausa/velocidad de los combos de jefe (`J_ESPERA`, `J_PACIENCIA`, `J_RECUP`, `J_GAP`, `J_VENT`). Tras editar: reiniciar el servidor y Ctrl+F5 en los navegadores.

## Monstruos del Mundo Abierto en el servidor
- El servidor simula los monstruos (`server/mundo_sim.js`) y todos los jugadores ven lo mismo. Al arrancar muestra `Monstruos del Mundo Abierto: N simulados en el servidor`; `/api/estado` incluye `monstruos`.
- Si `tilemap/js/mundo_mapa.js` no tiene el marcador `SIM_FIN` o falla, el servidor lo avisa y los clientes simulan en local (sin sincronizar).
- La hora del mundo online es la del servidor (08:00 al arrancar). Reiniciar el servidor reinicia la hora y los monstruos.

## Nivel y ramas de los jefes de sector
- En `JEFES` (`tilemap/js/mundo_mapa.js`) cada jefe tiene `nivel:N` y `ramas:{...}` (las 2 ramas de su clase, en `false`).
- `nivel` sustituye al piso equivalente del sector para calcular vida, daño, defensa y XP del jefe (por defecto 3 / 5 / 7 = igual que antes). Se muestra como "Nv N" junto a su nombre.
- Pon `true` en UNA rama para que el jefe la use; solo funciona con `nivel` ≥ 50. Nv 50+ pasivos · Nv 60 Habilidad 1 de la rama · Nv 80 Habilidad 2 (como los jugadores). Si hay un error (rama inexistente, nivel < 50, varias en true) el servidor lo avisa al arrancar.
- Las habilidades de rama traducidas al formato de jefe están en `RAMA_JEFE` (mismo archivo) y se pueden retocar.
- Tras editar: reiniciar el servidor y recargar el juego en los navegadores (Ctrl+F5).

## Refuerzos de Paladín y Clérigo a los aliados (mundo abierto)
- Al lanzar, el efecto se aplica a ti y también a los miembros de tu grupo/raid que estén en el mundo a menos de 12 celdas (Pulso Vital: 6): curación (Bendición de Poderío, Pulso Vital, Luz Regeneradora, Resurgir Divino), defensa (Sentencia de Luz, Égida Radiante, Bastión), escudo, purga de aturdimiento/silencio, inmunidad a control y +% de daño (Plegaria de Pureza, Cruzada Fanática, Ascensión Radiante...).
- Mensaje nuevo `g_buff` en `server/servidor.js` (el servidor valida y limita los valores). El daño de Pulso Vital sigue siendo solo al enemigo.

## Jefes de los sectores 4 y 5
- **Sector 4: Capitán Sylas** (Arquero de la Ciudadela, sprite 83, ataca a distancia): Tiro Certero (200 % en línea), Lluvia de Flechas (140 % en área) y Paso Espectral (+30 % daño 5 s). Ramas: `Cazador` / `Francotirador`. Nivel por defecto 9.
- **Sector 5: Prelada Ysmera** (Guardiana del Santuario, sprite 85, daño mágico): Pulso Vital (110 % en área + roba vida), Égida Radiante (+25 % DEF y escudo del 5 %) y Plegaria de Pureza (+25 % daño 8 s). Ramas: `Hierofante` / `Heraldo Solar`. Nivel por defecto 11.
- Mismo botín y reaparición que los demás; se ajustan en `JEFES` (`f` = multiplicadores de vida/defensa/daño, `nivel`, `ramas`).

## Reaparición de los jefes de sector
- Todos los jefes vuelven **7 días del mundo** después de morir (`JEFE_RESP_DIAS` en `tilemap/js/mundo_mapa.js`; 1 día del mundo = 1440/5,6 ≈ 257 s reales, así que 7 días ≈ 30 min reales). Para una semana real: `JEFE_RESP=7*24*3600`. Reiniciar el servidor devuelve a todos los jefes.

## Volver a Oakhaven y relojes
- Ya no hay botones «← volver» en Oakhaven, el Mundo Abierto ni los interiores (salir por la puerta de la izquierda o con Esc). En el Claro del Mundo Abierto, el **Mensajero Doran** (junto al cartel sur; E para hablar) devuelve a Oakhaven; el cartel del sur sigue funcionando.
- Oakhaven y el Mundo Abierto usan el mismo reloj del servidor (🌐 en el HUD).

## Sectores 6, 7 y 8 (mapa) y sus jefes
| Sector | Zona (cuadrícula) | Nombre | Jefe (sprite · clase) | Nivel |
|---|---|---|---|---|
| 6 | col 0, fila 3 (bajo el Sector 5) | Cantera de los Gigantes Caídos | Acechadora Nyssa (73 · Asesino) · ramas Ninja / Sicario | 13 |
| 7 | col 1, fila 2 (entre 4 y 5) | Catedral Hundida | Inquisidor Aurelian (74 · Paladín) · ramas Inquisidor / Guardián | 15 |
| 8 | col 2, fila 1 (entre 3 y 4) | Bastión de los Reyes Olvidados | Rey Caído Valdemar (72 · Guerrero) · ramas Berserker / Ejecutor | 17 |
- Dificultad creciente (pe 13/15/17, vida ×2.85/3.1/3.35, daño ×2.4/2.6/2.8); se ajusta en `defSec` y en `JEFES` (`f`, `nivel`, `ramas`).
- Estructuras centrales nuevas (`cantera`, `catedral`, `bastion`) en `generar()`. Los sectores existentes conservan su diseño, pero al añadir sectores cambia la semilla aleatoria: el detalle de árboles/ruinas y la posición de las zonas de jefe de todo el mundo se regeneran.

## Bots aventureros (uno por clase)
- Módulo `server/bots.js` (cargado por `servidor.js`). Seis bots —**Brannoch** (Guerrero), **Elyndra** (Mago), **Faelan** (Arquero), **Aldous** (Paladín), **Vexara** (Asesino) y **Seraphel** (Clérigo)— entran como jugadores normales: aparecen en Oakhaven (nivel 1), se les puede invitar a grupo, susurrar, etc. **No ocupan plaza** de `MAX_JUGADORES`. Se desactivan con `BOTS_ACTIVOS=false` en `server/servidor.js` o `BOTS=0 node server/servidor.js`.
- **Usan las reglas reales del juego**: el servidor carga `js/data`, `js/core` y `js/sistemas` en un sandbox (stats, XP, loot, tienda, talentos, pociones, defensa/crítico de monstruos…). Cada bot es un personaje normal; su progreso se guarda en `server/datos/bots.json` (cada 45 s y al cerrar). Para reiniciarlos a nivel 1 borra ese archivo.
- **Ciclo de vida**: pasean por la plaza → Tienda (venden materiales y equipo viejo, compran pociones y la mejora de equipo que pueden pagar según su nivel) → hablan con el General Varek → Mundo Abierto. Allí eligen el sector que su personaje aguanta (cálculo de riesgo con sus stats reales; si mueren, se vuelven más prudentes), cazan con ataque básico + habilidades (y las de rama), esquivan telegrafías, usan pociones, huyen a curarse al campamento, mueren/reaparecen con 50 % de vida y vuelven por el Mensajero Doran a vender y comprar. Al Nv 50 eligen rama y gastan las almas en los talentos en orden.
- **Grupo**: aceptan la invitación (con una pequeña pausa y un saludo en el chat). En grupo te siguen entre Oakhaven y el Mundo Abierto, pelean junto a ti (cuerpo a cuerpo cerca, a distancia detrás; Clérigo y Paladín curan/refuerzan al grupo con `g_buff`) y reciben XP, oro y botín como cualquier miembro (también el botín de jefes). Un grupo admite 5 (tú + 4 bots); conviértelo en raid para más.
- **Órdenes** (chat o susurro; en grupo basta con escribirlas, fuera de grupo menciona su nombre): `seguir` · `quieto` · `atacar` · `ciudad` (vuelven a Oakhaven) · `salir` (abandonan el grupo) · `estado` · `hola`. Rechazan comerciar (te lo dicen por susurro).
- **Límites**: no entran al Laberinto (lo simula el cliente); si estás allí, esperan en Oakhaven.
- **Ajustes** (objeto `CFG` al inicio de `server/bots.js`): nombre, clase, **nivel inicial** y **rama** de cada bot (`nivel` solo se aplica al crearlos, salvo `forzar:true`), avatar, tiempos en ciudad y de caza (`T_CIUDAD`, `T_SALIDA`), prudencia (`RIESGO`), `PAUSAR_SIN_JUGADORES` (true = quietos si no hay nadie conectado), `ACEPTA_GRUPO`, `RESPONDE_CHAT`. Tras editar: reiniciar el servidor.
- Estado en vivo: `http://IP:8080/api/bots` (nivel, lugar, actividad, vida, oro, bajas…). `/api/estado` incluye `bots`.
