"use strict";
/* THE CHRONICLES OF NARADAK — servidor local (sin internet, sin dependencias)
   Uso:  node server/servidor.js   [puerto]      (por defecto 8080)
   - Sirve el juego (index.html, js/, css/, tilemap/, assets/) por HTTP en la red local.
   - WebSocket en /ws: jugadores conectados, presencia por lugar (pueblo, gremio...), posiciones y chat.
   - Misiones en grupo: EN DESARROLLO (flag MISIONES_GRUPO_ACTIVO).
   - CUENTAS: usuario + contraseña (scrypt). Las partidas se guardan EN EL SERVIDOR (server/datos/), una por usuario. */
var http=require("http"),fs=require("fs"),path=require("path"),crypto=require("crypto"),os=require("os");

var PUERTO=parseInt(process.argv[2]||process.env.PORT||"8080",10);
var RAIZ=path.resolve(__dirname,"..");
var MAX_JUGADORES=20;
var MISIONES_GRUPO_ACTIVO=false;   /* en desarrollo */
/* IA de comportamientos de monstruos y jefes del Mundo Abierto (tilemap/js/mundo_ia.js): true = navegación sin atascos, tácticas y combos · false = IA básica.
   También:  IA=0 node server/servidor.js */
var IA_MUNDO_ACTIVA=true;
if(process.env.IA==="0"||process.env.IA==="1")IA_MUNDO_ACTIVA=process.env.IA==="1";
/* Joystick táctil en el Mundo Abierto: true = Android/móvil · false = PC (teclado/ratón).
   También se puede fijar al arrancar sin editar nada:  JOYSTICK=0 node server/servidor.js   (o JOYSTICK=1) */
var JOYSTICK_ACTIVO=true;
if(process.env.JOYSTICK==="0"||process.env.JOYSTICK==="1")JOYSTICK_ACTIVO=process.env.JOYSTICK==="1";
var LUGARES=["pueblo","oakhaven","laberinto","gremio","tienda","herreria","hospital","alquimia","taberna","castillo","entrenamiento","muelle","mundo"];
var INICIO=Date.now();   /* instante de arranque: origen del reloj de mundo compartido (NPCs sincronizados) */
var MAX_MSG=65536, MIN_MOVER_MS=40, MAX_CHAT=200;

var MIME={".html":"text/html; charset=utf-8",".js":"application/javascript; charset=utf-8",".css":"text/css; charset=utf-8",".json":"application/json; charset=utf-8",".png":"image/png",".jpg":"image/jpeg",".jpeg":"image/jpeg",".gif":"image/gif",".webp":"image/webp",".svg":"image/svg+xml",".mp3":"audio/mpeg",".ogg":"audio/ogg",".wav":"audio/wav",".ico":"image/x-icon",".txt":"text/plain; charset=utf-8",".woff":"font/woff",".woff2":"font/woff2",".ttf":"font/ttf"};

/* ---------------- Cuentas y datos de jugador (guardado en el servidor) ---------------- */
var DATOS=path.join(__dirname,"datos"),F_USU=path.join(DATOS,"usuarios.json"),D_JUG=path.join(DATOS,"jugadores"),F_SEC=path.join(DATOS,"secreto.key");
var REGISTRO_ABIERTO=true;          /* false = nadie nuevo puede crear cuenta */
var MIN_CLAVE=4;                   /* longitud mínima de contraseña al crear la cuenta */
var MAX_USUARIOS=500,TOKEN_DIAS=30,MAX_BODY=4*1024*1024,MAX_VALOR=1024*1024,MAX_CLAVES=64,MAX_TOTAL=8*1024*1024;
var RE_USU=/^[^\u0000-\u001f\u007f<>]{1,32}$/,RE_KEY=/^naradak_[A-Za-z0-9_]{1,48}$/;
fs.mkdirSync(D_JUG,{recursive:true});
function escribirAtomico(f,txt){var t=f+"."+process.pid+".tmp";fs.writeFileSync(t,txt);fs.renameSync(t,f);}
function leerJSON(f,def){try{return JSON.parse(fs.readFileSync(f,"utf8"));}catch(e){return def;}}
var SECRETO;try{SECRETO=Buffer.from(fs.readFileSync(F_SEC,"utf8").trim(),"hex");if(SECRETO.length<32)throw 0;}catch(e){SECRETO=crypto.randomBytes(32);fs.writeFileSync(F_SEC,SECRETO.toString("hex"),{mode:0o600});}
var usuarios=leerJSON(F_USU,{});                       /* id -> {nombre,sal,hash,pv,creado} */
var cacheDatos={};                                      /* id -> {claves:{},act} */
function idDe(nombre){return crypto.createHash("sha256").update(String(nombre).toLowerCase()).digest("hex").slice(0,24);}
function b64u(b){return Buffer.from(b).toString("base64").replace(/\+/g,"-").replace(/\//g,"_").replace(/=+$/,"");}
function firmar(s){return b64u(crypto.createHmac("sha256",SECRETO).update(s).digest());}
function crearToken(id,sid){var u=usuarios[id],p=b64u(JSON.stringify({i:id,pv:u.pv,s:sid||"",exp:Date.now()+TOKEN_DIAS*864e5}));return p+"."+firmar(p);}
function verToken(t){
 if(typeof t!=="string"||t.length>600)return null;
 var a=t.split(".");if(a.length!==2)return null;
 var ok=firmar(a[0]),x=Buffer.from(ok),y=Buffer.from(a[1]);
 if(x.length!==y.length||!crypto.timingSafeEqual(x,y))return null;
 var p;try{p=JSON.parse(Buffer.from(a[0].replace(/-/g,"+").replace(/_/g,"/"),"base64").toString("utf8"));}catch(e){return null;}
 var u=p&&usuarios[p.i];if(!u||u.pv!==p.pv||!(p.exp>Date.now()))return null;
 return {id:p.i,s:String(p.s||"")};
}
/* ---- Sesión única por cuenta ----
   Una cuenta solo puede tener UNA sesión activa. La sesión se mantiene viva con cualquier llamada a la API
   (el cliente envía un latido cada 15 s) o con la conexión online. Si pasan SESION_MS sin señales, se considera cerrada.
   Mientras haya una sesión activa, un nuevo inicio de sesión con esa cuenta se rechaza. */
var SESION_MS=90000;
var sesiones={};                                         /* id -> {sid, ult} (en memoria) */
function sesionActiva(id){var s=sesiones[id];return !!s&&Date.now()-s.ult<SESION_MS;}
function sesionOk(id,sid){   /* ¿esta sesión (sid) es la vigente de la cuenta? Si lo es (o la vigente caducó), la marca viva */
 var s=sesiones[id],n=Date.now();
 if(!s||s.sid===sid||n-s.ult>=SESION_MS){sesiones[id]={sid:sid,ult:n};return true;}
 return false;
}
function autenticar(req){var t=verToken(tokenDe(req));return t&&sesionOk(t.id,t.s)?t.id:null;}
function hashClave(clave,sal){return new Promise(function(ok,ko){crypto.scrypt(String(clave),sal,32,function(e,k){e?ko(e):ok(k);});});}
function guardarUsuarios(){escribirAtomico(F_USU,JSON.stringify(usuarios));}
function datosDe(id){
 if(cacheDatos[id])return cacheDatos[id];
 var d=leerJSON(path.join(D_JUG,id+".json"),null);
 if(!d||typeof d.claves!=="object"||!d.claves)d={claves:{},act:0};
 return (cacheDatos[id]=d);
}
function guardarDatos(id){var d=datosDe(id);d.act=Date.now();escribirAtomico(path.join(D_JUG,id+".json"),JSON.stringify(d));indexarPJ(id);}
/* ---- Nombres de personaje únicos (sin distinguir mayúsculas, tildes ni espacios repetidos) ----
   El índice se deduce de las partidas guardadas (naradak_slot_N de cada cuenta): al borrar o sobrescribir un personaje el nombre queda libre.
   Antes de crear un personaje el cliente lo reserva (10 min) con POST /api/personaje. */
var RE_PJ=/^[^\u0000-\u001f\u007f<>]{1,16}$/,RESERVA_MS=600000;
var indicePJ={},reservasPJ={};                           /* nombre normalizado -> cuenta */
function normPJ(n){return String(n).replace(/\s+/g," ").trim().normalize("NFD").replace(/[\u0300-\u036f]/g,"").toLowerCase();}
function indexarPJ(id){
 var k,d=datosDe(id);
 for(k in indicePJ)if(indicePJ[k]===id)delete indicePJ[k];
 for(k in d.claves){
  if(!/^naradak_slot_\d+$/.test(k))continue;
  try{var j=JSON.parse(d.claves[k]),nm=j&&typeof j.nombre==="string"?normPJ(j.nombre):"";
   if(nm){if(!indicePJ[nm])indicePJ[nm]=id;else if(indicePJ[nm]!==id)log("⚠ Nombre de personaje repetido entre cuentas: "+j.nombre);}}catch(e){}
 }
 for(k in reservasPJ)if(reservasPJ[k].c===id&&indicePJ[k]===id)delete reservasPJ[k];
}
function nombrePJOcupado(kn,id){
 if(indicePJ[kn])return true;                             /* ya lo tiene un personaje (de esta u otra cuenta) */
 var r=reservasPJ[kn];
 return !!r&&r.c!==id&&Date.now()-r.t<RESERVA_MS;         /* reservado por otra cuenta */
}
setInterval(function(){var n=Date.now();for(var k in reservasPJ)if(n-reservasPJ[k].t>=RESERVA_MS)delete reservasPJ[k];},60000).unref();
Object.keys(usuarios).forEach(function(id){try{indexarPJ(id);}catch(e){}});   /* personajes que ya existen */
/* Freno a fuerza bruta: 6 fallos en 10 min por (IP, usuario) */
var fallos={};
function bloqueado(k){var f=fallos[k];return !!f&&f.n>=6&&Date.now()<f.hasta;}
function falla(k){var f=fallos[k];if(!f||Date.now()>f.hasta)f=fallos[k]={n:0,hasta:Date.now()+600000};f.n++;}
setInterval(function(){var n=Date.now();for(var k in fallos)if(n>fallos[k].hasta)delete fallos[k];},600000).unref();

function cors(res){res.setHeader("Access-Control-Allow-Origin","*");res.setHeader("Access-Control-Allow-Headers","Authorization, Content-Type");res.setHeader("Access-Control-Allow-Methods","GET, POST, PUT, OPTIONS");res.setHeader("Access-Control-Max-Age","600");}
function enviarJSON(res,code,obj){res.writeHead(code,{"Content-Type":MIME[".json"],"Cache-Control":"no-store"});res.end(JSON.stringify(obj));}
function leerCuerpo(req,cb){
 var n=0,ch=[],fin=false;
 req.on("data",function(c){if(fin)return;n+=c.length;if(n>MAX_BODY){fin=true;cb(new Error("grande"));req.destroy();return;}ch.push(c);});
 req.on("end",function(){if(fin)return;fin=true;try{cb(null,JSON.parse(Buffer.concat(ch).toString("utf8")||"{}"));}catch(e){cb(new Error("json"));}});
 req.on("error",function(){if(!fin){fin=true;cb(new Error("red"));}});
}
function tokenDe(req){
 var h=req.headers.authorization||"",m=/^Bearer\s+(\S+)$/i.exec(h);if(m)return m[1];
 try{return new URL(req.url,"http://x").searchParams.get("t")||"";}catch(e){return "";}
}
function ipDe(req){return (req.socket&&req.socket.remoteAddress)||"?";}

function api(req,res,u){
 cors(res);
 if(req.method==="OPTIONS"){res.writeHead(204);return res.end();}
 if(u==="/api/estado")return enviarJSON(res,200,estado());
 if(u==="/api/bots")return enviarJSON(res,200,{activo:BOTS_ACTIVOS,bots:BOTS.resumen()});   /* estado de los bots aventureros */
 if(u==="/api/registro"||u==="/api/login"){
  if(req.method!=="POST")return enviarJSON(res,405,{error:"Método no permitido"});
  return leerCuerpo(req,function(err,b){
   if(err||!b)return enviarJSON(res,400,{error:"Petición no válida"});
   var nombre=String(b.usuario==null?"":b.usuario).trim(),clave=String(b.clave==null?"":b.clave);
   if(!RE_USU.test(nombre))return enviarJSON(res,400,{error:"Escribe un nombre de usuario (hasta 32 caracteres)."});
   if(clave.length<1||clave.length>1024)return enviarJSON(res,400,{error:"Escribe una contraseña."});
   var id=idDe(nombre),fk=ipDe(req)+"|"+id;
   if(bloqueado(fk))return enviarJSON(res,429,{error:"Demasiados intentos fallidos. Espera unos minutos."});
   if(u==="/api/registro"){
    if(!REGISTRO_ABIERTO)return enviarJSON(res,403,{error:"El registro de cuentas está cerrado en este servidor."});
    if(clave.length<MIN_CLAVE)return enviarJSON(res,400,{error:"La contraseña debe tener al menos "+MIN_CLAVE+" caracteres."});
    if(usuarios[id])return enviarJSON(res,409,{error:"El nombre de usuario ya existe, prueba con otro."});
    if(Object.keys(usuarios).length>=MAX_USUARIOS)return enviarJSON(res,403,{error:"Se alcanzó el máximo de cuentas."});
    var sal=crypto.randomBytes(16);
    return hashClave(clave,sal).then(function(h){
     if(usuarios[id])return enviarJSON(res,409,{error:"El nombre de usuario ya existe, prueba con otro."});
     usuarios[id]={nombre:nombre,sal:sal.toString("hex"),hash:h.toString("hex"),pv:crypto.randomBytes(6).toString("hex"),creado:Date.now()};
     guardarUsuarios();log("★ Cuenta creada: "+nombre);
     var sid0=crypto.randomBytes(6).toString("hex");sesiones[id]={sid:sid0,ult:Date.now()};
     enviarJSON(res,200,{ok:true,usuario:nombre,token:crearToken(id,sid0),nuevo:true});
    }).catch(function(){enviarJSON(res,500,{error:"Error interno"});});
   }
   var us=usuarios[id];
   var salB=Buffer.from(us?us.sal:"00".repeat(16),"hex");   /* mismo coste exista o no el usuario */
   return hashClave(clave,salB).then(function(h){
    var bien=us&&crypto.timingSafeEqual(h,Buffer.from(us.hash,"hex"));
    if(!bien){falla(fk);return enviarJSON(res,401,{error:"Usuario o contraseña incorrectos."});}
    delete fallos[fk];
    if(sesionActiva(id))return enviarJSON(res,409,{error:"Esta cuenta ya tiene una sesión abierta en otro dispositivo o ventana. Ciérrala (botón Salir) o espera un par de minutos e inténtalo de nuevo."});
    var sid=crypto.randomBytes(6).toString("hex");sesiones[id]={sid:sid,ult:Date.now()};
    log("→ Login: "+us.nombre);
    enviarJSON(res,200,{ok:true,usuario:us.nombre,token:crearToken(id,sid)});
   }).catch(function(){enviarJSON(res,500,{error:"Error interno"});});
  });
 }
 if(u==="/api/salir"){   /* cierra la sesión: libera la cuenta para volver a entrar desde otro sitio */
  var ts=verToken(tokenDe(req));
  if(ts&&sesiones[ts.id]&&sesiones[ts.id].sid===ts.s)delete sesiones[ts.id];
  return enviarJSON(res,200,{ok:true});
 }
 if(u==="/api/personaje"){   /* comprueba y reserva un nombre de personaje (único en todo el servidor) */
  if(req.method!=="POST")return enviarJSON(res,405,{error:"Método no permitido"});
  var idp=autenticar(req);
  if(!idp)return enviarJSON(res,401,{error:"Sesión no válida, caducada o abierta en otro dispositivo."});
  return leerCuerpo(req,function(err,b){
   if(err||!b)return enviarJSON(res,400,{error:"Petición no válida"});
   var nm=String(b.nombre==null?"":b.nombre).replace(/\s+/g," ").trim();
   if(!RE_PJ.test(nm))return enviarJSON(res,400,{error:"Escribe un nombre para tu héroe (hasta 16 caracteres)."});
   var kn=normPJ(nm);
   if(nombrePJOcupado(kn,idp))return enviarJSON(res,409,{error:"El nombre de personaje ya existe, prueba con otro."});
   reservasPJ[kn]={c:idp,t:Date.now()};
   enviarJSON(res,200,{ok:true,nombre:nm});
  });
 }
 if(u==="/api/datos"||u==="/api/yo"){
  var id=autenticar(req);
  if(!id)return enviarJSON(res,401,{error:"Sesión no válida, caducada o abierta en otro dispositivo."});
  if(u==="/api/yo")return enviarJSON(res,200,{ok:true,usuario:usuarios[id].nombre});
  if(req.method==="GET")return enviarJSON(res,200,{ok:true,usuario:usuarios[id].nombre,claves:datosDe(id).claves});
  if(req.method!=="PUT"&&req.method!=="POST")return enviarJSON(res,405,{error:"Método no permitido"});
  return leerCuerpo(req,function(err,b){
   if(err||!b||typeof b!=="object")return enviarJSON(res,400,{error:"Petición no válida"});
   var d=datosDe(id),set=b.set&&typeof b.set==="object"?b.set:{},del=Array.isArray(b.del)?b.del:[];
   var nuevo=Object.assign({},d.claves),k;
   for(k in set){if(!RE_KEY.test(k)||typeof set[k]!=="string"||set[k].length>MAX_VALOR)return enviarJSON(res,400,{error:"Clave o valor no válido: "+limpiaTxt(k,30)});nuevo[k]=set[k];}
   del.forEach(function(x){if(typeof x==="string"&&RE_KEY.test(x))delete nuevo[x];});
   var tot=0,nk=0;for(k in nuevo){tot+=k.length+nuevo[k].length;nk++;}
   if(nk>MAX_CLAVES||tot>MAX_TOTAL)return enviarJSON(res,413,{error:"Datos de la cuenta demasiado grandes."});
   d.claves=nuevo;
   try{guardarDatos(id);}catch(e){return enviarJSON(res,500,{error:"No se pudo guardar en el servidor."});}
   enviarJSON(res,200,{ok:true});
  });
 }
 enviarJSON(res,404,{error:"No encontrado"});
}
function cierreLimpio(){try{guardarUsuarios();}catch(e){}try{BOTS.guardar();}catch(e){}process.exit(0);}
process.on("SIGINT",cierreLimpio);process.on("SIGTERM",cierreLimpio);

/* ---------------- HTTP estático ---------------- */
function cuentaReales(){var n=0;for(var id in jugadores)if(!jugadores[id].bot)n++;return n;}   /* los bots no ocupan plaza */
function estado(){return {juego:"Naradak",jugadores:cuentaReales(),bots:BOTS.cuenta(),max:MAX_JUGADORES,misionesGrupo:MISIONES_GRUPO_ACTIVO,joystick:JOYSTICK_ACTIVO,ia:IA_MUNDO_ACTIVA,cuentas:true,registro:REGISTRO_ABIERTO,registroUrl:"/registro",minClave:MIN_CLAVE,monstruos:SIMMUNDO.cuenta()};}
var servidor=http.createServer(function(req,res){
 var u;try{u=decodeURIComponent(req.url.split("?")[0]);}catch(e){res.writeHead(400);return res.end("Bad request");}
 if(u.indexOf("/api/")===0)return api(req,res,u);
 if(u==="/")u="/index.html";
 else if(u==="/registro"||u==="/registro/")u="/registro.html";   /* alta de cuentas: siempre en el navegador, nunca en el cliente */
 var f=path.normalize(path.join(RAIZ,u));
 var rel=path.relative(RAIZ,f);
 if(rel.indexOf("..")===0||path.isAbsolute(rel)||/^(server|\.)/.test(rel.split(path.sep)[0])){res.writeHead(403);return res.end("Prohibido");}
 fs.stat(f,function(err,st){
  if(err||!st.isFile()){res.writeHead(404);return res.end("No encontrado");}
  var cab={"Content-Type":MIME[path.extname(f).toLowerCase()]||"application/octet-stream","Accept-Ranges":"bytes","Cache-Control":"no-cache"};
  var rg=/^bytes=(\d*)-(\d*)$/.exec(req.headers.range||"");   /* audio/vídeo: Safari y WebView exigen soporte Range (206) */
  if(rg&&(rg[1]||rg[2])){
   var a=rg[1]?parseInt(rg[1],10):Math.max(0,st.size-parseInt(rg[2],10)),b=(rg[1]&&rg[2])?Math.min(parseInt(rg[2],10),st.size-1):st.size-1;
   if(a>b||a>=st.size){cab["Content-Range"]="bytes */"+st.size;res.writeHead(416,cab);return res.end();}
   cab["Content-Range"]="bytes "+a+"-"+b+"/"+st.size;cab["Content-Length"]=b-a+1;
   res.writeHead(206,cab);
   if(req.method==="HEAD")return res.end();
   var s206=fs.createReadStream(f,{start:a,end:b});s206.on("error",function(){res.destroy();});return s206.pipe(res);
  }
  cab["Content-Length"]=st.size;
  res.writeHead(200,cab);
  if(req.method==="HEAD")return res.end();
  var s200=fs.createReadStream(f);s200.on("error",function(){res.destroy();});
  s200.pipe(res);
 });
});

/* ---------------- WebSocket mínimo (RFC 6455) ---------------- */
var GUID="258EAFA5-E914-47DA-95CA-C5AB0DC85B11";
function wsEnviar(sock,obj){
 if(sock.bot){try{sock.bot(obj);}catch(e){}return;}   /* BOT del servidor (server/bots.js): recibe el mensaje directamente */
 if(sock.destroyed)return;
 var d=Buffer.from(JSON.stringify(obj)),n=d.length,h;
 if(n<126){h=Buffer.from([0x81,n]);}
 else if(n<65536){h=Buffer.alloc(4);h[0]=0x81;h[1]=126;h.writeUInt16BE(n,2);}
 else{h=Buffer.alloc(10);h[0]=0x81;h[1]=127;h.writeBigUInt64BE(BigInt(n),2);}
 try{sock.write(Buffer.concat([h,d]));}catch(e){}
}
function wsCtrl(sock,op,payload){if(sock.destroyed)return;var p=payload||Buffer.alloc(0);try{sock.write(Buffer.concat([Buffer.from([0x80|op,p.length]),p]));}catch(e){}}
/* Devuelve mensajes de texto completos; maneja fragmentación, ping, pong y cierre */
function wsLeer(sock,chunk,onTexto,onCerrar){
 sock._b=Buffer.concat([sock._b||Buffer.alloc(0),chunk]);
 while(true){
  var b=sock._b;if(b.length<2)return;
  var fin=(b[0]&0x80)!==0,op=b[0]&0x0f,masc=(b[1]&0x80)!==0,len=b[1]&0x7f,o=2;
  if(len===126){if(b.length<4)return;len=b.readUInt16BE(2);o=4;}
  else if(len===127){if(b.length<10)return;var big=b.readBigUInt64BE(2);if(big>BigInt(MAX_MSG)){onCerrar(1009);return;}len=Number(big);o=10;}
  if(len>MAX_MSG){onCerrar(1009);return;}
  if(!masc){onCerrar(1002);return;}
  if(b.length<o+4+len)return;
  var mk=b.slice(o,o+4),p=Buffer.from(b.slice(o+4,o+4+len));
  for(var i=0;i<p.length;i++)p[i]^=mk[i&3];
  sock._b=b.slice(o+4+len);
  if(op===0x8){onCerrar(1000);return;}
  if(op===0x9){wsCtrl(sock,0xA,p);continue;}
  if(op===0xA){sock._vivo=true;continue;}
  if(op===0x1||op===0x0){
   if(op===0x1)sock._frag=[];
   if(!sock._frag)sock._frag=[];
   sock._frag.push(p);
   if(sock._frag.reduce(function(a,x){return a+x.length;},0)>MAX_MSG){onCerrar(1009);return;}
   if(fin){var t=Buffer.concat(sock._frag).toString("utf8");sock._frag=null;onTexto(t);}
  }
 }
}

/* ---------------- Grupos, raids, comercio y laberinto de grupo ---------------- */
var MAX_GRUPO=5, MAX_RAID=MAX_JUGADORES;   /* un grupo admite 5; el líder puede convertirlo en raid (hasta MAX_JUGADORES) */
var grupos={},sigGrupo=1,invGrupo={},invCom={};

/* ---------------- Jugadores y lugares ---------------- */
var jugadores={},sigId=1;
function limpiaTxt(s,n){return String(s==null?"":s).replace(/[\u0000-\u001f<>]/g,"").slice(0,n);}
function num(v,min,max,def){v=Number(v);return isFinite(v)?Math.min(max,Math.max(min,v)):def;}
function pub(p){return {id:p.id,nombre:p.nombre,clase:p.clase,nivel:p.nivel,avatar:p.avatar,lugar:p.lugar,x:p.x,y:p.y,dir:p.dir};}
function aTodos(obj,excepto,lugar){for(var id in jugadores){var p=jugadores[id];if(p.id===excepto)continue;if(lugar&&p.lugar!==lugar)continue;wsEnviar(p.sock,obj);}}
function salir(p){if(!p||!jugadores[p.id])return;try{SIMMUNDO.sale(p);}catch(e){}try{if(p.com)cCerrar(p.com,"desconectado",p.id);gSalir(p,"desconectado");}catch(e){}delete invGrupo[p.id];delete invCom[p.id];delete jugadores[p.id];aTodos({t:"sale",id:p.id},p.id);log("− "+p.nombre+" salió ("+cuentaReales()+"/"+MAX_JUGADORES+")");}
function log(s){console.log("["+new Date().toLocaleTimeString()+"] "+s);}
function aviso(p,msg){if(p)wsEnviar(p.sock,{t:"g_aviso",msg:msg});}
/* Simulación de los monstruos del Mundo Abierto en el servidor (el servidor es el anfitrión; ver server/mundo_sim.js) */
var SIMMUNDO=require("./mundo_sim.js")({jugadores:jugadores,wsEnviar:wsEnviar,INICIO:INICIO,RAIZ:RAIZ,log:log,gDe:gDe,iaActiva:IA_MUNDO_ACTIVA});
function gDe(p){return p&&p.grupo?grupos[p.grupo]||null:null;}
/* ---------------- BOTS (server/bots.js): 6 aventureros controlados por el servidor, uno por clase ----------------
   Entran como un jugador más (misma lista, mismo protocolo) pero sin conexión de red. */
var BOTS_ACTIVOS=true;                       /* false = no se crea ningún bot.   También:  BOTS=0 node server/servidor.js */
if(process.env.BOTS==="0"||process.env.BOTS==="1")BOTS_ACTIVOS=process.env.BOTS==="1";
function crearJugadorBot(d){
 var sock={bot:d.recibe,destroyed:false,_vivo:true,write:function(){},end:function(){},destroy:function(){}};
 var p={id:sigId++,sock:sock,nombre:limpiaTxt(d.nombre,20),clase:limpiaTxt(d.clase,20),nivel:num(d.nivel,1,100,1)|0,avatar:num(d.avatar,0,9999,0)|0,lugar:LUGARES.indexOf(d.lugar)>=0?d.lugar:"oakhaven",x:num(d.x,-9999,9999,0),y:num(d.y,-9999,9999,0),dir:"s",ult:0,cuenta:null,sid:"",vistoUlt:Date.now(),grupo:0,com:null,hp:0,hpMax:0,mp:0,mpMax:0,rn:"",act:true,ultInfo:0,ultEv:{},bot:true};
 sock._p=p;jugadores[p.id]=p;
 aTodos({t:"entra",jugador:pub(p)},p.id);
 if(p.lugar==="mundo")SIMMUNDO.entra(p);
 var nk=normPJ(p.nombre);if(nk&&!indicePJ[nk])indicePJ[nk]="__bot__";   /* el nombre del bot queda reservado: ningún jugador puede crear un héroe con ese nombre */
 return p;
}
var BOTS=require("./bots.js")({activo:BOTS_ACTIVOS,jugadores:jugadores,crearJugadorBot:crearJugadorBot,mensaje:mensaje,SIMMUNDO:SIMMUNDO,RAIZ:RAIZ,DATOS:DATOS,log:log,gDe:gDe,grupos:grupos,INICIO:INICIO});
function gCap(g){return g.raid?MAX_RAID:MAX_GRUPO;}
function gPub(g){
 return {id:g.id,lider:g.lider,raid:g.raid,max:gCap(g),
  miembros:g.miembros.map(function(id){var q=jugadores[id];return q?{id:q.id,nombre:q.nombre,clase:q.clase,nivel:q.nivel,hp:q.hp,hpMax:q.hpMax,mp:q.mp,mpMax:q.mpMax,rn:q.rn,act:q.act,lugar:q.lugar}:null;}).filter(Boolean),
  lab:g.lab?{host:g.lab.host,en:g.lab.en.slice(),seed:g.lab.seed}:null};
}
function aGrupo(g,obj,excepto){g.miembros.forEach(function(id){var q=jugadores[id];if(q&&id!==excepto)wsEnviar(q.sock,obj);});}
function gEnviar(g){aGrupo(g,{t:"g_estado",grupo:gPub(g)});}
/* Laberinto de grupo: instancia propia del grupo. host = quien simula a los enemigos */
function labQuitar(g,p){
 if(!g||!g.lab)return;
 var i=g.lab.en.indexOf(p.id);if(i<0)return;
 g.lab.en.splice(i,1);
 if(!g.lab.en.length){g.lab=null;return;}
 if(g.lab.host===p.id){
  g.lab.host=g.lab.en[0];
  g.lab.en.forEach(function(id){var q=jugadores[id];if(q)wsEnviar(q.sock,{t:"lab_host",id:g.lab.host});});
 }
}
function gSalir(p,motivo){
 var g=gDe(p);if(!g)return;
 labQuitar(g,p);
 g.miembros=g.miembros.filter(function(id){return id!==p.id;});p.grupo=0;
 if(jugadores[p.id])wsEnviar(p.sock,{t:"g_estado",grupo:null,motivo:motivo||"salir"});
 if(g.miembros.length<=1){
  g.miembros.forEach(function(id){var q=jugadores[id];if(q){q.grupo=0;wsEnviar(q.sock,{t:"g_estado",grupo:null,motivo:"disuelto"});}});
  delete grupos[g.id];
 }else{
  if(g.lider===p.id)g.lider=g.miembros[0];
  aGrupo(g,{t:"g_aviso",msg:p.nombre+(motivo==="expulsado"?" fue expulsado del grupo.":" abandonó el grupo.")});
  gEnviar(g);
 }
 log("Grupo: "+p.nombre+" sale ("+(motivo||"salir")+")");
}
/* Comercio entre dos jugadores (oro + objetos del inventario) */
/* Equipo de la bolsa que se ofrece en un comercio (p. ej. el botín de un jefe): solo campos conocidos, con límites */
function eqLimpio(it){
 if(!it||typeof it!=="object")return null;var nm=limpiaTxt(it.n,60);if(!nm)return null;var c={n:nm};
 ["tipo","clase","slot","rareza"].forEach(function(k){if(it[k]!=null)c[k]=limpiaTxt(it[k],20);});
 ["atk","def","vida","recurso","nivel","precio","oro","mejora"].forEach(function(k){if(it[k]!=null)c[k]=Math.floor(num(it[k],0,1e9,0));});
 if(it.attr&&typeof it.attr==="object"){c.attr={};["fue","agi","int","per","eva","enf"].forEach(function(k){if(it.attr[k]!=null)c.attr[k]=Math.floor(num(it.attr[k],0,1e6,0));});}
 return c;
}
function ofertaLimpia(o){
 var r={oro:0,items:{},eq:[]},n=0;if(!o||typeof o!=="object")return r;
 if(Array.isArray(o.eq))o.eq.slice(0,12).forEach(function(it){var c=eqLimpio(it);if(c)r.eq.push(c);});
 r.oro=Math.floor(num(o.oro,0,1e9,0));
 if(o.items&&typeof o.items==="object")for(var k in o.items){if(n>=30)break;var nm=limpiaTxt(k,40),c=Math.floor(num(o.items[k],0,9999,0));if(nm&&c>0){r.items[nm]=c;n++;}}
 return r;
}
function cEstado(tr){
 [tr.a,tr.b].forEach(function(id){var q=jugadores[id];if(!q)return;var otro=id===tr.a?tr.b:tr.a;
  wsEnviar(q.sock,{t:"c_estado",con:otro,mia:tr.of[id],suya:tr.of[otro],okMia:!!tr.ok[id],okSuya:!!tr.ok[otro]});});
}
function cCerrar(tr,motivo,quien){
 [tr.a,tr.b].forEach(function(id){var q=jugadores[id];if(q){q.com=null;if(id!==quien)wsEnviar(q.sock,{t:"c_cancelado",motivo:motivo||"cancelado"});}});
}

function mensaje(sock,txt){
 var m;try{m=JSON.parse(txt);}catch(e){return;}
 if(!m||typeof m.t!=="string")return;
 var p=sock._p;
 if(p){p.vistoUlt=Date.now();var ss=sesiones[p.cuenta];if(ss&&ss.sid===p.sid)ss.ult=p.vistoUlt;}   /* la conexión online mantiene viva la sesión */
 if(m.t==="ping"){wsEnviar(sock,{t:"pong"});return;}
 if(m.t==="reloj"){wsEnviar(sock,{t:"reloj",c:m.c,ahora:Date.now(),inicio:INICIO});return;}
 if(m.t==="hola"){
  if(p)return;
  /* identidad: el token de la cuenta. Una cuenta = una conexión online */
  var tk=verToken(String(m.tk||""));
  if(!tk||!sesionOk(tk.id,tk.s)){wsEnviar(sock,{t:"error",msg:"Sesión no válida o abierta en otro dispositivo. Vuelve a iniciar sesión.",fatal:1});sock.end();return;}
  for(var idq in jugadores){
   var qd=jugadores[idq];if(qd.cuenta!==tk.id)continue;
   if(Date.now()-qd.vistoUlt<8000){wsEnviar(sock,{t:"error",msg:"Esta cuenta ya está conectada en otra ventana o dispositivo.",fatal:1});sock.end();return;}
   salir(qd);try{qd.sock.destroy();}catch(e){}   /* conexión anterior muerta (corte de red): se sustituye */
  }
  if(cuentaReales()>=MAX_JUGADORES){wsEnviar(sock,{t:"error",msg:"Servidor lleno ("+MAX_JUGADORES+" jugadores)."});sock.end();return;}
  p={id:sigId++,sock:sock,nombre:limpiaTxt(m.nombre,20)||"Aventurero",clase:limpiaTxt(m.clase,20),nivel:num(m.nivel,1,100,1)|0,avatar:num(m.avatar,0,9999,0)|0,lugar:LUGARES.indexOf(m.lugar)>=0?m.lugar:"pueblo",x:num(m.x,-9999,9999,0),y:num(m.y,-9999,9999,0),dir:"s",ult:0,cuenta:tk.id,sid:tk.s,vistoUlt:Date.now(),grupo:0,com:null,hp:0,hpMax:0,mp:0,mpMax:0,rn:"",act:true,ultInfo:0,ultEv:{}};
  sock._p=p;jugadores[p.id]=p;
  var lista=[];for(var id in jugadores)if(+id!==p.id)lista.push(pub(jugadores[id]));
  wsEnviar(sock,{t:"bienvenido",id:p.id,jugadores:lista,misionesGrupo:MISIONES_GRUPO_ACTIVO});
  aTodos({t:"entra",jugador:pub(p)},p.id);
  if(p.lugar==="mundo")SIMMUNDO.entra(p);
  log("+ "+p.nombre+" entró ("+cuentaReales()+"/"+MAX_JUGADORES+")");
  return;
 }
 if(!p)return;
 if(m.t.indexOf("mon_")===0){SIMMUNDO.mensaje(p,m);return;}
 if(m.t==="lugar"){
  var l=limpiaTxt(m.lugar,20);if(LUGARES.indexOf(l)<0)return;
  p.lugar=l;if(m.x!=null)p.x=num(m.x,-9999,9999,0);if(m.y!=null)p.y=num(m.y,-9999,9999,0);
  aTodos({t:"lugar",id:p.id,lugar:l,x:p.x,y:p.y},p.id);
  if(l==="mundo")SIMMUNDO.entra(p);else SIMMUNDO.sale(p);
  return;
 }
 if(m.t==="mover"){
  var ahora=Date.now();if(ahora-p.ult<MIN_MOVER_MS)return;p.ult=ahora;
  p.x=num(m.x,-9999,9999,p.x);p.y=num(m.y,-9999,9999,p.y);p.dir=limpiaTxt(m.dir,2)||p.dir;
  aTodos({t:"mueve",id:p.id,x:p.x,y:p.y,dir:p.dir},p.id,p.lugar);return;
 }
 if(m.t==="chat"){
  var tx=limpiaTxt(m.texto,MAX_CHAT).trim();if(!tx)return;
  aTodos({t:"chat",id:p.id,nombre:p.nombre,texto:tx});return;
 }
 if(m.t==="info"){
  var ahoraI=Date.now();if(ahoraI-p.ultInfo<300)return;p.ultInfo=ahoraI;
  var nv0=p.nivel;p.nivel=num(m.nivel,1,100,p.nivel)|0;
  if(m.clase!=null)p.clase=limpiaTxt(m.clase,20)||p.clase;
  p.hp=Math.floor(num(m.hp,0,1e9,p.hp));p.hpMax=Math.floor(num(m.hpMax,0,1e9,p.hpMax));p.mp=Math.floor(num(m.mp,0,1e9,p.mp));p.mpMax=Math.floor(num(m.mpMax,0,1e9,p.mpMax));
  if(m.rn!=null)p.rn=limpiaTxt(m.rn,16);p.act=m.act!==false;
  if(p.nivel!==nv0)aTodos({t:"info",id:p.id,nivel:p.nivel},p.id);
  var gi=gDe(p);if(gi)aGrupo(gi,{t:"g_info",id:p.id,nivel:p.nivel,clase:p.clase,hp:p.hp,hpMax:p.hpMax,mp:p.mp,mpMax:p.mpMax,rn:p.rn,act:p.act},p.id);
  return;}
 /* ---- grupos / raid ---- */
 if(m.t==="g_invitar"){
  var o=jugadores[m.id|0];if(!o||o.id===p.id)return;
  var g0=gDe(p);
  if(o.grupo){aviso(p,o.nombre+" ya está en un grupo.");return;}
  if(g0&&g0.miembros.length>=gCap(g0)){aviso(p,"Tu "+(g0.raid?"raid":"grupo")+" está completo ("+gCap(g0)+").");return;}
  invGrupo[o.id]={de:p.id,t:Date.now()};
  wsEnviar(o.sock,{t:"g_invitacion",de:p.id,nombre:p.nombre,nivel:p.nivel,clase:p.clase});
  aviso(p,"Invitación enviada a "+o.nombre+".");return;
 }
 if(m.t==="g_resp"){
  var inv=invGrupo[p.id];delete invGrupo[p.id];
  if(!inv||inv.de!==(m.de|0)||Date.now()-inv.t>40000)return;
  var q=jugadores[inv.de];if(!q)return;
  if(!m.ok){aviso(q,p.nombre+" rechazó la invitación.");return;}
  if(p.grupo){return;}
  var g1=gDe(q);
  if(!g1){g1={id:sigGrupo++,lider:q.id,raid:false,miembros:[q.id],lab:null};grupos[g1.id]=g1;q.grupo=g1.id;}
  if(g1.miembros.length>=gCap(g1)){aviso(p,"El grupo está completo.");return;}
  g1.miembros.push(p.id);p.grupo=g1.id;
  aGrupo(g1,{t:"g_aviso",msg:p.nombre+" se unió al "+(g1.raid?"raid":"grupo")+"."},p.id);
  gEnviar(g1);log("Grupo "+g1.id+": "+p.nombre+" se une ("+g1.miembros.length+")");return;
 }
 if(m.t==="g_salir"){gSalir(p,"salir");return;}
 if(m.t==="g_expulsar"){
  var g2=gDe(p);if(!g2||g2.lider!==p.id)return;
  var ex=jugadores[m.id|0];if(!ex||ex.grupo!==g2.id||ex.id===p.id)return;gSalir(ex,"expulsado");return;
 }
 if(m.t==="g_raid"){
  var g3=gDe(p);if(!g3||g3.lider!==p.id)return;
  if(m.on)g3.raid=true;else{if(g3.miembros.length>MAX_GRUPO){aviso(p,"Hay más de "+MAX_GRUPO+" miembros: no se puede volver a grupo.");return;}g3.raid=false;}
  aGrupo(g3,{t:"g_aviso",msg:g3.raid?"El grupo se ha convertido en raid (hasta "+MAX_RAID+").":"El raid vuelve a ser un grupo ("+MAX_GRUPO+")."});gEnviar(g3);return;
 }
 if(m.t==="g_lider"){
  var g4=gDe(p);if(!g4||g4.lider!==p.id)return;var nl=jugadores[m.id|0];if(!nl||nl.grupo!==g4.id)return;g4.lider=nl.id;gEnviar(g4);return;
 }
 /* ---- chat privado ---- */
 if(m.t==="susurro"){
  var d=jugadores[m.a|0],tx2=limpiaTxt(m.texto,MAX_CHAT).trim();if(!d||!tx2||d.id===p.id)return;
  wsEnviar(d.sock,{t:"susurro",de:p.id,nombre:p.nombre,texto:tx2});return;
 }
 /* ---- comercio ---- */
 if(m.t==="c_pedir"){
  var ot=jugadores[m.id|0];if(!ot||ot.id===p.id)return;
  if(p.com||ot.com){aviso(p,p.com?"Ya estás comerciando.":ot.nombre+" está ocupado comerciando.");return;}
  invCom[ot.id]={de:p.id,t:Date.now()};
  wsEnviar(ot.sock,{t:"c_solicitud",de:p.id,nombre:p.nombre});aviso(p,"Propuesta de comercio enviada a "+ot.nombre+".");return;
 }
 if(m.t==="c_resp"){
  var ic=invCom[p.id];delete invCom[p.id];
  if(!ic||ic.de!==(m.de|0)||Date.now()-ic.t>40000)return;
  var qc=jugadores[ic.de];if(!qc)return;
  if(!m.ok){aviso(qc,p.nombre+" rechazó el comercio.");return;}
  if(p.com||qc.com)return;
  var tr={a:qc.id,b:p.id,of:{},ok:{}};tr.of[qc.id]={oro:0,items:{},eq:[]};tr.of[p.id]={oro:0,items:{},eq:[]};tr.ok[qc.id]=false;tr.ok[p.id]=false;
  qc.com=tr;p.com=tr;
  wsEnviar(qc.sock,{t:"c_abrir",con:p.id,nombre:p.nombre});wsEnviar(p.sock,{t:"c_abrir",con:qc.id,nombre:qc.nombre});cEstado(tr);return;
 }
 if(m.t==="c_oferta"){
  var tr1=p.com;if(!tr1)return;tr1.of[p.id]=ofertaLimpia(m);tr1.ok[tr1.a]=false;tr1.ok[tr1.b]=false;cEstado(tr1);return;
 }
 if(m.t==="c_conf"){
  var tr2=p.com;if(!tr2)return;tr2.ok[p.id]=!!m.ok;cEstado(tr2);
  if(tr2.ok[tr2.a]&&tr2.ok[tr2.b]){
   var A=jugadores[tr2.a],B=jugadores[tr2.b];
   if(A&&B){
    wsEnviar(A.sock,{t:"c_fin",con:B.id,da:tr2.of[A.id],recibe:tr2.of[B.id]});
    wsEnviar(B.sock,{t:"c_fin",con:A.id,da:tr2.of[B.id],recibe:tr2.of[A.id]});
    log("Comercio: "+A.nombre+" ⇄ "+B.nombre);
   }
   cCerrar(tr2,"",0);
  }
  return;
 }
 if(m.t==="c_cancelar"){var tr3=p.com;if(!tr3)return;cCerrar(tr3,"cancelado",p.id);return;}
 /* ---- refuerzos de Paladín/Clérigo sobre los aliados del grupo (mundo abierto) ----
    El lanzador calcula el efecto con sus stats; el servidor lo reenvía solo a los miembros de su grupo que estén en el mundo y a menos de r celdas. */
 if(m.t==="g_buff"){
  var gb=gDe(p);if(!gb||p.lugar!=="mundo"||!m.fx||typeof m.fx!=="object")return;
  var ahB=Date.now();if(ahB-(p.ultBuff||0)<250)return;p.ultBuff=ahB;
  var f0=m.fx,tb0=f0.tb&&typeof f0.tb==="object"?f0.tb:null,fb={
   n:limpiaTxt(f0.n,32),col:/^#[0-9a-fA-F]{6}$/.test(f0.col)?f0.col:"#ffe9a0",
   hp:num(f0.hp,0,1,0),df:num(f0.df,0,2,0),dfl:num(f0.dfl,0,2000,0),dfT:num(f0.dfT,0,60,0),
   sh:num(f0.sh,0,1,0),shT:num(f0.shT,0,60,0),pur:f0.pur?1:0,inv:num(f0.inv,0,10,0),fxt:limpiaTxt(f0.fxt,12)};
  if(tb0)fb.tb={n:limpiaTxt(tb0.n,32),t:num(tb0.t,0,60,0),dm:num(tb0.dm,0,2,0),red:num(tb0.red,0,.9,0),reg:num(tb0.reg,0,.5,0),cc:tb0.cc?1:0};
  var rb=num(m.r,1,15,12),envB=0;
  gb.miembros.forEach(function(id){
   if(id===p.id)return;var q=jugadores[id];
   if(!q||q.lugar!=="mundo"||Math.hypot(q.x-p.x,q.y-p.y)>rb)return;
   wsEnviar(q.sock,{t:"g_buff",de:p.id,nombre:p.nombre,fx:fb});envB++;});
  return;
 }
 /* ---- laberinto de grupo (instancia propia; host = quien simula enemigos) ---- */
 if(m.t==="lab_unir"){
  var gl=gDe(p);if(!gl){wsEnviar(sock,{t:"lab_inicio",error:"sin_grupo"});return;}
  var nuevo=false;
  if(!gl.lab){gl.lab={seed:Math.floor(num(m.seed,1,2e9,1)),piso:Math.floor(num(m.piso,1,70,1)),ciclo:Math.floor(num(m.ciclo,0,50,0)),host:p.id,en:[p.id]};nuevo=true;}
  else if(gl.lab.en.indexOf(p.id)<0){
   gl.lab.en.push(p.id);var hq=jugadores[gl.lab.host];if(hq)wsEnviar(hq.sock,{t:"lab_pedir",id:p.id});
  }
  wsEnviar(sock,{t:"lab_inicio",seed:gl.lab.seed,piso:gl.lab.piso,ciclo:gl.lab.ciclo,host:gl.lab.host,nuevo:nuevo,id:p.id});
  gEnviar(gl);log("Laberinto de grupo "+gl.id+": "+p.nombre+" entra ("+gl.lab.en.length+")");return;
 }
 if(m.t==="lab_salir"){var gs=gDe(p);if(gs){labQuitar(gs,p);gEnviar(gs);}return;}
 if(m.t==="lab_ev"){
  var ge=gDe(p);if(!ge||!ge.lab||ge.lab.en.indexOf(p.id)<0)return;
  if(m.k==="p"||m.k==="s"){var ah=Date.now();if(ah-(p.ultEv[m.k]||0)<45)return;p.ultEv[m.k]=ah;}
  var fw={};for(var kk in m)fw[kk]=m[kk];fw.t="lab_ev";fw.de=p.id;delete fw.a;
  if(m.a!=null){var dq=jugadores[m.a|0];if(dq&&ge.lab.en.indexOf(dq.id)>=0)wsEnviar(dq.sock,fw);}
  else ge.lab.en.forEach(function(id){if(id!==p.id){var z=jugadores[id];if(z)wsEnviar(z.sock,fw);}});
  return;
 }
 /* Misiones en grupo (iniciar desde el Gremio): EN DESARROLLO */
 if(/^(grupo|mision)_/.test(m.t)){
  if(!MISIONES_GRUPO_ACTIVO){wsEnviar(sock,{t:"en_desarrollo",funcion:"misiones_grupo",msg:"Las misiones en grupo están en desarrollo."});return;}
  return;
 }
}

servidor.on("upgrade",function(req,sock){
 var u=(req.url||"").split("?")[0],k=req.headers["sec-websocket-key"];
 if(u!=="/ws"||!k||String(req.headers.upgrade).toLowerCase()!=="websocket"){sock.end("HTTP/1.1 400 Bad Request\r\n\r\n");return;}
 var acc=crypto.createHash("sha1").update(k+GUID).digest("base64");
 sock.write("HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Accept: "+acc+"\r\n\r\n");
 sock.setNoDelay(true);sock._vivo=true;
 var cerrado=false;
 function cerrar(cod){if(cerrado)return;cerrado=true;try{var c=Buffer.alloc(2);c.writeUInt16BE(cod||1000);wsCtrl(sock,0x8,c);}catch(e){}salir(sock._p);sock.destroy();}
 sock.on("data",function(c){try{wsLeer(sock,c,function(t){mensaje(sock,t);},cerrar);}catch(e){cerrar(1011);}});
 sock.on("close",function(){cerrado=true;salir(sock._p);});
 sock.on("error",function(){cerrado=true;salir(sock._p);sock.destroy();});
});
/* latido: elimina conexiones muertas */
setInterval(function(){for(var id in jugadores){if(jugadores[id].bot)continue;var s=jugadores[id].sock;if(!s._vivo){salir(jugadores[id]);s.destroy();continue;}s._vivo=false;wsCtrl(s,0x9);}},20000).unref();

servidor.on("error",function(e){console.error(e.code==="EADDRINUSE"?"El puerto "+PUERTO+" está en uso. Usa: node server/servidor.js <otro_puerto>":e.message);process.exit(1);});
servidor.listen(PUERTO,"0.0.0.0",function(){
 console.log("\n=== THE CHRONICLES OF NARADAK · Servidor local ===");
 console.log("Este equipo:  http://localhost:"+PUERTO);
 var ifs=os.networkInterfaces();
 Object.keys(ifs).forEach(function(n){ifs[n].forEach(function(a){if(a.family==="IPv4"&&!a.internal)console.log("Otros equipos: http://"+a.address+":"+PUERTO+"   ("+n+")");});});
 console.log("IA de monstruos y jefes (Mundo Abierto): "+(IA_MUNDO_ACTIVA?"ACTIVADA (navegación, tácticas y combos)":"DESACTIVADA (IA básica)"));
 console.log("Joystick táctil (Mundo Abierto): "+(JOYSTICK_ACTIVO?"ACTIVADO (modo Android)":"DESACTIVADO (modo PC)"));
 console.log("Crear cuentas (navegador): /registro"+(REGISTRO_ABIERTO?"":"  [CERRADO]"));
 console.log("Bots aventureros (uno por clase): "+(BOTS_ACTIVOS?"ACTIVADOS":"DESACTIVADOS")+"  (no ocupan plaza; ajustes en server/bots.js)");
 console.log("Misiones en grupo: EN DESARROLLO · Máx. jugadores: "+MAX_JUGADORES);
 try{BOTS.iniciar();}catch(e){log("⚠ Los bots no se pudieron iniciar: "+(e&&e.stack||e));}
 console.log("Cuentas: "+Object.keys(usuarios).length+" · Partidas guardadas en: "+DATOS+(REGISTRO_ABIERTO?"":" · REGISTRO CERRADO")+"\nCtrl+C para detener.\n");
});
module.exports={servidor:servidor};
