#!/bin/sh
cd "$(dirname "$0")/.." || exit 1
command -v node >/dev/null 2>&1 || { echo "Instala Node.js (nodejs.org)."; exit 1; }
exec node server/servidor.js "$@"
