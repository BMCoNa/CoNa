"use strict";
/* THE CHRONICLES OF NARADAK — BOTS aventureros (uno por clase), controlados por el servidor.

   Cada bot es un "cliente virtual": entra en la lista de jugadores como uno más (aparece en Oakhaven y en el Mundo Abierto,
   se puede invitar a grupo, susurrar, etc.) pero lo maneja este módulo en vez de un navegador.

   REGLAS REALES DEL JUEGO: el módulo carga en el servidor los mismos archivos del juego que usa el cliente (js/data, js/core,
   js/sistemas) en un sandbox, así que los bots usan calcStats, ganarXP, dropearLoot, la tienda, los talentos de rama, las
   pociones, etc. con las MISMAS fórmulas que un jugador.  Su partida es un personaje normal (`j`) y se guarda en
   server/datos/bots.json (progreso persistente entre reinicios).

   COMPORTAMIENTO
   · Empiezan en Oakhaven (nivel 1): pasean por la plaza, compran/venden en la Tienda (equipo, pociones, materiales) y charlan.
   · Salen a subir de nivel al Mundo Abierto por el General Varek: eligen el sector que su personaje aguanta, cazan monstruos con
     ataque básico + habilidades (y las de rama al llegar al Nv 50/60/80), usan pociones, esquivan telegrafías, se retiran a curarse
     al campamento, mueren y reaparecen igual que un jugador, y vuelven a Oakhaven (por el Mensajero Doran) a vender y a comprar.
   · Aceptan invitaciones a grupo. En grupo te siguen entre Oakhaven y el Mundo Abierto, te ayudan a pelear con su rol de clase
     (cuerpo a cuerpo delante, a distancia detrás, Clérigo/Paladín curan y refuerzan al grupo) y reparten XP/oro como cualquier miembro.
   · Responden al chat y a susurros con órdenes sencillas: seguir · quieto · atacar · ciudad · salir · estado.
   · No ocupan plaza de jugador (MAX_JUGADORES) y no entran al Laberinto (instancia que simula el cliente).

   AJUSTES: objeto CFG (más abajo): nombre, clase, nivel inicial, rama y avatar de cada bot, y tiempos de comportamiento.
   Desactivar todos los bots: `BOTS_ACTIVOS=false` en server/servidor.js (o `BOTS=0 node server/servidor.js`). */
var fs=require("fs"),path=require("path"),vm=require("vm");

/* ===================================== AJUSTES ===================================== */
var CFG={
 /* Un bot por clase. nivel = nivel con el que se CREA el bot (si ya existe en server/datos/bots.json se conserva su progreso;
    pon forzar:true para aplicar este nivel en cada arranque). rama = rama de talentos al llegar al Nv 50 (null = la predeterminada):
      Guerrero: Berserker | Ejecutor            Paladin: Inquisidor | Guardián      Arquero: Cazador | Francotirador
      Asesino:  Ninja | Sicario                 Mago: Ignis | Cryomante             Clérigo: Hierofante | Heraldo Solar
    avatar = sprite humano (0-79, ver CHARS_INFO en tilemap/js/chars.js). */
 BOTS:[
  {nombre:"Brannoch",clase:"Guerrero",nivel:1,rama:null,avatar:10},
  {nombre:"Elyndra", clase:"Mago",    nivel:1,rama:null,avatar:20},
  {nombre:"Faelan",  clase:"Arquero", nivel:1,rama:null,avatar:30},
  {nombre:"Aldous",  clase:"Paladin", nivel:1,rama:null,avatar:40},
  {nombre:"Vexara",  clase:"Asesino", nivel:1,rama:null,avatar:50},
  {nombre:"Seraphel",clase:"Clérigo", nivel:1,rama:null,avatar:60}
 ],
 RAMA_DEF:{Guerrero:"Berserker",Paladin:"Guardián",Arquero:"Francotirador",Asesino:"Ninja",Mago:"Ignis","Clérigo" :"Hierofante"},
 PAUSAR_SIN_JUGADORES:false,   /* true = los bots se quedan quietos en Oakhaven mientras no haya ningún jugador conectado */
 ACEPTA_GRUPO:true,            /* aceptan las invitaciones a grupo */
 RESPONDE_CHAT:true,           /* responden a órdenes y saludos (chat y susurros) */
 T_CIUDAD:[45,130],            /* segundos que pasan en Oakhaven entre salidas (paseo, tienda, charla) */
 T_SALIDA:[600,1200],           /* segundos de caza antes de volver a vender/comprar (si no hay motivo antes) */
 RIESGO:.34,                   /* fracción de su vida que aceptan perder, de media, por monstruo del sector elegido (menor = más prudentes) */
 SAVE_S:45                     /* guardado del progreso (segundos) */
};

/* ============================ constantes de juego (iguales al cliente) ============================ */
var U=32,TS=2,SPD_OAK=4.2,SPD_MUN=4.4,SPR_DUR=4,SPR_CD=12,SPR_MULT=1.6;
var REGEN_ESPERA=10,REGEN_MP=.02,HIT_GAIN=.015,POT_CD=4,MAXM=230,MAXT=320;
var MELEE_R={Guerrero:[84,2.0],Paladin:[80,2.1],Asesino:[66,1.55]},MELEE={Guerrero:1,Paladin:1,Asesino:1};
var DT=.05;

/* ================================== utilidades ================================== */
function rnd(a,b){return a+Math.floor(Math.random()*(b-a+1));}
function rf(a,b){return a+Math.random()*(b-a);}
function pick(a){return a[Math.floor(Math.random()*a.length)];}
function clamp(v,a,b){return v<a?a:v>b?b:v;}
function r2(v){return Math.round(v*100)/100;}
function angd(a,b){var d=a-b;while(d>Math.PI)d-=2*Math.PI;while(d<-Math.PI)d+=2*Math.PI;return d;}
function dirOf(dx,dy){var sx=dx-dy,sy=dx+dy;return Math.abs(sx)>Math.abs(sy)?(sx<0?1:2):(sy>0?0:3);}   /* 0 abajo · 1 izq · 2 der · 3 arriba */
var DIRC=["s","a","d","w"];
function norm(t){return String(t||"").normalize("NFD").replace(/[\u0300-\u036f]/g,"").toLowerCase();}
function entre(r){return rf(r[0],r[1]);}

/* ======================== carga de las reglas del juego (sandbox) ======================== */
function dummyDom(){var f=function(){return p;},p=new Proxy(f,{get:function(t,k){if(k===Symbol.toPrimitive)return function(){return 0;};return p;},apply:function(){return p;},set:function(){return true;}});return p;}
function cargarJuego(RAIZ){
 var store={};
 var sb={document:dummyDom(),navigator:{userAgent:"node"},console:{log:function(){},warn:function(){},error:function(){}},performance:{now:Date.now},
  localStorage:{getItem:function(k){return store[k]===undefined?null:store[k];},setItem:function(k,v){store[k]=String(v);},removeItem:function(k){delete store[k];}},
  setTimeout:function(){return 0;},clearTimeout:function(){}};
 sb.window=sb;vm.createContext(sb);
 ["js/data/clases.js","js/data/items.js","js/data/mundo.js","js/data/loot.js","js/data/gremio.js","js/data/forja.js","js/data/alquimia.js",
  "js/sistemas/profesiones.js","js/sistemas/talentos.js","js/core/estado.js","js/core/combate_velocidad.js","js/core/danos.js","js/core/combate.js","js/sistemas/equipamiento.js"
 ].forEach(function(f){vm.runInContext(fs.readFileSync(path.join(RAIZ,f),"utf8"),sb,{filename:f,timeout:10000});});
 sb.guardar=function(){};sb.avanzarTiempo=function(){};   /* sin interfaz ni reloj de partida */
 sb.G.log=[];
 ["calcStats","ganarXP","dropearLoot","crearJugador","HABILIDADES","ITEMS","itemObj","RAMAS","ramaNodos","ramaAct","talEst","costoNodo","costoHab","talMods","gmGlob","velJugador","armarEnemigo",
  "danoMitigado","defensaEnemigo","equiparItem","poseeEquipo","copiaItem","equipoBolsa","precioVentaEquipo","venderMaterial","esMaterial","precioMaterial","POCIONES","cosechar","curaMult","potBuff","recetaObj","CLASES"
 ].forEach(function(k){if(sb[k]===undefined)throw new Error("falta "+k+" en las reglas del juego");});
 return sb;
}
/* Oakhaven: se ejecuta la parte de GENERACIÓN del mapa (determinista) de tilemap/js/oakhaven_mapa.js para conocer calles, muros y edificios */
function cargarOak(RAIZ){
 var src=fs.readFileSync(path.join(RAIZ,"tilemap","js","oakhaven_mapa.js"),"utf8");
 var fin=src.indexOf("/* ---------- camino (BFS) ---------- */");if(fin<0)throw new Error("Oakhaven: no se encontró el final de la generación del mapa");
 var pre=src.slice(0,fin),ini="(function(){\n";if(pre.indexOf(ini)<0)throw new Error("Oakhaven: inicio de módulo no encontrado");
 pre=pre.replace(ini,"__OAK=(function(){\n")+"\nreturn {W:W,H:H,blk:blk,reach:reach,road:road,blds:blds,SPAWN:SPAWN,GEN:GEN};\n})();";
 var sb={document:dummyDom(),window:{},innerWidth:1280,innerHeight:800,performance:{now:Date.now},__OAK:null,console:{log:function(){},warn:function(){},error:function(){}}};
 vm.runInNewContext(pre,sb,{timeout:30000,filename:"oakhaven_mapa.js"});
 if(!sb.__OAK)throw new Error("Oakhaven no se generó");
 return sb.__OAK;
}

/* ====================================================================================== */
module.exports=function(ctx){
 var api={activo:false,cuenta:function(){return 0;},iniciar:function(){},guardar:function(){},resumen:function(){return [];}};
 if(!ctx.activo)return api;
 var J=ctx.jugadores,log=ctx.log,SIM=ctx.SIMMUNDO,RAIZ=ctx.RAIZ,gDe=ctx.gDe;
 var GM,OK;
 try{GM=cargarJuego(RAIZ);OK=cargarOak(RAIZ);}catch(e){log("⚠ Bots DESACTIVADOS: "+(e&&e.message||e));return api;}

 /* ---------------- mundo abierto (lo comparte el simulador de monstruos del servidor) ---------------- */
 var MD=SIM&&SIM.MD||null,IA=null,NAVB=null,W=0,blk=null,sec=null,TM=null,CC=null,SPAWN=null,SECT=[];
 var BQ=null,BD=null,BS=null,bst=0;
 if(!MD)log("⚠ Bots: el mundo abierto no está disponible en el servidor; los bots se quedarán en Oakhaven.");
 else{
  W=MD.W;blk=MD.blk;sec=MD.sec;TM=MD.TM;CC=MD.CC;SPAWN=MD.SPAWN;
  try{IA=require(path.join(RAIZ,"tilemap","js","mundo_ia.js"));NAVB=IA.crearNav(W,W,SIM.jLibre);}catch(e){IA=null;NAVB=null;log("⚠ Bots: sin navegación A* ("+e.message+"); usarán movimiento simple.");}
  BQ=new Int32Array(W*W);BD=new Int32Array(W*W);BS=new Uint32Array(W*W);
  for(var k=0;k<MD.GN*MD.GN;k++)if(TM[k].built)SECT.push({k:k,id:TM[k].id,n:TM[k].n,dif:TM[k].dif,cx:MD.OX(TM[k].c)+MD.S/2,cy:MD.OX(TM[k].r)+MD.S/2});
  SECT.sort(function(a,b){return a.dif.pe-b.dif.pe;});
 }
 var OW=OK.W,OH=OK.H,oblk=OK.blk,oreach=OK.reach,GEN=OK.GEN;
 var FDAT=path.join(ctx.DATOS,"bots.json");
 var DATA={version:1,bots:{}};
 try{var rd=JSON.parse(fs.readFileSync(FDAT,"utf8"));if(rd&&rd.bots)DATA=rd;}catch(e){}
 var BOTS=[],tickN=0,pausa=false,lastErr=0;

 /* ---------------- mensajes del bot hacia el servidor (mismo protocolo que un cliente) ---------------- */
 function env(b,o){try{ctx.mensaje(b.sock,JSON.stringify(o));}catch(e){}}
 function decir(b,txt,fuerza){var n=Date.now();if(!CFG.RESPONDE_CHAT&&!fuerza)return;if(n-b.ultChat<2500)return;b.ultChat=n;env(b,{t:"chat",texto:txt});}
 function susurrar(b,a,txt){env(b,{t:"susurro",a:a,texto:txt});}
 function tarde(b,s,fn){b.TML.push({t:s,fn:fn});}

 /* ---------------- creación / estado del personaje ---------------- */
 function ramaValida(clase,nm){var R=GM.RAMAS[clase]||[];for(var i=0;i<R.length;i++)if(R[i].n===nm)return true;return false;}
 function nuevoJ(cfg){
  var j=GM.crearJugador(cfg.nombre,cfg.clase);
  j.nivel=Math.max(1,Math.min(100,cfg.nivel|0||1));j.xp=0;
  if(j.nivel>1)j.oro+=j.nivel*180;       /* un bot creado con nivel alto tiene algo de oro para equiparse */
  j.piso=1;j.bot=true;
  return j;
 }
 function crearBot(cfg,idx){
  if(!GM.CLASES[cfg.clase]){log("⚠ Bot "+cfg.nombre+": clase desconocida «"+cfg.clase+"».");return null;}
  var sv=DATA.bots[cfg.nombre],j=null;
  if(sv&&sv.j&&sv.j.clase===cfg.clase&&!cfg.forzar){j=sv.j;}
  if(!j)j=nuevoJ(cfg);
  if(!j.tal)j.tal={rama:null,act:[],almas:0};
  if(!j.inventario)j.inventario={};
  var rama=cfg.rama&&ramaValida(cfg.clase,cfg.rama)?cfg.rama:CFG.RAMA_DEF[cfg.clase];
  if(cfg.rama&&!ramaValida(cfg.clase,cfg.rama))log("⚠ Bot "+cfg.nombre+": rama «"+cfg.rama+"» no existe para "+cfg.clase+"; se usa "+rama+".");
  var b={cfg:cfg,idx:idx,nombre:cfg.nombre,clase:cfg.clase,j:j,rama:rama,p:null,sock:null,lugar:"oakhaven",x:0,y:0,dir:0,mv:0,bias:Math.random()<.5?1:-1,
   PS:{hp:1,mp:1,max:1,mpMax:1,atkT:0,potT:0,cd:[0,0,0,0,0],sh:0,shT:0,defB:0,defT:0,invT:0,stunT:0,silT:0,resStun:0,comb:0,regW:0,sprT:0,sprCd:0,vivo:true,nx:null},
   MON:{},TML:[],tg:0,t:0,ultChat:0,ultMov:0,ultInfo:0,movAcc:0,_x:-99,_y:-99,
   modo:"ciudad",task:"espera",tt:rf(3,10),plan:null,path:null,ruta:null,rutaI:0,dest:null,
   auto:"ir",sector:null,tCaza:0,tCiudad:entre(CFG.T_CIUDAD)+idx*9,tIni:0,kills:0,muertes:0,muertesRec:[],
   prud:rf(.85,1.15),esq:rf(.3,.6),orden:null,metaOro:400,aceptar:null,dodge:null,dash:null,rutaT:0,atascoT:0,progX:0,progY:0,lastHunt:0,tLugar:0,sinCaza:0,flee:false};
  b.PS.vivo=true;
  alCambiarStats(b,true);
  b.PS.hp=Math.max(1,Math.min(b.PS.max,Math.round(j.vida||b.PS.max)));b.PS.mp=Math.max(0,Math.min(b.PS.mpMax,Math.round(j.recurso||b.PS.mpMax)));
  /* posición inicial: plaza de Oakhaven */
  var c=celdaOakCerca(rnd(64,82),rnd(41,52),6)||{x:OK.SPAWN.x,y:OK.SPAWN.y};
  b.x=c.x+.5;b.y=c.y+.5;
  b.p=ctx.crearJugadorBot({nombre:cfg.nombre,clase:cfg.clase,nivel:j.nivel,avatar:cfg.avatar|0,lugar:"oakhaven",x:b.x,y:b.y,recibe:function(m){recibe(b,m);}});
  b.sock=b.p.sock;
  elegirRamaYTalentos(b);
  return b;
 }
 function elegirRamaYTalentos(b){
  var j=b.j,T=GM.talEst(j);
  if(j.nivel>=50&&!T.rama){T.rama=b.rama;T.act=[];log("Bot "+b.nombre+" elige la rama "+b.rama+".");alCambiarStats(b);}
  if(!T.rama)return;
  var r=GM.ramaAct(j);if(!r)return;
  var N=GM.ramaNodos(r),cambio=false;
  for(var i=0;i<N.length;i++){
   var n=N[i];if(T.act.indexOf(n.id)>=0)continue;
   if(j.nivel<n.nv||T.almas<GM.costoNodo(n)||(i>0&&T.act.indexOf(N[i-1].id)<0))break;
   T.almas-=GM.costoNodo(n);T.act.push(n.id);cambio=true;
  }
  if(cambio)alCambiarStats(b);
 }
 /* recalcula stats derivados (nivel, equipo, talentos) y las 5 habilidades */
 function alCambiarStats(b,primera){
  var j=b.j,PS=b.PS,st=GM.calcStats(j),cl=GM.CLASES[j.clase]||{};
  b.st=st;b.M=GM.talMods(j);b.vel=GM.velJugador(j)||1;b.crit=(cl.crit||5)+(st.critB||0);
  var ra=GM.ramaAct(j),T=j.tal;
  var hab=(GM.HABILIDADES[j.clase]||[]).slice(0,3).map(function(h){return Object.assign({},h,{costo:GM.costoHab(j,h.costo)});});
  if(ra&&T&&T.act)[ra.h1,ra.h2].forEach(function(sk){if(T.act.indexOf(ra.n+"_"+sk.s)>=0)hab.push({n:sk.n,costo:GM.costoHab(j,sk.c),efecto:"rama",cd:Math.max(1,sk.cd-b.M[sk.s+"cd"]),rama:sk});});
  b.habs=hab;
  PS.max=Math.max(1,st.vidaMax);PS.mpMax=Math.max(1,st.recursoMax);
  if(PS.hp>PS.max)PS.hp=PS.max;if(PS.mp>PS.mpMax)PS.mp=PS.mpMax;
  b.melee=!!MELEE[j.clase];b.cura=j.clase==="Clérigo"||j.clase==="Paladin";
 }
 function guardarTodo(){
  try{
   BOTS.forEach(function(b){var j=b.j,tb=j.tb;j.tb=null;j.vida=Math.max(1,Math.round(b.PS.hp));j.recurso=Math.max(0,Math.round(b.PS.mp));DATA.bots[b.nombre]={j:JSON.parse(JSON.stringify(j)),kills:b.kills,t:Date.now()};j.tb=tb;});
   var t=FDAT+"."+process.pid+".tmp";fs.writeFileSync(t,JSON.stringify(DATA));fs.renameSync(t,FDAT);
  }catch(e){log("⚠ No se pudo guardar el progreso de los bots: "+e.message);}
 }

 /* ---------------- mapa de Oakhaven (calles, edificios) ---------------- */
 var DX=[1,0,-1,0],DY=[0,1,0,-1];
 function oI(x,y){return y*OW+x;}
 function oLibre(x,y){return x>=0&&y>=0&&x<OW&&y<OH&&!oblk[oI(x,y)]&&oreach[oI(x,y)]===1;}
 function celdaOakCerca(x,y,rad){
  if(oLibre(x,y))return{x:x,y:y};
  for(var r=1;r<=rad;r++)for(var b=-r;b<=r;b++)for(var a=-r;a<=r;a++){if(Math.max(Math.abs(a),Math.abs(b))!==r)continue;if(oLibre(x+a,y+b))return{x:x+a,y:y+b};}
  return null;
 }
 var _oq=new Int32Array(OW*OH),_op=new Int32Array(OW*OH);
 function bfsOak(ax,ay,bx,by){
  if(!oLibre(bx,by)||!oLibre(ax,ay))return null;
  _op.fill(-2);var qh=0,qt=0,s=oI(ax,ay),e=oI(bx,by);_op[s]=-1;_oq[qt++]=s;
  while(qh<qt){var c=_oq[qh++];if(c===e)break;var x=c%OW,y=(c/OW)|0;
   for(var k=0;k<4;k++){var X=x+DX[k],Y=y+DY[k];if(!oLibre(X,Y))continue;var j=oI(X,Y);if(_op[j]!==-2)continue;_op[j]=c;_oq[qt++]=j;}}
  if(_op[e]===-2)return null;
  var p=[],c2=e;while(c2!==-1){p.push({x:c2%OW,y:(c2/OW)|0});c2=_op[c2];}p.reverse();p.shift();return p;
 }
 var PLAZA=[],TIENDA=null;
 OK.blds.forEach(function(o){if(o.id==="tienda"&&o.fx===74&&o.fy===39)TIENDA=o;});
 if(!TIENDA)OK.blds.forEach(function(o){if(!TIENDA&&o.id==="tienda")TIENDA=o;});
 function puertaOak(o){
  if(!o)return null;
  var cand=[{x:o.fx,y:o.fy+o.fh},{x:o.fx+1,y:o.fy+o.fh},{x:o.fx-1,y:o.fy+o.fh},{x:o.fx+o.fw,y:o.fy+o.fh-1}];
  for(var i=0;i<cand.length;i++)if(oLibre(cand[i].x,cand[i].y))return cand[i];
  return celdaOakCerca(o.fx,o.fy+o.fh,5);
 }
 var PUERTA_TIENDA=puertaOak(TIENDA)||{x:74,y:41};
 for(var py0=40;py0<=52;py0++)for(var px0=62;px0<=82;px0++)if(oLibre(px0,py0))PLAZA.push({x:px0,y:py0});
 var CELDA_GEN=celdaOakCerca(Math.floor(GEN.x),Math.floor(GEN.y)+1,4)||{x:74,y:46};

 /* ======================================== COMBATE ======================================== */
 function crearMonB(s){
  var e={id:s.id,sk:s.sk,nombre:s.nb,alfa:!!s.alfa,pack:s.pack,x:s.x,y:s.y,hx:s.hx,hy:s.hy,vidaMax:s.vm,vida:s.vm,atkMin:s.a0,atkMax:s.a1,def:s.df,xp:s.xp,oro:s.oro,rec:s.rec,spd:s.spd,agro:s.agro,
   tipo:"normal",st:0,wind:0,windA:0,stunT:0,r:16,muerto:false,bid:1,dummy:false};
  if(s.jf){
   e.jefe=1;e.tipo="jefe";e.jd=jefeDef(s.jid);e.r=s.r||24;e.tipoDano=(e.jd&&e.jd.td)||"fisico";e.pEsq=0;e.pAbs=0;e.pBloq=0;e.pCrit=6;e.critMult=1.5;e.windK=0;
  }else{try{GM.armarEnemigo(e);}catch(x){e.tipoDano="fisico";e.pEsq=e.pAbs=e.pBloq=e.pCrit=0;e.critMult=1.5;}}
  return e;
 }
 function jefeDef(id){var L=MD&&MD.JEFES||[];for(var i=0;i<L.length;i++)if(L[i].id===id)return L[i];return null;}
 function habJ(e,k){var d=e&&e.jd;if(!d||!d.habs)return null;for(var i=0;i<d.habs.length;i++)if(d.habs[i].k===k)return d.habs[i];return null;}
 function vivos(b){var a=[];for(var id in b.MON){var e=b.MON[id];if(!e.muerto&&e.vida>0)a.push(e);}return a;}
 function dU(b,e){return Math.hypot(e.x*U-b.x*U,e.y*U-b.y*U);}     /* distancia en unidades (32 = 1 celda) */
 function dC(b,e){return Math.hypot(e.x-b.x,e.y-b.y);}
 function angA(b,e){return Math.atan2(e.y-b.y,e.x-b.x);}
 function jf2(e){return e.tipo==="jefe"?.5:e.tipo==="mini_jefe"?.7:1;}
 function alcanceB(b,e){return b.melee?MELEE_R[b.j.clase][0]*.8+e.r:(b.j.clase==="Mago"||b.j.clase==="Arquero"?6:4)*U;}
 function enAlcance(b,e,maxd){return dU(b,e)<=(maxd||(b.j.clase==="Asesino"?MAXT:MAXM))+e.r;}
 function circ(b,x,y,rad,fn){vivos(b).forEach(function(e){if(Math.hypot(e.x*U-x,e.y*U-y)<=rad+e.r)fn(e);});}
 function cono(b,x,y,ang,rango,arc,fn){vivos(b).forEach(function(e){var dx=e.x*U-x,dy=e.y*U-y,d=Math.hypot(dx,dy);if(d>rango+e.r)return;if(Math.abs(angd(Math.atan2(dy,dx),ang))<=arc/2||d<e.r+10)fn(e);});}
 function mejora(b,e){var M=b.M,m=1;if(M.exth&&e.vida<e.vidaMax*M.exth)m*=1+M.exv;if(M.elite&&e.tipo!=="normal")m*=1+M.elite;if(e.mk)m*=1+e.mk.dm;return m;}
 function B(b,i){return rnd(b.st.atkMin,Math.max(b.st.atkMin,b.st.atkMax))*GM.gmGlob(b.j,i);}

 /* daño del bot a un monstruo: misma cadena que herir() del cliente, y lo envía al servidor como mon_hit */
 function herir(b,e,raw,o){
  o=o||{};var PS=b.PS;if(!e||e.muerto||e.vida<=0||!PS.vivo)return 0;
  var st=b.st,j=b.j,M=b.M,crit=false;raw*=mejora(b,e);
  if(o.crit){var solo=vivos(b).filter(function(m){return dU(b,m)<420;}).length===1,cp=Math.min(60,b.crit)+(solo?M.critU*100:0);if(o.fc||Math.random()*100<cp){raw*=st.critMult;crit=true;}}
  var dfn=Math.floor(e.def*(1-M.ig)),d=GM.danoMitigado(Math.floor(raw),dfn,crit),df=GM.defensaEnemigo(e,d);d=df.d;
  if(df.ev==="esq")return 0;
  if(df.ev==="abs"){e.vida=Math.min(e.vidaMax,e.vida+df.cura);env(b,{t:"mon_fx",id:e.id,heal:df.cura});return 0;}
  e.vida-=d;PS.comb=6;PS.regW=REGEN_ESPERA;
  var tb0=j.tb,lsv=M.ls+(tb0?(tb0.vl||0)+(tb0.rb||0):0);if(tb0)tb0.acc=(tb0.acc||0)+d;if(lsv)PS.hp=Math.min(PS.max,PS.hp+Math.floor(d*lsv));
  var jf=e.tipo==="jefe"?.2:e.tipo==="mini_jefe"?.5:1,hkx=0,hky=0,hst=0;
  if(o.kb){var a=Math.atan2(e.y*U-b.y*U,e.x*U-b.x*U);hkx=Math.cos(a)*o.kb*jf*4/U;hky=Math.sin(a)*o.kb*jf*4/U;}
  if(o.stun){hst=o.stun*jf2(e);e.stunT=Math.max(e.stunT,hst);}
  env(b,{t:"mon_hit",id:e.id,d:d,kx:+hkx.toFixed(3),ky:+hky.toFixed(3),stun:+hst.toFixed(2)});
  if(o.heal){PS.hp=Math.min(PS.max,PS.hp+Math.floor(d*o.heal));}
  if(e.vida<0)e.vida=0;
  return d;
 }
 function aturde(b,e,s){e.stunT=Math.max(e.stunT,s);env(b,{t:"mon_fx",id:e.id,stun:+s.toFixed(2)});}
 function purgar(b){var PS=b.PS;PS.stunT=0;PS.silT=0;PS.resStun=0;}
 function aliados(b,fx,r){if(b.lugar!=="mundo"||!gDe(b.p))return;env(b,{t:"g_buff",fx:fx,r:r||12});}

 /* ataque básico (cuerpo a cuerpo en cono o proyectil guiado) */
 function atacar(b,e){
  var PS=b.PS,M=b.M,j=b.j;
  if(!e||e.muerto||PS.atkT>0||PS.stunT>0||b.dash||!PS.vivo)return false;
  if(dU(b,e)>alcanceB(b,e)+8)return false;
  var px=b.x*U,py=b.y*U,ang=angA(b,e),nx=PS.nx,R=MELEE_R[j.clase];
  PS.atkT=TS/(b.vel*(j.tb&&j.tb.vl2&&PS.hp<PS.max*.2?1.3:1))*.35;PS.comb=6;PS.regW=REGEN_ESPERA;b.dir=dirOf(Math.cos(ang),Math.sin(ang));
  if(M.dbl&&Math.random()<M.dbl)PS.atkT*=.35;
  if(M.rec)PS.mp=Math.min(PS.mpMax,PS.mp+M.rec);
  if(nx){nx.h--;if(nx.h<=0)PS.nx=null;}
  var f=GM.gmGlob(j,-1)*(1+M.clone);
  function B0(){return rnd(b.st.atkMin,Math.max(b.st.atkMin,b.st.atkMax));}
  if(b.melee){
   var ase=j.clase==="Asesino",hit=false,first=null;
   if(ase){var cand=[];cono(b,px,py,ang,R[0],R[1],function(m){cand.push(m);});var one=cand.indexOf(e)>=0?e:cand.sort(function(a,c){return dU(b,a)-dU(b,c);})[0];if(one){hit=true;first=one;herir(b,one,B0()*f*(nx?1+nx.dm:1),{crit:true,fc:!!nx,kb:90});}}
   else cono(b,px,py,ang,R[0],R[1],function(m){hit=true;if(!first)first=m;herir(b,m,B0()*f*(nx?1+nx.dm:1),{crit:true,fc:!!nx,kb:90});});
   if(hit)PS.mp=Math.min(PS.mpMax,PS.mp+PS.mpMax*HIT_GAIN);
  }else{
   var mago=j.clase==="Mago"||j.clase==="Clérigo",t=dU(b,e)/(mago?560:700),id=e.id;
   tarde(b,t,function(){var m=b.MON[id];if(!m||m.muerto)return;herir(b,m,B0()*f*(nx?1+nx.dm:1),{crit:true,fc:!!nx,kb:70});PS.mp=Math.min(PS.mpMax,PS.mp+PS.mpMax*HIT_GAIN);});
  }
  return true;
 }

 /* habilidades (mismos efectos y números que lanzarH/lanzarRama del cliente; sin gráficos) */
 function lanzarH(b,i,e){
  var h=b.habs[i],PS=b.PS,j=b.j,st=b.st,M=b.M,ef=h&&h.efecto,ok=true,px=b.x*U,py=b.y*U,ang=e?angA(b,e):b.dir*0;
  if(!h||PS.stunT>0||PS.silT>0||PS.cd[i]>0||PS.mp<h.costo||b.dash||!PS.vivo)return false;
  function Bi(){return B(b,i);}
  var melee1=function(){if(!e||!enAlcance(b,e))return false;return true;};
  if(ef==="dano_150_stun"){
   if(!melee1())ok=false;else{herir(b,e,Bi()*1.5,{stun:1.5,kb:150});cono(b,px,py,ang,115,2.4,function(m){if(m!==e)herir(b,m,Bi()*1.5,{stun:1.5,kb:150});});}
  }else if(ef==="def_30_2t"||ef==="def_50_3t"){
   var sac=ef.indexOf("50")>=0,bo=Math.floor((sac?50:Math.floor(st.def*.3))*st.potencia*(1+M["bp"+i]));
   PS.defB=bo;PS.defT=((ef.indexOf("3t")>=0?3:2)+M.durx)*TS;
   if(sac)aliados(b,{n:"Sentencia de Luz",col:"#ffe080",dfl:bo,dfT:PS.defT});
  }else if(ef==="robo_vida_50"){
   if(!melee1())ok=false;else{herir(b,e,Bi(),{heal:.5,kb:100});cono(b,px,py,ang,100,1.6,function(m){if(m!==e)herir(b,m,Bi(),{heal:.5,kb:100});});}
  }else if(ef==="escudo_vida"){PS.sh=Math.floor(PS.max*.4*st.potencia);PS.shT=8;
  }else if(ef==="dano_200"){
   if(!e||dU(b,e)>620)ok=false;else{var id=e.id;tarde(b,dU(b,e)/950,function(){var m=b.MON[id];if(m&&!m.muerto)herir(b,m,Bi()*2,{kb:130});});}
  }else if(ef==="fuego_250"){
   if(!e||dU(b,e)>620)ok=false;else{var id2=e.id;tarde(b,dU(b,e)/520,function(){var m=b.MON[id2];if(!m||m.muerto)return;herir(b,m,Bi()*2.5,{kb:90});circ(b,m.x*U,m.y*U,95,function(o){if(o!==m)herir(b,o,Bi()*2.5*.5,{kb:80});});});}
  }else if(ef==="stun_aoe"){circ(b,px,py,185,function(m){herir(b,m,Bi()*.7*(1+M.aoe),{stun:2,kb:60});});
  }else if(ef==="aoe_75"){
   if(!e||dU(b,e)>620)ok=false;else{var cx0=e.x*U,cy0=e.y*U,mult=.45*(1+M.aoe);[.35,.7,1.05].forEach(function(t){tarde(b,t,function(){circ(b,cx0,cy0,120,function(m){herir(b,m,Bi()*mult,{kb:40});});});});}
  }else if(ef==="aoe_140"){
   if(!melee1())ok=false;else circ(b,e.x*U,e.y*U,155,function(m){herir(b,m,Bi()*1.4*(1+M.aoe),{kb:120});});
  }else if(ef==="vida_max_75"){
   PS.hp=Math.min(PS.max,PS.hp+Math.floor(PS.max*.75));aliados(b,{n:"Bendición de Poderío",col:"#7ab88a",hp:.75});
  }else if(ef==="punalada"){
   if(!melee1())ok=false;else{var a0=angA(b,e);b.x=e.x-Math.cos(a0)*.9;b.y=e.y-Math.sin(a0)*.9;herir(b,e,Bi()*2.5,{kb:40});}
  }else if(ef==="stun_2"){circ(b,px,py,165,function(m){aturde(b,m,3.5*jf2(m));});PS.invT=Math.max(PS.invT,2);
  }else if(ef==="atk_mult"){
   var ls=vivos(b).filter(function(m){return m!==e&&dU(b,m)<=MAXT;}).sort(function(a,c){return a.vida-c.vida;});if(e)ls=[e].concat(ls);ls=ls.slice(0,3);
   if(!ls.length||!enAlcance(b,ls[0]))ok=false;else for(var q=0;q<3;q++)(function(q){var t=ls[q%ls.length],id3=t.id;tarde(b,q*.18,function(){var m=b.MON[id3];if(m&&!m.muerto){var a1=angA(b,m);b.x=m.x-Math.cos(a1)*.9;b.y=m.y-Math.sin(a1)*.9;herir(b,m,Bi(),{kb:30});}});})(q);
  }else if(ef==="inmunidad_60"){
   var aw=e?angA(b,e)+Math.PI:b.dir*1.57;b.dash={t:.22,vx:Math.cos(aw)*240/.22/U,vy:Math.sin(aw)*240/.22/U};PS.invT=Math.max(PS.invT,2);
   if(e)herir(b,e,Bi()*.6,{});
  }else if(ef==="pulso_vital"){
   var hv=.25*GM.curaMult(j)*(1+M.bp0);PS.hp=Math.min(PS.max,PS.hp+Math.floor(PS.max*hv));
   aliados(b,{n:"Pulso Vital",col:"#8ff0d0",hp:hv},175/U+1);
   circ(b,px,py,175,function(m){herir(b,m,Bi()*1.1*(1+M.aoe),{kb:70});});
  }else if(ef==="egida_rad"){
   var bo2=Math.floor(st.def*.4*st.potencia*(1+M.bp1)),es2=Math.floor(PS.max*.2*st.potencia*(1+M.cura));
   PS.defB=bo2;PS.defT=(3+M.durx)*TS;PS.sh=es2;PS.shT=Math.max(8,PS.defT);
   aliados(b,{n:"Égida Radiante",col:"#8ff0d0",df:.4*st.potencia*(1+M.bp1),dfT:PS.defT,sh:.2*st.potencia*(1+M.cura),shT:PS.shT});
  }else if(ef==="pureza"){
   purgar(b);j.tb={n:"Pureza",t:(3+M.durx)*TS,dm:.25*GM.potBuff(st)*(1+M.bp2),cc:1,acc:0};
   aliados(b,{n:"Plegaria de Pureza",col:"#ffe9a0",pur:1,tb:{n:"Pureza",t:j.tb.t,dm:j.tb.dm,cc:1}});
  }else if(ef==="rama")ok=lanzarRama(b,h.rama,i,e);
  else ok=false;
  if(ok){PS.mp-=h.costo;PS.cd[i]=h.cd*TS;PS.comb=6;PS.regW=REGEN_ESPERA;if(e)b.dir=dirOf(Math.cos(angA(b,e)),Math.sin(angA(b,e)));}
  return ok;
 }
 function lanzarRama(b,sk,i,e){
  var j=b.j,st=b.st,M=b.M,PS=b.PS,k=sk.s,pw0=1+M[k+"p"],px=b.x*U,py=b.y*U,mCls=(j.clase==="Guerrero"||j.clase==="Paladin");
  function base(){return B(b,i);}
  if(sk.k==="d"){
   var h=(sk.h||1)+M[k+"h"],tg,cen,rad;
   if(sk.a){
    if(mCls){if(e){if(!enAlcance(b,e))return false;cen=j.clase==="Guerrero"?{x:px,y:py}:{x:e.x*U,y:e.y*U};}else cen={x:px,y:py};rad=175;}
    else{if(!e)return false;cen={x:e.x*U,y:e.y*U};rad=140;}
    tg=vivos(b).filter(function(m){return Math.hypot(m.x*U-cen.x,m.y*U-cen.y)<=rad+m.r;});
   }else{
    var melee=mCls||j.clase==="Asesino";
    if(!e||!enAlcance(b,e,melee?0:620))return false;
    if(melee){var a0=angA(b,e);b.x=e.x-Math.cos(a0)*.9;b.y=e.y-Math.sin(a0)*.9;}
    tg=[e];
   }
   if(!tg.length)return false;
   var esc=1+(sk.esc||0)*tg.length,sg=1+(sk.sg||0)+M[k+"sg"]+M.sg,ig=Math.min(1,(sk.ig||0)+M[k+"ig"]+M.ig),stn=sk.st?(sk.st+M[k+"st"]+M.stb)*1.25:0,cp=Math.min(60,b.crit);
   if(sk.sdf){PS.defB=-Math.floor(st.def*sk.sdf);PS.defT=4;}
   var ids=tg.map(function(m){return m.id;});
   for(var n=0;n<h;n++)(function(n){tarde(b,n*.14,function(){ids.forEach(function(id){var m=b.MON[id];if(!m||m.muerto)return;
    var cr=1;if(sk.cr||(sk.fx&&m.stunT>0)||(sk.ci&&Math.random()*100<cp+sk.ci*100*n))cr=st.critMult*(m.stunT>0?1+M.fz:1);
    var mm=sk.m*((sk.fm&&n===h-1)?sk.fm:1)*((sk.und&&/No-Muerto|Espectro|Momia|Lich|Alma|Sombra/.test(m.nombre))?2:1),dd=m.def;m.def=Math.floor(dd*(1-ig));
    herir(b,m,base()*mm*pw0*esc*cr*sg,{kb:30});m.def=dd;});});})(n);
   tarde(b,h*.14+.03,function(){ids.forEach(function(id){var m=b.MON[id];if(!m||m.muerto)return;if(stn)aturde(b,m,stn*jf2(m));if(sk.dd){m.def=Math.floor(m.def*(1-sk.dd));env(b,{t:"mon_fx",id:m.id,dd:sk.dd});}});
    if(sk.lh&&ids.length){PS.hp=Math.min(PS.max,PS.hp+Math.floor(PS.max*sk.lh*Math.min(6,ids.length)*GM.curaMult(j)));}
    var xe=M[k+"ex"];if(xe)vivos(b).forEach(function(m){if(m.tipo==="normal"&&m.vida>0&&m.vida<m.vidaMax*xe&&dU(b,m)<420){m.vida=0;env(b,{t:"mon_hit",id:m.id,d:0,ex:1});}});
    if(sk.rs&&ids.length){var t0=b.MON[ids[0]];if(!t0||t0.muerto||t0.vida<=0){PS.cd[i]=0;PS.mp=Math.min(PS.mpMax,PS.mp+sk.rs);}}});
   return true;
  }
  if(sk.k==="b"){
   if(sk.t)j.tb={n:sk.n,t:sk.t,dm:(sk.dm||0)*pw0,rb:sk.rb||0,vl:sk.vl||0,vl2:sk.vl2||0,dpl:sk.dpl||0,cc:sk.cc||0,red:Math.min(.9,(sk.red||0)*pw0),reg:(sk.reg||0)*pw0,ref:(sk.ref||0)+M[k+"ref"],hp:M[k+"hp"],acc:0};
   if(sk.inv)PS.invT=Math.max(PS.invT,sk.inv*1.5);
   var sh=((sk.sh||0)+M[k+"sh"])*(sk.sh?pw0:1)*(1+M.cura);if(sh){PS.sh=Math.floor(PS.max*sh);PS.shT=8;}
   if(sk.hl)PS.hp=Math.min(PS.max,PS.hp+Math.floor(PS.max*sk.hl*pw0*GM.curaMult(j)));
   if(sk.df){PS.defB=Math.floor(st.def*sk.df*pw0);PS.defT=sk.t;}
   if(sk.pur)purgar(b);
   if(sk.nx)PS.nx={dm:sk.nx.dm*pw0,bn:sk.nx.bn||0,h:1+M[k+"nx"]};
   if(j.clase==="Paladin"||j.clase==="Clérigo"){var fa={n:sk.n,col:"#ffe9a0"};if(sk.hl)fa.hp=sk.hl*pw0*GM.curaMult(j);if(sk.df){fa.df=sk.df*pw0;fa.dfT=sk.t;}if(sh){fa.sh=sh;fa.shT=8;}if(sk.pur)fa.pur=1;if(sk.inv)fa.inv=sk.inv*1.5;
    if(sk.t)fa.tb={n:sk.n,t:sk.t,dm:(sk.dm||0)*pw0,red:Math.min(.9,(sk.red||0)*pw0),reg:(sk.reg||0)*pw0,cc:sk.cc||0};aliados(b,fa);}
   return true;
  }
  if(!e)return false;
  e.mk={dm:sk.dm,cof:(sk.cof||0)+M[k+"cof"],orp:(sk.orp||0)+M[k+"oro"],bf:sk.bf||null};return true;
 }

 /* pociones (cinturón Q/R del juego) */
 function potCuenta(b,tipo){var n=0;GM.POCIONES.forEach(function(p){if(p.tipo===tipo||p.tipo==="full")n+=b.j.inventario[p.n]||0;});return n;}
 function usaPocion(b,auto){
  var j=b.j,PS=b.PS;if(PS.potT>0||!PS.vivo)return false;
  var tipo=auto==="v"?"vida":"recurso",cand=GM.POCIONES.filter(function(q){return q.tipo===tipo&&(j.inventario[q.n]||0)>0;}).sort(function(a,c){return a.pct-c.pct;});
  if(!cand.length)cand=GM.POCIONES.filter(function(q){return q.tipo==="full"&&(j.inventario[q.n]||0)>0;});
  if(!cand.length)return false;
  var mx=auto==="v"?PS.max:PS.mpMax,cur=auto==="v"?PS.hp:PS.mp,falta=mx-cur,f=1;
  var p=cand.filter(function(q){return Math.floor(mx*q.pct*f)>=falta;})[0]||cand[cand.length-1];
  j.inventario[p.n]--;if(j.inventario[p.n]<=0)delete j.inventario[p.n];
  if(p.tipo==="full"){PS.hp=PS.max;PS.mp=PS.mpMax;}
  else if(p.tipo==="vida")PS.hp=Math.min(PS.max,PS.hp+Math.floor(PS.max*p.pct*f));
  else PS.mp=Math.min(PS.mpMax,PS.mp+Math.floor(PS.mpMax*p.pct*f));
  PS.potT=POT_CD;return true;
 }

 /* daño recibido (igual que golpeMon del cliente) */
 function golpeMon(b,m,mx,stn){
  var PS=b.PS,j=b.j,M=b.M,st=b.st;if(!PS.vivo)return;
  var tipo=m.tipoDano||"fisico";
  if(PS.invT>0)return;
  if(tipo==="fisico"&&Math.random()*100<(st.probEsq||0))return;
  var base=Math.floor(rnd(m.atkMin,m.atkMax)*(mx||1)),critE=Math.random()*100<(m.pCrit||0);if(critE)base=Math.floor(base*(m.critMult||1.5));
  var def=st.def+(PS.defT>0?PS.defB:0)+(tipo==="magico"?(st.redMag||0):(st.redFis||0));
  var d=GM.danoMitigado(base,def,critE),dr=Math.min(.9,M.dr+(j.tb&&j.tb.red||0));
  d=Math.max(Math.floor(d*(1-dr)),Math.max(1,Math.floor(base*(GM.PISO_DANO||.3))));
  if(PS.sh>0){if(d<=PS.sh){PS.sh-=d;d=0;}else{d-=PS.sh;PS.sh=0;}}
  PS.hp-=d;PS.comb=6;PS.regW=REGEN_ESPERA;b.golpeado=b.t;
  if(stn>0&&d>0&&!(PS.resStun>0)&&!(j.tb&&j.tb.cc)){PS.stunT=Math.max(PS.stunT,stn);PS.resStun=stn+2.5;}
  if(j.tb&&j.tb.ref&&d>0)herir(b,m,d*j.tb.ref,{});
  if(!(PS.hp>0)){PS.hp=0;morir(b);}
 }
 function morir(b){
  if(b.muerte)return;b.muerte={t:0,hecho:false};b.PS.vivo=false;b.tg=0;b.path=null;b.ruta=null;b.dash=null;b.TML.length=0;b.muertes++;b.muertesRec.push(Date.now());
  env(b,{t:"mon_est",mu:1});log("☠ Bot "+b.nombre+" (Nv "+b.j.nivel+") cae en combate.");
 }
 function muerteStep(b,dt){
  var m=b.muerte;m.t+=dt;
  if(!m.hecho&&m.t>=.9&&b.lugar==="mundo"){
   m.hecho=true;var ok=false;
   for(var n=0;n<60&&!ok;n++){var X=Math.floor(CC.x)+rnd(-3,3),Y=Math.floor(CC.y)+3+rnd(0,3);if(mLibre(X,Y)){b.x=X+.5;b.y=Y+.5;ok=true;}}
   var PS=b.PS;PS.hp=Math.max(1,Math.floor(PS.max*.5));PS.comb=0;PS.regW=0;PS.sh=0;PS.shT=0;PS.defB=0;PS.defT=0;PS.invT=0;PS.stunT=0;PS.silT=0;PS.nx=null;b.j.tb=null;
   env(b,{t:"mover",x:r2(b.x),y:r2(b.y),dir:"s"});env(b,{t:"mon_est",mu:0});
  }
  if(m.t>=1.8){b.muerte=null;b.PS.vivo=true;b.auto="descanso";b.flee=false;b.sector=null;}
 }

 /* recompensa al caer un monstruo (XP, oro, botín y almas con las reglas del juego) */
 function recompensa(b,e){
  var j=b.j,xp=Math.max(1,Math.floor(e.xp*e.rec)),n0=j.nivel,oro0=j.oro;
  try{
   GM.G.log=[];GM.ganarXP(j,xp);GM.dropearLoot(e,j);
   var dO=j.oro-oro0;if(e.rec>1&&dO>0)j.oro+=Math.floor(dO*(e.rec-1));
   try{GM.cosechar(j,e);}catch(x){}
   try{if(e.mk&&GM.marcaMuerta)GM.marcaMuerta(j,e);}catch(x){}
  }catch(x){}
  GM.G.log=[];b.kills++;
  if(j.nivel>n0)alSubir(b,n0);
 }
 function alSubir(b,n0){
  var PS=b.PS;alCambiarStats(b);elegirRamaYTalentos(b);PS.hp=PS.max;PS.mp=PS.mpMax;b.sector=null;
  log("★ Bot "+b.nombre+" ("+b.j.clase+") sube al nivel "+b.j.nivel);
  if(b.j.nivel%5===0&&Math.random()<.7)tarde(b,rf(1,3),function(){decir(b,pick(["¡Nivel "+b.j.nivel+"!","Por fin, nivel "+b.j.nivel+" 💪","¡Ya soy nivel "+b.j.nivel+"!"]));});
 }
 function botinJefe(b,m){
  var j=b.j,n0=j.nivel;
  try{GM.G.log=[];if(m.xp>0)GM.ganarXP(j,m.xp);GM.G.log=[];if(m.oro>0)j.oro=(j.oro||0)+m.oro;
   if(m.item&&m.para===b.p.id){var r=(GM.RECETAS_FORJA||[]).filter(function(a){return a[0]===m.item;})[0];if(r)GM.equipoBolsa(j).push(GM.copiaItem(GM.recetaObj(r)));}}catch(x){}
  if(j.nivel>n0)alSubir(b,n0);
 }
 /* refuerzos de Paladín/Clérigo de otros jugadores */
 function recibeBuff(b,m){
  var f=m.fx,PS=b.PS,j=b.j;if(!f||!PS.vivo)return;
  if(f.hp>0)PS.hp=Math.min(PS.max,PS.hp+Math.floor(PS.max*f.hp));
  if(f.df>0||f.dfl>0){var bo=Math.floor((f.dfl||0)+b.st.def*(f.df||0));if(bo>0&&(PS.defT<=0||bo>=PS.defB)){PS.defB=bo;PS.defT=f.dfT>0?f.dfT:6;}}
  if(f.sh>0){var es=Math.floor(PS.max*f.sh);if(es>PS.sh){PS.sh=es;PS.shT=Math.max(8,f.shT||0);}}
  if(f.pur)purgar(b);if(f.inv>0)PS.invT=Math.max(PS.invT,f.inv);
  if(f.tb&&f.tb.t>0){var o=j.tb;if(!o||!(o.t>0)||(o.dm||0)<=(f.tb.dm||0))j.tb={n:f.tb.n,t:f.tb.t,dm:f.tb.dm||0,red:f.tb.red||0,reg:f.tb.reg||0,cc:f.tb.cc||0,acc:0};}
 }
 function mLibre(x,y){return x>=0&&y>=0&&x<W&&y<W&&!blk[y*W+x]&&sec[y*W+x]>=0;}

 /* temporizadores de combate, regeneración y efectos (como el bucle del cliente) */
 function timers(b,dt){
  var PS=b.PS,j=b.j,i;
  PS.atkT-=dt;PS.potT-=dt;for(i=0;i<5;i++)PS.cd[i]-=dt;PS.comb-=dt;PS.regW-=dt;PS.stunT-=dt;PS.silT-=dt;PS.resStun-=dt;PS.invT-=dt;
  if(PS.defT>0){PS.defT-=dt;if(PS.defT<=0)PS.defB=0;}
  if(PS.shT>0){PS.shT-=dt;if(PS.shT<=0)PS.sh=0;}
  if(PS.sprT>0){PS.sprT-=dt;if(PS.sprT<=0)PS.sprCd=SPR_CD;}else if(PS.sprCd>0)PS.sprCd-=dt;
  var tb=j.tb;if(tb){tb.t-=dt;if(tb.reg){tb.rg=(tb.rg||0)+dt;if(tb.rg>=TS){tb.rg-=TS;PS.hp=Math.min(PS.max,PS.hp+Math.floor(PS.max*tb.reg));}}if(tb.t<=0)j.tb=null;}
  if(!PS.vivo)return;
  var ciudad=b.lugar==="oakhaven",camp=!ciudad&&MD&&Math.hypot(b.x-CC.x,b.y-CC.y)<MD.MON_SEGURA-.5;
  if(ciudad||camp){PS.hp=Math.min(PS.max,PS.hp+PS.max*.06*dt);PS.mp=Math.min(PS.mpMax,PS.mp+PS.mpMax*.08*dt);}
  else if(PS.regW<=0){PS.hp=Math.min(PS.max,PS.hp+PS.max*.012*dt);PS.mp=Math.min(PS.mpMax,PS.mp+PS.mpMax*REGEN_MP*dt);}
  if(PS.hp>PS.max)PS.hp=PS.max;
  for(i=b.TML.length-1;i>=0;i--){var t=b.TML[i];t.t-=dt;if(t.t<=0){b.TML.splice(i,1);try{t.fn();}catch(e){}}}
  if(b.dash){var d=b.dash,s=Math.min(dt,d.t),nx=b.x+d.vx*s,ny=b.y+d.vy*s;if(b.lugar==="mundo"&&mLibre(Math.floor(nx),Math.floor(ny))){b.x=nx;b.y=ny;}d.t-=dt;if(d.t<=0)b.dash=null;}
 }

 /* ======================================== MOVIMIENTO ======================================== */
 function pasoMundo(b,tx,ty,sp,dt){
  var ox=b.x,oy=b.y;
  if(NAVB)NAVB.paso(b,tx,ty,sp,dt);
  else{var dx=tx-b.x,dy=ty-b.y,d=Math.hypot(dx,dy);if(d>.05){var s=Math.min(d,sp*dt),nx=b.x+dx/d*s,ny=b.y+dy/d*s;if(SIM.jLibre(nx,ny)){b.x=nx;b.y=ny;}else if(SIM.jLibre(nx,b.y))b.x=nx;else if(SIM.jLibre(b.x,ny))b.y=ny;}}
  var mx=b.x-ox,my=b.y-oy;if(Math.abs(mx)+Math.abs(my)>1e-4)b.dir=dirOf(mx,my);
 }
 function velMundo(b){return SPD_MUN*(b.PS.sprT>0?SPR_MULT:1)*(b.PS.stunT>0?0:1);}
 function rutaMundo(b,gx,gy){   /* BFS desde la meta: ruta global fiable entre sectores; devuelve waypoints cada ~8 celdas */
  var g0=Math.floor(gx),g1=Math.floor(gy),s0=Math.floor(b.x),s1=Math.floor(b.y);
  function cerca(x,y,r){if(mLibre(x,y))return{x:x,y:y};for(var k=1;k<=r;k++)for(var c=-k;c<=k;c++)for(var a=-k;a<=k;a++){if(Math.max(Math.abs(a),Math.abs(c))!==k)continue;if(mLibre(x+a,y+c))return{x:x+a,y:y+c};}return null;}
  var G=cerca(g0,g1,6),S=cerca(s0,s1,4);if(!G||!S)return null;
  var g=G.y*W+G.x,s=S.y*W+S.x;bst++;var qh=0,qt=0,found=g===s;BS[g]=bst;BD[g]=0;BQ[qt++]=g;
  while(qh<qt&&!found){var c0=BQ[qh++],cx=c0%W,cy=(c0/W)|0,d0=BD[c0]+1;
   for(var k=0;k<4;k++){var nx=cx+DX[k],ny=cy+DY[k];if(nx<0||ny<0||nx>=W||ny>=W)continue;var j=ny*W+nx;if(BS[j]===bst||blk[j]||sec[j]<0)continue;BS[j]=bst;BD[j]=d0;BQ[qt++]=j;if(j===s){found=true;break;}}}
  if(!found)return null;
  var path=[],cur=s,cd=BD[s],ld=0;
  while(cur!==g){var x=cur%W,y=(cur/W)|0,nxt=-1;
   for(var q=0;q<4;q++){var k2=(ld+q)%4,X=x+DX[k2],Y=y+DY[k2];if(X<0||Y<0||X>=W||Y>=W)continue;var nj=Y*W+X;if(BS[nj]===bst&&BD[nj]===cd-1){nxt=nj;ld=k2;break;}}
   if(nxt<0)break;cur=nxt;cd--;path.push(cur);}
  var wp=[];for(var i=7;i<path.length;i+=8)wp.push({x:(path[i]%W)+.5,y:((path[i]/W)|0)+.5});wp.push({x:(g%W)+.5,y:((g/W)|0)+.5});return wp;
 }
 /* viaja hacia (x,y): cerca usa A* local, lejos usa ruta global. Devuelve "llego" | "ruta" | "fallo" */
 function viajar(b,dt,x,y,sprint){
  var d=Math.hypot(x-b.x,y-b.y);
  if(d<1.4){b.ruta=null;return "llego";}
  if(sprint&&d>14&&b.PS.sprT<=0&&b.PS.sprCd<=0)b.PS.sprT=SPR_DUR;
  if(d<12){b.ruta=null;pasoMundo(b,x,y,velMundo(b),dt);return "ruta";}
  var ahora=Date.now();
  if(!b.ruta||!b.dest||Math.hypot(b.dest.x-x,b.dest.y-y)>3.5){
   if(b.ruta&&ahora-b.rutaT<700){}else{b.dest={x:x,y:y};b.ruta=rutaMundo(b,x,y);b.rutaI=0;b.rutaT=ahora;b.atascoT=0;b.progX=b.x;b.progY=b.y;if(!b.ruta)return "fallo";}
  }
  var wp=b.ruta&&b.ruta[b.rutaI];if(!wp){b.ruta=null;return "ruta";}
  pasoMundo(b,wp.x,wp.y,velMundo(b),dt);
  if(Math.hypot(wp.x-b.x,wp.y-b.y)<1.3)b.rutaI++;
  b.atascoT+=dt;if(b.atascoT>3){if(Math.hypot(b.x-b.progX,b.y-b.progY)<1){b.ruta=null;b.rutaT=0;}b.progX=b.x;b.progY=b.y;b.atascoT=0;}
  return "ruta";
 }
 /* Oakhaven: ruta por celdas (BFS) y caminata a 4,2 celdas/s */
 function rutaOak(b,x,y){
  var c0=celdaOakCerca(Math.floor(b.x),Math.floor(b.y),4),c1=celdaOakCerca(Math.floor(x),Math.floor(y),4);
  if(!c0||!c1){b.path=null;return false;}
  b.path=bfsOak(c0.x,c0.y,c1.x,c1.y);b.pathDest={x:c1.x,y:c1.y};return !!b.path;
 }
 function caminarOak(b,dt,mult){
  if(!b.path||!b.path.length){b.path=null;b.mv=0;return true;}
  var c=b.path[0],tx=c.x+.5,ty=c.y+.5,dx=tx-b.x,dy=ty-b.y,d=Math.hypot(dx,dy),st=SPD_OAK*(mult||1)*dt;
  if(d<=st){b.x=tx;b.y=ty;b.path.shift();}else{b.x+=dx/d*st;b.y+=dy/d*st;}
  b.dir=dirOf(dx,dy);b.mv=1;
  if(!b.path.length){b.path=null;return true;}
  return false;
 }

 /* ======================================== DECISIONES ======================================== */
 var ESTM={v:.9625,a:.9125,d:.7875};   /* medias de STATS_ENEM del bioma 1 (vida, ataque, defensa) */
 function monMedio(d){
  var pe=d.pe,mp=Math.min(9,pe);
  var vida=Math.floor(Math.floor((80+mp*2+pe*1.2)*ESTM.v*1.44)*1.75*d.vida),a=Math.floor((15+mp+pe*.28)*ESTM.a*1.44*d.dano),df=Math.floor(Math.floor((15+mp+pe*.45)*ESTM.d*1.38)*(1+(d.vida-1)*.5));
  return{vida:vida,a:a,df:df,xp:(15+pe*2)*d.rec};
 }
 /* fracción de la vida del bot que costaría, de media, matar a un monstruo de ese sector */
 function riesgo(b,d){
  var m=monMedio(d),st=b.st,atk=(st.atkMin+st.atkMax)/2,cc=Math.min(.6,b.crit/100),hit=atk*(1+cc*(st.critMult-1));
  var dmg=Math.max(GM.danoMitigado(Math.floor(hit),Math.floor(m.df),false),1),dps=dmg/(TS/b.vel*.35)*.8*(b.j.clase==="Clérigo"?1:1.35);
  var ttk=m.vida/Math.max(1,dps),mit=GM.danoMitigado(m.a,st.def+(st.redFis||0),false),mdps=mit/1.05*(1-Math.min(.35,(st.probEsq||0)/100));
  var r=ttk*mdps*1.3/Math.max(1,st.vidaMax);
  return b.melee?r:r*.8;
 }
 function elegirSector(b){
  if(!SECT.length)return null;
  var rec=0,ahora=Date.now();b.muertesRec=b.muertesRec.filter(function(t){return ahora-t<15*60000;});rec=b.muertesRec.length;
  var lim=CFG.RIESGO*b.prud*Math.pow(.72,rec),best=SECT[0],br=riesgo(b,SECT[0].dif);
  SECT.forEach(function(s){var r=riesgo(b,s.dif);if(r<=lim&&s.dif.pe>=best.dif.pe){best=s;br=r;}});
  b.riesgoAct=br;b.puedeAlfa=br<.17;
  return best;
 }
 function puntoCaza(b){
  var s=b.sector||SECT[0];
  for(var n=0;n<40;n++){var a=Math.random()*6.283,r=s.id===0?rf(17,32):rf(6,30),x=s.cx+Math.cos(a)*r,y=s.cy+Math.sin(a)*r;
   if(mLibre(Math.floor(x),Math.floor(y))&&Math.hypot(x-CC.x,y-CC.y)>MD.MON_SEGURA+2)return{x:Math.floor(x)+.5,y:Math.floor(y)+.5};}
  return{x:CC.x+16,y:CC.y+4};
 }
 function matCount(b){var n=0;for(var k in b.j.inventario)if(GM.esMaterial(k))n+=b.j.inventario[k];return n;}
 function refGrupo(b,g){
  if(!g)return null;var l=J[g.lider];if(l&&!l.bot)return l;
  for(var i=0;i<g.miembros.length;i++){var q=J[g.miembros[i]];if(q&&!q.bot)return q;}return null;
 }

 /* ---- combate: elige objetivo, usa habilidades, se acerca/retira, esquiva y bebe pociones ---- */
 function elegirObj(b,c,vs){
  var best=null,bs=1e9;
  vs.forEach(function(m){
   if(m.jefe&&(!c.jefe||m.st!==1))return;
   if(c.soloChasers&&m.st!==1)return;
   var d=dC(b,m);
   if(c.ref){if(dC(c.ref,m)>c.radio)return;}else{if(d>34||m.st===2)return;if(m.alfa&&!b.puedeAlfa&&m.st!==1)return;}
   var s=d-(m.st===1?7:0)-(m.id===b.tg?4:0)-(m.vida<m.vidaMax*.5?2:0);
   if(!c.ref&&m.st===0){var n=0;vs.forEach(function(o){if(o.pack&&o.pack===m.pack&&o!==m)n++;});if(n>=3)s+=12;}
   if(s<bs){bs=s;best=m;}
  });
  return best;
 }
 function apoyo(b,g){
  if(!b.cura||!g)return false;var PS=b.PS,i=b.j.clase==="Clérigo"?0:2,H=b.habs[i];
  if(!H||PS.cd[i]>0||PS.mp<H.costo||PS.silT>0)return false;
  var bajo=0;g.miembros.forEach(function(id){var q=J[id];if(!q||q.id===b.p.id||q.lugar!=="mundo"||!q.hpMax)return;if(Math.hypot(q.x-b.x,q.y-b.y)<5.3&&q.hp/q.hpMax<.55)bajo++;});
  if(bajo>0||PS.hp<PS.max*.45)return lanzarH(b,i,null);
  return false;
 }
 function usarHabs(b,e,vs,ch){
  var PS=b.PS,H=b.habs,cl=b.j.clase,hpf=PS.hp/PS.max,n=ch.filter(function(m){return dC(b,m)<6;}).length,d=dU(b,e),alc=alcanceB(b,e);
  function ok(i){return H[i]&&PS.cd[i]<=0&&PS.mp>=H[i].costo&&PS.silT<=0;}
  function go(i){return ok(i)&&lanzarH(b,i,e);}
  var cerca=vivos(b).filter(function(m){return dU(b,m)<190;}).length;
  if(PS.stunT>0)return false;
  if(cl==="Guerrero"){if(n>=2&&PS.defT<=0&&go(1))return true;if(hpf<.55&&d<=alc&&go(2))return true;if(d<=alc&&go(0))return true;}
  else if(cl==="Mago"){if((hpf<.7||n>=2)&&PS.sh<=0&&go(2))return true;if((cerca>=2||(n>=1&&d<3*U))&&go(1))return true;if(d>1.5*U&&go(0))return true;}
  else if(cl==="Arquero"){if(n>=1&&d<2.6*U&&go(2))return true;var agr=vivos(b).filter(function(m){return Math.hypot(m.x-e.x,m.y-e.y)<3.7;}).length;if(agr>=2&&go(1))return true;if(go(0))return true;}
  else if(cl==="Paladin"){if(n>=1&&PS.defT<=0&&go(1))return true;if(hpf<.5&&go(2))return true;if(d<=alc&&(cerca>=1)&&go(0))return true;}
  else if(cl==="Asesino"){if((n>=3||hpf<.45)&&go(1))return true;if(go(0))return true;if((n>=2||e.vida>e.vidaMax*.4)&&go(2))return true;}
  else if(cl==="Clérigo"){if(n>=1&&PS.defT<=0&&go(1))return true;if((hpf<.7||cerca>=2)&&go(0))return true;if(!(b.j.tb&&b.j.tb.t>0)&&n>=1&&go(2))return true;}
  var tbOn=b.j.tb&&b.j.tb.t>0;
  for(var i=3;i<H.length;i++){var sk=H[i].rama;if(!sk||!ok(i))continue;
   if(sk.k==="b"){var def=sk.hl||sk.sh||sk.red||sk.pur;if(def?(hpf<.65&&PS.comb>0):(!tbOn&&e.vida>e.vidaMax*.35&&(n>=1||PS.comb>0))){if(go(i))return true;}}
   else if(go(i))return true;}
  return false;
 }
 function combate(b,dt,c){
  var PS=b.PS;if(!PS.vivo)return false;
  if(PS.hp<PS.max*.4)usaPocion(b,"v");else if(PS.mp<PS.mpMax*.15&&PS.comb>0&&potCuenta(b,"recurso")>0)usaPocion(b,"r");
  var vs=vivos(b),ch=vs.filter(function(m){return m.st===1&&dC(b,m)<14&&!m.jefe;});
  var g=gDe(b.p);
  if(!c.ref&&((PS.hp<PS.max*.3&&potCuenta(b,"vida")===0)||(PS.hp<PS.max*.2&&ch.length>=2))){b.flee=true;b.tg=0;}
  if(b.flee)return false;
  if(PS.stunT>0)return true;
  if(c.ref&&dC(b,c.ref)>c.leash)return false;
  apoyo(b,g);
  var e=b.MON[b.tg];
  if(!e||e.muerto||e.vida<=0||(e.jefe&&!c.jefe))e=null;
  if(!e||(c.ref&&dC(c.ref,e)>c.radio)){e=elegirObj(b,c,vs);b.tg=e?e.id:0;}
  if(!e)return false;
  usarHabs(b,e,vs,ch);
  var d=dU(b,e),alc=alcanceB(b,e),sp=velMundo(b),cl=b.j.clase;
  /* esquiva de la telegrafía (cono delante del monstruo) */
  for(var i=0;i<ch.length;i++){var m=ch[i];
   if(m.wind>.05&&!b.dodge&&dU(b,m)<2.3*U&&Math.random()<b.esq*dt*6){var aw=Math.atan2(b.y-m.y,b.x-m.x)+rf(-.6,.6);b.dodge={t:Math.min(.4,m.wind+.05),ang:aw};break;}}
  if(b.dodge){b.dodge.t-=dt;var nx=b.x+Math.cos(b.dodge.ang)*sp*1.1*dt,ny=b.y+Math.sin(b.dodge.ang)*sp*1.1*dt;if(mLibre(Math.floor(nx),Math.floor(ny))){b.x=nx;b.y=ny;b.dir=dirOf(Math.cos(b.dodge.ang),Math.sin(b.dodge.ang));}if(b.dodge.t<=0)b.dodge=null;
   if(d<=alc)atacar(b,e);return true;}
  if(b.melee){
   if(d>alc*.9)pasoMundo(b,e.x,e.y,sp,dt);else{b.mv=0;atacar(b,e);}
   if(d<=alc+8)atacar(b,e);
  }else{
   var kite=cl!=="Clérigo"&&d<3.1*U&&e.st===1;
   if(kite){var aw2=Math.atan2(b.y-e.y,b.x-e.x),nx2=b.x+Math.cos(aw2)*sp*dt,ny2=b.y+Math.sin(aw2)*sp*dt;if(mLibre(Math.floor(nx2),Math.floor(ny2))){b.x=nx2;b.y=ny2;b.dir=dirOf(Math.cos(aw2),Math.sin(aw2));}else pasoMundo(b,e.x,e.y,sp*.2,dt);}
   else if(d>alc*.88)pasoMundo(b,e.x,e.y,sp,dt);else b.mv=0;
   if(d<=alc)atacar(b,e);
  }
  return true;
 }

 /* ---- cerebro en el Mundo Abierto ---- */
 function irOakhaven(b){
  b.lugar="oakhaven";b.MON={};b.ruta=null;b.dest=null;b.path=null;b.tg=0;b.flee=false;b.dodge=null;
  var c=celdaOakCerca(OK.SPAWN.x+rnd(-2,2),OK.SPAWN.y+rnd(-2,2),6)||OK.SPAWN;b.x=c.x+.5;b.y=c.y+.5;
  b.modo="ciudad";b.task="espera";b.tt=rf(1,4);b.tiendaHecha=false;b.tCiudad=entre(CFG.T_CIUDAD);b.PS.comb=0;b.PS.regW=0;
  env(b,{t:"lugar",lugar:"oakhaven",x:r2(b.x),y:r2(b.y)});
 }
 function irMundo(b){
  if(!MD)return;
  b.lugar="mundo";b.MON={};b.ruta=null;b.dest=null;b.path=null;b.tg=0;b.flee=false;b.modo="mundo";b.auto="ir";b.sector=null;b.tIni=b.t;b.tCaza=entre(CFG.T_SALIDA);
  var X=SPAWN.x+rf(-2,2),Y=SPAWN.y+rf(-.5,1.5);if(!mLibre(Math.floor(X),Math.floor(Y))){X=SPAWN.x;Y=SPAWN.y;}b.x=X;b.y=Y;b.PS.comb=0;
  env(b,{t:"lugar",lugar:"mundo",x:r2(b.x),y:r2(b.y)});
 }
 function volverACiudad(b,dt){
  var PS=b.PS;
  combate(b,dt,{ref:null,jefe:false,soloChasers:true});if(b.flee){huir(b,dt);return;}
  var x=CC.x-2.5,y=CC.y+5.5,r=viajar(b,dt,x,y,true);
  if(r==="llego"){b.mv=0;b.espDoran=(b.espDoran||0)+dt;if(b.espDoran>.9){b.espDoran=0;irOakhaven(b);}}
  else if(r==="fallo"){b.espDoran=0;pasoMundo(b,x,y,velMundo(b),dt);}
 }
 function huir(b,dt){
  var PS=b.PS,r=viajar(b,dt,CC.x,CC.y+3,true);
  usarDefensivas(b);
  var ch=vivos(b).filter(function(m){return m.st===1&&dC(b,m)<10&&!m.jefe;});
  if(Math.hypot(b.x-CC.x,b.y-CC.y)<MD.MON_SEGURA-2||(!ch.length&&PS.hp>PS.max*.35)){b.flee=false;if(b.auto!=="volver")b.auto="descanso";}
 }
 function usarDefensivas(b){
  var PS=b.PS,cl=b.j.clase,H=b.habs;if(PS.stunT>0||PS.silT>0)return;
  var idx=cl==="Arquero"?2:cl==="Asesino"?1:cl==="Mago"?2:cl==="Paladin"?2:cl==="Clérigo"?1:1;
  if(H[idx]&&PS.cd[idx]<=0&&PS.mp>=H[idx].costo){var e=vivos(b).filter(function(m){return m.st===1;}).sort(function(a,c){return dU(b,a)-dU(b,c);})[0]||null;lanzarH(b,idx,e);}
 }
 function descansar(b,dt){
  var PS=b.PS;
  if(Math.hypot(b.x-CC.x,b.y-CC.y)>MD.MON_SEGURA-4){var r=viajar(b,dt,CC.x+rf(-2,2),CC.y+rf(2,5),true);if(r==="fallo")pasoMundo(b,CC.x,CC.y+3,velMundo(b),dt);return;}
  b.mv=0;
  if(PS.hp>=PS.max*.92&&PS.mp>=PS.mpMax*.7){b.auto=quiereVolver(b)?"volver":"ir";}
 }
 function quiereVolver(b){
  var j=b.j,dur=b.t-b.tIni;
  if(potCuenta(b,"vida")<=1&&j.oro>=120)return true;
  if(dur<150)return false;
  return dur>b.tCaza||matCount(b)>=45||j.oro>=b.metaOro;
 }
 function explorar(b,dt){
  if(!b.sector||b.t-b.tSec>90){var s0=b.sector;b.sector=elegirSector(b);b.tSec=b.t;if(s0&&b.sector&&s0.k!==b.sector.k)b.dest=null;}
  if(!b.sector){pasoMundo(b,CC.x+16,CC.y+4,velMundo(b),dt);return;}
  if(!b.objetivo||b.sinRuta>=3){b.objetivo=puntoCaza(b);b.sinRuta=0;}
  var r=viajar(b,dt,b.objetivo.x,b.objetivo.y,true);
  if(r==="llego"){b.objetivo=puntoCaza(b);b.sinRuta=0;}
  else if(r==="fallo"){b.sinRuta=(b.sinRuta||0)+1;b.objetivo=null;}
 }
 function autonomo(b,dt){
  var PS=b.PS;
  if(b.flee){huir(b,dt);return;}
  if(b.auto==="descanso"){descansar(b,dt);return;}
  if(b.auto==="volver"){volverACiudad(b,dt);return;}
  if(combate(b,dt,{ref:null,jefe:false}))return;
  if(b.flee)return;
  if(PS.comb<=0&&(PS.hp<PS.max*.55||(!b.melee&&PS.mp<PS.mpMax*.2))){b.auto="descanso";return;}
  if(quiereVolver(b)){b.auto="volver";return;}
  explorar(b,dt);
 }
 function seguirMundo(b,ref,dt){
  var g=gDe(b.p),ang=b.idx*1.05+1,r=b.melee?rf(2,3):(b.j.clase==="Clérigo"?3.5:5);
  if(!b.offR)b.offR=r;
  if(combate(b,dt,{ref:ref,radio:15,leash:19,jefe:true}))return;
  apoyo(b,g);
  var d=dC(b,ref);
  var tx=ref.x+Math.cos(ang)*b.offR,ty=ref.y+Math.sin(ang)*b.offR;
  if(!mLibre(Math.floor(tx),Math.floor(ty))){tx=ref.x;ty=ref.y;}
  if(d>b.offR+2.2||d>9){var rr=viajar(b,dt,tx,ty,d>14);if(rr==="fallo")pasoMundo(b,ref.x,ref.y,velMundo(b),dt);}else b.mv=0;
 }
 function cerebroMundo(b,dt){
  var g=gDe(b.p),ref=refGrupo(b,g);
  if(ref&&!b.orden){if(ref.lugar!=="mundo"){volverACiudad(b,dt);return;}seguirMundo(b,ref,dt);return;}
  if(b.orden==="ciudad"){volverACiudad(b,dt);return;}
  if(b.orden==="quieto"){combate(b,dt,{ref:null,jefe:false,soloChasers:true});if(b.flee)huir(b,dt);return;}
  autonomo(b,dt);
 }

 /* ======================================== TIENDA ======================================== */
 var SLOTS=["arma","pecho","piernas","guantes","botas","accesorio"];
 function valorIt(b,it){
  if(!it||!it.n||it.n==="Ninguno")return 0;var tank=b.j.clase==="Paladin"||b.j.clase==="Guerrero";
  return (it.atk||0)*3+(it.def||0)*(tank?2.4:1.6)+(it.vida||0)*.45+(it.recurso||0)*.3+GM.attrSuma(GM.itemAttr(it))*2.2;
 }
 function reservaOro(b){return 40+b.j.nivel*6;}
 function candidatos(b){var lim=1+Math.floor(b.j.nivel/4);return GM.ITEMS.filter(function(a){return a[2]===b.j.clase&&a[9]<=lim;}).map(GM.itemObj);}
 function mejorCompra(b,oro){
  var best=null,bg=0;
  candidatos(b).forEach(function(it){
   if(GM.poseeEquipo(b.j,it.n)||oro<it.precio)return;
   var gain=valorIt(b,it)-valorIt(b,b.j.equipo[GM.slotDeItem(it)]);if(gain<=0)return;
   var ef=gain/it.precio;if(ef>bg){bg=ef;best=it;}});
  return best;
 }
 function visitaTienda(b){
  var j=b.j,comp=[],vend=0,res=reservaOro(b),i;
  /* 1) vender lo que sobra: equipo reemplazado y materiales */
  var bolsa=GM.equipoBolsa(j);while(bolsa.length){var it0=bolsa.pop();var pv=GM.precioVentaEquipo(it0);j.oro+=pv;vend+=pv;}
  Object.keys(j.inventario).forEach(function(k){if(GM.esMaterial(k)&&j.inventario[k]>0){var o0=j.oro;GM.venderMaterial(j,k,j.inventario[k]);vend+=j.oro-o0;}});
  /* 2) pociones de vida primero, luego equipo, luego el resto de pociones */
  function pociones(tipo,meta){
   var tier=j.nivel<12?0:j.nivel<35?1:2,lst=GM.POCIONES.filter(function(p){return p.tipo===tipo;}),p=lst[Math.min(tier,lst.length-1)];
   while(potCuenta(b,tipo)<meta&&j.oro-res>=p.precio*0+Math.min(res,60)&&j.oro>=p.precio){j.oro-=p.precio;j.inventario[p.n]=(j.inventario[p.n]||0)+1;comp.push(p.n);}
  }
  var mV=5+Math.floor(j.nivel/8),mR=(b.j.clase==="Guerrero"||b.j.clase==="Asesino"||b.j.clase==="Arquero")?2:4;
  pociones("vida",Math.ceil(mV/2));
  for(i=0;i<8;i++){var c=mejorCompra(b,j.oro-res);if(!c)break;j.oro-=c.precio;GM.equiparItem(j,GM.copiaItem(c));comp.push(c.n);}
  var bolsa2=GM.equipoBolsa(j);while(bolsa2.length){var it1=bolsa2.pop();var pv1=GM.precioVentaEquipo(it1);j.oro+=pv1;vend+=pv1;}
  pociones("vida",mV);pociones("recurso",mR);
  /* 3) próxima meta de oro para volver a comprar */
  var sig=null,pm=1e9;candidatos(b).forEach(function(it){if(GM.poseeEquipo(j,it.n))return;if(valorIt(b,it)-valorIt(b,j.equipo[GM.slotDeItem(it)])>0&&it.precio<pm){pm=it.precio;sig=it;}});
  b.metaOro=Math.max(300,(sig?sig.precio:600+j.nivel*40)+reservaOro(b));
  if(comp.length)alCambiarStats(b);
  if(comp.length||vend)log("🛒 Bot "+b.nombre+" (Nv "+j.nivel+"): "+(vend?"vende por "+vend+" · ":"")+(comp.length?"compra "+comp.slice(0,4).join(", ")+(comp.length>4?"…":""):"")+" · oro "+j.oro);
  if(comp.some(function(n){return !/Poci/.test(n);})&&Math.random()<.5)tarde(b,1.5,function(){decir(b,pick(["¡Equipo nuevo!","Qué buena compra, a probarlo.","Ya tengo mejor equipo ⚔"]));});
 }

 /* ---- cerebro en Oakhaven ---- */
 function irTarea(b,x,y){return rutaOak(b,x,y);}
 function paseoAleatorio(b){
  var p=Math.random()<.7?pick(PLAZA):null;
  if(!p){var c=celdaOakCerca(rnd(20,125),rnd(10,80),8);p=c||pick(PLAZA);}
  return irTarea(b,p.x,p.y);
 }
 function seguirOak(b,ref,dt){
  var d=Math.hypot(ref.x-b.x,ref.y-b.y);
  if(d>3.6){
   if(!b.path||!b.pathDest||Math.hypot(b.pathDest.x-ref.x,b.pathDest.y-ref.y)>3){var a=b.idx*1.05,c=celdaOakCerca(Math.floor(ref.x+Math.cos(a)*2),Math.floor(ref.y+Math.sin(a)*2),4);if(c)irTarea(b,c.x,c.y);}
   caminarOak(b,dt,d>12?1.35:1.05);
  }else{b.mv=0;b.path=null;}
 }
 function cerebroOak(b,dt){
  var g=gDe(b.p),ref=refGrupo(b,g);
  if(ref&&!b.orden){
   if(ref.lugar==="oakhaven"){seguirOak(b,ref,dt);return;}
   if(ref.lugar==="mundo"&&MD){tareaGeneral(b,dt);return;}
   b.task="espera";b.mv=0;return;
  }
  if(b.orden==="quieto"||b.orden==="ciudad"){b.mv=0;return;}
  b.tCiudad-=dt;
  if(b.task==="espera"){b.mv=0;b.tt-=dt;if(b.tt<=0){
    if(!b.tiendaHecha){b.task="tienda";b.fase=0;irTarea(b,PUERTA_TIENDA.x,PUERTA_TIENDA.y);}
    else if(b.tCiudad>0||!MD){b.task="paseo";if(!paseoAleatorio(b)){b.task="espera";b.tt=3;}}
    else{b.task="general";b.fase=0;irTarea(b,CELDA_GEN.x,CELDA_GEN.y);}}
  }else if(b.task==="paseo"){
   if(caminarOak(b,dt)){b.task="espera";b.tt=rf(2,9);b.dir=rnd(0,3);if(Math.random()<.12)decir(b,pick(["¿Alguien para ir de caza?","Qué bullicio hoy en Oakhaven.","Me vendría bien un grupo para el Mundo Abierto.","Buenas, aventureros 👋"]));}
  }else if(b.task==="tienda"){
   if(b.fase===0){if(caminarOak(b,dt)){b.fase=1;b.tt=rf(3,6);}}
   else{b.mv=0;b.tt-=dt;if(b.tt<=0){visitaTienda(b);b.tiendaHecha=true;b.task="espera";b.tt=rf(2,6);}}
  }else if(b.task==="general")tareaGeneral(b,dt);
 }
 function tareaGeneral(b,dt){
  if(b.task!=="general"){b.task="general";b.fase=0;irTarea(b,CELDA_GEN.x,CELDA_GEN.y);}
  if(b.fase===0){if(!b.path&&Math.hypot(b.x-GEN.x,b.y-GEN.y)>3)irTarea(b,CELDA_GEN.x,CELDA_GEN.y);if(caminarOak(b,dt)){b.fase=1;b.tt=rf(1.2,2.6);}}
  else{b.mv=0;b.tt-=dt;if(b.tt<=0){b.task="espera";b.tt=3;irMundo(b);}}
 }

 /* ======================================== CHAT Y ÓRDENES ======================================== */
 function orden(b,de,txt,resp){
  var t=norm(txt),g=gDe(b.p),mismo=g&&de&&de.grupo===b.p.grupo,nom=t.indexOf(norm(b.nombre))>=0;
  if(!mismo&&!nom)return;
  function r(s){tarde(b,rf(.8,2),function(){resp(s);});}
  if(/\b(seguir|sigueme|sigue|ven|vamos)\b/.test(t)){b.orden=null;r(pick(["¡Te sigo!","Voy contigo.","Vamos allá."]));}
  else if(/\b(quieto|espera|esperame|alto|para|quedate)\b/.test(t)){b.orden="quieto";r(pick(["Vale, aquí me quedo.","Te espero.","Entendido, me quedo quieto."]));}
  else if(/\b(atacar|ataca|ayuda|ayudame|pelea)\b/.test(t)){b.orden=null;r("¡A por ellos!");}
  else if(/\b(ciudad|oakhaven|volver|vuelve|vuelvo)\b/.test(t)){b.orden="ciudad";r("Voy a Oakhaven a vender y comprar.");}
  else if(/\b(salir|abandona|dejar grupo|adios)\b/.test(t)){if(g)env(b,{t:"g_salir"});b.orden=null;r("Vale, nos vemos. ¡Suerte!");}
  else if(/\b(estado|nivel|como estas|vida)\b/.test(t)){r("Nv "+b.j.nivel+" "+b.j.clase+" · vida "+Math.floor(b.PS.hp)+"/"+b.PS.max+" · "+Math.floor(b.j.oro)+" de oro.");}
  else if(/\b(hola|buenas|hey|saludos)\b/.test(t)){r(pick(["¡Hola!","¡Buenas! ¿Salimos a cazar?","¡Eh, hola! Soy "+b.nombre+"."]));}
 }

 /* ======================================== MENSAJES RECIBIDOS ======================================== */
 function recibe(b,m){
  switch(m.t){
   case "mon_ini":b.MON={};b.tg=0;break;
   case "mon_s":
    (m.d||[]).forEach(function(id){delete b.MON[id];if(b.tg===id)b.tg=0;});
    (m.a||[]).forEach(function(s){if(!b.MON[s.id])b.MON[s.id]=crearMonB(s);});
    (m.m||[]).forEach(function(r){var e=b.MON[r[0]];if(!e||e.muerto)return;e.x=r[1];e.y=r[2];e.vida=r[3];e.st=r[4];e.wind=r[5];e.windA=r[6];e.stunT=r[7];e.def=r[8];if(e.jefe&&r.length>9){e.windK=r[9]|0;e.buffT=r[11]||0;}});
    break;
   case "mon_muere":{var e=b.MON[m.id];delete b.MON[m.id];if(b.tg===m.id)b.tg=0;
    if(e&&!e.jefe&&(m.by===b.p.id||(m.eq&&m.eq.indexOf(b.p.id)>=0)))recompensa(b,e);break;}
   case "mon_atq":{var q=b.MON[m.id];if(!q||q.muerto)break;q.wind=0;q.windA=m.a;
    var hb=q.jefe&&m.k?habJ(q,m.k):null;if(hb&&!hb.m)break;
    if(b.PS.vivo&&m.h&&m.h.indexOf(b.p.id)>=0)golpeMon(b,q,(hb?hb.m:1)*(m.dm||1),hb?hb.stun:0);break;}
   case "jefe_botin":botinJefe(b,m);break;
   case "g_buff":recibeBuff(b,m);break;
   case "g_invitacion":
    if(!CFG.ACEPTA_GRUPO||b.muerte)break;
    (function(de,nom){tarde(b,rf(1.2,3.2),function(){if(gDe(b.p))return;env(b,{t:"g_resp",de:de,ok:true});b.orden=null;b.saludarA=nom;});})(m.de,m.nombre||"");
    break;
   case "g_estado":if(!m.grupo){b.orden=null;b.grupoVisto=0;}
    else if(b.grupoVisto!==m.grupo.id){b.grupoVisto=m.grupo.id;var nm=b.saludarA||"";b.saludarA=null;tarde(b,rf(.8,1.8),function(){decir(b,pick(["¡Claro, voy contigo"+(nm?", "+nm:"")+"!","¡Encantado de unirme! 👍","¡Vamos! Cuenta conmigo."]));});}
    break;
   case "c_solicitud":(function(de){tarde(b,rf(.8,2),function(){env(b,{t:"c_resp",de:de,ok:false});susurrar(b,de,"Prefiero no comerciar, ¡perdona! Pero encantado de ir en grupo.");});})(m.de);break;
   case "chat":{var de=J[m.id];if(!de||de.bot||m.id===b.p.id)break;if(CFG.RESPONDE_CHAT)orden(b,de,m.texto,function(s){decir(b,s);});break;}
   case "susurro":{var de2=J[m.de];if(!de2||de2.bot)break;if(CFG.RESPONDE_CHAT){var tx=m.texto;tarde(b,rf(.6,1.6),function(){
     var t=norm(tx),r=null;
     if(/\b(seguir|sigueme|sigue|ven|vamos)\b/.test(t)){b.orden=null;r="¡Te sigo!";}
     else if(/\b(quieto|espera|alto|para|quedate)\b/.test(t)){b.orden="quieto";r="Vale, me quedo aquí.";}
     else if(/\b(ciudad|oakhaven|volver)\b/.test(t)){b.orden="ciudad";r="Voy a Oakhaven.";}
     else if(/\b(estado|nivel|vida)\b/.test(t))r="Nv "+b.j.nivel+" "+b.j.clase+" · vida "+Math.floor(b.PS.hp)+"/"+b.PS.max+" · "+Math.floor(b.j.oro)+" de oro.";
     else r=pick(["¡Hola! Invítame a tu grupo y te acompaño.","Dime: «seguir», «quieto», «ciudad» o «estado».","Estoy subiendo de nivel. ¿Vamos juntos?"]);
     susurrar(b,m.de,r);});}break;}
  }
 }

 /* ======================================== BUCLE PRINCIPAL ======================================== */
 function step(b,dt){
  b.t+=dt;
  timers(b,dt);
  if(b.muerte){muerteStep(b,dt);}
  else if(b.lugar==="oakhaven")cerebroOak(b,dt);
  else cerebroMundo(b,dt);
  b.movAcc+=dt;
  if(b.movAcc>=.1){b.movAcc=0;if(Math.abs(b.x-b._x)>.03||Math.abs(b.y-b._y)>.03){b._x=b.x;b._y=b.y;env(b,{t:"mover",x:r2(b.x),y:r2(b.y),dir:DIRC[b.dir]});}}
  b.ultInfo+=dt;if(b.ultInfo>=1.2){b.ultInfo=0;var PS=b.PS;env(b,{t:"info",nivel:b.j.nivel,clase:b.j.clase,hp:Math.floor(PS.hp),hpMax:PS.max,mp:Math.floor(PS.mp),mpMax:PS.mpMax,rn:b.j.recursoNombre||"",act:true});}
 }
 var last=Date.now();
 function hayReales(){for(var id in J)if(!J[id].bot)return true;return false;}
 function tick(){
  var now=Date.now(),dt=Math.min(.1,Math.max(0,(now-last)/1000));last=now;tickN++;
  if(CFG.PAUSAR_SIN_JUGADORES&&!hayReales())return;
  if(NAVB)NAVB.tick();
  for(var i=0;i<BOTS.length;i++){try{step(BOTS[i],dt);}catch(e){if(now-lastErr>10000){lastErr=now;log("⚠ Error en el bot "+BOTS[i].nombre+": "+(e&&e.stack||e));}}}
 }

 api.activo=true;
 api.cuenta=function(){return BOTS.length;};
 api.guardar=guardarTodo;
 api.resumen=function(){return BOTS.map(function(b){var g=gDe(b.p);return{nombre:b.nombre,clase:b.j.clase,nivel:b.j.nivel,xp:b.j.xp,rama:(b.j.tal&&b.j.tal.rama)||null,lugar:b.lugar,modo:b.lugar==="oakhaven"?b.task:(b.flee?"huyendo":b.auto),hp:Math.floor(b.PS.hp),hpMax:b.PS.max,oro:Math.floor(b.j.oro),bajas:b.kills,muertes:b.muertes,grupo:g?g.id:0,sector:b.sector?b.sector.id:null};});};
 api.iniciar=function(){
  if(BOTS.length)return;
  CFG.BOTS.forEach(function(c,i){var b=crearBot(c,i);if(b)BOTS.push(b);});
  setInterval(tick,50).unref();
  setInterval(guardarTodo,CFG.SAVE_S*1000).unref();
  log("Bots aventureros: "+BOTS.map(function(b){return b.nombre+" ("+b.j.clase+" Nv "+b.j.nivel+")";}).join(" · "));
 };
 return api;
};
