"use strict";
/* UI Personaje (inventario / talentos) */
/* ---------- UI Personaje ---------- */
function perTabsHTML(){
 var t=G.perTab||"inventario";
 return '<div style="display:flex;gap:6px;margin-bottom:10px">'+[["inventario","🎒 Inventario"],["materiales","🪨 Materiales"],["talentos","✨ Talentos"]].map(function(x){return '<button class="btn perTab" data-t="'+x[0]+'" style="padding:6px 14px;font-size:12px;'+(t===x[0]?'background:var(--accent-soft);border-color:var(--accent)':'')+'">'+x[1]+'</button>';}).join('')+'</div>';
}
function perBind(){document.querySelectorAll(".perTab").forEach(function(b){b.onclick=function(){G.perTab=b.getAttribute("data-t");render();};});}
function materialesHTML(j){
 var mats=Object.keys(j.inventario).filter(function(k){return esMaterial(k)&&j.inventario[k]>0;}).sort(function(a,b){return a.localeCompare(b,"es");});
 var tot=mats.reduce(function(s,k){return s+j.inventario[k];},0);
 var h='<div class="card" style="margin-bottom:12px"><div style="display:flex;justify-content:space-between;flex-wrap:wrap;gap:6px;margin-bottom:10px"><span class="font-disp" style="color:var(--accent)">Materiales</span><span style="color:var(--muted);font-size:12px">'+mats.length+' tipo(s) · '+tot+' unidad(es)</span></div>';
 if(!mats.length)return h+'<div style="color:var(--muted);font-size:13px">Sin materiales. Derrota enemigos y explora para conseguirlos.</div></div>';
 mats.forEach(function(nm){
  var res=reservadoEntrega(j,nm),pu=precioMaterial(nm);
  h+='<div style="display:flex;justify-content:space-between;align-items:center;gap:6px;padding:6px 0;border-bottom:1px dashed var(--border);font-size:13px;flex-wrap:wrap"><span>'+itemImg(nm,32)+'<b>'+nm+'</b> x'+j.inventario[nm]+' <span style="color:var(--muted);font-size:11px">'+infoMaterial(nm)+'</span>'+(res?' <span style="color:#8ab0d8;font-size:11px">(reservados: '+res+')</span>':'')+'</span><span style="color:#e0c060;font-size:12px">'+pu+' oro c/u</span></div>';
 });
 return h+'</div>';
}
function talentosHTML(j){
 var T=talEst(j),R=RAMAS[j.clase],r=ramaAct(j),ext=(j.ciclo||0)>0;
 var h='<div class="card" style="margin-bottom:12px"><div style="display:flex;justify-content:space-between;flex-wrap:wrap;gap:6px"><span class="font-disp" style="color:var(--accent)">Talentos de Rama</span><span style="color:#b8a0e8;font-weight:700">👻 Almas: '+T.almas+'</span></div>';
 h+='<div style="font-size:11px;color:var(--muted);margin:4px 0 10px">Las almas solo se cosechan a partir del nivel '+NIV_RAMA+' ('+(j.nivel>=NIV_RAMA?'<span style="color:#7ab88a">activo</span>':'<span style="color:#e08080">aún inactivo: Nv '+j.nivel+'</span>')+'), al derrotar enemigos en Exploración y Modo Aventura, hasta '+(ext?15:10)+' pisos por debajo del actual'+(ext?' (+20% almas en Extremo)':'')+'. No todos los enemigos liberan almas (más probable en pisos altos); los mini jefes y jefes siempre lo hacen y en mayor cantidad. La cosecha crece ligeramente con el piso. El costo en almas de cada talento sube con su nivel (más caro cuanto más alto); las habilidades de rama cuestan +180%.</div>';
 if(!r){
  if(j.nivel<NIV_RAMA)h+='<div style="font-size:13px;color:#e08080">La elección de rama se desbloquea al nivel '+NIV_RAMA+' (Nv actual: '+j.nivel+').</div>';
  else{
   h+='<div style="font-size:12px;color:#e0c060;margin-bottom:8px">⚠ Elige 1 rama. La otra queda bloqueada para siempre en este personaje.</div><div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(240px,1fr));gap:10px">';
   R.forEach(function(b){
    h+='<div class="card" style="padding:10px;background:rgba(0,0,0,.25)"><div style="font-weight:700;color:var(--accent)">'+b.n+'</div><div style="font-size:11px;color:var(--muted);margin:2px 0 6px">'+b.foco+'</div>';
    ramaNodos(b).forEach(function(n){h+='<div style="font-size:11px;padding:1px 0;display:flex;align-items:center;gap:6px"><span class="pill">Nv '+n.nv+'</span> '+(n.sk?habImg(n.n,j.clase,24):'')+n.n+'</div>';});
    h+='<button class="btn btn-primary ramaElegir" data-r="'+b.n+'" style="margin-top:8px;width:100%;padding:6px">Elegir '+b.n+'</button></div>';
   });
   h+='</div>';
  }
 }else{
  h+='<div style="font-size:13px;margin-bottom:8px"><b style="color:var(--accent)">'+r.n+'</b> <span style="color:var(--muted);font-size:11px">· '+r.foco+'</span></div>';
  var N=ramaNodos(r);
  N.forEach(function(n,i){
   var on=T.act.indexOf(n.id)>=0,prev=i===0||T.act.indexOf(N[i-1].id)>=0,lv=j.nivel>=n.nv;
   var est=on?'<span style="color:#7ab88a;font-weight:700">✔ Activo</span>':(!lv?'<span style="color:var(--muted);font-size:11px">Nv '+n.nv+'</span>':(!prev?'<span style="color:var(--muted);font-size:11px">Requiere anterior</span>':'<button class="btn talAct" data-id="'+n.id+'" style="padding:4px 10px;font-size:12px" '+(T.almas<costoNodo(n)?'disabled':'')+'>Activar ('+costoNodo(n)+' 👻)</button>'));
   h+='<div style="display:flex;justify-content:space-between;align-items:center;gap:8px;padding:7px 0;border-bottom:1px dashed var(--border);font-size:13px;flex-wrap:wrap;opacity:'+((on||lv)?1:.55)+'"><div class="habRow" style="flex:1;min-width:200px">'+(n.sk?habImg(n.n,j.clase,44):'')+'<div><span class="pill">Nv '+n.nv+'</span> '+(n.sk?'<span class="pill" style="border-color:#b070e0">Habilidad</span> ':'')+'<b>'+n.n+'</b><div style="font-size:11px;color:var(--muted);margin-top:2px">'+n.d+(n.sk?' · '+n.sk.c+' '+j.recursoNombre+' · CD '+n.sk.cd+' turnos':'')+'</div></div></div>'+est+'</div>';
  });
  var o=R.filter(function(b){return b.n!==r.n;})[0];
  if(o)h+='<div style="margin-top:10px;font-size:11px;color:#c97a9a">🔒 Rama bloqueada para siempre: '+o.n+'</div>';
 }
 return h+'</div>';
}
function habilidadesHTML(j){
 var r=ramaAct(j),T=talEst(j),L=HABILIDADES[j.clase].slice();
 if(r)[r.h1,r.h2].forEach(function(sk){var on=T.act.indexOf(r.n+"_"+sk.s)>=0;L.push({n:sk.n,costo:sk.c,desc:sk.d+(on?habBonoTxt(j,sk):""),cd:Math.max(1,sk.cd-(on?talMods(j)[sk.s+"cd"]:0)),on:on,rama:1});});
 var h='<div class="card" style="margin-bottom:12px"><div class="font-disp" style="color:var(--accent);margin-bottom:8px">Habilidades</div><div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(250px,1fr));gap:8px">';
 L.forEach(function(a,ix){if(!a.rama&&ix<3)a.desc+=baseBonoTxt(j,ix);
  h+='<div class="habRow" style="padding:6px;border-radius:8px;background:rgba(0,0,0,.22);opacity:'+((a.rama&&!a.on)?.45:1)+'">'+habImg(a.n,j.clase,44)+'<div><b style="font-size:13px">'+a.n+'</b>'+(a.rama?' <span class="pill" style="border-color:#b070e0">'+(a.on?'Rama':'Rama · bloqueada')+'</span>':'')+'<div style="font-size:11px;color:var(--muted)">'+a.desc+' · '+costoHab(j,a.costo)+' '+j.recursoNombre+' · CD '+a.cd+'</div></div></div>';
 });
 return h+'</div></div>';
}
function talBind(j){
 var T=talEst(j);
 document.querySelectorAll(".ramaElegir").forEach(function(b){b.onclick=function(){
  var nm=b.getAttribute("data-r");
  if(!confirm("Elegir "+nm+" es IRREVERSIBLE: la otra rama queda bloqueada para siempre en este personaje. ¿Continuar?"))return;
  T.rama=nm;T.act=[];guardar();render();
 };});
 document.querySelectorAll(".talAct").forEach(function(b){b.onclick=function(){
  var r=ramaAct(j);if(!r)return;
  var N=ramaNodos(r),id=b.getAttribute("data-id"),i=-1;
  N.forEach(function(n,k){if(n.id===id)i=k;});
  if(i<0||T.act.indexOf(id)>=0)return;
  var n=N[i];
  var cs=costoNodo(n);
  if(j.nivel<n.nv||T.almas<cs||(i>0&&T.act.indexOf(N[i-1].id)<0))return;
  T.almas-=cs;T.act.push(id);guardar();render();
 };});
}
function renderPersonaje(){
 var j=G.j;
 if(G.perTab==="materiales"){
  el.innerHTML=hudHTML(j)+perTabsHTML()+materialesHTML(j)+'<button class="btn" id="bBack">← Volver</button>';
  perBind();document.getElementById("bBack").onclick=function(){G.screen="hub";render();};return;
 }
 if(G.perTab!=="talentos"){renderInventory();el.insertAdjacentHTML("afterbegin",perTabsHTML());perBind();return;}
 el.innerHTML=hudHTML(j)+perTabsHTML()+habilidadesHTML(j)+talentosHTML(j)+'<button class="btn" id="bBack">← Volver</button>';
 perBind();talBind(j);
 document.getElementById("bBack").onclick=function(){G.screen="hub";render();};
}

relojInit();
render();
