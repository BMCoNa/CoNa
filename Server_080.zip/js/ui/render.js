"use strict";
/* UI: render de pantallas */
/* ============================================================
   UI — render de todas las pantallas
   ============================================================ */
var el=document.getElementById("game");
function iconoSVG(tipo){
 var P={espada:'<path d="M14.5 17.5 3 6V3h3l11.5 11.5M13 19l6-6M16 16l4 4M19 21l2-2"/>',corazon:'<path d="M12 21s-7-4.5-9.5-9C.5 8 2.5 4.5 6 4.5c2 0 3.5 1 4.5 2.5 1-1.5 2.5-2.5 4.5-2.5 3.5 0 5.5 3.5 3.5 7.5C19 16.5 12 21 12 21z"/>',escudo:'<path d="M12 2 4 5v6c0 5 3.5 9.5 8 11 4.5-1.5 8-6 8-11V5l-8-3z"/>',moneda:'<circle cx="12" cy="12" r="9"/><path d="M12 7v10M9.5 9.5c0-1 1-1.8 2.5-1.8s2.5.8 2.5 1.8-1 1.6-2.5 1.8-2.5.8-2.5 1.8 1 1.8 2.5 1.8 2.5-.8 2.5-1.8"/>',pocion:'<path d="M10 2h4v4l5 9a3 3 0 0 1-3 4H8a3 3 0 0 1-3-4l5-9V2z"/>',calabozo:'<rect x="3" y="3" width="18" height="18" rx="2"/><path d="M9 3v18M15 3v18M3 9h18M3 15h18"/>',ciudad:'<path d="M3 21V9l6-4 6 4v12M9 21v-6h6v6M21 21V13l-3-2"/>',bolsa:'<path d="M6 7h12l1.5 13a2 2 0 0 1-2 2.5h-11a2 2 0 0 1-2-2.5L6 7zM9 7V5a3 3 0 0 1 6 0v2"/>',hospital:'<rect x="4" y="4" width="16" height="16" rx="2"/><path d="M12 8v8M8 12h8"/>',martillo:'<path d="M14 12l7-7 3 3-7 7M13 13l-2 2-6 6-3-3 6-6 2-2z"/>',libro:'<path d="M4 4h7a3 3 0 0 1 3 3v13a2 2 0 0 0-2-2H4V4zM20 4h-7a3 3 0 0 0-3 3v13a2 2 0 0 1 2-2h8V4z"/>',gremio:'<path d="M3 21h18M5 21V8l7-5 7 5v13M9 21v-6h6v6"/>',alquimista:'<path d="M9 3h6M10 3v6l-5 9a2 2 0 0 0 1.8 3h10.4a2 2 0 0 0 1.8-3l-5-9V3"/>',aventura:'<path d="M12 2l3 6 7 1-5 5 1 7-6-3-6 3 1-7-5-5 7-1z"/>'};
 return '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" style="vertical-align:-3px;margin-right:5px;display:inline-block">'+(P[tipo]||P.espada)+'</svg>';
}
function barraHTML(val,max,color){var pct=max>0?Math.max(0,Math.min(100,(val/max)*100)):0;return '<div class="bar"><div style="width:'+pct+'%;background:linear-gradient(90deg,'+color+','+color+'cc)"></div></div>';}
function hudHTML(j){
 var st=calcStats(j),b=getBioma(j),crit=Math.min(60,CLASES[j.clase].crit+st.critB),mald=Object.keys(j.maldiciones);
 var h='<div class="card" style="margin-bottom:12px">';
 h+='<div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:6px;margin-bottom:8px">';
 h+='<div><span class="font-disp" style="font-size:18px;font-weight:700;color:var(--accent)">'+j.nombre+'</span> <span style="color:var(--muted);font-size:13px">el '+j.clase+' · Nv '+j.nivel+'</span>'+(tituloJ(j)?' <span style="color:#e0c060;font-size:12px;font-weight:700;border:1px solid #8a6a2a;border-radius:10px;padding:1px 8px;margin-left:4px" title="Título por fama">🏅 '+tituloJ(j)+'</span>':'')+'</div>';
 h+='<div style="font-size:13px;color:'+b.color+'">'+b.emoji+' · '+b.nombre+' · Piso '+j.piso+'</div></div>';
 h+='<div style="font-size:12px;color:var(--muted);margin-bottom:3px">Vida '+j.vida+'/'+st.vidaMax+(j.escudo>0?' · Escudo '+j.escudo:'')+(j.defTemp>0?' · DEF +'+j.defTemp:'')+'</div>'+barraHTML(j.vida,st.vidaMax,'#b8342c');
 h+='<div style="font-size:12px;color:var(--muted);margin:6px 0 3px">'+j.recursoNombre+' '+j.recurso+'/'+st.recursoMax+'</div>'+barraHTML(j.recurso,st.recursoMax,'#3a6ea5');
 if(j.nivel>=NIVEL_MAX){var fm=j.fama||0,sf=sigFama(j);h+='<div style="font-size:12px;color:var(--muted);margin:6px 0 3px">Nivel máximo · Fama '+fm+(sf?'/'+sf.f+' (próximo título: '+sf.n+')':' · título máximo')+'</div>'+barraHTML(fm,sf?sf.f:FAMA_MAX,'#9a6ac9');}
 else h+='<div style="font-size:12px;color:var(--muted);margin:6px 0 3px">XP '+j.xp+'/'+(j.nivel*100)+'</div>'+barraHTML(j.xp,j.nivel*100,'#7a8c3a');
 h+='<div style="display:flex;flex-wrap:wrap;gap:10px;margin-top:10px;font-size:13px">';
 h+='<span style="color:#e08060">'+iconoSVG('espada')+st.atkMin+'-'+st.atkMax+'</span>';
 h+='<span style="color:#8ab0d8">'+iconoSVG('escudo')+st.def+'</span>';
 h+='<span style="color:#c9a25a">Crítico '+crit+'%</span>';
 h+='<span style="color:#e0c060">'+iconoSVG('moneda')+j.oro+'</span>';
 h+='<span style="color:#c9a2c9">'+iconoSVG('gremio')+'Rango '+RANGOS_GREMIO[j.gremio.rango].n+'</span>'+((j.ciclo||0)>0?' <span style="color:#e06a5a;font-weight:700" title="Modo Extremo">☠ Extremo '+j.ciclo+'/'+MAX_EXTREMO+'</span>':'')+'</div>';
 if(mald.length)h+='<div style="margin-top:8px;font-size:12px;color:#c97a9a">☠ Maldiciones: '+mald.join(' · ').replace(/Maldición (de|del) /g,'')+'</div>';
 if(typeof bonosRama==="function"){var br=bonosRama(j);if(br.length)h+='<div style="margin-top:8px;font-size:12px;color:#8ac9a2">🌿 Rama '+(j.tal&&j.tal.rama||'')+': '+br.join(' · ')+'</div>';}
 h+='</div>';return h;
}
function render(){
 var j=G.j;
 var map={title:renderTitle,intro:renderIntro,create:renderCreate,hub:renderHub,city:renderCity,tabint:renderTabInt,gremint:renderGremInt,herint:renderHerInt,hospint:renderHospInt,alqint:renderAlqInt,tienint:renderTienInt,castint:renderCastInt,entint:renderEntInt,muint:renderMuInt,oakint:renderOakInt,mundoint:renderMundoInt,conectando:renderConectando,inventory:renderPersonaje,shop:renderShop,hospital:renderHospital,gremio:renderGremio,herreria:renderHerreria,alquimista:renderAlquimista,aventura:renderAventura,infinita:renderInfinita,laberinto:renderLaberinto,slots:renderSlots,creditos:renderCreditos,taberna:renderTaberna};
 (map[G.screen]||renderHub)();
 mapaVis(G.screen);
 relojRender();
}
function renderSlots(){
 slotMigrar();
 var modo=G.slotModo||"cargar",tit={cargar:"Cargar Partida",guardar:"Guardar Partida",nueva:"Nueva Partida — elige un slot"}[modo];
 var h='<div style="max-width:560px;margin:0 auto;padding:20px 10px"><div class="font-disp" style="font-size:22px;color:var(--accent);margin-bottom:12px;text-align:center">'+tit+'</div>';
 for(var i=1;i<=SLOTS;i++){
  var d=slotLeer(i),act=(G.j&&G.slot===i&&modo==="guardar");
  h+='<div class="card" style="padding:12px;margin-bottom:10px;background:rgba(0,0,0,.25);'+(act?'border-color:var(--accent)':'')+'"><div style="display:flex;justify-content:space-between;align-items:center;gap:8px;flex-wrap:wrap"><div style="font-size:13px"><div style="font-weight:700">Slot '+i+(act?' <span class="pill">Actual</span>':'')+'</div>';
  if(d)h+='<div style="color:var(--muted);font-size:12px;margin-top:2px">'+d.nombre+(tituloPorFama(d.fama)?' «'+tituloPorFama(d.fama).n+'»':'')+' · '+d.clase+' · Nv '+d.nivel+' · Piso '+d.piso+((d.ciclo||0)>0?' · Extremo '+d.ciclo+'/'+MAX_EXTREMO:'')+(d.fin?' · COMPLETADO':'')+' · '+d.oro+' oro'+(d.savedAt?'<br>'+new Date(d.savedAt).toLocaleString():'')+'</div>';
  else h+='<div style="color:var(--muted);font-size:12px;margin-top:2px">Vacío</div>';
  h+='</div><div style="display:flex;gap:6px">';
  if(modo==="cargar")h+='<button class="btn btn-primary slotAct" data-a="cargar" data-n="'+i+'" style="padding:6px 14px;font-size:12px" '+(d?'':'disabled')+'>Cargar</button>';
  else if(modo==="guardar")h+='<button class="btn btn-primary slotAct" data-a="guardar" data-n="'+i+'" style="padding:6px 14px;font-size:12px">Guardar aquí</button>';
  else h+='<button class="btn btn-primary slotAct" data-a="nueva" data-n="'+i+'" style="padding:6px 14px;font-size:12px">'+(d?'Sobrescribir':'Usar')+'</button>';
  if(d)h+='<button class="btn btn-danger slotAct" data-a="borrar" data-n="'+i+'" style="padding:6px 10px;font-size:12px">Borrar</button>';
  h+='</div></div></div>';
 }
 h+='<div style="text-align:center;margin-top:14px"><button class="btn" id="bSlotVolver">← Volver</button></div></div>';
 el.innerHTML=h;
 document.querySelectorAll(".slotAct").forEach(function(b){b.onclick=function(){
  var a=b.getAttribute("data-a"),n=parseInt(b.getAttribute("data-n"),10),d=slotLeer(n);
  if(a==="cargar"){var j=cargar(n);if(!j){alert("Slot vacío o dañado.");return;}G.j=j;G.slot=n;checkAutoRango(G.j);G.log=[];G.screen=j.fin?"creditos":"hub";}
  else if(a==="guardar"){if(d&&G.slot!==n&&!confirm("¿Sobrescribir el slot "+n+"?"))return;G.slot=n;guardar();G.msg="Partida guardada en el slot "+n+".";G.screen="hub";}
  else if(a==="nueva"){if(d&&!confirm("¿Sobrescribir el slot "+n+"? Se perderá esa partida."))return;try{localStorage.removeItem(slotKey(n));}catch(e){}G.slot=n;G.screen="intro";}
  else if(a==="borrar"){if(!confirm("¿Borrar el slot "+n+"? Esta acción no se puede deshacer."))return;try{localStorage.removeItem(slotKey(n));}catch(e){}}
  render();};});
 document.getElementById("bSlotVolver").onclick=function(){G.screen=(modo==="guardar"&&G.j)?"hub":"title";render();};
}
function renderTitle(){
 var save=haySave();
 var h='<div style="text-align:center;padding:40px 10px 20px">';
 h+='<div style="font-size:12px;letter-spacing:.4em;color:var(--muted);text-transform:uppercase;margin-bottom:14px">Dark Wolf Studios</div>';
 h+='<h1 class="font-disp flicker" style="font-size:clamp(30px,6vw,52px);font-weight:900;margin:0;line-height:1.1;background:linear-gradient(100deg,#e8c878,#c9923c,#8a5a2a);-webkit-background-clip:text;background-clip:text;color:transparent">THE CHRONICLES<br>OF NARADAK</h1>';
 h+='<div style="font-size:14px;color:var(--muted);margin-top:10px;font-style:italic">El despertar de los Titanes</div>';
 h+='<div style="width:60px;height:2px;background:var(--accent);margin:22px auto;opacity:.6"></div>';
 h+='<div style="max-width:480px;margin:0 auto;color:var(--muted);font-size:14px;line-height:1.7">Guardé mi estandarte. Enterré mi espada junto a los muertos. Dije que mi guerra había terminado. <span style="color:#e0c060">Me equivoqué.</span></div>';
 h+='<div style="margin-top:30px;display:flex;gap:12px;justify-content:center;flex-wrap:wrap">';
 h+='<button class="btn btn-primary" id="bNew" style="font-size:16px;padding:12px 28px">'+iconoSVG('espada')+'Nueva Partida</button>';
 h+='<button class="btn" id="bLoad" style="font-size:16px;padding:12px 28px" '+(save?'':'disabled')+'>'+iconoSVG('libro')+'Cargar Partida</button>';
 h+='<button class="btn btn-danger" id="bSalir" style="font-size:16px;padding:12px 28px">Salir del juego</button></div><div style="margin-top:30px;font-size:11px;color:var(--muted);opacity:.7">Versión web completa · guardado automático en este navegador</div></div>';
 el.innerHTML=h;
 document.getElementById("bNew").onclick=function(){var l=slotLibre();if(l){G.slot=l;G.screen="intro";}else{G.slotModo="nueva";G.screen="slots";}render();};
 document.getElementById("bLoad").onclick=function(){G.slotModo="cargar";G.screen="slots";render();};
 document.getElementById("bSalir").onclick=function(){el.innerHTML='<div style="text-align:center;padding:80px 20px"><div class="font-disp" style="font-size:28px;color:var(--accent);margin-bottom:14px">Que la luz te acompañe, Comandante.</div><div style="color:var(--muted);font-size:14px;max-width:420px;margin:0 auto;line-height:1.8">Tu partida está guardada. Cuando vuelvas, Naradak seguirá aquí... esperándote.</div><div style="width:60px;height:2px;background:var(--accent);margin:24px auto;opacity:.6"></div><button class="btn" id="bVolverTitulo">Volver al título</button></div>';document.getElementById("bVolverTitulo").onclick=function(){G.screen="title";render();};try{window.close();}catch(e){}};
}
var INTRO=["NARADAK. AÑOS DESPUÉS DE LA GUERRA.","Guardé mi estandarte. Enterré mi espada junto a los muertos.","Dije que mi guerra había terminado.","ME EQUIVOQUÉ.","El sello de los Titanes se hizo pedazos. De la oscuridad emergió un grito.","El Olvidado camina de nuevo. Y no viene solo.","Trae al General. Al que una vez entrenó a reyes.","Ahora comanda un ejército que no respira... no cede... Solo avanza...","Nerzas aguanta a duras penas. Connor ha cerrado el Norte.","El Este ya es solo ceniza y silencio.","Anoche el Manantial volvió a sangrar. Y en el pulso... escuché sus voces.","Hermano. Te necesitamos.","No me piden que sea rey. Me piden que sea lo que siempre fui.","Su escudo. Su lanza. Su última orden.","VUELVE, COMANDANTE. NARADAK ESTÁ MURIENDO.","LA GUERRA NO HA TERMINADO... SOLO ESTABAN ESPERANDO..."];
function renderIntro(){
 el.innerHTML='<div style="min-height:420px;display:flex;flex-direction:column;justify-content:center;padding:30px 10px"><div id="introText" style="font-family:Cinzel,serif;font-size:clamp(16px,2.6vw,22px);line-height:1.9;color:#d8c8a0;max-width:640px;margin:0 auto;text-align:center;min-height:260px"></div><div style="text-align:center;margin-top:24px"><button class="btn" id="bSkip">Continuar ▸</button></div></div>';
 var tgt=document.getElementById("introText"),i=0;
 function typeLine(){
  if(i>=INTRO.length)return;
  var line=INTRO[i],color=(line.indexOf("ME EQUIVOQUÉ")>=0||line.indexOf("VUELVE")>=0||line.indexOf("LA GUERRA")>=0)?"#e07050":"#d8c8a0";
  var div=document.createElement("div");div.style.color=color;div.style.marginBottom="10px";div.style.opacity="0";div.style.transition="opacity .6s";
  tgt.appendChild(div);var c=0;
  var iv=setInterval(function(){div.textContent=line.substring(0,++c);if(c>=line.length){clearInterval(iv);div.style.opacity="1";i++;setTimeout(typeLine,700);}},28);
 }
 typeLine();
 document.getElementById("bSkip").onclick=function(){G.screen="create";render();};
}
var selClase=null,selNombre="",selAvatar=null;
/* Selector de personaje (aspecto): carga las hojas de sprites bajo demanda */
/* Personajes recomendados por clase (índices de tilemap/js/chars.js); el selector permite además cualquier otro humano (Generales y Héroes incluidos). */
var AVATARES={
 "Guerrero":[4,6,12,14,21,24,26,28,34,36,39,50],
 "Mago":[0,1,8,9,16,17,25,29,38,52,54,55,64],
 "Arquero":[3,5,7,10,15,18,20,23,49,51,53,69,71],
 "Paladin":[27,31,32,35,37,40,41,43,44,45,46,47],
 "Asesino":[2,11,13,19,22,30,33,42,66],
 "Clérigo":[31,33,37,38,45,9,5,12,41,16,17]
};
/* Todos los personajes humanos de chars.js son elegibles (también Generales y Héroes); los recomendados para la clase van primero */
function avatarHumanos(){
 if(!selClase)return[];
 var rec=AVATARES[selClase]||[];
 if(typeof CHARS_INFO==="undefined")return rec;
 var r=rec.slice();
 for(var i=0;i<CHARS_INFO.length;i++)if(CHARS_INFO[i].k==="humano"&&r.indexOf(i)<0)r.push(i);
 return r;
}
function avatarInicial(){var l=avatarHumanos(),v=NaN;try{v=parseInt(localStorage.getItem("naradak_pc"),10);}catch(e){}return l.indexOf(v)>=0?v:(l.length?l[0]:4);}
var _avCarga=0,_avImgs={};
function avatarCargar(cb){
 if(typeof CHARS!=="undefined"&&typeof CHARS_INFO!=="undefined"){cb();return;}
 if(_avCarga===1)return;_avCarga=1;
 var s=document.createElement("script");s.src="tilemap/js/chars.js";
 s.onload=function(){_avCarga=2;cb();};s.onerror=function(){_avCarga=0;};
 document.head.appendChild(s);
}
function avatarPintar(){
 var cv=document.getElementById("avPrv"),nm=document.getElementById("avNum");if(!cv||typeof CHARS==="undefined")return;
 var hum=avatarHumanos();if(!hum.length){cv.getContext("2d").clearRect(0,0,cv.width,cv.height);if(nm)nm.textContent="Elige una clase para ver sus personajes";return;}
 if(selAvatar===null||hum.indexOf(selAvatar)<0)selAvatar=avatarInicial();
 if(nm)nm.textContent=selClase+" · "+(hum.indexOf(selAvatar)+1)+" / "+hum.length;
 var d=CHARS_INFO[selAvatar],g=cv.getContext("2d");g.imageSmoothingEnabled=false;
 function dib(im){g.clearRect(0,0,cv.width,cv.height);var k=Math.min(cv.width/d.w,cv.height/d.h),w=d.w*k,h=d.h*k;g.drawImage(im,d.w,0,d.w,d.h,(cv.width-w)/2,cv.height-h,w,h);}
 var im=_avImgs[selAvatar];
 if(!im){im=new Image();im.onload=function(){if(selAvatar!==null&&_avImgs[selAvatar]===im)dib(im);};_avImgs[selAvatar]=im;im.src=CHARS[selAvatar];}
 if(im.complete&&im.naturalWidth)dib(im);
}
function renderCreate(){
 var h='<div style="padding:10px 4px">';
 h+='<h2 class="font-disp" style="text-align:center;font-size:26px;color:var(--accent);margin:10px 0 4px">Creación de Héroe</h2>';
 h+='<div style="text-align:center;color:var(--muted);font-size:13px;margin-bottom:18px">Elige tu nombre y tu clase</div>';
 h+='<div style="margin-bottom:16px;text-align:center"><div style="font-size:12px;color:var(--muted);margin-bottom:6px">Elige tu personaje</div><div style="display:inline-flex;align-items:center;gap:14px"><button class="btn" id="avPrev" style="padding:8px 14px">◀</button><canvas id="avPrv" width="96" height="144" style="width:96px;height:144px;image-rendering:pixelated;background:rgba(0,0,0,.18);border-radius:8px;border:1px solid var(--border)"></canvas><button class="btn" id="avNext" style="padding:8px 14px">▶</button></div><div id="avNum" style="font-size:11px;color:var(--muted);margin-top:4px">...</div></div>';
 h+='<div style="margin-bottom:16px"><input id="inpName" type="text" maxlength="16" placeholder="Nombre de tu héroe..." value="'+selNombre+'"><div id="nameErr" style="min-height:18px;margin-top:6px;font-size:13px;color:#e08080"></div></div>';
 h+='<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:10px">';
 Object.keys(CLASES).forEach(function(c){var d=CLASES[c];
  h+='<div class="card classcard '+(selClase===c?'sel':'')+'" data-clase="'+c+'" style="padding:12px"><div style="font-family:Cinzel,serif;font-weight:700;font-size:16px;color:'+d.color+'">'+c+'</div>';
  h+='<div style="font-size:11px;color:var(--muted);margin-bottom:8px">'+d.recNombre+'</div>';
  h+='<div style="font-size:12px;line-height:1.7">♥ Vida: '+d.vida+'<br>⚔ Daño: '+d.atk[0]+'-'+d.atk[1]+'<br>⛨ Defensa: '+d.def+'<br>✦ Crítico: '+d.crit+'%<br><span style="color:var(--muted)">'+attrTxt(ATTR_CLASES[c]?ATTR_CLASES[c].base:{})+'</span></div></div>';
 });
 h+='</div><div style="text-align:center;margin-top:20px"><button class="btn btn-primary" id="bStart" style="font-size:16px;padding:12px 32px" '+(selClase?'':'disabled')+'>Comenzar la guerra ▸</button></div></div>';
 el.innerHTML=h;
 document.querySelectorAll(".classcard").forEach(function(c){c.onclick=function(){selClase=c.getAttribute("data-clase");selAvatar=null;render();};});
 var inp=document.getElementById("inpName");inp.oninput=function(){selNombre=inp.value;};inp.focus();
 avatarCargar(function(){
  var hum=avatarHumanos();if(hum.length&&(selAvatar===null||hum.indexOf(selAvatar)<0))selAvatar=avatarInicial();
  function stp(o){if(!hum.length)return;var i=hum.indexOf(selAvatar);selAvatar=hum[(i+o+hum.length)%hum.length];avatarPintar();}
  var ap=document.getElementById("avPrev"),an=document.getElementById("avNext");
  if(ap)ap.onclick=function(){stp(-1);};if(an)an.onclick=function(){stp(1);};
  avatarPintar();
 });
 var b=document.getElementById("bStart");
 if(selClase)b.onclick=function(){
  var nm=selNombre.replace(/\s+/g," ").trim(),ne=document.getElementById("nameErr");
  function err(t){if(ne)ne.textContent=t;b.disabled=false;}
  if(!nm){err("Escribe un nombre para tu héroe.");return;}
  b.disabled=true;if(ne)ne.textContent="";
  /* el nombre del personaje debe ser único en el servidor (así es fácil buscarse en las raids) */
  if(window.nrdkCuenta&&nrdkCuenta.reservarNombre)nrdkCuenta.reservarNombre(nm,function(ok,msg){if(!ok){err(msg);return;}b.disabled=false;empezar(nm);});
  else empezar(nm);
 };
 function empezar(nm){G.j=crearJugador(nm,selClase);if(selAvatar===null)selAvatar=avatarInicial();G.j.avatar=selAvatar;try{localStorage.setItem("naradak_pc",selAvatar);}catch(e){}if(typeof mapaReset==="function")mapaReset();G.log=["Bienvenido, "+nm+" el "+selClase+"."];guardar();G.screen="hub";render();};
}
function renderHub(){
 var j=G.j,b=getBioma(j);checkAutoRango(j);
 var h=hudHTML(j)+'<div class="card">';
 h+='<div class="font-disp" style="font-size:16px;color:'+b.color+';margin-bottom:12px">'+b.emoji+' · '+b.nombre+' — ¿Qué harás?</div>';
 h+='<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:10px">';
 h+='<button class="btn btn-primary" id="bExp" style="text-align:left;padding:14px">'+iconoSVG('calabozo')+'Explorar Mazmorra<div style="font-size:11px;font-weight:400;color:var(--muted);margin-top:4px">Piso '+j.piso+(((j.ciclo||0)>0&&j.piso%10!==5&&j.piso%10!==0)?' · Etapa '+(j.etapa||1)+'/5':'')+' · combate y botín'+((j.ciclo||0)>0?' · ☠ Extremo '+j.ciclo+'/'+MAX_EXTREMO:'')+'</div></button>';
 h+='<button class="btn" id="bCity" style="text-align:left;padding:14px">'+iconoSVG('ciudad')+'Ir a la Ciudad<div style="font-size:11px;font-weight:400;color:var(--muted);margin-top:4px">Explora el pueblo y entra a cada local</div></button>';
 h+='<button class="btn" id="bInv" style="text-align:left;padding:14px">'+iconoSVG('bolsa')+'Personaje<div style="font-size:11px;font-weight:400;color:var(--muted);margin-top:4px">Inventario, materiales, talentos y almas</div></button>';
 h+='<button class="btn" id="bSave" style="text-align:left;padding:14px">'+iconoSVG('libro')+'Guardar Partida<div style="font-size:11px;font-weight:400;color:var(--muted);margin-top:4px">Elige un slot (1-5) · guardado automático en el slot actual</div></button>';
  h+='<button class="btn" id="bOnline" style="text-align:left;padding:14px">🌐 Modo Online<div style="font-size:11px;font-weight:400;color:var(--muted);margin-top:4px">Ciudad de Oakhaven con otros jugadores (servidor local)</div></button>';
 h+='</div>';
 h+='<div style="margin-top:10px"><button class="btn btn-danger" id="bMenu" style="font-size:12px;padding:6px 14px">Volver al menú principal</button></div>';
 var _es=mEst(j),_m=mActual(j),_g=GRUPOS[_es.grupo];
 if(_es.estado==="activa"&&_m){var _pp=Object.keys(_m.obj).map(function(k){return progMision(j,k)+"/"+_m.obj[k]+" "+k;}).join(" · ");h+='<div style="margin-top:12px;padding:10px;border-radius:8px;background:rgba(90,154,201,.12);border:1px solid #5a9ac9;font-size:13px">📜 Misión activa ('+_g.nombre+' #'+(_es.indice+1)+'/25): '+_pp+'</div>';}
 else if(_es.estado==="lista"&&_m){h+='<div style="margin-top:12px;padding:10px;border-radius:8px;background:rgba(122,140,58,.18);border:1px solid #7a8c3a;font-size:13px;font-weight:700">🏆 ¡Misión lista! Reclámala en el Gremio ('+_m.oro+' oro + XP)</div>';}
 if(G.msg){h+='<div style="margin-top:12px;padding:10px;border-radius:8px;background:var(--accent-soft);border:1px solid var(--accent);font-size:13px">'+G.msg+'</div>'; G.msg="";}
 h+='</div>';
 el.innerHTML=h;
 document.getElementById("bExp").onclick=function(){mazmorraExplorar();};
 document.getElementById("bCity").onclick=function(){G.screen="city";render();};
 document.getElementById("bInv").onclick=function(){G.perTab="inventario";G.screen="inventory";render();};
 document.getElementById("bOnline").onclick=function(){onlineAbrir();};
 document.getElementById("bSave").onclick=function(){G.slotModo="guardar";G.screen="slots";render();};
 document.getElementById("bMenu").onclick=function(){guardar();G.screen="title";render();};
}
