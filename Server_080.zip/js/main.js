"use strict";
/* THE CHRONICLES OF NARADAK — arranque */
relojInit();
render();
