"use strict";
/* Tiempo del juego + Taberna */
/* ============================================================
   TIEMPO DEL JUEGO + TABERNA
   - Reloj global (arriba a la derecha). Cada acción suma minutos.
   - En reposo (fuera de combate y menús) el tiempo corre acelerado:
     1 s real = 5.6 min de juego => 1 día = 4.3 min reales, 7 días = 30 min reales.
   ============================================================ */
var MIN_DIA=1440,IDLE_RATE=5.6,TAB_MAX_ESCUADRON=2;
var PANTALLAS_SIN_TIEMPO=["title","slots","intro","create","creditos"];
function minJ(j){if(typeof j.min!=="number")j.min=480;return j.min;}
function diaJ(j){return Math.floor(minJ(j)/MIN_DIA)+1;}
function pad2(n){return(n<10?"0":"")+n;}
function horaTxt(j){var m=Math.floor(minJ(j))%MIN_DIA;return pad2(Math.floor(m/60))+":"+pad2(m%60);}
function relojActivo(){return !!G.j&&PANTALLAS_SIN_TIEMPO.indexOf(G.screen)<0;}
function avanzarTiempo(min){
 var j=G.j;if(!j||!(min>0))return;
 var a=minJ(j);j.min=a+min;
 var d0=Math.floor(a/MIN_DIA),d1=Math.floor(j.min/MIN_DIA);
 for(var d=d0+1;d<=d1;d++)procesarDia(j,d+1);
 relojRender();
}
function relojTick(){
 if(!relojActivo())return;
 var dia0=diaJ(G.j),listo0=expedicionLista(G.j);
 avanzarTiempo(IDLE_RATE);
 if(G.screen==="city"||G.screen==="tabint"||G.screen==="gremint"||G.screen==="herint"||G.screen==="tienint"||G.screen==="castint"||G.screen==="entint"||G.screen==="muint"||G.screen==="oakint"||G.screen==="mundoint"){relojRender();mapaSync();}
 if(relojOculto())relojRender();
 if(G.screen==="taberna"){
  if(diaJ(G.j)!==dia0||expedicionLista(G.j)!==listo0)render();else tabernaLive();
 }
}
function relojInit(){
 if(document.getElementById("reloj"))return;
 var e=document.createElement("div");e.id="reloj";
 e.style.cssText="position:fixed;top:8px;right:10px;z-index:9999;display:none;padding:4px 11px;border-radius:10px;background:rgba(10,8,5,.82);border:1px solid rgba(201,146,60,.35);font-family:'Karla',sans-serif;font-size:12px;color:#e8dcc4;box-shadow:0 2px 10px rgba(0,0,0,.5);user-select:none";
 e.onclick=function(){if(G.j&&expedicionLista(G.j)){G.screen="taberna";G.tabTab="barra";render();}};
 document.body.appendChild(e);
 setInterval(relojTick,1000);
 setInterval(function(){if(relojActivo()&&G.slot)guardar();},20000);
 window.addEventListener("beforeunload",function(){try{if(G.j&&G.slot)guardar();}catch(e){}});
}
/* true mientras Oakhaven o el Mundo Abierto están en modo online con el reloj del servidor (el mapa avisa cada 4 s) */
function relojOnlineMapa(){return !!window._relojOnline&&Date.now()-window._relojOnline<12000&&(G.screen==="mundoint"||G.screen==="oakint");}
/* sin reloj flotante en Oakhaven, el Mundo Abierto y el Laberinto (online / mapas con su propio reloj) */
function relojOculto(){
 if(["oakint","mundoint","laberinto","conectando"].indexOf(G.screen)>=0)return true;
 try{if(window.labOnlineInfo&&window.labOnlineInfo())return true;}catch(e){}
 return false;
}
function relojRender(){
 var e=document.getElementById("reloj");if(!e)return;
 if(!G.j||["title","slots","intro","create"].indexOf(G.screen)>=0){e.style.display="none";return;}
 if(relojOnlineMapa()||relojOculto()){e.style.display="none";return;}
 var j=G.j,m=Math.floor(minJ(j))%MIN_DIA,sol=(m>=360&&m<1080),listo=expedicionLista(j);
 e.style.display="block";e.style.cursor=listo?"pointer":"default";
 e.innerHTML=(sol?"☀ ":"🌙 ")+"Día "+diaJ(j)+" · <b>"+horaTxt(j)+"</b>"+(listo?' <span style="color:#7ab88a;font-weight:700">· 🍺 Expedición lista</span>':'');
}

/* ---------- estado de la taberna ---------- */
function tabEst(j){
 minJ(j);
 if(!j.tab)j.tab={escuadron:[],cand:[],candDia:0,rumores:[],rumDia:0,ocultas:[],tablon:[],tabDia:0,exp:null,rep:0,recetas:[],avisos:[],informe:null,hechas:[],sid:1};
 var T=j.tab,d=diaJ(j);
 if(!T.avisos)T.avisos=[];if(!T.recetas)T.recetas=[];if(!T.ocultas)T.ocultas=[];if(!T.hechas)T.hechas=[];
 if(!T.cand.length)generarCandidatos(j,d);
 if(!T.rumDia)generarRumores(j,d);
 if(!T.tabDia)refrescarTablon(j,d);
 return T;
}
function expedicionLista(j){return !!(j&&j.tab&&j.tab.exp&&minJ(j)>=j.tab.exp.fin);}
function procesarDia(j,dia){
 if(!j.tab)return;
 var T=j.tab,quedan=[];
 T.escuadron.forEach(function(c){
  if(j.oro>=c.sal){j.oro-=c.sal;quedan.push(c);}
  else T.avisos.push("Día "+dia+": "+c.nombre+" ("+c.prof+") se marchó: no pudiste pagar su salario de "+c.sal+" oro.");
 });
 T.escuadron=quedan;
 if(dia>=T.rumDia+2)generarRumores(j,dia);
 if(dia>=T.candDia+3)generarCandidatos(j,dia);
 refrescarTablon(j,dia);
 if(T.avisos.length>8)T.avisos=T.avisos.slice(-8);
}

/* ---------- 1. BARRA: ESCUADRÓN ---------- */
var CAM_NOMBRES=["Borin","Kael","Mira","Tobias","Elara","Grum","Sibil","Roderic","Nessa","Dorn","Vela","Hakon","Ysolde","Pip","Orla","Thane"];
var CAM_APODOS=["el Tuerto","la Rápida","Manoslargas","el Cojo","la Sabia","Pies Ligeros","el Gruñón","la Ciega","el Viejo","la Zurda"];
var CAM_TIPOS=[
 {prof:"Minero",e:"⛏",sal:60,bono:{t:"cat",g:"menas",v:.25,txt:"+25% menas"},desv:{t:"gasto",oro:25,txt:"Rompe picos: -25 oro por día de expedición"}},
 {prof:"Herborista",e:"🌿",sal:55,bono:{t:"cat",g:"hierbas",v:.25,txt:"+25% hierbas"},desv:{t:"retraso",p:.30,dias:1,txt:"Alérgico: 30% de retrasar la expedición 1 día"}},
 {prof:"Desollador",e:"🐺",sal:60,bono:{t:"cat",g:"pieles",v:.25,txt:"+25% pieles"},desv:{t:"evento",p:.30,oro:120,txt:"Apesta a sangre: 30% de atraer una emboscada (-120 oro)"}},
 {prof:"Tejedor",e:"🧵",sal:55,bono:{t:"cat",g:"telas",v:.25,txt:"+25% telas"},desv:{t:"robo",v:.08,txt:"Manos largas: se queda con el 8% del botín"}},
 {prof:"Gemólogo",e:"💎",sal:75,bono:{t:"gema",p:.5,txt:"50% de traer una gema extra"},desv:{t:"gasto",oro:35,txt:"Caprichoso: -35 oro por día de expedición"}},
 {prof:"Explorador",e:"🧭",sal:80,bono:{t:"rareza",v:.25,txt:"+25% de materiales raros y de loot oculto"},desv:{t:"retraso",p:.25,dias:1,txt:"Se pierde: 25% de retrasar la expedición 1 día"}},
 {prof:"Mercenario",e:"🗡",sal:95,bono:{t:"seguro",v:.5,txt:"-50% de eventos peligrosos"},desv:{t:"gasto",oro:40,txt:"Borracho: -40 oro por día de expedición"}},
 {prof:"Cocinero",e:"🍲",sal:50,bono:{t:"prov",v:.3,txt:"-30% costo de provisiones"},desv:{t:"robo",v:.05,txt:"Se come parte del botín: -5%"}}
];
function generarCandidatos(j,dia){
 var T=j.tab,idx=[],i;
 for(i=0;i<CAM_TIPOS.length;i++)idx.push(i);
 idx.sort(function(){return Math.random()-0.5;});
 T.cand=idx.slice(0,4).map(function(k){
  var t=CAM_TIPOS[k],sal=Math.round(t.sal*(1+j.nivel/25));
  return {id:"c"+(T.sid++),nombre:pick(CAM_NOMBRES)+" "+pick(CAM_APODOS),prof:t.prof,e:t.e,sal:sal,bono:t.bono,desv:t.desv};
 });
 T.candDia=dia;
}
function contratar(j,id){
 var T=tabEst(j),c=T.cand.filter(function(x){return x.id===id;})[0];
 if(!c||T.escuadron.length>=TAB_MAX_ESCUADRON)return false;
 var adelanto=c.sal*2;if(j.oro<adelanto)return false;
 j.oro-=adelanto;T.escuadron.push(c);T.cand=T.cand.filter(function(x){return x.id!==id;});
 avanzarTiempo(15);return true;
}
function despedir(j,id){
 var T=tabEst(j);if(T.exp)return false;
 T.escuadron=T.escuadron.filter(function(x){return x.id!==id;});return true;
}

/* ---------- 2. MESA DEL RINCÓN: RUMORES ---------- */
var TAB_UNICOS={"Colmillo Dorado":1,"Bolsa de Tesoro Goblin":1,"Resina Luminosa":1,"Ámbar de Savia Antigua":1,"Tomo Mohoso":2,"Tinta Arcana Antigua":2,"Cristal Soñador":2,"Esquirla Rúnica":2,"Perla Helada":3,"Aguja de Escarcha Eterna":3,"Colmillo de Mamut Ancestral":3,"Pelaje Nevado":3,"Hierro Estelar":4,"Brasa Eterna":4,"Cáscara de Dragón":4,"Lágrima de Fénix":4,"Ámbar del Desierto":5,"Sello de Faraón":5,"Perla Abisal":6,"Sal del Naufragio":6,"Fragmento del Vacío":6,"Ceniza Espectral":6,"Corona Quebrada":7,"Sangre de Malakor":7};
var TAB_PRECIO={};
(function(){for(var k in TAB_UNICOS)TAB_PRECIO[k]=Math.round(60*TAB_UNICOS[k]*TAB_UNICOS[k]+120*TAB_UNICOS[k]);})();
function _rm(id,n,b,txt,l1,l2,rec,mis){return {id:id,n:n,bioma:b,txt:txt,loot:[[l1,.9,1,2],[l2,.6,1,2]],receta:rec,mision:mis};}
var RUMORES_DEF=[
 _rm("r1","El Goblin que Sabía Demasiado",1,"Un goblin borracho jura que el Rey Goblin enterró su botín bajo un tocón hueco.","Colmillo Dorado","Bolsa de Tesoro Goblin",["guantes","del Saqueador"],"Bajo el tocón hallas un cofre con el sello del Rey Goblin."),
 _rm("r2","Luces en el Pantano Verde",1,"Los leñadores ven luces danzando entre los árboles muertos al caer la noche.","Resina Luminosa","Ámbar de Savia Antigua",null,"Las luces eran espíritus del bosque guardando una savia milenaria."),
 _rm("r3","La Biblioteca Hundida de Eldroria",2,"Una sala sellada de la biblioteca real se abrió con el último temblor.","Tomo Mohoso","Tinta Arcana Antigua",["arma","del Archivista"],"Entre los estantes derrumbados hallas el diario secreto del Archimago Traidor."),
 _rm("r4","El Guardián que Sueña",2,"Dicen que un guardián de cristal murmura cada noche un nombre olvidado.","Cristal Soñador","Esquirla Rúnica",null,"El guardián despierta un instante y te entrega una esquirla antes de apagarse."),
 _rm("r5","Canto bajo el Hielo",3,"Los cazadores de Nersaz oyen una melodía bajo el lago congelado.","Perla Helada","Aguja de Escarcha Eterna",["botas","del Ventisquero"],"Rompes el hielo y encuentras un coro de perlas cantoras."),
 _rm("r6","El Último Mamut",3,"Un mamut anciano se retiró a morir a una cueva que solo conoce un trampero.","Colmillo de Mamut Ancestral","Pelaje Nevado",["pecho","del Mamut"],"El mamut te deja sus colmillos como pago por acompañarlo."),
 _rm("r7","La Forja que no se Apaga",4,"En Ignisgarde hay una fragua sin dueño cuyo fuego nunca se extingue.","Hierro Estelar","Brasa Eterna",["arma","de la Forja Eterna"],"Soplas las brasas y la fragua te revela un lingote caído del cielo."),
 _rm("r8","El Huevo del Dragón Joven",4,"Un mercader vende un mapa que promete un nido abandonado.","Cáscara de Dragón","Lágrima de Fénix",["accesorio","del Dragón Joven"],"El nido estaba vacío, pero las cáscaras aún guardan calor."),
 _rm("r9","Tormenta de Arena Dorada",5,"Una caravana perdida en Artaros dejó un cargamento bajo las dunas.","Ámbar del Desierto","Sello de Faraón",["piernas","del Faraón"],"Desentierras el cargamento y un sello real brilla entre la arena."),
 _rm("r10","Susurros de Ghaela",6,"Los pescadores escuchan voces que prometen riquezas bajo la marea baja.","Perla Abisal","Sal del Naufragio",["pecho","del Leviatán"],"En la marea baja aparece la bodega de un barco hundido hace siglos."),
 _rm("r11","Ecos del Olvidado",6,"Un cultista arrepentido cuenta que el Olvidado dejó fragmentos de sí mismo.","Fragmento del Vacío","Ceniza Espectral",["accesorio","del Vacío"],"Los fragmentos vibran al reconocer tu nombre."),
 _rm("r12","El Trono de Ebanos",7,"Se murmura que el trono del Señor de Ebanos no fue destruido, solo escondido.","Corona Quebrada","Sangre de Malakor",["arma","del Trono Caído"],"El trono te acepta un instante y suelta su corona rota.")
];
function rumorPrecio(r){return 200+150*r.bioma;}
function generarRumores(j,dia){
 var T=j.tab,b=getBioma(j).id;
 var ya=T.ocultas.map(function(o){return o.rid;});
 var pool=RUMORES_DEF.filter(function(r){return r.bioma<=b&&ya.indexOf(r.id)<0;});
 pool.sort(function(){return Math.random()-0.5;});
 T.rumores=pool.slice(0,rnd(2,3)).map(function(r){return r.id;});
 T.rumDia=dia;
}
function comprarRumor(j,rid){
 var T=tabEst(j),r=RUMORES_DEF.filter(function(x){return x.id===rid;})[0];
 if(!r||T.rumores.indexOf(rid)<0)return false;
 var pr=rumorPrecio(r);if(j.oro<pr)return false;
 j.oro-=pr;T.rumores=T.rumores.filter(function(x){return x!==rid;});
 T.ocultas.push({rid:rid,dia:diaJ(j)});
 avanzarTiempo(10);return true;
}

/* ---------- Recetas de la Taberna (Épicas por tablón, Legendarias por rumor) ---------- */
var TAB_BASES={
 Guerrero:{arma:"Espada Mayor",pecho:"Coraza",piernas:"Grebas",guantes:"Manoplas",botas:"Botas",accesorio:"Sello"},
 Paladin:{arma:"Martillo Sagrado",pecho:"Égida",piernas:"Escarcelas",guantes:"Guanteletes",botas:"Botas Consagradas",accesorio:"Relicario"},
 Arquero:{arma:"Arco Largo",pecho:"Jubón",piernas:"Pantalones de Cazador",guantes:"Guantes de Tirador",botas:"Botas de Rastreo",accesorio:"Carcaj"},
 Asesino:{arma:"Dagas Gemelas",pecho:"Chaleco de Sombras",piernas:"Calzas Silenciosas",guantes:"Guantes de Ladrón",botas:"Botas Sigilosas",accesorio:"Amuleto"},
 Mago:{arma:"Báculo",pecho:"Túnica",piernas:"Pantalones Arcanos",guantes:"Guantes Arcanos",botas:"Botas Arcanas",accesorio:"Orbe"},
 "Clérigo":{arma:"Cetro",pecho:"Vestidura",piernas:"Pantalones Sagrados",guantes:"Guantes de Plegaria",botas:"Botas de Gracia",accesorio:"Rosario"}
};
var TAB_EPICAS=[
 {id:"t1",slot:"arma",tema:"de la Guardia Real",ing:{"Mena de Hierro":15,"Mena de Plata":8,"Escama Gélida":4}},
 {id:"t2",slot:"pecho",tema:"del Cazador de Ogros",ing:{"Piel de Oso":10,"Escama de Basilisco":6,"Esencia de Cristal":6}},
 {id:"t3",slot:"piernas",tema:"de la Caravana Perdida",ing:{"Cuero de Jabalí":12,"Piel de Lobo":10,"Núcleo de Lava":3}},
 {id:"t4",slot:"guantes",tema:"del Maestro Armero",ing:{"Seda de Araña":10,"Algodón Salvaje":8,"Esencia de Cristal":4}},
 {id:"t5",slot:"botas",tema:"del Peregrino",ing:{"Piel de Yeti":8,"Piel de Oso":6,"Escama Gélida":4}},
 {id:"t6",slot:"accesorio",tema:"del Gremio Dorado",ing:{"Zafiro Bruto":4,"Rubí Bruto":3,"Lingote de Opalo":2}}
];
var TABERNA_REC=[];
(function(){
 var clases=Object.keys(TAB_BASES);
 function ref(c,slot,rar){
  var m=null;
  RECETAS_FORJA.forEach(function(r){if(r[2]===c&&r[3]===slot&&r[8]===rar)m=r;});
  return m;
 }
 clases.forEach(function(c){
  TAB_EPICAS.forEach(function(e){
   var f=ref(c,e.slot,3);if(!f)return;
   TABERNA_REC.push({id:e.id,fuente:"tablon",clase:c,slot:e.slot,mult:2.5,fila:[TAB_BASES[c][e.slot]+" "+e.tema,f[1],c,f[3],Math.round(f[4]*1.1),Math.round(f[5]*1.1),Math.round(f[6]*1.1),Math.round(f[7]*1.1),3,9,e.ing,Math.round(f[11]*1.1)]});
  });
  RUMORES_DEF.forEach(function(r){
   if(!r.receta)return;
   var f=ref(c,r.receta[0],4);if(!f)return;
   var ing={};ing[r.loot[0][0]]=3;ing[r.loot[1][0]]=3;ing[BIOMAS[r.bioma].material]=6;
   TABERNA_REC.push({id:"leg_"+r.id,fuente:"rumor",clase:c,slot:r.receta[0],mult:3.5,fila:[TAB_BASES[c][r.receta[0]]+" "+r.receta[1],f[1],c,f[3],Math.round(f[4]*1.2),Math.round(f[5]*1.2),Math.round(f[6]*1.2),Math.round(f[7]*1.2),4,10,ing,Math.round(f[11]*1.2)]});
  });
 });
})();
function recetasTaberna(j){
 var T=tabEst(j);
 return TABERNA_REC.filter(function(r){return r.clase===j.clase&&T.recetas.indexOf(r.id)>=0;}).map(function(r){
  var o=recetaObj(r.fila);o.attr=attrItem(r.clase,r.slot,r.fila[9],r.mult);return o;
 });
}
function desbloquearReceta(j,id){
 var T=tabEst(j);if(T.recetas.indexOf(id)>=0)return false;
 T.recetas.push(id);return true;
}

/* ---------- Expediciones ---------- */
function expDestinos(j){
 var T=tabEst(j),b=getBioma(j).id,l=[];
 for(var i=1;i<=b;i++)l.push({id:"b"+i,tipo:"recurso",nombre:"Recolección en "+BIOMAS[i].nombre,bioma:i,dias:7,costo:60+40*i});
 T.ocultas.forEach(function(o){
  var r=RUMORES_DEF.filter(function(x){return x.id===o.rid;})[0];
  if(r)l.push({id:"o"+r.id,tipo:"oculta",nombre:"★ "+r.n,bioma:r.bioma,dias:5,costo:150+80*r.bioma,rid:r.id});
 });
 return l;
}
function expCostos(j,d){
 var T=tabEst(j),prov=d.costo,gasto=0;
 T.escuadron.forEach(function(c){
  if(c.bono.t==="prov")prov=Math.round(prov*(1-c.bono.v));
  if(c.desv.t==="gasto")gasto+=c.desv.oro*d.dias;
 });
 return {prov:prov,gasto:gasto,total:prov+gasto};
}
function enviarExpedicion(j,did){
 var T=tabEst(j),d=expDestinos(j).filter(function(x){return x.id===did;})[0];
 if(!d||T.exp||!T.escuadron.length)return false;
 var c=expCostos(j,d);if(j.oro<c.total)return false;
 j.oro-=c.total;
 var dias=d.dias,notas=[];
 T.escuadron.forEach(function(m){if(m.desv.t==="retraso"&&Math.random()<m.desv.p){dias+=m.desv.dias;notas.push(m.nombre+" ("+m.desv.txt.split(":")[0]+") retrasa la expedición "+m.desv.dias+" día.");}});
 var ini=minJ(j);
 T.exp={did:d.id,tipo:d.tipo,nombre:d.nombre,bioma:d.bioma,rid:d.rid||null,dias:dias,inicio:ini,fin:ini+dias*MIN_DIA,miembros:T.escuadron.map(function(m){return JSON.parse(JSON.stringify(m));}),costo:c.total,notas:notas};
 if(d.tipo==="oculta")T.ocultas=T.ocultas.filter(function(o){return o.rid!==d.rid;});
 avanzarTiempo(20);
 return true;
}
function redond(x){return Math.floor(x)+(Math.random()<(x%1)?1:0);}
function catItems(b){
 var niv=Math.min(100,1+(b-1)*14);
 var pool=function(l){var p=l.filter(function(x){return x[1]<=niv&&x[1]>niv-30;});if(!p.length)p=l.filter(function(x){return x[1]<=niv;});return p.map(function(x){return x[0];});};
 return {menas:pool(PROF_RAW.herrero.main),pieles:pool(PROF_RAW.peletero.main),hierbas:pool(PROF_RAW.alquimista.main),telas:pool(PROF_RAW.sastre.main),gemas:pool(PROF_RAW.joyero.extra)};
}
function efectosEscuadron(miembros){
 var f={cat:{},gema:0,rareza:0,seguro:0,robo:0};
 miembros.forEach(function(m){
  var b=m.bono,d=m.desv;
  if(b.t==="cat")f.cat[b.g]=(f.cat[b.g]||0)+b.v;
  else if(b.t==="gema")f.gema=Math.max(f.gema,b.p);
  else if(b.t==="rareza")f.rareza+=b.v;
  else if(b.t==="seguro")f.seguro=Math.max(f.seguro,b.v);
  if(d.t==="robo")f.robo+=d.v;
 });
 return f;
}
function cobrarExpedicion(j){
 var T=tabEst(j),e=T.exp;
 if(!e||minJ(j)<e.fin)return null;
 var f=efectosEscuadron(e.miembros),b=e.bioma,out={},lines=[];
 function add(n,q){if(q>0)out[n]=(out[n]||0)+q;}
 /* eventos */
 var ne=Math.max(1,Math.floor(e.dias/3)),pel=0.25*(1-f.seguro),extra=0;
 for(var k=0;k<ne;k++){
  var r=Math.random();
  if(r<pel){var perd=Math.min(j.oro,50+30*b);j.oro-=perd;lines.push("⚠ Emboscada en el camino: pierdes "+perd+" oro.");}
  else if(r<pel+0.2){extra++;lines.push("✨ Hallazgo afortunado: botín extra.");}
 }
 e.miembros.forEach(function(m){if(m.desv.t==="evento"&&Math.random()<m.desv.p){var p2=Math.min(j.oro,m.desv.oro);j.oro-=p2;lines.push("⚠ "+m.nombre+" atrae una emboscada: -"+p2+" oro.");}});
 if(e.tipo==="recurso"){
  var cats=catItems(b),drops=LOOT_BIOMA[b].drops,rolls=8+4*b+extra*3;
  for(var i=0;i<rolls;i++){
   if(Math.random()<0.55){
    var keys=["menas","pieles","hierbas","telas"],kc=pick(keys),q=redond(rnd(1,3)*(1+(f.cat[kc]||0)));
    add(pick(cats[kc]),q);
   }else{
    var tot=0,ws=drops.map(function(d){var w=100*Math.pow(.5,d[2])*(d[2]>=1?(1+f.rareza*2):1);tot+=w;return w;}),rr=Math.random()*tot,ix=0;
    while(ix<ws.length-1&&rr>=ws[ix]){rr-=ws[ix];ix++;}
    add(drops[ix][0],rnd(1,2));
   }
  }
  if(f.gema&&Math.random()<f.gema)add(pick(cats.gemas),1);
 }else{
  var r2=RUMORES_DEF.filter(function(x){return x.id===e.rid;})[0];
  if(r2){
   r2.loot.forEach(function(l,idx){if(idx===0||Math.random()<Math.min(1,l[1]*(1+f.rareza)))add(l[0],rnd(l[2],l[3]));});
   var dr=LOOT_BIOMA[b].drops,rare=dr[dr.length-1];add(rare[0],rnd(1,3));
   lines.push("📜 "+r2.mision);
   if(r2.receta){
    var rid="leg_"+r2.id;
    if(desbloquearReceta(j,rid)){
     var rr2=TABERNA_REC.filter(function(x){return x.id===rid&&x.clase===j.clase;})[0];
     lines.push("🏆 ¡Receta legendaria descubierta: "+(rr2?rr2.fila[0]:rid)+"! (Herrería > Forja > Taberna)");
    }
   }
   T.hechas.push(r2.id);
  }
 }
 /* robo / mermas */
 if(f.robo>0){for(var n in out){var q2=Math.floor(out[n]*(1-Math.min(.5,f.robo)));out[n]=q2;}lines.push("⚠ Tu escuadrón se quedó con parte del botín.");}
 var res=[];
 for(var n2 in out){if(out[n2]>0){agregarItem(j,n2,out[n2]);res.push(out[n2]+" "+n2);}}
 T.informe={nombre:e.nombre,dia:diaJ(j),lineas:lines,botin:res};
 T.exp=null;
 avanzarTiempo(10);
 return T.informe;
}

/* ---------- 3. TABLÓN: ENCARGOS ---------- */
var ENCARGOS_DEF=[
 {item:"Mena de Cobre",c:[15,25],minB:1,txt:"Necesito {n} Menas de Cobre para la fragua del pueblo."},
 {item:"Mena de Estaño",c:[10,18],minB:1,txt:"El herrero pide {n} Menas de Estaño para fundir bronce."},
 {item:"Pellejo de Conejo",c:[8,14],minB:1,txt:"Se necesita cuero ligero ({n} pellejos) para reparar los arneses de la guardia."},
 {item:"Piel de Lobo",c:[8,12],minB:1,txt:"La guardia busca {n} Pieles de Lobo para forrar los cuarteles."},
 {item:"Flor de Paz",c:[12,20],minB:1,txt:"El boticario necesita {n} Flores de Paz."},
 {item:"Hoja de Plata",c:[10,16],minB:1,txt:"Un alquimista pide {n} Hojas de Plata."},
 {item:"Fibra de Lino",c:[15,25],minB:1,txt:"La costurera encarga {n} Fibras de Lino."},
 {item:"Lana Cruda",c:[12,20],minB:1,txt:"Necesitamos {n} Lanas Crudas antes del invierno."},
 {item:"Cuero Curtido Genérico",c:[6,10],minB:1,txt:"Necesito {n} cueros curtidos para reparar las sillas del gremio."},
 {item:"Poción de Vida",c:[3,5],minB:1,txt:"El hospital se quedó sin pociones: {n} Pociones de Vida."},
 {item:"Mena de Hierro",c:[15,25],minB:3,txt:"La guardia real pide {n} Menas de Hierro."},
 {item:"Mena de Plata",c:[8,14],minB:3,txt:"Un joyero necesita {n} Menas de Plata."},
 {item:"Piel de Oso",c:[8,12],minB:3,txt:"Se necesitan {n} Pieles de Oso para los abrigos del norte."},
 {item:"Seda de Araña",c:[8,14],minB:3,txt:"La sastrería real encarga {n} Sedas de Araña."},
 {item:"Mena de Oro",c:[10,16],minB:5,txt:"El tesoro del reino requiere {n} Menas de Oro."},
 {item:"Piel de Yeti",c:[8,12],minB:5,txt:"Un noble exige {n} Pieles de Yeti."},
 {item:"Lingote de Bronce",c:[15,20],minB:1,craft:true,txt:"Necesito {n} lingotes de bronce para la armería."},
 {item:"Lingote de Hierro",c:[10,16],minB:3,craft:true,txt:"La fortaleza pide {n} lingotes de hierro."},
 {item:"Cuero Ligero Curtido de Lobo",c:[6,10],minB:1,craft:true,txt:"Se necesita cuero ligero curtido ({n}) para reparar las armaduras de la guardia."},
 {item:"Hilo de Plata",c:[6,10],minB:3,craft:true,txt:"La sastrería necesita {n} Hilos de Plata."}
];
function encargoItems(j){
 var b=getBioma(j).id,mats=[];
 for(var i=1;i<=b;i++)mats.push({item:BIOMAS[i].material,c:[8,14],minB:i,txt:"El gremio de mercaderes compra {n} "+BIOMAS[i].material+"."});
 return ENCARGOS_DEF.filter(function(x){return x.minB<=b&&(!x.craft||PROF_ACTIVO);}).concat(mats);
}
function generarEncargo(j,dia){
 var T=j.tab,pool=encargoItems(j),usados=T.tablon.map(function(e){return e.item;});
 var libres=pool.filter(function(x){return usados.indexOf(x.item)<0;});if(!libres.length)libres=pool;
 var d=pick(libres),n=rnd(d.c[0],d.c[1]),b=getBioma(j).id;
 var oro=Math.round(n*precioMaterial(d.item)*1.8+40*b);
 var rec=null;
 if(Math.random()<0.35){
  var pend=TABERNA_REC.filter(function(r){return r.clase===j.clase&&r.fuente==="tablon"&&T.recetas.indexOf(r.id)<0;});
  var yaOfrecida=T.tablon.map(function(e){return e.receta;});
  pend=pend.filter(function(r){return yaOfrecida.indexOf(r.id)<0;});
  if(pend.length)rec=pick(pend).id;
 }
 return {id:"e"+(T.sid++),item:d.item,cant:n,oro:oro,receta:rec,vence:dia+rnd(6,10),txt:d.txt.replace("{n}",n)};
}
function refrescarTablon(j,dia){
 var T=j.tab;
 T.tablon=T.tablon.filter(function(e){return e.vence>=dia;});
 while(T.tablon.length<4)T.tablon.push(generarEncargo(j,dia));
 T.tabDia=dia;
}
function entregarEncargo(j,id){
 var T=tabEst(j),e=T.tablon.filter(function(x){return x.id===id;})[0];
 if(!e||(j.inventario[e.item]||0)<e.cant)return false;
 j.inventario[e.item]-=e.cant;if(j.inventario[e.item]<=0)delete j.inventario[e.item];
 j.oro+=e.oro;T.rep=(T.rep||0)+1;
 var msg="Entregaste "+e.cant+" "+e.item+": +"+e.oro+" oro.";
 if(e.receta){desbloquearReceta(j,e.receta);var rr=TABERNA_REC.filter(function(x){return x.id===e.receta&&x.clase===j.clase;})[0];msg+=" 📜 Receta obtenida: "+(rr?rr.fila[0]:e.receta)+" (Herrería > Forja > Taberna).";}
 T.tablon=T.tablon.filter(function(x){return x.id!==id;});
 T.informe={nombre:"Encargo entregado",dia:diaJ(j),lineas:[msg],botin:[]};
 avanzarTiempo(10);
 refrescarTablon(j,diaJ(j));
 return true;
}

/* ---------- UI ---------- */
function diasTxt(min){var d=min/MIN_DIA;return d>=1?d.toFixed(1)+" días":Math.max(1,Math.round(min/60))+" h";}
function realTxt(min){var s=min/IDLE_RATE,m=Math.floor(s/60),ss=Math.round(s%60);return m>0?"≈ "+m+" min "+pad2(ss)+" s":"≈ "+ss+" s";}
function renderTaberna(){
 var j=G.j,T=tabEst(j),dia=diaJ(j);
 if(["barra","rumores","tablon"].indexOf(G.tabTab)<0)G.tabTab="barra";
 var nuevos=T.rumores.length,listo=expedicionLista(j);
 var h=hudHTML(j)+'<div class="card"><div class="font-disp" style="color:var(--accent);margin-bottom:6px;font-size:16px">🍺 Taberna del Cuervo Dorado</div>';
 h+='<div style="font-size:11px;color:var(--muted);margin-bottom:10px">Día '+dia+' · '+horaTxt(j)+' · Reputación '+(T.rep||0)+(listo?' · <span style="color:#7ab88a">¡Tu expedición ha vuelto!</span>':'')+'</div>';
 h+='<div style="display:flex;gap:6px;flex-wrap:wrap;margin-bottom:12px">';
 [["barra","🍺 Barra · Escuadrón"+(listo?" ●":"")],["rumores","🕯 Mesa del Rincón"+(nuevos?" ("+nuevos+")":"")],["tablon","📋 Tablón ("+T.tablon.length+")"]].forEach(function(t){h+='<button class="btn tabT" data-t="'+t[0]+'" style="padding:6px 12px;font-size:12px;'+(G.tabTab===t[0]?'background:var(--accent-soft);border-color:var(--accent)':'')+'">'+t[1]+'</button>';});
 h+='</div>';
 if(T.avisos.length){h+='<div style="margin-bottom:10px;padding:8px;border-radius:8px;background:rgba(168,50,50,.14);border:1px solid rgba(168,50,50,.4);font-size:12px">'+T.avisos.map(function(a){return '⚠ '+a;}).join('<br>')+'<br><button class="btn" id="bAvisos" style="margin-top:6px;padding:3px 10px;font-size:11px">Entendido</button></div>';}
 if(T.informe){h+='<div style="margin-bottom:10px;padding:8px;border-radius:8px;background:var(--accent-soft);border:1px solid var(--accent);font-size:12px"><b>'+T.informe.nombre+'</b>'+T.informe.lineas.map(function(l){return '<div>'+l+'</div>';}).join('')+(T.informe.botin.length?'<div style="margin-top:4px"><b>Botín:</b> '+T.informe.botin.join(', ')+'</div>':'')+'<button class="btn" id="bInforme" style="margin-top:6px;padding:3px 10px;font-size:11px">Cerrar informe</button></div>';}
 var fila='<div style="display:flex;justify-content:space-between;align-items:center;gap:8px;padding:8px 0;border-bottom:1px dashed var(--border);font-size:13px;flex-wrap:wrap">';
 if(G.tabTab==="barra"){
  h+='<div style="font-weight:700;margin-bottom:6px">Escuadrón ('+T.escuadron.length+'/'+TAB_MAX_ESCUADRON+') <span style="font-weight:400;color:var(--muted);font-size:11px">· salario diario, se descuenta cada medianoche</span></div>';
  if(!T.escuadron.length)h+='<div style="color:var(--muted);font-size:13px;margin-bottom:8px">Aún no tienes camaradas. Contrata hasta 2.</div>';
  T.escuadron.forEach(function(c){
   h+='<div class="card" style="padding:10px;margin-bottom:8px;background:rgba(0,0,0,.22)"><div style="display:flex;justify-content:space-between;align-items:center"><b>'+c.e+' '+c.nombre+' <span class="pill">'+c.prof+'</span></b><span style="color:#e0c060;font-size:12px">'+c.sal+' oro/día</span></div><div style="font-size:12px;color:#7ab88a;margin-top:4px">▲ '+c.bono.txt+'</div><div style="font-size:12px;color:#e08080">▼ '+c.desv.txt+'</div>'+(T.exp?'<div style="font-size:11px;color:var(--muted);margin-top:4px">En expedición</div>':'<button class="btn despedir" data-id="'+c.id+'" style="margin-top:6px;padding:3px 10px;font-size:11px">Despedir</button>')+'</div>';
  });
  h+='<div class="cmb-sub">En la barra (disponibles) — nuevos candidatos en '+Math.max(0,T.candDia+3-dia)+' día(s)</div>';
  if(!T.cand.length)h+='<div style="color:var(--muted);font-size:13px">Nadie busca trabajo hoy.</div>';
  T.cand.forEach(function(c){
   var ad=c.sal*2,lleno=T.escuadron.length>=TAB_MAX_ESCUADRON;
   h+=fila+'<div><b>'+c.e+' '+c.nombre+'</b> <span class="pill">'+c.prof+'</span><div style="font-size:11px;color:#7ab88a">▲ '+c.bono.txt+'</div><div style="font-size:11px;color:#e08080">▼ '+c.desv.txt+'</div></div><div style="text-align:right"><div style="font-size:11px;color:var(--muted)">'+c.sal+' oro/día</div><button class="btn contratar" data-id="'+c.id+'" style="padding:4px 12px;font-size:12px" '+((lleno||j.oro<ad)?'disabled':'')+'>Contratar ('+ad+')</button></div></div>';
  });
  h+='<div class="cmb-sub" id="tabSecExp">Expedición</div>';
  if(T.exp){
   var e=T.exp,rest=Math.max(0,e.fin-minJ(j)),tot=e.fin-e.inicio,p=Math.min(100,(1-rest/tot)*100);
   h+='<div class="card" style="padding:10px;background:rgba(0,0,0,.22)"><div style="font-weight:700">'+e.nombre+'</div><div style="font-size:11px;color:var(--muted);margin:3px 0">Escuadrón: '+e.miembros.map(function(m){return m.nombre;}).join(' y ')+' · '+e.dias+' días</div>'+(e.notas&&e.notas.length?'<div style="font-size:11px;color:#e08080">'+e.notas.join('<br>')+'</div>':'')+'<div class="bar" style="margin-top:6px"><div id="tabExpBar" style="width:'+p+'%;background:linear-gradient(90deg,#3c6ab8,#7ab88a)"></div></div><div id="tabExpTxt" style="font-size:12px;margin-top:4px">'+(rest>0?'Regresa en '+diasTxt(rest)+' de juego ('+realTxt(rest)+' reales)':'¡Han regresado!')+'</div><button class="btn btn-primary" id="bCobrar" style="margin-top:8px" '+(rest>0?'disabled':'')+'>Recibir expedición y cobrar botín</button></div>';
  }else{
   var dest=expDestinos(j);if(!G.tabDest||!dest.some(function(d){return d.id===G.tabDest;}))G.tabDest=dest[0].id;
   h+='<div style="font-size:12px;color:var(--muted);margin-bottom:6px">El escuadrón entero sale a recolectar. Recursos: 7 días de juego (~30 min reales). Expediciones ocultas: 5 días.</div><div style="display:flex;gap:6px;flex-wrap:wrap;margin-bottom:8px">';
   dest.forEach(function(d){h+='<button class="btn destBtn" data-d="'+d.id+'" style="padding:4px 10px;font-size:11px;'+(G.tabDest===d.id?'background:var(--accent-soft);border-color:var(--accent)':'')+'">'+d.nombre+' · '+d.dias+'d</button>';});
   h+='</div>';
   var sel=dest.filter(function(d){return d.id===G.tabDest;})[0],co=expCostos(j,sel);
   h+='<div style="font-size:12px;margin-bottom:6px">Costo: provisiones '+co.prov+(co.gasto?' + gastos del escuadrón '+co.gasto:'')+' = <b style="color:#e0c060">'+co.total+' oro</b></div>';
   h+='<button class="btn btn-primary" id="bEnviar" '+((!T.escuadron.length||j.oro<co.total)?'disabled':'')+'>🧭 Enviar expedición ('+sel.dias+' días)</button>'+(!T.escuadron.length?'<div style="font-size:11px;color:#e08080;margin-top:4px">Necesitas al menos 1 camarada.</div>':'');
  }
 }
 else if(G.tabTab==="rumores"){
  h+='<div style="font-size:12px;color:var(--muted);margin-bottom:8px">Cada 2 días llegan 2-3 rumores nuevos (próximos en '+Math.max(0,T.rumDia+2-dia)+' día(s)). Compra uno para desbloquear una expedición oculta con loot y recetas que no están en el mapa normal.</div>';
  if(!T.rumores.length)h+='<div style="color:var(--muted);font-size:13px">La mesa está vacía. Vuelve más tarde.</div>';
  T.rumores.forEach(function(rid){
   var r=RUMORES_DEF.filter(function(x){return x.id===rid;})[0],pr=rumorPrecio(r);
   h+=fila+'<div style="flex:1;min-width:200px"><b>🕯 '+r.n+'</b> <span class="pill">'+BIOMAS[r.bioma].nombre+'</span><div style="font-size:12px;color:var(--muted);margin-top:2px">'+r.txt+'</div></div><button class="btn comprarRumor" data-r="'+rid+'" style="padding:5px 12px;font-size:12px" '+(j.oro<pr?'disabled':'')+'>Comprar ('+pr+')</button></div>';
  });
  h+='<div class="cmb-sub">Expediciones ocultas desbloqueadas</div>';
  if(!T.ocultas.length)h+='<div style="color:var(--muted);font-size:13px">Ninguna. Compra un rumor para desbloquearla.</div>';
  T.ocultas.forEach(function(o){var r=RUMORES_DEF.filter(function(x){return x.id===o.rid;})[0];h+='<div style="font-size:13px;padding:4px 0">★ <b>'+r.n+'</b> <span style="color:var(--muted);font-size:11px">— envíala desde la Barra</span></div>';});
  var rc=recetasTaberna(j);
  h+='<div class="cmb-sub">Recetas de la Taberna obtenidas</div>';
  if(!rc.length)h+='<div style="color:var(--muted);font-size:13px">Ninguna aún.</div>';
  rc.forEach(function(r){h+='<div style="font-size:12px;padding:2px 0">📜 '+r.n+' <span style="color:var(--muted)">('+r.rareza+')</span></div>';});
 }
 else{
  h+='<div style="font-size:12px;color:var(--muted);margin-bottom:8px">Encargos de materiales. Saca tu excedente y llévate oro y, a veces, una receta.</div>';
  if(!T.tablon.length)h+='<div style="color:var(--muted);font-size:13px">No hay encargos.</div>';
  T.tablon.forEach(function(e){
   var tiene=j.inventario[e.item]||0,ok=tiene>=e.cant,rr=e.receta?TABERNA_REC.filter(function(x){return x.id===e.receta&&x.clase===j.clase;})[0]:null;
   h+=fila+'<div style="flex:1;min-width:220px"><div>'+e.txt+'</div><div style="font-size:12px;margin-top:2px"><span style="color:'+(ok?'#7ab88a':'#e08080')+'">'+itemImg(e.item,22)+e.item+' '+tiene+'/'+e.cant+'</span> · <span style="color:var(--muted)">vence en '+Math.max(0,e.vence-dia+1)+' día(s)</span></div><div style="font-size:12px;color:#e0c060">Recompensa: '+e.oro+' oro'+(rr?' + 📜 '+rr.fila[0]:'')+'</div></div><button class="btn entregar" data-id="'+e.id+'" style="padding:5px 12px;font-size:12px" '+(ok?'':'disabled')+'>Entregar</button></div>';
  });
 }
 h+='<div style="margin-top:14px"><button class="btn" id="bBack">← Volver a la sala</button></div></div>';
 el.innerHTML=h;
 document.querySelectorAll(".tabT").forEach(function(b){b.onclick=function(){G.tabTab=b.getAttribute("data-t");render();};});
 var bA=document.getElementById("bAvisos");if(bA)bA.onclick=function(){T.avisos=[];guardar();render();};
 var bI=document.getElementById("bInforme");if(bI)bI.onclick=function(){T.informe=null;render();};
 document.querySelectorAll(".despedir").forEach(function(b){b.onclick=function(){if(despedir(j,b.getAttribute("data-id"))){guardar();render();}};});
 document.querySelectorAll(".contratar").forEach(function(b){b.onclick=function(){if(contratar(j,b.getAttribute("data-id"))){guardar();render();}};});
 document.querySelectorAll(".destBtn").forEach(function(b){b.onclick=function(){G.tabDest=b.getAttribute("data-d");render();};});
 var bE=document.getElementById("bEnviar");if(bE)bE.onclick=function(){if(enviarExpedicion(j,G.tabDest)){guardar();render();}};
 var bC=document.getElementById("bCobrar");if(bC)bC.onclick=function(){if(cobrarExpedicion(j)){guardar();render();}};
 document.querySelectorAll(".comprarRumor").forEach(function(b){b.onclick=function(){if(comprarRumor(j,b.getAttribute("data-r"))){guardar();render();}};});
 document.querySelectorAll(".entregar").forEach(function(b){b.onclick=function(){if(entregarEncargo(j,b.getAttribute("data-id"))){guardar();render();}};});
 document.getElementById("bBack").onclick=function(){G.screen="tabint";render();};
 if(G.tabScroll){var _sx=document.getElementById("tabSecExp");G.tabScroll=null;if(_sx)_sx.scrollIntoView({block:"start"});else window.scrollTo(0,0);}else window.scrollTo(0,0);
}
function tabernaLive(){
 var j=G.j,T=j&&j.tab;if(!T||!T.exp)return;
 var e=T.exp,rest=Math.max(0,e.fin-minJ(j)),tot=e.fin-e.inicio;
 var b=document.getElementById("tabExpBar");if(b)b.style.width=Math.min(100,(1-rest/tot)*100)+"%";
 var t=document.getElementById("tabExpTxt");if(t)t.textContent=rest>0?"Regresa en "+diasTxt(rest)+" de juego ("+realTxt(rest)+" reales)":"¡Han regresado!";
}
/* ---------- Ciudad = mapa 2.5D · Interior de la Taberna (iframes persistentes) ---------- */
function volverLocal(){var v=G.desdeOak?"oakint":"city";G.desdeOak=false;G.screen=v;render();}
function irLocal(id){
 G.desdeOak=(G.screen==="oakint");
 var t={
  tienda:function(){G.screen="tienint";},
  gremio:function(){G.screen="gremint";},
  herreria:function(){G.screen="herint";},
  alquimista:function(){G.screen="alqint";},
  hospital:function(){G.screen="hospint";},
  taberna:function(){G.screen="tabint";},
  castillo:function(){G.screen="castint";},
  entrenamiento:function(){G.screen="entint";},
  muelle:function(){G.screen="muint";}
 }[id];
 if(!t)return;t();render();
}
/* personajes fijos del interior -> interfaz de la Taberna */
function irNpcTaberna(id){
 var m={barra:["barra",0],exp:["barra","exp"],rumores:["rumores",0],tablon:["tablon",0]}[id];
 if(!m)return;G.tabTab=m[0];G.tabScroll=m[1]||null;G.screen="taberna";render();
}
function irNpcCastillo(id){
 if(id==="aventura"){G.screen="aventura";render();}
 else if(id==="infinita"){G.screen="infinita";render();}
}
function irNpcHerreria(id){
 var m={armas:["comprar","arma"],armaduras:["comprar","armadura"],accesorios:["comprar","accesorio"],forja:["forja",null],mejorar:["mejorar",null]}[id];
 if(!m)return;generarStock();G.herreriaTab=m[0];if(m[0]==="comprar")G.herrCSub=m[1];G.screen="herreria";render();
}
function irNpcHospital(id){
 if(["sanar","recurso","purga"].indexOf(id)<0)return;G.screen="hospital";render();
}
function irNpcTienda(id){
 var m={equipo:["comprar","armas"],pociones:["comprar","pociones"],misc:["comprar","misc"],vender:["vender","equipo"]}[id];
 if(!m)return;generarStock();G.shopModo=m[0];if(m[0]==="comprar")G.shopTab=m[1];else G.shopVSub=m[1];G.screen="shop";render();
}
function irNpcAlquimia(id){
 var m={craftear:"pocion",transmutar:"transmutar"}[id];
 if(!m)return;G.alquimistaTab=m;G.screen="alquimista";render();
}
function irNpcGremio(id){
 if(["campana","grupo","rango","vender","profesion"].indexOf(id)<0)return;G.gremioTab=id;G.screen="gremio";render();
}
var _mapaFr={},MAPA_URL={city:"tilemap/mapa.html?embed=1",tabint:"tilemap/taberna_mapa.html",gremint:"tilemap/gremio_mapa.html",herint:"tilemap/herreria_mapa.html",hospint:"tilemap/hospital_mapa.html",alqint:"tilemap/alquimia_mapa.html",tienint:"tilemap/tienda_mapa.html",castint:"tilemap/castillo_mapa.html",entint:"tilemap/entrenamiento_mapa.html",muint:"tilemap/muelle_mapa.html",oakint:"tilemap/oakhaven_mapa.html?embed=1&online=1",mundoint:"tilemap/mundo_mapa.html?embed=1&online=1"};
/* Cierra los mapas ya abiertos (se vuelven a crear con el personaje elegido de la partida actual) */
function mapaReset(){for(var k in _mapaFr){try{if(_mapaFr[k].parentNode)_mapaFr[k].parentNode.removeChild(_mapaFr[k]);}catch(e){}}_mapaFr={};document.body.style.overflow="";}
function mapaVis(scr){
 var any=false;
 for(var k in MAPA_URL){
  var on=scr===k;
  if(k==="oakint"&&!on&&_mapaFr[k]){try{if(_mapaFr[k].parentNode)_mapaFr[k].parentNode.removeChild(_mapaFr[k]);}catch(e){}delete _mapaFr[k];continue;} /* al salir de Oakhaven se cierra la conexión */
  if(k==="mundoint"&&!on&&_mapaFr[k]){try{if(_mapaFr[k].parentNode)_mapaFr[k].parentNode.removeChild(_mapaFr[k]);}catch(e){}delete _mapaFr[k];continue;} /* al salir del Mundo Abierto se cierra: al volver se aparece en el campamento */
  if(on&&!_mapaFr[k]){
   var f=document.createElement("iframe");f.src=MAPA_URL[k];
   f.style.cssText="position:fixed;top:0;left:0;width:100%;height:100%;border:0;z-index:9000;background:#12100c;display:none";
   document.body.appendChild(f);_mapaFr[k]=f;
  }
  if(_mapaFr[k]){
   _mapaFr[k].style.display=on?"block":"none";
   if(on){any=true;try{_mapaFr[k].contentWindow.focus();}catch(e){}}
  }
 }
 document.body.style.overflow=any?"hidden":"";
 if(any)mapaSync();
}
function mapaSync(){
 var f=_mapaFr[G.screen];if(!f||!G.j||!f.contentWindow)return;
 try{
  if(G.screen==="city"||G.screen==="oakint"||G.screen==="mundoint")f.contentWindow.postMessage({naradak:"t",min:minJ(G.j)%MIN_DIA*(1440/MIN_DIA),dia:diaJ(G.j)},"*");
  else if(G.screen==="gremint"||G.screen==="herint"||G.screen==="hospint"||G.screen==="alqint"||G.screen==="tienint"||G.screen==="castint"||G.screen==="entint"||G.screen==="muint"){}
  else{var T=tabEst(G.j);f.contentWindow.postMessage({naradak:"tb",exp:!!expedicionLista(G.j),rum:T.rumores.length,tab:T.tablon.length},"*");}
 }catch(e){}
}
window.addEventListener("message",function(e){
 var d=e.data;if(!d||!d.naradak)return;
 /* Modo online: el mapa usa el reloj del servidor (misma hora para todos) y este reloj flotante se oculta mientras dura */
 if(d.naradak==="reloj_online"){window._relojOnline=d.on?Date.now():0;relojRender();return;}
 if(G.screen==="city"){
  if(d.naradak==="enter")irLocal(d.id);
  else if(d.naradak==="exit"){G.screen="hub";render();}
  else if(d.naradak==="ready")mapaSync();
 }else if(G.screen==="gremint"){
  if(d.naradak==="npc")irNpcGremio(d.id);
  else if(d.naradak==="exit"){volverLocal();}
 }else if(G.screen==="herint"){
  if(d.naradak==="npc")irNpcHerreria(d.id);
  else if(d.naradak==="exit"){volverLocal();}
 }else if(G.screen==="hospint"){
  if(d.naradak==="npc")irNpcHospital(d.id);
  else if(d.naradak==="exit"){volverLocal();}
 }else if(G.screen==="tienint"){
  if(d.naradak==="npc")irNpcTienda(d.id);
  else if(d.naradak==="exit"){volverLocal();}
 }else if(G.screen==="alqint"){
  if(d.naradak==="npc")irNpcAlquimia(d.id);
  else if(d.naradak==="exit"){volverLocal();}
 }else if(G.screen==="castint"){
  if(d.naradak==="npc")irNpcCastillo(d.id);
  else if(d.naradak==="exit"){volverLocal();}
 }else if(G.screen==="muint"){
  if(d.naradak==="exit"){volverLocal();}
  else if(d.naradak==="npc"&&d.id==="capitan"){if(typeof onlineIrOakhaven==="function")onlineIrOakhaven("muint");}
 }else if(G.screen==="oakint"){
  if(d.naradak==="exit"){G.screen="muint";render();}
  else if(d.naradak==="enter")irLocal(d.id);
  else if(d.naradak==="general"){if(d.op==="mazmorras"){G.labVolver="oakint";G.screen="laberinto";render();}else if(d.op==="explorar"){G.screen="mundoint";render();}}
  else if(d.naradak==="ready")mapaSync();
 }else if(G.screen==="mundoint"){
  if(d.naradak==="exit"){G.screen="oakint";render();}
  else if(d.naradak==="ready")mapaSync();
 }else if(G.screen==="entint"){
  if(d.naradak==="npc"){if(window.demoCombateAbrir)demoCombateAbrir();}
  else if(d.naradak==="exit"){volverLocal();}
 }else if(G.screen==="tabint"){
  if(d.naradak==="npc")irNpcTaberna(d.id);
  else if(d.naradak==="exit"){volverLocal();}
  else if(d.naradak==="ready")mapaSync();
 }
});
function renderCity(){el.innerHTML="";}
function renderTabInt(){el.innerHTML="";}
function renderGremInt(){el.innerHTML="";}
function renderHerInt(){el.innerHTML="";}
function renderHospInt(){el.innerHTML="";}
function renderAlqInt(){el.innerHTML="";}
function renderTienInt(){el.innerHTML="";}
function renderCastInt(){el.innerHTML="";}
function renderEntInt(){el.innerHTML="";}
function renderMuInt(){el.innerHTML="";}
function renderOakInt(){el.innerHTML="";}
function renderMundoInt(){el.innerHTML="";}
