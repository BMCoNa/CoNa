"use strict";
/* Profesiones, materiales, crafteo (inhibido: PROF_ACTIVO) */
/* ============================================================
   NOTA: SISTEMA DE PROFESIONES INHIBIDO (EN DESARROLLO)
   Todo el código de profesiones se conserva para retomarlo después.
   Para reactivarlo: PROF_ACTIVO = true.
   Con PROF_ACTIVO=false: no hay recolección al ganar combates, no se puede
   craftear/encantar y la pestaña Profesión del Gremio muestra "En desarrollo".
   ============================================================ */
var PROF_ACTIVO=false;
/* ============================================================
   PROFESIONES (profesiones.txt) — 1 activa a la vez
   Recolección: al ganar un combate (finCombateVictoria -> profOnVictoria)
   ============================================================ */
var PROF_ORDEN=["herrero","joyero","peletero","sastre","alquimista"];
var PROF_DEF={
 herrero:{n:"Herrero",sub:"Herrero-Minero",e:"🔨",d:"Menas → Lingotes → Armas y armaduras"},
 joyero:{n:"Joyero",sub:"Joyero-Minero",e:"💍",d:"Menas + Gemas → Engarces → Anillos y amuletos"},
 peletero:{n:"Peletero",sub:"Peletero-Desollador",e:"🧵",d:"Pieles → Cuero curtido → Armaduras de cuero y bolsas"},
 sastre:{n:"Sastre",sub:"Sastre-Encantador",e:"🪡",d:"Telas + Fragmentos → Ropa y encantamientos"},
 alquimista:{n:"Alquimista",sub:"Herborista-Alquimista",e:"⚗️",d:"Hierbas → Esencias → Pociones y elixires"}
};
var PROF_XP_MULT={herrero:1,joyero:1,peletero:1,sastre:1.5,alquimista:1};
var PROF_XP_TIER=[20,60,100,150,200];
var PROF_XP_ALQ=[25,75,125,190,250];
var PROF_PRECIO_TIER=[1,3,8,20,50];
var PROF_LOOT_QTY={herrero:[[1,2],[1,4],[3,6],[5,8],[7,10]],joyero:[[1,2],[3,5],[4,6],[6,8],[8,10]],peletero:[[1,3],[3,5],[5,7],[6,8],[8,10]],alquimista:[[1,2],[3,4],[5,6],[7,8],[9,10]],sastre:[[1,2],[2,4],[3,5],[4,6],[5,8]]};
/* [nombre, nivel de desbloqueo] */
var _MENAS=[["Mena de Cobre",1],["Mena de Estaño",1],["Mena de Hierro",21],["Mena de Plata",21],["Mena de Oro",41],["Mena de Cobalto",41],["Mena de Mithril",61],["Mena de Titanio",61],["Mena de Adamantita",81],["Mena de Obsidiana",81]];
var PROF_RAW={
 herrero:{main:_MENAS,extra:null,mx:1},
 joyero:{main:_MENAS,extra:[["Cuarzo Bruto",1],["Amatista Bruta",1],["Ojo de Gato Bruto",21],["Jade Bruto",21],["Zafiro Bruto",41],["Rubí Bruto",41],["Esmeralda Bruta",61],["Diamante Bruto",61],["Ópalo Abisal Bruto",81],["Alma de Gema Bruta",81]],mx:3},
 peletero:{main:[["Pellejo de Conejo",1],["Piel de Lobo",1],["Cuero de Jabalí",15],["Piel de Oso",21],["Escama de Basilisco",41],["Piel de Yeti",41],["Escama de Wyvern",51],["Piel de Quimera",71],["Escama de Dragón Joven",71],["Piel de Behemoth",81]],extra:null,mx:1},
 sastre:{main:[["Fibra de Lino",1],["Lana Cruda",1],["Algodón Salvaje",21],["Seda de Araña",21],["Tela Vil",41],["Seda de Luna",41],["Tela de Sombra",61],["Tejido de Éter",61],["Tela de Alma",61],["Hilo de Vacío",61]],extra:[["Fragmento Menor",1],["Fragmento Mayor",21],["Fragmento de Luz",41],["Fragmento de Sombra",41],["Fragmento Prismático",61]],mx:2},
 alquimista:{main:[["Flor de Paz",1],["Hoja de Plata",1],["Raíz de Tierra",21],["Hierba Sombría",21],["Loto de Sangre",41],["Musgo Helado",41],["Flor Abisal",61],["Espora Vil",61],["Pétalo de Éter",81],["Semilla del Vacío",81]],extra:null,mx:1}
};
/* Grupos "cualquiera de": ingrediente genérico -> variantes */
var PROF_ALT={
 "Cuero Ligero Curtido":["Cuero Ligero Curtido de Conejo","Cuero Ligero Curtido de Lobo","Cuero Ligero Curtido de Jabalí"],
 "Cuero Medio Curtido":["Cuero Medio Curtido de Oso","Escama Media Curtida de Basilisco","Cuero Medio Curtido de Yeti","Escama Media Curtida de Wyvern"],
 "Cuero Pesado Curtido":["Cuero Pesado Curtido de Quimera","Escama Pesada Curtida de Dragón","Cuero Pesado Curtido de Behemoth"],
 "Tela Bruta":["Tela Bruta de Lino","Tela Bruta de Lana","Tela Bruta de Algodón"],
 "Tela Fina":["Tela Fina de Araña","Tela Fina Vil","Tela Fina Lunar"],
 "Tela Refinada":["Tela Refinada de Sombra","Tela Refinada de Éter"],
 "Tela Rúnica":["Tela Rúnica de Alma","Tela Rúnica de Vacío"]
};
/* Materiales comprables (precio compra = max(4, precio venta x4)) y valores base de venta */
var PROF_TIENDA=["Carbón","Arena","Hueso","Cuero Curtido Genérico","Frasco Vacío","Madera de Silverleaf","Fibra de Lino","Flor de Paz","Hoja de Plata","Loto de Sangre"];
var PROF_BASE_PRECIO={"Carbón":2,"Arena":1,"Hueso":2,"Cuero Curtido Genérico":10};
/* Escala de stats de piezas fabricadas: por tier (0-4) x perfil de slot */
var PROF_BASE={atk:[8,20,34,48,64],def:[5,12,20,28,38],vida:[0,10,22,35,50],recurso:[0,0,10,20,30]};
var PROF_PERFIL={arma:{atk:1},pecho:{def:1,vida:1},tunica:{def:.6,vida:.6,recurso:1},casco:{def:.7,vida:.5},guantes:{atk:.15,def:.5},botas:{def:.4,vida:.4},capa:{def:.4,vida:.3,recurso:1},anillo:{atk:.3,vida:.8,recurso:.5},amuleto:{atk:.3,vida:1,recurso:.8}};
var PROF_SLOT={arma:"arma",pecho:"pecho",tunica:"pecho",casco:"casco",guantes:"guantes",botas:"botas",capa:"capa",anillo:"accesorio",amuleto:"amuleto"};
/* Consumibles de profesión (efectos con mecánicas existentes + buffs por nº de combates) */
var PROF_CONS={
 "Elixir de Fuerza":{d:"+20 ATK · 3 combates",buff:["atk",20,3]},
 "Antídoto Sombrío":{d:"Purga 1 maldición",purga:1},
 "Veneno de Arma":{d:"+35 ATK · 2 combates",buff:["atk",35,2]},
 "Poción Abisal":{d:"+60% Vida y Recurso",vida:.6,rec:.6},
 "Elixir de Escarcha":{d:"+40 DEF · 3 combates",buff:["def",40,3]},
 "Poción de Fuego":{d:"+60 ATK · 2 combates",buff:["atk",60,2]},
 "Poción de Éter":{d:"+50% Vida, +100% Recurso",vida:.5,rec:1},
 "Elixir del Vacío":{d:"Restaura todo y +50 ATK · 3 combates",vida:1,rec:1,buff:["atk",50,3]}
};
/* Encantamientos: bonus aplicado al item equipado (Herrero/Peletero) */
var PROF_REC={herrero:[],joyero:[],peletero:[],sastre:[],alquimista:[]};
var PROF_OUT={};
function _i(){var o={};for(var i=0;i<arguments.length;i+=2)o[arguments[i]]=arguments[i+1];return o;}
function _r(p,cat,n,ing,o){
 o=o||{};
 var sal=o.sal||((o.eq||o.bolsa||o.ench)?null:_i(n,1));
 var r={cat:cat,n:n,ing:ing,sal:sal,xp:o.xp||0,niv:o.niv||1,eq:o.eq||null,bolsa:o.bolsa||0,ench:o.ench||null,bonus:o.bonus||null};
 PROF_REC[p].push(r);
 if(sal&&(cat==="proc"||cat==="pieza")){for(var k in sal){if(!PROF_OUT[k])PROF_OUT[k]=r;}}
 return r;
}
(function(){
 var X=PROF_XP_TIER,XA=PROF_XP_ALQ;
 var men=["Cobre","Estaño","Hierro","Plata","Oro","Cobalto","Mithril","Titanio","Adamantita","Obsidiana"];
 function fundir(p){men.forEach(function(m){_r(p,"proc","Fundir "+m,_i("Mena de "+m,3),{sal:_i("Lingote de "+m,1),xp:10});});}
 var adam=function(p){_r(p,"pieza","Lingote de Adamantita Puro",_i("Lingote de Adamantita",2,"Esencia Abisal",1));};
 /* ---------- HERRERO ---------- */
 fundir("herrero");
 _r("herrero","pieza","Lingote de Bronce",_i("Lingote de Cobre",1,"Lingote de Estaño",1));
 _r("herrero","pieza","Lámina de Acero",_i("Lingote de Hierro",2));
 _r("herrero","pieza","Mango de Madera",_i("Madera de Silverleaf",1,"Cuero Curtido Genérico",1));
 _r("herrero","pieza","Remache",_i("Lingote de Hierro",1),{sal:_i("Remache",5)});
 _r("herrero","pieza","Filo Templado",_i("Lámina de Acero",1,"Carbón",1));
 _r("herrero","pieza","Placa Reforzada",_i("Lingote de Hierro",2,"Lámina de Acero",1));
 _r("herrero","pieza","Empuñadura",_i("Cuero Curtido Genérico",1,"Hilo Simple",1));
 _r("herrero","pieza","Guarda",_i("Lingote de Plata",1));
 _r("herrero","pieza","Cadena de Malla",_i("Lingote de Hierro",10));
 adam("herrero");
 _r("herrero","final","Daga de Cobre",_i("Lingote de Cobre",2,"Remache",1),{eq:["arma",0],niv:1,xp:X[0]});
 _r("herrero","final","Casco de Cobre",_i("Lingote de Cobre",3,"Lámina de Acero",1),{eq:["casco",0],niv:1,xp:X[0]});
 _r("herrero","final","Espada de Hierro",_i("Lingote de Hierro",3,"Mango de Madera",1,"Filo Templado",1),{eq:["arma",1],niv:21,xp:X[1]});
 _r("herrero","final","Pechera de Hierro",_i("Lingote de Hierro",5,"Placa Reforzada",2),{eq:["pecho",1],niv:21,xp:X[1]});
 _r("herrero","final","Hacha de Cobalto",_i("Lingote de Cobalto",3,"Empuñadura",1,"Remache",2),{eq:["arma",2],niv:41,xp:X[2]});
 _r("herrero","final","Yelmo de Oro",_i("Lingote de Oro",4,"Guarda",1),{eq:["casco",2],niv:41,xp:X[2]});
 _r("herrero","final","Filo de Mithril",_i("Lingote de Mithril",4,"Filo Templado",1,"Empuñadura",1),{eq:["arma",3],niv:61,xp:X[3]});
 _r("herrero","final","Armadura de Titanio",_i("Lingote de Titanio",8,"Placa Reforzada",4),{eq:["pecho",3],niv:61,xp:X[3]});
 _r("herrero","final","Espada de Adamantita",_i("Lingote de Adamantita Puro",5,"Guarda",1,"Filo Templado",2),{eq:["arma",4],niv:81,xp:X[4]});
 _r("herrero","final","Armadura de Obsidiana",_i("Lingote de Obsidiana",10,"Cadena de Malla",5),{eq:["pecho",4],niv:81,xp:X[4]});
 /* ---------- JOYERO ---------- */
 fundir("joyero");
 [["Cuarzo Bruto","Cuarzo Tallado"],["Amatista Bruta","Amatista Tallada"],["Ojo de Gato Bruto","Ojo de Gato Tallado"],["Jade Bruto","Jade Tallado"],["Zafiro Bruto","Zafiro Tallado"],["Rubí Bruto","Rubí Tallado"],["Esmeralda Bruta","Esmeralda Tallada"],["Diamante Bruto","Diamante Tallado"],["Ópalo Abisal Bruto","Ópalo Abisal Tallado"],["Alma de Gema Bruta","Alma de Gema Tallada"]].forEach(function(g){_r("joyero","proc","Tallar "+g[0].replace(/ Bruta?o?$/,""),_i(g[0],1),{sal:_i(g[1],1),xp:10});});
 _r("joyero","pieza","Lingote de Plata Pura",_i("Lingote de Plata",2));
 _r("joyero","pieza","Lingote de Oro Puro",_i("Lingote de Oro",2));
 _r("joyero","pieza","Engarce Simple",_i("Lingote de Cobre",1));
 _r("joyero","pieza","Engarce Real",_i("Lingote de Oro",1,"Lingote de Plata Pura",1));
 _r("joyero","pieza","Cadena Fina",_i("Lingote de Plata",1),{sal:_i("Cadena Fina",3)});
 _r("joyero","pieza","Anillo Base",_i("Lingote de Cobre",2));
 _r("joyero","pieza","Anillo Base de Oro",_i("Lingote de Oro",2));
 _r("joyero","pieza","Sello Grabado",_i("Lingote de Hierro",1));
 _r("joyero","pieza","Filigrana",_i("Lingote de Oro Puro",1,"Lingote de Plata Pura",1));
 _r("joyero","pieza","Cadena Fina de Oro",_i("Lingote de Oro",1),{sal:_i("Cadena Fina de Oro",3)});
 _r("joyero","pieza","Gema Perfecta",_i("Diamante Tallado",2));
 adam("joyero");
 _r("joyero","pieza","Engarce Real Legendario",_i("Lingote de Oro Puro",1,"Lingote de Adamantita Puro",1));
 _r("joyero","final","Anillo de Cobre con Cuarzo",_i("Anillo Base",1,"Cuarzo Tallado",1),{eq:["anillo",0],niv:1,xp:X[0]});
 _r("joyero","final","Amuleto de Amatista",_i("Cadena Fina",1,"Amatista Tallada",1,"Engarce Simple",1),{eq:["amuleto",0],niv:1,xp:X[0]});
 _r("joyero","final","Anillo de Plata con Ojo de Gato",_i("Lingote de Plata Pura",1,"Ojo de Gato Tallado",1,"Engarce Simple",1),{eq:["anillo",1],niv:21,xp:X[1]});
 _r("joyero","final","Amuleto de Jade",_i("Cadena Fina",1,"Jade Tallado",1,"Sello Grabado",1),{eq:["amuleto",1],niv:21,xp:X[1]});
 _r("joyero","final","Sortija de Oro y Zafiro",_i("Lingote de Oro Puro",1,"Zafiro Tallado",1,"Engarce Real",1),{eq:["anillo",2],niv:41,xp:X[2]});
 _r("joyero","final","Anillo de Rubí",_i("Anillo Base de Oro",1,"Rubí Tallado",1,"Filigrana",1),{eq:["anillo",2,1.1],niv:41,xp:X[2]});
 _r("joyero","final","Anillo de Mithril con Esmeralda",_i("Lingote de Mithril",1,"Esmeralda Tallada",1,"Engarce Real",1),{eq:["anillo",3],niv:61,xp:X[3]});
 _r("joyero","final","Amuleto de Diamante",_i("Cadena Fina de Oro",1,"Diamante Tallado",1,"Filigrana",1),{eq:["amuleto",3],niv:61,xp:X[3]});
 _r("joyero","final","Anillo de Ópalo Abisal",_i("Lingote de Adamantita Puro",1,"Ópalo Abisal Tallado",1,"Gema Perfecta",1),{eq:["anillo",4],niv:81,xp:X[4]});
 _r("joyero","final","Amuleto de Alma de Gema",_i("Alma de Gema Tallada",1,"Lingote de Oro Puro",2,"Engarce Real Legendario",1),{eq:["amuleto",4],niv:81,xp:X[4]});
 /* ---------- PIEZAS COMPARTIDAS (Peletero y Sastre) ---------- */
 function compartidas(p){
  _r(p,"pieza","Hilo Simple",_i("Fibra de Lino",1));
  _r(p,"pieza","Hilo de Lino",_i("Fibra de Lino",2));
  _r(p,"pieza","Hilo de Plata",_i("Lingote de Plata",1));
  _r(p,"pieza","Hilo de Oro",_i("Lingote de Oro",1));
  _r(p,"pieza","Hilo de Mithril",_i("Lingote de Mithril",1));
  _r(p,"pieza","Tinta Negra",_i("Flor de Paz",1,"Frasco Vacío",1));
  _r(p,"pieza","Tinta Arcana",_i("Hoja de Plata",1,"Frasco Vacío",1));
  _r(p,"pieza","Tinte Carmesí",_i("Loto de Sangre",1,"Frasco Vacío",1));
  _r(p,"pieza","Aguja de Hueso",_i("Hueso",1,"Lingote de Hierro",1));
 }
 /* ---------- PELETERO ---------- */
 [["Pellejo de Conejo","Cuero Ligero Curtido de Conejo","Tinta Negra",1],["Piel de Lobo","Cuero Ligero Curtido de Lobo","Tinta Negra",1],["Cuero de Jabalí","Cuero Ligero Curtido de Jabalí","Tinta Negra",1],
  ["Piel de Oso","Cuero Medio Curtido de Oso","Tinta Arcana",21],["Escama de Basilisco","Escama Media Curtida de Basilisco","Tinta Arcana",41],["Piel de Yeti","Cuero Medio Curtido de Yeti","Tinta Arcana",41],["Escama de Wyvern","Escama Media Curtida de Wyvern","Tinta Arcana",41],
  ["Piel de Quimera","Cuero Pesado Curtido de Quimera","Tinte Carmesí",71],["Escama de Dragón Joven","Escama Pesada Curtida de Dragón","Tinte Carmesí",71],["Piel de Behemoth","Cuero Pesado Curtido de Behemoth","Tinte Carmesí",71]
 ].forEach(function(c){_r("peletero","proc","Curtir "+c[0],_i(c[0],2,c[2],1),{sal:_i(c[1],1),xp:15,niv:c[3]});});
 compartidas("peletero");
 _r("peletero","final","Botas Ligeras",_i("Cuero Ligero Curtido de Conejo",3,"Hilo Simple",2),{eq:["botas",0],niv:1,xp:X[0]});
 _r("peletero","final","Guantes de Lobo",_i("Cuero Ligero Curtido de Lobo",2,"Tinta Negra",1),{eq:["guantes",0],niv:1,xp:X[0]});
 _r("peletero","final","Pechera de Jabalí",_i("Cuero Ligero Curtido de Jabalí",6,"Hilo de Lino",3,"Aguja de Hueso",1),{eq:["pecho",1],niv:21,xp:X[1]});
 _r("peletero","final","Capa de Oso",_i("Cuero Medio Curtido de Oso",4,"Hilo de Plata",2),{eq:["capa",1],niv:21,xp:X[1]});
 _r("peletero","final","Armadura de Basilisco",_i("Escama Media Curtida de Basilisco",8,"Hilo de Oro",4,"Tinta Arcana",1),{eq:["pecho",2],niv:41,xp:X[2]});
 _r("peletero","final","Botas de Yeti",_i("Cuero Medio Curtido de Yeti",5,"Hilo de Oro",3),{eq:["botas",2],niv:41,xp:X[2]});
 _r("peletero","final","Casco de Wyvern",_i("Escama Media Curtida de Wyvern",6,"Tinte Carmesí",2),{eq:["casco",2],niv:41,xp:X[2]});
 _r("peletero","final","Armadura de Quimera",_i("Cuero Pesado Curtido de Quimera",10,"Hilo de Mithril",5,"Tinte Carmesí",2),{eq:["pecho",3],niv:71,xp:X[3]});
 _r("peletero","final","Escama de Dragón",_i("Escama Pesada Curtida de Dragón",12,"Hilo de Mithril",6),{eq:["pecho",4],niv:71,xp:X[4]});
 _r("peletero","final","Capa de Behemoth",_i("Cuero Pesado Curtido de Behemoth",15,"Hilo de Mithril",8,"Alma de Gema Tallada",1),{eq:["capa",4],niv:71,xp:X[4]});
 _r("peletero","final","Bolsa de 12 slots",_i("Cuero Ligero Curtido",10,"Hilo Simple",5),{bolsa:12,niv:1,xp:X[0]});
 _r("peletero","final","Bolsa de 24 slots",_i("Cuero Medio Curtido",15,"Hilo de Plata",8),{bolsa:24,niv:31,xp:X[2]});
 _r("peletero","final","Bolsa de 36 slots",_i("Cuero Pesado Curtido",20,"Hilo de Mithril",10),{bolsa:36,niv:71,xp:X[4]});
 /* ---------- SASTRE ---------- */
 [["Fibra de Lino","Tela Bruta de Lino",1],["Lana Cruda","Tela Bruta de Lana",1],["Algodón Salvaje","Tela Bruta de Algodón",1],
  ["Seda de Araña","Tela Fina de Araña",31],["Tela Vil","Tela Fina Vil",31],["Seda de Luna","Tela Fina Lunar",31],
  ["Tela de Sombra","Tela Refinada de Sombra",61],["Tejido de Éter","Tela Refinada de Éter",61],
  ["Tela de Alma","Tela Rúnica de Alma",81],["Hilo de Vacío","Tela Rúnica de Vacío",81]
 ].forEach(function(c){_r("sastre","proc","Tejer "+c[0],_i(c[0],3),{sal:_i(c[1],1),xp:15,niv:c[2]});});
 [["Fragmento Menor","Glifo Menor",1],["Fragmento Mayor","Glifo Mayor",21],["Fragmento de Luz","Runa de Poder",41],["Fragmento de Sombra","Esencia Prismática",41],["Fragmento Prismático","Símbolo del Vacío",61]
 ].forEach(function(c){_r("sastre","proc","Glifo: "+c[1],_i(c[0],3),{sal:_i(c[1],1),xp:15,niv:c[2]});});
 compartidas("sastre");
 _r("sastre","pieza","Cuero Curtido Genérico (refuerzo)",_i("Cuero Curtido Genérico",1),{sal:_i("Cuero Curtido Genérico",1)});
 _r("sastre","final","Túnica de Lino",_i("Tela Bruta de Lino",4,"Hilo Simple",2),{eq:["tunica",0],niv:1,xp:X[0]});
 _r("sastre","final","Capucha de Lana",_i("Tela Bruta de Lana",3,"Hilo de Lino",1),{eq:["casco",0],niv:1,xp:X[0]});
 _r("sastre","final","Túnica de Seda",_i("Tela Fina de Araña",6,"Hilo de Plata",3,"Tinta Arcana",1),{eq:["tunica",1],niv:31,xp:X[1]});
 _r("sastre","final","Manto Vil",_i("Tela Fina Vil",5,"Hilo de Oro",2),{eq:["capa",1],niv:31,xp:X[1]});
 _r("sastre","final","Túnica de Sombra",_i("Tela Refinada de Sombra",8,"Hilo de Oro",4,"Glifo Mayor",1),{eq:["tunica",2],niv:61,xp:X[2]});
 _r("sastre","final","Capa de Éter",_i("Tela Refinada de Éter",7,"Hilo de Mithril",3),{eq:["capa",2],niv:61,xp:X[2]});
 _r("sastre","final","Túnica de Alma",_i("Tela Rúnica de Alma",10,"Hilo de Mithril",5,"Símbolo del Vacío",1),{eq:["tunica",3],niv:81,xp:X[3]});
 _r("sastre","final","Manto del Vacío",_i("Tela Rúnica de Vacío",12,"Hilo de Mithril",6,"Símbolo del Vacío",2),{eq:["capa",4],niv:81,xp:X[4]});
 _r("sastre","final","Bolsa de 32 slots",_i("Tela Refinada",20,"Hilo de Oro",10),{bolsa:32,niv:61,xp:X[2]});
 _r("sastre","ench","Encantamiento Menor - Fuerza",_i("Glifo Menor",1,"Tela Bruta",2),{ench:{atk:5},niv:1,xp:25});
 _r("sastre","ench","Encantamiento Mayor - Intelecto",_i("Glifo Mayor",1,"Tela Fina",2),{ench:{recurso:10},niv:31,xp:50});
 _r("sastre","ench","Encantamiento de Luz",_i("Runa de Poder",1,"Tela Refinada",3),{ench:{def:20},niv:61,xp:100});
 _r("sastre","ench","Encantamiento Prismático",_i("Esencia Prismática",1,"Tela Rúnica",1),{ench:{atk:15,def:15},niv:81,xp:150});
 _r("sastre","ench","Encantamiento del Vacío",_i("Símbolo del Vacío",1,"Tela Rúnica de Vacío",2,"Alma de Gema Tallada",1),{ench:{atk:25,vida:25},niv:81,xp:250});
 /* ---------- ALQUIMISTA ---------- */
 [["Flor de Paz","Esencia de Vida","Polvo de Vida"],["Hoja de Plata","Esencia de Maná","Polvo de Maná"],["Raíz de Tierra","Esencia de Tierra","Polvo de Tierra"],["Hierba Sombría","Esencia Sombría","Polvo Sombrío"],["Loto de Sangre","Esencia de Sangre","Polvo de Sangre"],["Musgo Helado","Esencia Helada","Polvo Helado"],["Flor Abisal","Esencia Abisal","Polvo Abisal"],["Espora Vil","Esencia Vil","Polvo Vil"],["Pétalo de Éter","Esencia de Éter","Polvo de Éter"],["Semilla del Vacío","Esencia del Vacío","Polvo del Vacío"]
 ].forEach(function(c){_r("alquimista","proc","Destilar "+c[0],_i(c[0],2),{sal:_i(c[1],1),xp:10,bonus:[c[2],.2]});});
 _r("alquimista","pieza","Frasco Vacío",_i("Arena",1));
 _r("alquimista","pieza","Frasco Grande",_i("Frasco Vacío",3,"Lingote de Plata",1));
 _r("alquimista","pieza","Catalizador",_i("Raíz de Tierra",1,"Polvo de Tierra",1));
 _r("alquimista","pieza","Veneno de Basilisco",_i("Escama de Basilisco",1,"Esencia Vil",1));
 _r("alquimista","pieza","Esencia de Fuego",_i("Esencia de Sangre",2));
 _r("alquimista","pieza","Esencia de Hielo",_i("Esencia Helada",2));
 _r("alquimista","pieza","Extracto de Raíz",_i("Esencia de Tierra",2));
 _r("alquimista","pieza","Agua Destilada",_i("Frasco Vacío",1));
 _r("alquimista","final","Poción de Vida Menor",_i("Esencia de Vida",1,"Frasco Vacío",1,"Agua Destilada",1),{sal:_i("Poción de Vida",1),niv:1,xp:XA[0]});
 _r("alquimista","final","Poción de Maná Menor",_i("Esencia de Maná",1,"Frasco Vacío",1),{sal:_i("Poción de Recurso",1),niv:1,xp:XA[0]});
 _r("alquimista","final","Poción de Vida Media",_i("Esencia de Vida",2,"Esencia de Tierra",1,"Frasco Vacío",1),{sal:_i("Poción de Vida Mayor",1),niv:21,xp:XA[1]});
 _r("alquimista","final","Elixir de Fuerza",_i("Esencia de Tierra",1,"Esencia de Sangre",1,"Catalizador",1),{niv:21,xp:XA[1]});
 _r("alquimista","final","Poción de Vida Superior",_i("Esencia de Sangre",2,"Esencia Helada",1,"Frasco Grande",1),{niv:41,xp:XA[2]});
 _r("alquimista","final","Antídoto Sombrío",_i("Esencia Sombría",2,"Extracto de Raíz",1,"Polvo Sombrío",1),{niv:41,xp:XA[2]});
 _r("alquimista","final","Veneno de Arma",_i("Esencia Vil",1,"Veneno de Basilisco",1,"Frasco Vacío",1),{niv:41,xp:XA[2]});
 _r("alquimista","final","Poción Abisal",_i("Esencia Abisal",3,"Esencia Vil",1,"Frasco Grande",1),{niv:61,xp:XA[3]});
 _r("alquimista","final","Elixir de Escarcha",_i("Esencia Helada",2,"Esencia de Hielo",1,"Catalizador",1),{niv:61,xp:XA[3]});
 _r("alquimista","final","Poción de Fuego",_i("Esencia de Sangre",2,"Esencia de Fuego",2,"Frasco Grande",1),{niv:61,xp:XA[3]});
 _r("alquimista","final","Poción de Éter",_i("Esencia de Éter",3,"Polvo de Éter",2,"Frasco Grande",1),{niv:81,xp:XA[4]});
 _r("alquimista","final","Elixir del Vacío",_i("Esencia del Vacío",2,"Esencia Abisal",2,"Frasco Grande",1,"Alma de Gema Tallada",1),{niv:81,xp:XA[4]});
 _r("alquimista","final","Transmutación",_i("Lingote de Cobre",5),{sal:_i("Lingote de Plata",1),niv:81,xp:XA[4]});
})();
/* ---------- estado ---------- */
function profEst(j){
 if(!j.prof)j.prof={activa:null,niv:{},xp:{},equipo:[],bolsa:0,buffs:{}};
 if(!j.prof.buffs)j.prof.buffs={};if(!j.prof.equipo)j.prof.equipo=[];
 return j.prof;
}
function profNivel(j,p){return profEst(j).niv[p]||1;}
function profXpSig(p,n){return Math.floor((40+n*6)*PROF_XP_MULT[p]);}
function profGanarXP(j,p,c){
 var e=profEst(j),n=e.niv[p]||1,x=(e.xp[p]||0)+c;
 while(n<100&&x>=profXpSig(p,n)){x-=profXpSig(p,n);n++;G.log.push("⚒ "+PROF_DEF[p].n+" sube a nivel "+n+".");}
 if(n>=100)x=0;
 e.niv[p]=n;e.xp[p]=x;
}
function profBuff(j,tipo){var b=j.prof&&j.prof.buffs&&j.prof.buffs[tipo];return(b&&b.c>0)?b.v:0;}
function profAlts(k){return PROF_ALT[k]||[k];}
function profCuenta(j,k){var t=0;profAlts(k).forEach(function(x){t+=j.inventario[x]||0;});return t;}
function profConsumir(j,k,n){
 var a=profAlts(k);
 for(var i=0;i<a.length&&n>0;i++){var h=j.inventario[a[i]]||0,u=Math.min(h,n);if(u>0){j.inventario[a[i]]-=u;if(j.inventario[a[i]]<=0)delete j.inventario[a[i]];n-=u;}}
}
function profElegir(lista,niv){
 var pool=lista.filter(function(x){return x[1]<=niv;});
 return pool.length?pool[Math.floor(Math.random()*pool.length)][0]:null;
}
/* Enganche: cada victoria en combate */
function profOnVictoria(j){
 if(!PROF_ACTIVO)return;
 var e=profEst(j);
 for(var k in e.buffs){e.buffs[k].c--;if(e.buffs[k].c<=0)delete e.buffs[k];}
 var p=e.activa;if(!p)return;
 var niv=profNivel(j,p),rg=PROF_LOOT_QTY[p][Math.min(4,Math.floor((niv-1)/20))],cant=rnd(rg[0],rg[1]),R=PROF_RAW[p],got={},i,it;
 for(i=0;i<cant;i++){it=profElegir(R.main,niv);if(it)got[it]=(got[it]||0)+1;}
 if(R.extra){it=profElegir(R.extra,niv);if(it)got[it]=(got[it]||0)+1;}
 for(var n in got){j.inventario[n]=(j.inventario[n]||0)+got[n];G.log.push("⚒ +"+got[n]+" "+n);}
}
/* ---------- precios ---------- */
var _PP=null;
function profPrecio(n){
 if(!_PP){
  _PP={};
  PROF_ORDEN.forEach(function(p){var R=PROF_RAW[p];
   R.main.forEach(function(x){_PP[x[0]]=PROF_PRECIO_TIER[Math.floor((x[1]-1)/20)];});
   if(R.extra)R.extra.forEach(function(x){_PP[x[0]]=PROF_PRECIO_TIER[Math.floor((x[1]-1)/20)]*R.mx;});});
  for(var b in PROF_BASE_PRECIO)_PP[b]=PROF_BASE_PRECIO[b];
 }
 if(_PP.hasOwnProperty(n))return _PP[n];
 var r=PROF_OUT[n];
 if(r){var t=0;for(var k in r.ing)t+=precioMaterial(profAlts(k)[0])*r.ing[k];return Math.max(1,Math.floor(t/(r.sal[n]||1)));}
 return 0;
}
function profPrecioCompra(n){return Math.max(4,precioMaterial(n)*4);}
/* ---------- crafteo ---------- */
function profPuede(j,p,r){
 if(profEst(j).activa!==p)return"Profesión inactiva";
 if(profNivel(j,p)<r.niv)return"Requiere nivel "+r.niv;
 if(r.eq&&poseeEquipo(j,r.n))return"Ya posees este equipo";
 for(var k in r.ing){if(profCuenta(j,k)<r.ing[k])return"Faltan materiales";}
 return"";
}
function profStats(perfil,t,m){
 var o={};
 for(var k in PROF_PERFIL[perfil]){var v=Math.round(PROF_BASE[k][t]*PROF_PERFIL[perfil][k]*(m||1));if(v>0)o[k]=v;}
 return o;
}
function profCraft(j,p,r){
 if(!PROF_ACTIVO)return false;
 var err=profPuede(j,p,r);if(err){G.profMsg=err;return false;}
 var e=profEst(j);
 for(var k in r.ing)profConsumir(j,k,r.ing[k]);
 if(r.eq){
  var st=profStats(r.eq[0],r.eq[1],r.eq[2]);
  e.equipo.push({n:r.n,tipo:"prof",clase:"Todas",slot:PROF_SLOT[r.eq[0]],atk:st.atk||0,def:st.def||0,vida:st.vida||0,recurso:st.recurso||0,precio:0,nivel:r.niv,fab:p,enc:null,encB:null});
  G.profMsg="✔ Fabricaste "+r.n+" (ver pestaña Equipo)";
 }else if(r.bolsa){
  e.bolsa=Math.max(e.bolsa||0,r.bolsa);
  G.profMsg="✔ "+r.n+": capacidad de bolsa "+e.bolsa;
 }else{
  var txt=[];
  for(var s in r.sal){j.inventario[s]=(j.inventario[s]||0)+r.sal[s];txt.push(r.sal[s]+" "+s);}
  if(r.bonus&&Math.random()<r.bonus[1]){j.inventario[r.bonus[0]]=(j.inventario[r.bonus[0]]||0)+1;txt.push("1 "+r.bonus[0]);}
  G.profMsg="✔ Obtuviste "+txt.join(", ");
 }
 if(r.xp){profGanarXP(j,p,r.xp);G.profMsg+=" · +"+r.xp+" XP";}
 return true;
}
function profEncantar(j,r,slot){
 if(!PROF_ACTIVO)return false;
 var err=profPuede(j,"sastre",r);if(err){G.profMsg=err;return false;}
 var it=j.equipo[slot];
 if(!it||(it.fab!=="herrero"&&it.fab!=="peletero")){G.profMsg="Solo equipo fabricado por Herrero o Peletero.";return false;}
 if(it.encB){for(var o in it.encB)it[o]=(it[o]||0)-it.encB[o];}
 for(var k in r.ing)profConsumir(j,k,r.ing[k]);
 it.encB={};for(var b in r.ench){it[b]=(it[b]||0)+r.ench[b];it.encB[b]=r.ench[b];}
 it.enc=r.n;
 profGanarXP(j,"sastre",r.xp);
 G.profMsg="✔ "+r.n+" aplicado a "+it.n+" · +"+r.xp+" XP";
 return true;
}
function profEquipar(j,i){
 var e=profEst(j),it=e.equipo[i];if(!it)return;
 e.equipo.splice(i,1);
 var prev=j.equipo[it.slot];
 if(prev&&prev.n&&prev.n!=="Ninguno")equipoBolsa(j).push(prev);
 j.equipo[it.slot]=it;
 G.profMsg="✔ Equipaste "+it.n;
}
function profUsar(j,nombre){
 var c=PROF_CONS[nombre];if(!c||!(j.inventario[nombre]>0))return false;
 var st=calcStats(j),e=profEst(j);
 if(c.vida)j.vida=Math.min(st.vidaMax,j.vida+Math.floor(st.vidaMax*c.vida));
 if(c.rec)j.recurso=Math.min(st.recursoMax,j.recurso+Math.floor(st.recursoMax*c.rec));
 if(c.purga){var ms=Object.keys(j.maldiciones||{});if(ms.length)delete j.maldiciones[ms[0]];}
 if(c.buff)e.buffs[c.buff[0]]={v:c.buff[1],c:c.buff[2]};
 j.inventario[nombre]--;if(j.inventario[nombre]<=0)delete j.inventario[nombre];
 G.log.push("Usaste "+nombre+". "+c.d);G.profMsg="✔ Usaste "+nombre+": "+c.d;
 return true;
}
function profComprar(j,n){
 var pr=profPrecioCompra(n);
 if(j.oro<pr){G.profMsg="Oro insuficiente.";return;}
 j.oro-=pr;j.inventario[n]=(j.inventario[n]||0)+1;G.profMsg="✔ Compraste 1 "+n+" (-"+pr+" oro)";
}
/* ---------- UI ---------- */
function profIngHTML(j,ing){
 var a=[];
 for(var k in ing){var t=profCuenta(j,k);a.push('<span style="color:'+(t>=ing[k]?'#7ab88a':'#e08080')+';font-size:11px">'+k+' '+t+'/'+ing[k]+'</span>');}
 return a.join(' · ');
}
function profStatsTxt(o){
 var a=[];if(o.atk)a.push("ATK +"+o.atk);if(o.def)a.push("DEF +"+o.def);if(o.vida)a.push("VIDA +"+o.vida);if(o.recurso)a.push("REC +"+o.recurso);
 return a.join(", ");
}
function profFila(j,p,r,i){
 var err=profPuede(j,p,r),extra="";
 if(r.eq)extra=profStatsTxt(profStats(r.eq[0],r.eq[1],r.eq[2]));
 else if(r.bolsa)extra="Bolsa "+r.bolsa+" slots";
 else if(r.ench)extra=profStatsTxt(r.ench)+" (sobre equipo de Herrero/Peletero)";
 else{var s=[];for(var k in r.sal)s.push(r.sal[k]+" "+k);extra="→ "+s.join(", ")+(r.bonus?" (+"+Math.round(r.bonus[1]*100)+"% "+r.bonus[0]+")":"");}
 var h='<div style="padding:8px 0;border-bottom:1px dashed var(--border);font-size:13px;opacity:'+(profNivel(j,p)<r.niv?'.55':'1')+'"><div style="display:flex;justify-content:space-between;align-items:center;gap:6px;flex-wrap:wrap"><div><span style="font-weight:700">'+r.n+'</span>'+(r.niv>1?' <span class="pill">Nv '+r.niv+'</span>':'')+(r.xp?' <span style="color:var(--muted);font-size:11px">+'+r.xp+' XP</span>':'')+'</div>';
 if(r.ench){
  var n=0;
  for(var s2 in j.equipo){var it=j.equipo[s2];if(it&&(it.fab==="herrero"||it.fab==="peletero")){n++;h+='<button class="btn profAct" data-a="ench" data-i="'+i+'" data-slot="'+s2+'" style="padding:4px 10px;font-size:11px" '+(err?'disabled':'')+'>Aplicar: '+it.n+'</button>';}}
  if(!n)h+='<span style="color:var(--muted);font-size:11px">Sin equipo aplicable</span>';
 }else h+='<button class="btn profAct" data-a="craft" data-i="'+i+'" style="padding:4px 12px;font-size:12px" '+(err?'disabled':'')+'>Crear</button>';
 return h+'</div><div style="color:var(--muted);font-size:11px;margin-top:2px">'+extra+'</div><div style="margin-top:2px">'+profIngHTML(j,r.ing)+'</div></div>';
}
/* Pestaña Profesión mientras el sistema está inhibido */
function profHTMLDesarrollo(){
 var P=[["Herrero","🔨"],["Joyero","💍"],["Peletero","🧵"],["Sastre","🪡"],["Alquimista","⚗️"]];
 var h='<div style="font-size:12px;color:var(--muted);margin-bottom:10px">Sistema de profesiones en desarrollo.</div><div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:10px">';
 P.forEach(function(p){h+='<div class="card" style="padding:12px;background:rgba(0,0,0,.25);text-align:center;opacity:.75"><div style="font-size:26px">'+p[1]+'</div><div style="font-weight:700;margin:4px 0">'+p[0]+'</div><span class="pill">En desarrollo</span><button class="btn" style="margin-top:8px;padding:5px 12px;font-size:12px;width:100%" disabled>Próximamente</button></div>';});
 return h+'</div>';
}
function profHTML(j){
 if(!PROF_ACTIVO)return profHTMLDesarrollo();
 var e=profEst(j),act=e.activa,sub=G.profSub||"estado",h="";
 if(G.profMsg){h+='<div style="margin-bottom:10px;padding:8px;border-radius:8px;background:var(--accent-soft);border:1px solid var(--accent);font-size:12px">'+G.profMsg+'</div>';G.profMsg="";}
 var tabs=[["estado","Estado"]];
 if(act){tabs.push(["proc","Procesar"],["pieza","Piezas"],["final","Recetas"]);if(act==="sastre")tabs.push(["ench","Encantar"]);}
 tabs.push(["equipo","Equipo"],["tienda","Tienda"]);
 if(!act&&(sub==="proc"||sub==="pieza"||sub==="final"||sub==="ench"))sub="estado";
 if(act!=="sastre"&&sub==="ench")sub="estado";
 h+='<div style="display:flex;gap:6px;flex-wrap:wrap;margin-bottom:10px">';
 tabs.forEach(function(t){h+='<button class="btn profAct" data-a="sub" data-sub="'+t[0]+'" style="padding:4px 10px;font-size:11px;'+(sub===t[0]?'background:var(--accent-soft);border-color:var(--accent)':'')+'">'+t[1]+'</button>';});
 h+='</div>';
 if(sub==="estado"){
  h+='<div style="font-size:12px;color:var(--muted);margin-bottom:10px">Solo 1 profesión activa. Con una activa, cada victoria en combate te da únicamente los materiales de esa profesión (además del botín normal).</div>';
  h+='<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:10px">';
  PROF_ORDEN.forEach(function(p){
   var d=PROF_DEF[p],niv=profNivel(j,p),on=(act===p);
   h+='<div class="card" style="padding:10px;background:rgba(0,0,0,.25);'+(on?'border-color:var(--accent)':'')+'"><div style="font-weight:700">'+d.e+' '+d.n+(on?' <span class="pill">Activa</span>':'')+'</div><div style="font-size:11px;color:var(--muted);margin:2px 0">'+d.sub+' · '+d.d+'</div><div style="font-size:12px">Nivel '+niv+'/100'+(niv<100?' · XP '+(e.xp[p]||0)+'/'+profXpSig(p,niv):'')+'</div>'+barraHTML(niv<100?(e.xp[p]||0):1,niv<100?profXpSig(p,niv):1,'#c9a25a');
   h+=on?'<button class="btn profAct" data-a="desactivar" style="margin-top:8px;padding:5px 12px;font-size:12px;width:100%">Dejar profesión</button>':'<button class="btn btn-primary profAct" data-a="activar" data-prof="'+p+'" style="margin-top:8px;padding:5px 12px;font-size:12px;width:100%">Activar</button>';
   h+='</div>';});
  h+='</div>';
  if(act){
   var niv2=profNivel(j,act),rg=PROF_LOOT_QTY[act][Math.min(4,Math.floor((niv2-1)/20))],R=PROF_RAW[act];
   var disp=R.main.filter(function(x){return x[1]<=niv2;}).map(function(x){return x[0];}),ex=R.extra?R.extra.filter(function(x){return x[1]<=niv2;}).map(function(x){return x[0];}):[];
   h+='<div style="margin-top:12px;font-size:12px"><b>Por victoria:</b> '+rg[0]+'-'+rg[1]+' de: '+disp.join(", ")+(ex.length?'<br><b>+1 de:</b> '+ex.join(", "):'')+'</div>';
  }
  if(e.bolsa)h+='<div style="margin-top:8px;font-size:12px;color:var(--muted)">Bolsa fabricada: '+e.bolsa+' slots</div>';
  var bf=Object.keys(e.buffs).map(function(k){return k.toUpperCase()+" +"+e.buffs[k].v+" ("+e.buffs[k].c+" combates)";});
  if(bf.length)h+='<div style="margin-top:6px;font-size:12px;color:#8ab0d8">Efectos activos: '+bf.join(" · ")+'</div>';
 }
 else if(sub==="proc"||sub==="pieza"||sub==="final"||sub==="ench"){
  var lst=PROF_REC[act],c=0;
  lst.forEach(function(r,i){if(r.cat===sub){h+=profFila(j,act,r,i);c++;}});
  if(!c)h+='<div style="color:var(--muted);font-size:13px">Sin entradas.</div>';
 }
 else if(sub==="equipo"){
  h+='<div style="font-weight:700;margin-bottom:6px">Equipo fabricado</div>';
  if(!e.equipo.length)h+='<div style="color:var(--muted);font-size:13px">Sin piezas guardadas.</div>';
  e.equipo.forEach(function(it,i){
   h+='<div style="display:flex;justify-content:space-between;align-items:center;gap:6px;padding:6px 0;border-bottom:1px dashed var(--border);font-size:13px;flex-wrap:wrap"><span>'+it.n+' <span style="color:var(--muted);font-size:11px">['+it.slot+'] '+profStatsTxt(it)+(it.enc?' · '+it.enc:'')+'</span></span><button class="btn profAct" data-a="equipar" data-i="'+i+'" style="padding:4px 10px;font-size:11px">Equipar</button></div>';});
  h+='<div style="font-weight:700;margin:12px 0 6px">Consumibles de profesión</div>';
  var cn=Object.keys(PROF_CONS).filter(function(n){return j.inventario[n]>0;});
  if(!cn.length)h+='<div style="color:var(--muted);font-size:13px">Sin consumibles.</div>';
  cn.forEach(function(n){h+='<div style="display:flex;justify-content:space-between;align-items:center;gap:6px;padding:6px 0;border-bottom:1px dashed var(--border);font-size:13px"><span>'+n+' x'+j.inventario[n]+' <span style="color:var(--muted);font-size:11px">— '+PROF_CONS[n].d+'</span></span><button class="btn profAct" data-a="usar" data-n="'+n+'" style="padding:4px 10px;font-size:11px">Usar</button></div>';});
 }
 else{
  h+='<div style="font-size:12px;color:var(--muted);margin-bottom:8px">Materiales base a precio fijo. Tu oro: '+j.oro+'</div>';
  PROF_TIENDA.forEach(function(n){var pr=profPrecioCompra(n);h+='<div style="display:flex;justify-content:space-between;align-items:center;gap:6px;padding:6px 0;border-bottom:1px dashed var(--border);font-size:13px"><span>'+n+' <span style="color:var(--muted);font-size:11px">x'+(j.inventario[n]||0)+'</span></span><button class="btn profAct" data-a="comprar" data-n="'+n+'" style="padding:4px 10px;font-size:11px" '+(j.oro<pr?'disabled':'')+'>Comprar ('+pr+')</button></div>';});
 }
 return h;
}
function profBind(j){
 document.querySelectorAll(".profAct").forEach(function(b){b.onclick=function(){
  var a=b.getAttribute("data-a"),e=profEst(j),i=parseInt(b.getAttribute("data-i"),10);
  if(a==="sub")G.profSub=b.getAttribute("data-sub");
  else if(a==="activar"){e.activa=b.getAttribute("data-prof");G.profSub="estado";}
  else if(a==="desactivar"){e.activa=null;G.profSub="estado";}
  else if(a==="craft")profCraft(j,e.activa,PROF_REC[e.activa][i]);
  else if(a==="ench")profEncantar(j,PROF_REC[e.activa][i],b.getAttribute("data-slot"));
  else if(a==="equipar")profEquipar(j,i);
  else if(a==="usar")profUsar(j,b.getAttribute("data-n"));
  else if(a==="comprar")profComprar(j,b.getAttribute("data-n"));
  guardar();render();};});
}

