"use strict";
/* Equipamiento: propiedad, reemplazo y venta */
/* ---------- equipamiento: propiedad, reemplazo y venta ---------- */
function equipoBolsa(j){if(!j.bolsaEq)j.bolsaEq=[];return j.bolsaEq;}
function poseeEquipo(j,n){
 for(var s in j.equipo){if(j.equipo[s]&&j.equipo[s].n===n)return true;}
 if(equipoBolsa(j).some(function(x){return x.n===n;}))return true;
 return profEst(j).equipo.some(function(x){return x.n===n;});
}
function slotDeItem(it){return it.tipo==="arma"?"arma":(it.tipo==="accesorio"?"accesorio":it.slot);}
function copiaItem(it){var c=Object.assign({},it);if(it.attr)c.attr=Object.assign({},it.attr);return c;}
/* Equipa un item; el reemplazado pasa a la bolsa de equipo (inventario) para venderlo después */
function equiparItem(j,it){
 var sl=slotDeItem(it),prev=j.equipo[sl];
 if(prev&&prev.n&&prev.n!=="Ninguno")equipoBolsa(j).push(prev);
 j.equipo[sl]=it;
}
function attrSuma(o){var t=0;for(var k in o)t+=o[k];return t;}
/* Valor de compra: precio pagado/forja; sin precio (profesiones) se estima por stats */
function valorEquipo(it){
 var v=(it.precio>0)?it.precio:((it.atk||0)*20+(it.def||0)*15+(it.vida||0)*6+(it.recurso||0)*5+attrSuma(itemAttr(it))*25);
 return v+(it.mejora||0)*50;
}
function precioVentaEquipo(it){return Math.max(1,Math.floor(valorEquipo(it)*0.5));}
function listaVendible(j){
 var a=[];
 equipoBolsa(j).forEach(function(it,i){a.push({src:"b",i:i,it:it});});
 profEst(j).equipo.forEach(function(it,i){a.push({src:"p",i:i,it:it});});
 return a;
}
function precioVentaConsumible(n){
 var p=POCIONES.filter(function(x){return x.n===n;})[0];
 if(p)return Math.max(1,Math.floor(p.precio*0.5));
 var t=0,f=false;
 PROF_ORDEN.forEach(function(pr){PROF_REC[pr].forEach(function(r){if(!f&&r.cat==="final"&&r.n===n){f=true;for(var k in r.ing)t+=precioMaterial(profAlts(k)[0])*r.ing[k];}});});
 return Math.max(1,Math.floor(t*0.5));
}
function esConsumible(n){return POCIONES.some(function(p){return p.n===n;})||!!PROF_CONS[n]||/Poci[oó]n/i.test(n);}
function statsItemTxt(j,it){
 var b=[];if(it.atk)b.push("ATK +"+it.atk);if(it.def)b.push("DEF +"+it.def);if(it.vida)b.push("VIDA +"+it.vida);if(it.recurso)b.push(j.recursoNombre+" +"+it.recurso);
 var a=attrTxt(itemAttr(it));if(a)b.push(a);return b.join(", ");
}
function filaCompra(j,it,i,key){
 var tiene=poseeEquipo(j,it.n),bloq=tiene||j.oro<it.precio;
 return '<div style="display:flex;justify-content:space-between;align-items:center;padding:8px 0;border-bottom:1px dashed var(--border);font-size:13px;flex-wrap:wrap;gap:6px"><div style="display:flex;align-items:center">'+itemImg(it.n,38)+'<div><span style="font-weight:600">'+it.n+'</span> <span style="color:var(--muted);font-size:11px">— '+statsItemTxt(j,it)+' · Nv '+it.nivel+'</span></div></div><div><span style="color:#e0c060;margin-right:10px">'+it.precio+' oro</span><button class="btn buyItem" data-key="'+key+'" data-idx="'+i+'" style="padding:5px 12px;font-size:12px" '+(bloq?'disabled':'')+'>'+(tiene?'Ya lo posees':'Comprar')+'</button></div></div>';
}
function stockEquipoHTML(j,sub){
 var h='';
 if(sub==="armas")G.shopStock.armas.forEach(function(it,i){h+=filaCompra(j,it,i,"armas");});
 else if(sub==="armaduras"){
  h+='<div style="display:flex;gap:6px;flex-wrap:wrap;margin-bottom:10px">';
  ["pecho","piernas","guantes","botas"].forEach(function(sl){var lb={pecho:"Pecho",piernas:"Piernas",guantes:"Guantes",botas:"Botas"}[sl];h+='<button class="btn slotBtn" data-slot="'+sl+'" style="padding:5px 10px;font-size:11px;'+(G.shopStock.armaduraSlot===sl?'background:var(--accent-soft);border-color:var(--accent)':'')+'">'+lb+'</button>';});
  h+='</div>';
  G.shopStock.armaduras[G.shopStock.armaduraSlot].forEach(function(it,i){h+=filaCompra(j,it,i,"armaduras");});
 }else if(sub==="accesorios")G.shopStock.accesorios.forEach(function(it,i){h+=filaCompra(j,it,i,"accesorios");});
 return h;
}
function stockEquipoBind(j){
 document.querySelectorAll(".slotBtn").forEach(function(b){b.onclick=function(){G.shopStock.armaduraSlot=b.getAttribute("data-slot");render();};});
 document.querySelectorAll(".buyItem").forEach(function(b){b.onclick=function(){
  var key=b.getAttribute("data-key"),i=parseInt(b.getAttribute("data-idx"),10);
  var it=key==="armaduras"?G.shopStock.armaduras[G.shopStock.armaduraSlot][i]:G.shopStock[key][i];
  if(!it||poseeEquipo(j,it.n)||j.oro<it.precio)return;
  j.oro-=it.precio;avanzarTiempo(5);equiparItem(j,copiaItem(it));
  G.log.push("Compraste y equipaste "+it.n+". El equipo reemplazado pasó a tu inventario.");guardar();render();
 };});
}
function equipoGuardadoHTML(j){
 var h='<div class="card" style="margin-bottom:12px"><div class="font-disp" style="color:var(--accent);margin-bottom:10px">Equipo guardado</div>';
 var l=listaVendible(j);
 if(!l.length)h+='<div style="color:var(--muted);font-size:13px">Sin equipo guardado. Lo que reemplaces o fabriques aparece aquí para equiparlo o venderlo en la Tienda.</div>';
 l.forEach(function(e){h+='<div style="display:flex;justify-content:space-between;align-items:center;gap:6px;padding:6px 0;border-bottom:1px dashed var(--border);font-size:13px;flex-wrap:wrap"><span>'+itemImg(e.it.n,32)+e.it.n+' <span style="color:var(--muted);font-size:11px">['+slotDeItem(e.it)+'] '+statsItemTxt(j,e.it)+'</span></span><button class="btn equiparGuard" data-src="'+e.src+'" data-idx="'+e.i+'" style="padding:4px 10px;font-size:11px">Equipar</button></div>';});
 return h+'</div>';
}
function generarStock(){
 var j=G.j,c=j.clase;
 var porNivel=function(a,b){return a[9]-b[9];};
 var armas=ITEMS.filter(function(i){return i[1]==="arma"&&i[2]===c;}).sort(porNivel).map(itemObj);
 var armaduras={};
 ["pecho","piernas","guantes","botas"].forEach(function(slot){armaduras[slot]=ITEMS.filter(function(i){return i[1]==="armadura"&&i[2]===c&&i[3]===slot;}).sort(porNivel).map(itemObj);});
 var accs=ITEMS.filter(function(i){return i[1]==="accesorio"&&i[2]===c;}).sort(porNivel).map(itemObj);
 G.shopStock={armas:armas,armaduras:armaduras,accesorios:accs,pociones:POCIONES,armaduraSlot:"pecho"};
}
function renderShop(){
 var j=G.j;if(!G.shopStock)generarStock();
 var modo=G.shopModo==="vender"?"vender":"comprar";
 var subsC=[["armas","Armas"],["armaduras","Armaduras"],["accesorios","Accesorios"],["pociones","Pociones"],["misc","Miscelánea"]];
 var subsV=[["equipo","Equipo"],["misc","Miscelánea"],["pociones","Pociones"]];
 if(!subsC.some(function(x){return x[0]===G.shopTab;}))G.shopTab="armas";
 if(!subsV.some(function(x){return x[0]===G.shopVSub;}))G.shopVSub="equipo";
 var btnS=function(cls,attr,val,lb,on){return '<button class="btn '+cls+'" '+attr+'="'+val+'" style="padding:6px 12px;font-size:12px;'+(on?'background:var(--accent-soft);border-color:var(--accent)':'')+'">'+lb+'</button>';};
 var h=hudHTML(j)+'<div class="card"><div class="font-disp" style="color:var(--accent);margin-bottom:10px">'+iconoSVG('bolsa')+'Tienda — '+j.clase+'</div>';
 h+='<div style="display:flex;gap:6px;margin-bottom:10px">'+btnS("modoBtn","data-m","comprar","🛒 Comprar",modo==="comprar")+btnS("modoBtn","data-m","vender","💰 Vender",modo==="vender")+'</div>';
 h+='<div style="display:flex;gap:6px;flex-wrap:wrap;margin-bottom:14px">';
 (modo==="comprar"?subsC:subsV).forEach(function(t){h+=modo==="comprar"?btnS("tabBtn","data-tab",t[0],t[1],G.shopTab===t[0]):btnS("vtabBtn","data-tab",t[0],t[1],G.shopVSub===t[0]);});
 h+='</div>';
 var fila='<div style="display:flex;justify-content:space-between;align-items:center;padding:8px 0;border-bottom:1px dashed var(--border);font-size:13px;flex-wrap:wrap;gap:6px">';
 if(modo==="comprar"){
  if(G.shopTab==="pociones"){
   POCIONES.forEach(function(p,i){h+=fila+'<div>'+itemImg(p.n,34)+'<span style="font-weight:600">'+p.n+'</span> <span style="color:var(--muted);font-size:11px">— '+p.desc+'</span></div><div><span style="color:#e0c060;margin-right:10px">'+p.precio+' oro</span><button class="btn buyPoc" data-idx="'+i+'" style="padding:5px 12px;font-size:12px" '+(j.oro<p.precio?'disabled':'')+'>Comprar</button></div></div>';});
  }else if(G.shopTab==="misc"){
   var lista=PROF_TIENDA.slice(),bi=getBioma(j).id;
   for(var q=1;q<=bi;q++){if(lista.indexOf(BIOMAS[q].material)<0)lista.push(BIOMAS[q].material);}
   h+='<div style="font-size:12px;color:var(--muted);margin-bottom:8px">Materiales a precio fijo.</div>';
   lista.forEach(function(n){var pr=profPrecioCompra(n);h+=fila+'<div>'+itemImg(n,34)+'<span style="font-weight:600">'+n+'</span> <span style="color:var(--muted);font-size:11px">x'+(j.inventario[n]||0)+'</span></div><div><span style="color:#e0c060;margin-right:10px">'+pr+' oro</span><button class="btn buyMisc" data-n="'+n+'" style="padding:5px 12px;font-size:12px" '+(j.oro<pr?'disabled':'')+'>Comprar</button></div></div>';});
  }else h+=stockEquipoHTML(j,G.shopTab);
 }else{
  if(G.shopVSub==="equipo"){
   var l=listaVendible(j);
   h+='<div style="font-size:12px;color:var(--muted);margin-bottom:8px">Equipo reemplazado o fabricado. Se vende al 50% del precio de compra. El equipo puesto no se puede vender.</div>';
   if(!l.length)h+='<div style="color:var(--muted);font-size:13px">No tienes equipo para vender.</div>';
   l.forEach(function(e){var pv=precioVentaEquipo(e.it);h+=fila+'<div>'+itemImg(e.it.n,34)+'<span style="font-weight:600">'+e.it.n+'</span> <span style="color:var(--muted);font-size:11px">— '+statsItemTxt(j,e.it)+'</span></div><div><span style="color:#e0c060;margin-right:10px">'+pv+' oro</span><button class="btn sellEq" data-src="'+e.src+'" data-idx="'+e.i+'" style="padding:5px 12px;font-size:12px">Vender</button></div></div>';});
  }else if(G.shopVSub==="misc"){
   var mats=Object.keys(j.inventario).filter(function(k){return esMaterial(k)&&j.inventario[k]>0;});
   if(!mats.length)h+='<div style="color:var(--muted);font-size:13px">No tienes materiales para vender.</div>';
   mats.forEach(function(nm){var res=reservadoEntrega(j,nm),disp=j.inventario[nm]-res,pu=precioMaterial(nm);
    h+=fila+'<span>'+itemImg(nm,32)+nm+' x'+j.inventario[nm]+' <span style="color:var(--muted);font-size:11px">'+infoMaterial(nm)+' · '+pu+' oro c/u</span>'+(res?' <span style="color:#8ab0d8;font-size:11px">(reservados: '+res+')</span>':'')+'</span><span style="display:flex;gap:6px"><button class="btn sellMat" data-n="'+nm+'" data-cant="1" style="padding:4px 10px;font-size:11px" '+(disp<1?'disabled':'')+'>Vender 1 ('+pu+')</button><button class="btn sellMat" data-n="'+nm+'" data-cant="'+disp+'" style="padding:4px 10px;font-size:11px" '+(disp<1?'disabled':'')+'>Todo ('+(disp*pu)+')</button></span></div>';});
  }else{
   var pots=Object.keys(j.inventario).filter(function(k){return j.inventario[k]>0&&esConsumible(k);});
   h+='<div style="font-size:12px;color:var(--muted);margin-bottom:8px">Los consumibles se venden al 50%.</div>';
   if(!pots.length)h+='<div style="color:var(--muted);font-size:13px">No tienes pociones para vender.</div>';
   pots.forEach(function(nm){var pu=precioVentaConsumible(nm),c=j.inventario[nm];
    h+=fila+'<span>'+itemImg(nm,32)+nm+' x'+c+' <span style="color:var(--muted);font-size:11px">'+pu+' oro c/u</span></span><span style="display:flex;gap:6px"><button class="btn sellPoc" data-n="'+nm+'" data-cant="1" style="padding:4px 10px;font-size:11px">Vender 1 ('+pu+')</button><button class="btn sellPoc" data-n="'+nm+'" data-cant="'+c+'" style="padding:4px 10px;font-size:11px">Todo ('+(c*pu)+')</button></span></div>';});
  }
 }
 h+='<div style="margin-top:14px"><button class="btn" id="bBack">← Volver a la Tienda</button></div></div>';
 el.innerHTML=h;
 document.querySelectorAll(".modoBtn").forEach(function(b){b.onclick=function(){G.shopModo=b.getAttribute("data-m");render();};});
 document.querySelectorAll(".tabBtn").forEach(function(b){b.onclick=function(){G.shopTab=b.getAttribute("data-tab");render();};});
 document.querySelectorAll(".vtabBtn").forEach(function(b){b.onclick=function(){G.shopVSub=b.getAttribute("data-tab");render();};});
 stockEquipoBind(j);
 document.querySelectorAll(".buyPoc").forEach(function(b){b.onclick=function(){var p=POCIONES[parseInt(b.getAttribute("data-idx"),10)];if(j.oro>=p.precio){j.oro-=p.precio;avanzarTiempo(5);j.inventario[p.n]=(j.inventario[p.n]||0)+1;guardar();render();}};});
 document.querySelectorAll(".buyMisc").forEach(function(b){b.onclick=function(){var n=b.getAttribute("data-n"),pr=profPrecioCompra(n);if(j.oro>=pr){j.oro-=pr;avanzarTiempo(5);j.inventario[n]=(j.inventario[n]||0)+1;guardar();render();}};});
 document.querySelectorAll(".sellEq").forEach(function(b){b.onclick=function(){
  var lista=b.getAttribute("data-src")==="p"?profEst(j).equipo:equipoBolsa(j),i=parseInt(b.getAttribute("data-idx"),10),it=lista[i];
  if(!it)return;
  j.oro+=precioVentaEquipo(it);lista.splice(i,1);avanzarTiempo(5);guardar();render();
 };});
 document.querySelectorAll(".sellMat").forEach(function(b){b.onclick=function(){venderMaterial(j,b.getAttribute("data-n"),parseInt(b.getAttribute("data-cant"),10)||1);render();};});
 document.querySelectorAll(".sellPoc").forEach(function(b){b.onclick=function(){
  var n=b.getAttribute("data-n"),c=Math.min(parseInt(b.getAttribute("data-cant"),10)||1,j.inventario[n]||0);
  if(c<1)return;
  j.oro+=precioVentaConsumible(n)*c;avanzarTiempo(3);j.inventario[n]-=c;if(j.inventario[n]<=0)delete j.inventario[n];guardar();render();
 };});
 document.getElementById("bBack").onclick=function(){G.screen="tienint";render();};
}
function renderHospital(){
 var j=G.j,st=calcStats(j),faltaVida=st.vidaMax-j.vida,faltaRec=st.recursoMax-j.recurso,costoVida=Math.ceil(faltaVida/2),costoRec=Math.ceil(faltaRec/5);
 var h=hudHTML(j)+'<div class="card">';
 h+='<div class="font-disp" style="color:var(--accent);margin-bottom:12px">'+iconoSVG('hospital')+'Hospital de Nerzas</div>';
 h+='<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:10px;margin-bottom:14px">';
 h+='<button class="btn" id="bSanar" '+(faltaVida<=0||j.oro<costoVida?'disabled':'')+'>'+iconoSVG('corazon')+'Sanar<div style="font-size:11px;font-weight:400;color:var(--muted);margin-top:3px">'+(faltaVida>0?costoVida+' oro · +'+faltaVida+' HP':'Vida al máximo')+'</div></button>';
 h+='<button class="btn" id="bRec" '+(faltaRec<=0||j.oro<costoRec?'disabled':'')+'>✦ Reponer '+j.recursoNombre+'<div style="font-size:11px;font-weight:400;color:var(--muted);margin-top:3px">'+(faltaRec>0?costoRec+' oro · +'+faltaRec:'Recurso al máximo')+'</div></button>';
 h+='</div>';
 var mald=Object.keys(j.maldiciones),costo=costoPurga(j);
 h+='<div style="font-size:13px;color:var(--muted);margin-bottom:8px">☠ Purga de maldiciones ('+costo+' oro c/u · Total con 20% dto: '+Math.floor(mald.length*costo*0.8)+' oro)</div>';
 if(!mald.length)h+='<div style="color:#7ab88a;font-size:13px">No tienes maldiciones. Tu alma está limpia.</div>';
 else{mald.forEach(function(n){h+='<div style="display:flex;justify-content:space-between;align-items:center;padding:6px 0;border-bottom:1px dashed var(--border);font-size:13px;flex-wrap:wrap;gap:6px"><div><span style="color:#c97a9a">☠ '+n+'</span> <span style="color:var(--muted);font-size:11px">— '+j.maldiciones[n].desc+'</span></div><button class="btn purgarBtn" data-nombre="'+n+'" style="padding:5px 12px;font-size:12px" '+(j.oro<costo?'disabled':'')+'>Purgar</button></div>';});
 h+='<button class="btn btn-primary purgarTotal" style="margin-top:10px" '+(j.oro<Math.floor(mald.length*costo*0.8)?'disabled':'')+'>✨ Purga Total (-20%): '+Math.floor(mald.length*costo*0.8)+' oro</button>';}
 h+='<div style="margin-top:14px"><button class="btn" id="bBack">← Volver al Hospital</button></div></div>';
 el.innerHTML=h;
 var bS=document.getElementById("bSanar");if(bS&&!bS.disabled)bS.onclick=function(){if(j.oro>=costoVida){j.oro-=costoVida;avanzarTiempo(120);j.vida=st.vidaMax;guardar();render();}};
 var bR=document.getElementById("bRec");if(bR&&!bR.disabled)bR.onclick=function(){if(j.oro>=costoRec){j.oro-=costoRec;avanzarTiempo(60);j.recurso=st.recursoMax;guardar();render();}};
 document.querySelectorAll(".purgarBtn").forEach(function(b){b.onclick=function(){if(j.oro>=costo){j.oro-=costo;avanzarTiempo(60);delete j.maldiciones[b.getAttribute("data-nombre")];G.log.push("✨ Maldición purgada.");guardar();render();}};});
 var bT=document.querySelector(".purgarTotal");if(bT&&!bT.disabled)bT.onclick=function(){var total=Math.floor(mald.length*costo*0.8);if(j.oro>=total){j.oro-=total;avanzarTiempo(120);j.maldiciones={};G.log.push("✨ ¡Alma purificada!");guardar();render();}};
 document.getElementById("bBack").onclick=function(){G.screen="hospint";render();};
}
function renderGremio(){
 var j=G.j,es=mEst(j),g=GRUPOS[es.grupo],m=mActual(j),rango=RANGOS_GREMIO[j.gremio.rango];
 var h=hudHTML(j)+'<div class="card">';
 h+='<div class="font-disp" style="color:var(--accent);margin-bottom:12px">'+iconoSVG('gremio')+'Gremio de Aventureros — Rango '+rango.n+'</div>';
 h+='<div style="display:flex;gap:6px;flex-wrap:wrap;margin-bottom:14px">';
 ["campana","grupo","rango","vender","profesion"].forEach(function(t){var lb={campana:"📜 Campaña de Misiones",grupo:"👥 Misiones en grupo (en desarrollo)",rango:"⬆ Subir Rango",vender:"🏪 Vender Materiales",profesion:"⚒ Profesión"}[t];h+='<button class="btn tabBtn" data-tab="'+t+'" style="padding:6px 12px;font-size:12px;'+(G.gremioTab===t?'background:var(--accent-soft);border-color:var(--accent)':'')+'">'+lb+'</button>';});
 h+='</div>';
 var _sigR=(j.gremio.rango<7)?RANGOS_GREMIO[j.gremio.rango+1]:null;
 if(_sigR&&j.piso>=_sigR.req_piso){h+='<div style="margin-bottom:12px;padding:10px;border-radius:8px;background:rgba(122,140,58,.18);border:1px solid #7a8c3a;font-size:13px;font-weight:700">⬆ ¡Puedes subir a RANGO '+_sigR.n+'! Recompensa: '+_sigR.recompensa+' oro. Ve a la pestaña "Subir Rango".</div>';}
 if(G.gremioTab==="campana"){
  h+='<div style="font-size:13px;margin-bottom:10px"><span class="pill">Secuencia '+g.emoji+' '+g.nombre+' (Rango '+g.rango+')</span> · Misión '+(es.indice+1)+'/25 · Completadas: '+es.completadas+'/175</div>';
  if(es.estado==="fin"){h+='<div style="color:#c9a25a;font-weight:700">🏆 ¡CAMPAÑA COMPLETADA! Entregaste el Alma del Olvidado. Fin del juego.</div>';}
  else{
   var verbos={caza:"Caza",entrega:"Entrega",recoleccion:"Recoge"};
   var partes=Object.keys(m.obj).map(function(k){return m.obj[k]+" "+k;}).join(" + ");
   h+='<div class="card" style="margin-bottom:12px;background:rgba(0,0,0,.25)"><div style="font-weight:700;color:var(--text)">'+verbos[m.tipo]+' '+partes+(m.tag?' <span class="pill">'+m.tag+'</span>':'')+'</div>';
   h+='<div style="color:var(--muted);font-size:12px;margin-top:4px">Recompensa: '+m.oro+' oro · Estado: '+(es.estado==="disponible"?'Disponible':es.estado==="activa"?'En progreso':'¡LISTA PARA RECLAMAR!')+'</div>';
   if(es.estado==="activa")Object.keys(m.obj).forEach(function(k){h+='<div style="font-size:12px;color:#8ab0d8;margin-top:2px">'+itemImg(k,22)+progMision(j,k)+'/'+m.obj[k]+' '+k+'</div>';});
   h+='</div>';
   h+='<div style="display:flex;gap:8px;flex-wrap:wrap">';
   if(es.estado==="disponible")h+='<button class="btn btn-primary" id="bAceptar">✅ Aceptar misión</button>';
   if(es.estado==="lista"&&m.tipo!=="entrega")h+='<button class="btn btn-primary" id="bReclamar">🏆 Reclamar misión</button>';
   if(es.estado==="activa"&&m.tipo==="entrega")h+='<button class="btn btn-primary" id="bEntregar" '+(tieneEntrega(j,m)?'':'disabled')+'>📦 Entregar materiales</button>';
   else if(es.estado==="activa")h+='<div style="color:var(--muted);font-size:12px;align-self:center">Completa los objetivos explorando la mazmorra.</div>';
   h+='</div>';
  }
 }
 else if(G.gremioTab==="rango"){
  h+='<table class="tabla"><tr><th>Rango</th><th>Piso requerido</th><th>Recompensa</th><th></th></tr>';
  for(var id=1;id<=7;id++){var r=RANGOS_GREMIO[id];var tuyo=id===j.gremio.rango;var sig=id===j.gremio.rango+1;
   h+='<tr><td style="font-weight:700;color:'+(tuyo?'var(--accent)':'var(--text)')+'">'+r.n+(tuyo?' (tuyo)':'')+'</td><td>Piso '+r.req_piso+'</td><td>'+r.recompensa+' oro</td><td>'+(sig?'<button class="btn subirRango" style="padding:4px 10px;font-size:11px" '+(j.piso<r.req_piso?'disabled':'')+'>Subir</button>':'')+'</td></tr>';}
  h+='</table>';
 }
 else if(G.gremioTab==="vender"){
  var mats=Object.keys(j.inventario).filter(function(k){return esMaterial(k)&&j.inventario[k]>0;});
  h+='<div style="font-size:12px;color:var(--muted);margin-bottom:10px">El gremio compra materiales a precio fijo según su rareza y el bioma del que proceden.</div>';
  if(!mats.length)h+='<div style="color:var(--muted);font-size:13px">No tienes materiales para vender.</div>';
  else{mats.forEach(function(nm){var res=reservadoEntrega(j,nm),disp=j.inventario[nm]-res,pu=precioMaterial(nm);
   h+='<div style="display:flex;justify-content:space-between;align-items:center;gap:6px;padding:6px 0;border-bottom:1px dashed var(--border);font-size:13px;flex-wrap:wrap"><span>'+itemImg(nm,32)+nm+' x'+j.inventario[nm]+' <span style="color:var(--muted);font-size:11px">'+infoMaterial(nm)+' · '+pu+' oro c/u</span>'+(res?' <span style="color:#8ab0d8;font-size:11px">(reservados para entrega: '+res+')</span>':'')+'</span><span style="display:flex;gap:6px"><button class="btn venderMat" data-mat="'+nm+'" data-cant="1" style="padding:4px 10px;font-size:11px" '+(disp<1?'disabled':'')+'>Vender 1 ('+pu+')</button><button class="btn venderMat" data-mat="'+nm+'" data-cant="'+disp+'" style="padding:4px 10px;font-size:11px" '+(disp<1?'disabled':'')+'>Todo ('+(disp*pu)+')</button></span></div>';});}
 }
 else if(G.gremioTab==="grupo"){
  h+=onlineGrupoHTML();
 }
 else{
  h+=profHTML(j);
 }
 h+='<div style="margin-top:14px"><button class="btn" id="bBack">← Volver a la ciudad</button></div></div>';
 el.innerHTML=h;
 document.querySelectorAll(".tabBtn").forEach(function(b){b.onclick=function(){G.gremioTab=b.getAttribute("data-tab");render();};});
 if(G.gremioTab==="profesion")profBind(j);
 var bA=document.getElementById("bAceptar");if(bA)bA.onclick=function(){
  if(Math.floor((j.piso-1)/10)+1<es.grupo){G.msg="Debes llegar al bioma "+es.grupo+" ("+g.nombre+") para esta secuencia.";G.screen="hub";render();return;}
  avanzarTiempo(10);es.estado="activa";es.prog={};Object.keys(m.obj).forEach(function(k){es.prog[k]=0;});G.msg="Misión aceptada: "+Object.keys(m.obj).join(", ");G.screen="hub";render();};
 var bR=document.getElementById("bReclamar");if(bR)bR.onclick=function(){completarMision(j);guardar();G.screen="hub";render();};
 var bE=document.getElementById("bEntregar");if(bE)bE.onclick=function(){completarMision(j);guardar();G.screen="hub";render();};
 document.querySelectorAll(".subirRango").forEach(function(b){b.onclick=function(){var sig=RANGOS_GREMIO[j.gremio.rango+1];if(j.piso>=sig.req_piso){j.gremio.rango++;j.oro+=sig.recompensa;G.msg="¡Subiste a rango "+sig.n+"! +"+sig.recompensa+" oro.";guardar();render();}};});
 document.querySelectorAll(".venderMat").forEach(function(b){b.onclick=function(){venderMaterial(G.j,b.getAttribute("data-mat"),parseInt(b.getAttribute("data-cant"),10)||1);render();};});
 document.getElementById("bBack").onclick=function(){G.screen="gremint";render();};
}
var HERR_SLOTS={arma:"Arma",pecho:"Pecho",piernas:"Piernas",guantes:"Guantes",botas:"Botas",accesorio:"Accesorio",casco:"Casco",capa:"Capa",amuleto:"Amuleto"};
/* Mejora: +1 a cada atributo del item y +5 ATK (arma) o +5 DEF (resto). sign=-1 revierte */
function mejoraAplicar(it,sl,sign,clase){
 var a=Object.assign({},itemAttr(it));
 if(!Object.keys(a).length){
  var d=ATTR_CLASES[clase]||ATTR_CLASES["Guerrero"],idx=ATTR_SLOT[sl]||[0,1];
  idx.forEach(function(k){a[d.pri[k]]=0;});
 }
 for(var k in a)a[k]=Math.max(0,a[k]+sign);
 it.attr=a;
 if(sl==="arma")it.atk=Math.max(0,(it.atk||0)+5*sign);else it.def=Math.max(0,(it.def||0)+5*sign);
}
function renderHerreria(){
 var j=G.j;if(!G.shopStock)generarStock();
 if(["comprar","forja","mejorar"].indexOf(G.herreriaTab)<0)G.herreriaTab="comprar";
 var h=hudHTML(j)+'<div class="card">';
 h+='<div class="font-disp" style="color:var(--accent);margin-bottom:12px">'+iconoSVG('martillo')+'Herrería — Forja Maestra</div>';
 h+='<div style="display:flex;gap:6px;flex-wrap:wrap;margin-bottom:12px">';
 [["comprar","🛒 Comprar"],["forja","⚒ Forja"],["mejorar","⬆ Mejorar Item"]].forEach(function(t){
  h+='<button class="btn tabBtn" data-tab="'+t[0]+'" style="padding:6px 12px;font-size:12px;'+(G.herreriaTab===t[0]?'background:var(--accent-soft);border-color:var(--accent)':'')+'">'+t[1]+'</button>';});
 h+='</div>';
 if(G.herreriaTab==="comprar"){
  var mapa={arma:"armas",armadura:"armaduras",accesorio:"accesorios"};
  if(!mapa[G.herrCSub])G.herrCSub="arma";
  h+='<div style="display:flex;gap:6px;flex-wrap:wrap;margin-bottom:10px">';
  [["arma","Armas"],["armadura","Armaduras"],["accesorio","Accesorios"]].forEach(function(t){h+='<button class="btn hsubBtn" data-sub="'+t[0]+'" style="padding:5px 10px;font-size:11px;'+(G.herrCSub===t[0]?'background:var(--accent-soft);border-color:var(--accent)':'')+'">'+t[1]+'</button>';});
  h+='</div>'+stockEquipoHTML(j,mapa[G.herrCSub]);
 }
 else if(G.herreriaTab==="mejorar"){
  var bioma=getBioma(j),mat=bioma.material;
  h+='<div style="font-size:12px;color:var(--muted);margin-bottom:10px">Mejora tu equipo puesto con '+mat+' del bioma. Cada mejora: +1 a cada atributo del item, y +5 ATK (armas) o +5 DEF (armaduras y accesorios). Si fallas, el item baja 1 nivel de mejora.</div>';
  h+='<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:10px">';
  for(var sl in HERR_SLOTS){
   var it=j.equipo[sl];if(!it||!it.n||it.n==="Ninguno")continue;
   var m=(it.mejora||0),costoOro=100*(m+1)*j.nivel,costoMat=2*(m+1),prob=Math.max(0.3,1.0-m*0.15),tieneMat=j.inventario[mat]||0;
   var puede=j.oro>=costoOro&&tieneMat>=costoMat,at=attrTxt(itemAttr(it));
   h+='<div class="card" style="padding:10px;background:rgba(0,0,0,.25)"><div style="font-weight:700;font-size:13px">'+itemImg(it.n,34)+HERR_SLOTS[sl]+': '+it.n+'</div>';
   h+='<div style="font-size:11px;color:var(--muted);margin:4px 0">Mejora: +'+m+' · Prob. éxito: '+Math.floor(prob*100)+'%'+(at?'<br>'+at:'')+'</div>';
   h+='<div style="font-size:11px;color:var(--muted)">Coste: '+costoOro+' oro + '+costoMat+' '+mat+' (tienes '+tieneMat+')</div>';
   h+='<button class="btn mejorarBtn" data-slot="'+sl+'" style="margin-top:8px;padding:5px 12px;font-size:12px;width:100%" '+(puede?'':'disabled')+'>Forjar mejora +'+(m+1)+'</button></div>';
  }
  h+='</div>';
 }
 else if(j.piso<10){
  h+='<div style="text-align:center;padding:30px 10px"><div style="font-size:40px;margin-bottom:10px">🔒</div><div style="font-weight:700;color:#e08080;margin-bottom:6px">FORJA MAESTRA BLOQUEADA</div><div style="font-size:13px;color:var(--muted)">Desbloqueo: Derrotar al Jefe del Piso 10 (Treant Ancestral). Puedes comprar y mejorar desde ya.</div></div>';
 }
 else{
  if(["arma","armadura","accesorio","taberna"].indexOf(G.herreriaSub)<0)G.herreriaSub="arma";
  h+='<div style="display:flex;gap:6px;flex-wrap:wrap;margin-bottom:10px">';
  [["arma","⚔ Armas"],["armadura","🛡 Armaduras"],["accesorio","💍 Accesorios"],["taberna","🍺 Taberna"]].forEach(function(t){h+='<button class="btn hsubBtn" data-sub="'+t[0]+'" style="padding:5px 10px;font-size:11px;'+(G.herreriaSub===t[0]?'background:var(--accent-soft);border-color:var(--accent)':'')+'">'+t[1]+'</button>';});
  h+='</div>';
  var recetas=(G.herreriaSub==="taberna")?recetasTaberna(j):RECETAS_FORJA.filter(function(r){return r[2]===j.clase&&r[1]===G.herreriaSub;}).map(recetaObj);
  if(!recetas.length)h+='<div style="color:var(--muted);font-size:13px">'+(G.herreriaSub==="taberna"?"Aún no tienes recetas de la Taberna. Consíguelas con rumores (legendarias) y encargos del Tablón (épicas).":"No hay recetas de este tipo para tu clase.")+'</div>';
  recetas.forEach(function(r,i){
   var tiene=poseeEquipo(j,r.n),puede=j.oro>=r.oro&&j.nivel>=r.nivel&&!tiene,ingHtml=[];
   for(var k in r.ing){var tn=j.inventario[k]||0;if(tn<r.ing[k])puede=false;ingHtml.push('<span style="color:'+(tn>=r.ing[k]?'#7ab88a':'#e08080')+';font-size:11px">'+itemImg(k,18)+k+' '+tn+'/'+r.ing[k]+'</span>');}
   var rarezaColor={Raro:"#5a9ac9",Épico:"#a85ac9",Legendario:"#c9a23c"}[r.rareza]||"var(--muted)";
   h+='<div style="padding:10px 0;border-bottom:1px dashed var(--border)"><div style="display:flex;justify-content:space-between;flex-wrap:wrap;gap:6px"><div style="display:flex;align-items:flex-start">'+itemImg(r.n,42)+'<div><span style="font-weight:700;color:'+rarezaColor+'">'+r.n+'</span> <span class="pill" style="color:'+rarezaColor+';border-color:'+rarezaColor+'">'+r.rareza+'</span><div style="font-size:11px;color:var(--muted);margin-top:2px">'+statsItemTxt(j,r)+' · Nv '+r.nivel+(j.nivel<r.nivel?' <span style="color:#e08080">(requieres Nv '+r.nivel+')</span>':'')+'</div></div></div>';
   h+='<button class="btn forjarBtn" data-idx="'+i+'" style="padding:5px 12px;font-size:12px;align-self:flex-start" '+(puede?'':'disabled')+'>'+(tiene?'Ya lo posees':'Forjar ('+r.oro+' oro)')+'</button></div>';
   h+='<div style="margin-top:4px;display:flex;gap:10px;flex-wrap:wrap">'+ingHtml.join("")+'</div></div>';
  });
 }
 h+='<div style="margin-top:14px"><button class="btn" id="bBack">← Volver a la Herrería</button></div></div>';
 el.innerHTML=h;
 document.querySelectorAll(".tabBtn").forEach(function(b){b.onclick=function(){G.herreriaTab=b.getAttribute("data-tab");render();};});
 document.querySelectorAll(".hsubBtn").forEach(function(b){b.onclick=function(){if(G.herreriaTab==="comprar")G.herrCSub=b.getAttribute("data-sub");else G.herreriaSub=b.getAttribute("data-sub");render();};});
 stockEquipoBind(j);
 document.querySelectorAll(".forjarBtn").forEach(function(b){b.onclick=function(){
  var r=recetas[parseInt(b.getAttribute("data-idx"),10)];
  if(!r||poseeEquipo(j,r.n)||j.oro<r.oro)return;
  for(var k in r.ing){j.inventario[k]-=r.ing[k];if(j.inventario[k]<=0)delete j.inventario[k];}
  j.oro-=r.oro;
  avanzarTiempo(60);
  equiparItem(j,r);
  G.log.push("⚒ ¡Forjaste "+r.n+"! El equipo reemplazado pasó a tu inventario.");guardar();render();
 };});
 document.querySelectorAll(".mejorarBtn").forEach(function(b){b.onclick=function(){
  var sl=b.getAttribute("data-slot"),it=j.equipo[sl],m=(it.mejora||0);
  var costoOro=100*(m+1)*j.nivel,costoMat=2*(m+1),prob=Math.max(0.3,1.0-m*0.15),mat=getBioma(j).material;
  if(j.oro<costoOro||(j.inventario[mat]||0)<costoMat)return;
  j.oro-=costoOro;avanzarTiempo(30);j.inventario[mat]-=costoMat;if(j.inventario[mat]<=0)delete j.inventario[mat];
  var ext=(sl==="arma"?"+5 ATK":"+5 DEF");
  if(Math.random()<prob){
   mejoraAplicar(it,sl,1,j.clase);it.mejora=m+1;it.mejV=2;
   G.msg="⚒ ¡ÉXITO! "+it.n+" mejorado a +"+it.mejora+" (+1 a cada atributo, "+ext+").";
  }else{
   if(m>0){
    if(it.mejV===2)mejoraAplicar(it,sl,-1,j.clase);else{it.atk=Math.max(0,(it.atk||0)-2);it.def=Math.max(0,(it.def||0)-1);it.vida=Math.max(0,(it.vida||0)-1);}
    it.mejora=m-1;G.msg="💥 ¡FALLO! "+it.n+" bajó a +"+it.mejora+".";
   }else G.msg="💥 ¡FALLO! La forja se perdió, pero tu item no tenía mejoras que perder.";
  }
  guardar();G.screen="herreria";render();
 };});
 document.getElementById("bBack").onclick=function(){G.screen="herint";render();};
}
function renderAlquimista(){
 var j=G.j,h=hudHTML(j)+'<div class="card">';
 h+='<div class="font-disp" style="color:var(--accent);margin-bottom:12px">'+iconoSVG('alquimista')+'Alquimista</div>';
 h+='<div style="display:flex;gap:6px;flex-wrap:wrap;margin-bottom:14px">';
 ["pocion","transmutar"].forEach(function(t){var lb={pocion:"⚗ Craftear Pociones/Materiales",transmutar:"✨ Transmutar Materiales"}[t];h+='<button class="btn tabBtn" data-tab="'+t+'" style="padding:6px 12px;font-size:12px;'+(G.alquimistaTab===t?'background:var(--accent-soft);border-color:var(--accent)':'')+'">'+lb+'</button>';});
 h+='</div>';
 if(G.alquimistaTab==="pocion"){
  Object.keys(RECETAS_ALQUIMISTA).forEach(function(nombre,i){
   var r=RECETAS_ALQUIMISTA[nombre];var puede=j.oro>=r.oro;var ingHtml=[];
   for(var k in r.ing){var tiene=j.inventario[k]||0;if(tiene<r.ing[k])puede=false;ingHtml.push('<span style="color:'+(tiene>=r.ing[k]?'#7ab88a':'#e08080')+';font-size:11px">'+itemImg(k,18)+k+' '+tiene+'/'+r.ing[k]+'</span>');}
   h+='<div style="padding:8px 0;border-bottom:1px dashed var(--border)"><div style="display:flex;justify-content:space-between;flex-wrap:wrap;gap:6px"><div>'+itemImg(nombre,36)+'<span style="font-weight:600">'+nombre+'</span> <span style="color:var(--muted);font-size:11px">— '+r.efecto+' · '+r.oro+' oro</span></div><button class="btn craftearBtn" data-nombre="'+nombre+'" style="padding:5px 12px;font-size:12px;align-self:flex-start" '+(puede?'':'disabled')+'>Craftear</button></div>';
   h+='<div style="margin-top:3px;display:flex;gap:10px;flex-wrap:wrap">'+ingHtml.join("")+'</div></div>';
  });
 }
 else{
  var bioma=getBioma(j),matB=bioma.material;
  h+='<div style="font-size:12px;color:var(--muted);margin-bottom:10px">Convierte 3 materiales comunes en 1 '+matB+' (material de '+bioma.nombre+')</div>';
  var comunes=Object.keys(j.inventario).filter(function(k){return POCIONES.every(function(p){return p.n!==k;})&&j.inventario[k]>=3;});
  if(!comunes.length)h+='<div style="color:var(--muted);font-size:13px">No tienes 3+ unidades de ningún material.</div>';
  else comunes.forEach(function(m){var max=Math.floor(j.inventario[m]/3);h+='<div style="display:flex;justify-content:space-between;align-items:center;padding:6px 0;border-bottom:1px dashed var(--border);font-size:13px"><span>'+itemImg(m,30)+m+' x'+j.inventario[m]+' (máx '+max+' conversiones)</span><button class="btn transmutarBtn" data-mat="'+m+'" style="padding:4px 10px;font-size:11px">Transmutar 3→1</button></div>';});
 }
 h+='<div style="margin-top:14px"><button class="btn" id="bBack">← Volver al Alquimista</button></div></div>';
 el.innerHTML=h;
 document.querySelectorAll(".tabBtn").forEach(function(b){b.onclick=function(){G.alquimistaTab=b.getAttribute("data-tab");render();};});
 document.querySelectorAll(".craftearBtn").forEach(function(b){b.onclick=function(){
  var nombre=b.getAttribute("data-nombre"),r=RECETAS_ALQUIMISTA[nombre];
  for(var k in r.ing){j.inventario[k]-=r.ing[k];if(j.inventario[k]<=0)delete j.inventario[k];}
  j.oro-=r.oro;j.inventario[nombre]=(j.inventario[nombre]||0)+1;G.log.push("✨ Crafteaste "+nombre+".");guardar();render();
 };});
 document.querySelectorAll(".transmutarBtn").forEach(function(b){b.onclick=function(){
  var m=b.getAttribute("data-mat");j.inventario[m]-=3;if(j.inventario[m]<=0)delete j.inventario[m];
  j.inventario[matB]=(j.inventario[matB]||0)+1;G.log.push("✨ Transmutaste 3 "+m+" en 1 "+matB+".");guardar();render();
 };});
 document.getElementById("bBack").onclick=function(){G.screen="alqint";render();};
}
function renderLaberinto(){
 var j=G.j,H=window.OnlineHub,grp=!!(H&&H.conectado()&&H.enGrupo()),L=grp?(j.lab&&j.lab.g?j.lab:null):(j.lab&&!j.lab.g?j.lab:j.labPersonal),h=hudHTML(j)+'<div class="card">',volver=G.labVolver==="oakint"?"oakint":"hub";
 h+='<div class="font-disp" style="color:var(--accent);margin-bottom:4px">'+iconoSVG('calabozo')+'Mazmorras del Reino de Artaros — El Laberinto</div>';
 h+='<div style="font-size:12px;font-style:italic;color:var(--muted);margin-bottom:12px">«Dicen que nadie ha visto el final. Los que volvieron hablaban de palancas, compuertas de colores y algo enorme durmiendo al fondo.»</div>';
 h+='<div style="font-size:13px;line-height:1.7;margin-bottom:12px">'
  +'• Laberinto enorme de pasillos, criptas, osarios, bibliotecas, cámaras de tormento y calabozos.<br>'
  +'• <b>Palancas</b> que abren compuertas por color (una, varias a la vez o temporizadas), liberan celdas o desactivan trampas.<br>'
  +'• Trampas del juego: pinchos, llamas, glifos y veneno. Los enemigos duermen hasta que te acercas.<br>'
  +'• Mapa con niebla: el minimapa solo muestra lo que ya exploraste ([Tab] = mapa grande). [F] = interactuar.<br>'
  +'• Tu progreso se guarda al salir por la escalera de la entrada. No avanzas en la historia; sí obtienes XP, botín y cofres. Al caer, reapareces en la entrada con una maldición.</div>';
 if(grp){var gg=H.grupo();h+='<div style="padding:10px;border-radius:8px;background:var(--accent-soft);border:1px solid var(--accent);font-size:13px;margin-bottom:14px">👥 '+(gg.raid?'Raid':'Grupo')+' de '+gg.miembros.length+' jugadores · '+(gg.lab?'<b>expedición del grupo en curso</b> ('+gg.lab.en.length+' dentro): entrarás en el mismo laberinto.':'al entrar, el grupo comparte laberinto, enemigos, palancas y cofres. Quien entre después se une a tu expedición.')+'</div>';}
 if(L){h+='<div style="padding:10px;border-radius:8px;background:var(--accent-soft);border:1px solid var(--accent);font-size:13px;margin-bottom:14px">🧭 Expedición en curso · enemigos derrotados: <b>'+(L.kl||[]).length+'</b> · palancas accionadas: <b>'+(L.pl||[]).length+'</b> · cofres abiertos: <b>'+(L.co||[]).length+'</b></div>';}
 if(j.labHechos)h+='<div style="font-size:12px;color:#7ab88a;margin-bottom:10px">🏆 Laberintos superados: '+j.labHechos+'</div>';
 h+='<button class="btn btn-primary" id="bLabIr" style="padding:12px 28px;font-size:15px">🕳 '+(grp?(L||(H.grupo().lab)?'👥 Unirse a la expedición del grupo':'👥 Entrar con el grupo'):(L?'Continuar la expedición':'Entrar al Laberinto'))+'</button>';
 if(L&&!grp)h+=' <button class="btn btn-danger" id="bLabNuevo" style="padding:12px 18px;font-size:13px">Abandonar y generar uno nuevo</button>';
 h+='<div style="margin-top:14px"><button class="btn" id="bBack">← Volver</button></div></div>';
 el.innerHTML=h;
 document.getElementById("bLabIr").onclick=function(){if(window.mazmorraLaberinto)mazmorraLaberinto(false);else{G.msg="El Laberinto no está disponible.";G.screen=volver;render();}};
 var bn=document.getElementById("bLabNuevo");if(bn)bn.onclick=function(){if(confirm("Se perderá el progreso de esta expedición. ¿Continuar?")){j.lab=null;guardar();mazmorraLaberinto(true);}};
 document.getElementById("bBack").onclick=function(){G.screen=volver;render();};
}
function renderInfinita(){
 var j=G.j,rec=recordInfinita(j);
 var h=hudHTML(j)+'<div class="card">';
 h+='<div class="font-disp" style="color:var(--accent);margin-bottom:4px">'+iconoSVG('aventura')+'Mazmorra Infinita — General Kaelen</div>';
 h+='<div style="font-size:12px;font-style:italic;color:var(--muted);margin-bottom:12px">«Aquí no hay pisos ni descanso: solo oleadas. Cuanto más profundo bajes, más cosas te estarán esperando... y algunas llevan corona.»</div>';
 h+='<div style="font-size:13px;line-height:1.7;margin-bottom:12px">'
  +'• Oleadas infinitas en mapas de mazmorra con trampas.<br>'
  +'• Cada oleada trae más monstruos y más fuertes. A veces aparecen jefes con esbirros: hasta 7 a la vez hacia la oleada 200.<br>'
  +'• <b>No da experiencia</b>: solo oro y materiales.<br>'
  +'• Si mueres, la racha termina y empiezas otra vez en la oleada 1. Tu récord se conserva.<br>'
  +'• Las pociones se gastan de tu inventario.</div>';
 h+='<div style="padding:10px;border-radius:8px;background:var(--accent-soft);border:1px solid var(--accent);font-size:14px;margin-bottom:14px">🏆 Récord: '+(rec>0?'<b>'+rec+' oleada'+(rec>1?'s':'')+' superada'+(rec>1?'s':'')+'</b>':'aún sin récord')+'</div>';
 h+='<button class="btn btn-primary" id="bInfIr" style="padding:12px 28px;font-size:15px">∞ Entrar a la Mazmorra Infinita</button>';
 h+='<div style="margin-top:14px"><button class="btn" id="bBack">← Volver al Castillo</button></div></div>';
 el.innerHTML=h;
 document.getElementById("bInfIr").onclick=function(){if(window.mazmorraInfinita)mazmorraInfinita();else{G.msg="La Mazmorra Infinita no está disponible.";G.screen="castint";render();}};
 document.getElementById("bBack").onclick=function(){G.screen="castint";render();};
}
function renderAventura(){
 var j=G.j,pisoActual=j.piso;
 var h=hudHTML(j)+'<div class="card">';
 h+='<div class="font-disp" style="color:var(--accent);margin-bottom:12px">'+iconoSVG('aventura')+'Modo Aventura — Farmeo</div>';
 h+='<div style="font-size:12px;color:var(--muted);margin-bottom:12px">Rejuga pisos anteriores. Penalización: -30% Oro y XP · 100% Materiales. No avanzas en la historia.</div>';
 if(pisoActual<3){h+='<div style="color:#e08080;font-size:13px">Aún no tienes pisos disponibles. Debes avanzar al menos 2 pisos.</div>';}
 else{
  h+='<div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(140px,1fr));gap:8px">';
  for(var p=1;p<=pisoActual-2;p++){
   var b=getBioma({piso:p}),pe=p%10;if(pe===0)pe=10;
   var tipo=pe===10?"♛ JEFE":pe===5?"☠ MINI-JEFE":"Monstruos";
   h+='<button class="btn aventBtn" data-piso="'+p+'" style="text-align:left;padding:10px;font-size:12px"><div style="font-weight:700;color:'+b.color+'">Piso '+p+'</div><div style="font-weight:400;color:var(--muted);font-size:10px;margin-top:2px">'+b.emoji+' '+b.nombre+' · '+tipo+'</div></button>';
  }
  h+='</div>';
 }
 h+='<div style="margin-top:14px"><button class="btn" id="bBack">← Volver a la ciudad</button></div></div>';
 el.innerHTML=h;
 document.querySelectorAll(".aventBtn").forEach(function(b){b.onclick=function(){var pv=parseInt(b.getAttribute("data-piso"));mazmorraExplorar(pv);};});
 document.getElementById("bBack").onclick=function(){G.screen="castint";render();};
}
