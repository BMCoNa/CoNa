"use strict";
/* Talentos de rama + almas */
/* ============================================================
   TALENTOS DE RAMA + ALMAS (Clases_rama.txt)
   Nv50 elige rama (irreversible) · 50-58 talentos · 60 Hab.1 · 65-75 potencia · 80 Hab.2 · 85-100 maestría
   Coste de cada nodo en almas = nivel del nodo. Orden secuencial dentro de la rama.
   ============================================================ */
var NIV_RAMA=50;
/* Costo en almas de cada talento: nivel x (1 + nivel/TAL_ALMAS_DIV), redondeado a múltiplos de 5.
   (antes = nivel). Ej.: Nv50 -> 80 · Nv80 -> 160 · Nv100 -> 225. Menor divisor = más caro. */
var TAL_ALMAS_DIV=80;
/* Los nodos que desbloquean una habilidad (Hab. 1 Nv60 y Hab. 2 Nv80) cuestan +180% (x2.8) */
var TAL_HAB_MULT=2.8;
function costoTalento(nv,esHab){return Math.max(5,Math.round(nv*(1+nv/TAL_ALMAS_DIV)*(esHab?TAL_HAB_MULT:1)/5)*5);}
function costoNodo(n){return costoTalento(n.nv,!!n.sk);}
var POT_RAMA=[[65,"Potencia I","+20% poder Hab. 1",{h1p:.2}],[70,"Celeridad","-1 turno de enfriamiento Hab. 1",{h1cd:1}],[75,"Potencia II","+20% poder Hab. 1",{h1p:.2}]];
var RAMAS={
"Guerrero":[
{n:"Berserker",foco:"Daño bruto · Débil: defensa",
 t:[["Filo Doble","+15% daño",{dmg:.15}],["Sed Insaciable","Robo de vida 1% por golpe",{ls:.01}],["Furia Eterna","+3 Furia por acción",{rec:3}]],
 h1:{s:"h1",n:"Torbellino Aniquilador",c:45,cd:3,k:"d",a:1,h:2,m:1,esc:.08,sdf:.15,d:"2 giros en área, +8% daño por enemigo, -15% DEF 2 turnos"},
 h2:{s:"h2",n:"Sangre de Loco",c:60,cd:5,k:"b",t:10,cc:1,dpl:.12,vl2:.3,d:"10s inmune a CC, +12% daño por cada 10% vida perdida, <20% vida +30% vel."},
 m:[["Torbellino Sangrante","Torbellino deja sangrado (+20% daño)",{h1sg:.2}],["Sangre Vampírica","Sangre de Loco cura 25% del daño hecho al terminar",{h2hp:.25}],["Golpe Doble","Golpe Brutal +50% daño",{bp0:.5}]]},
{n:"Ejecutor",foco:"Ejecución / oro · Débil: área",
 t:[["Marca Fatal","Enemigos <30% vida reciben +25% daño",{exth:.3,exv:.25}],["Tasador","+40% oro y probabilidad de botín",{oro:.4,loot:.4}],["Corte Preciso","+20% crítico vs objetivo único",{critU:.2}]],
 h1:{s:"h1",n:"Sentencia Final",c:40,cd:3,k:"d",m:3,rs:20,d:"300% daño. Si mata: reinicia CD y +20 Furia"},
 h2:{s:"h2",n:"Marca del Condenado",c:50,cd:5,k:"m",dm:.2,cof:1,orp:0,d:"Marca a un objetivo: +20% daño recibido; si muere marcado suelta cofre extra"},
 m:[["Sentencia Verdadera","Sentencia ignora toda defensa",{h1ig:1}],["Marca Codiciosa","Marca suelta 100% más oro",{h2oro:1}],["Embate Ejecutor","Golpe Brutal +50% daño",{bp0:.5}]]}],
"Paladin":[
{n:"Inquisidor",foco:"Daño sagrado en área + buff · Débil: tanqueo",
 t:[["Juicio Ardiente","+20% daño en área",{aoe:.2}],["Fanatismo","+10% velocidad de ataque",{vel:.1}],["Suelo Bendito","Bendiciones de DEF duran +3 s",{durx:1.5}]],
 h1:{s:"h1",n:"Juicio Divino",c:50,cd:3,k:"d",a:1,m:1.6,sil:1,und:1,d:"160% daño en área + silencia. No-muertos reciben doble silencio y daño"},
 h2:{s:"h2",n:"Cruzada Fanática",c:60,cd:5,k:"b",t:12,dm:.25,d:"12s: +25% daño sagrado"},
 m:[["Marca Explosiva","Juicio +25% poder",{h1p:.25}],["Escudo de Cruzada","Cruzada da escudo 15% vida",{h2sh:.15}],["Golpe Inquisidor","Golpe Sagrado +50% daño",{bp0:.5}]]},
{n:"Guardián",foco:"Defensa + regeneración · Débil: daño",
 t:[["Muralla","+30% defensa",{defp:.3}],["Luz Perenne","Regenera 3% vida por turno",{regT:.03}],["Provocación Sagrada","-10% daño recibido",{dr:.1}]],
 h1:{s:"h1",n:"Bastión Inquebrantable",c:50,cd:4,k:"b",t:8,red:.6,d:"8s: daño recibido -60%"},
 h2:{s:"h2",n:"Luz Regeneradora",c:60,cd:5,k:"b",t:10,reg:.1,cl:1,d:"5 turnos: +10% vida máx por turno y limpia 1 maldición"},
 m:[["Bastión Reflectante","Bastión refleja 30% daño",{h1ref:.3}],["Luz Mayor","Regeneradora +50% poder",{h2p:.5}],["Muro de Fe","Sentencia de Luz +50% poder",{bp1:.5}]]}],
"Arquero":[
{n:"Cazador",foco:"Daño sostenido con mascota · Débil: distancia",
 t:[["Vínculo Bestial","Mascota: +10% daño",{dmg:.1}],["Jaula","Trampa inmoviliza +1 turno",{h2st:1}],["Caza en Manada","+15% crítico",{crit:.15}]],
 h1:{s:"h1",n:"Vínculo Alfa",c:40,cd:6,k:"b",t:10,dm:1,d:"10s: tu mascota ataca al unísono (+100% daño)"},
 h2:{s:"h2",n:"Trampa Alfa",c:50,cd:5,k:"d",a:1,m:.8,st:2,dd:.25,sg:.2,d:"Inmoviliza 2 turnos, sangra y reduce DEF 25%"},
 m:[["Mascota Evolucionada","+15% daño (Lobo Alfa / Oso Ancestral)",{dmg:.15}],["Trampa Inesquivable","Trampa inmoviliza +1 turno",{h2st:1}],["Marca de la Manada","Tiro Certero +50% daño",{bp0:.5}]]},
{n:"Francotirador",foco:"Distancia extrema + crítico · Débil: mascota y área",
 t:[["Ojo de Halcón","+10% daño",{dmg:.1}],["Calibre Pesado","Ignora 30% armadura",{ig:.3}],["Respiración Controlada","+10% crítico",{crit:.1}]],
 h1:{s:"h1",n:"Disparo de Largo Alcance",c:40,cd:6,k:"d",m:4,cr:1,ig:1,d:"400% daño, crítico garantizado, ignora defensa"},
 h2:{s:"h2",n:"Posición Elevada",c:50,cd:5,k:"b",t:0,inv:2,nx:{dm:.5,bn:3},d:"Inmune 2 turnos; próximo ataque +50% crítico y rebota a 3 enemigos"},
 m:[["Disparo Ejecutor","Disparo ejecuta enemigos <20% vida",{h1ex:.2}],["Doble Tiro","Posición da 2 tiros críticos",{h2nx:1}],["Disparo Perforante","Tiro Certero +50% daño",{bp0:.5}]]}],
"Asesino":[
{n:"Ninja",foco:"1v1 + multi-golpe · Débil: área y oro",
 t:[["Sombra Veloz","20% de atacar 2 veces",{dbl:.2}],["Filo Silencioso","+15% crítico vs objetivo único",{critU:.15}],["Kage Bunshin","Clon: +30% daño por ataque",{clone:.3}]],
 h1:{s:"h1",n:"Corte Sombra x7",c:50,cd:5,k:"d",h:7,m:.5,fm:4,ci:.1,d:"7 cortes al mismo objetivo, +10% crítico por corte, último 200%"},
 h2:{s:"h2",n:"Paso Espectral",c:45,cd:5,k:"b",t:0,inv:1,nx:{dm:.5},d:"Inmune 1 turno; próximo ataque 100% crítico y +50% daño"},
 m:[["Corte x10","Corte Sombra: 10 cortes",{h1h:3}],["Clon Explosivo","Paso Espectral +30% poder",{h2p:.3}],["Puñalada Sombra","Golpe Espectral +50% daño",{bp0:.5}]]},
{n:"Sicario",foco:"Área moderada + oro · Débil: daño 1v1",
 t:[["Negocio Sucio","+50% oro",{oro:.5}],["Lluvia de Acero","+20% daño en área",{aoe:.2}],["Contrato Abierto","+25% daño a élites y jefes",{elite:.25}]],
 h1:{s:"h1",n:"Lluvia de Cuchillas",c:45,cd:3,k:"d",a:1,h:2,m:.8,oro:20,d:"Cuchillas en área; +20 oro por baja"},
 h2:{s:"h2",n:"Contrato Marcado",c:50,cd:6,k:"m",dm:.15,cof:1,orp:.3,bf:{dm:.15},d:"Marca: +15% daño recibido; si muere: cofre, +30% oro y +15% daño 20s"},
 m:[["Veneno Mayor","Lluvia +60% poder",{h1p:.6}],["Doble Cofre","Contrato suelta 2 cofres",{h2cof:1}],["Veneno de Sicario","Golpe Espectral +50% daño",{bp0:.5}]]}],
"Mago":[
{n:"Ignis",foco:"Daño en área + DoT · Débil: control",
 t:[["Piromanía","Quemadura: +10% daño por golpe",{sg:.1}],["Incinerar","+25% daño en área",{aoe:.25}],["Combustible","+10% daño",{dmg:.1}]],
 h1:{s:"h1",n:"Infierno",c:55,cd:4,k:"d",a:1,h:3,m:.8,d:"3 oleadas de fuego en área (80% c/u)"},
 h2:{s:"h2",n:"Combustión",c:60,cd:5,k:"d",a:1,m:2.5,st:1,d:"250% daño en área + aturde 1 turno"},
 m:[["Infierno Persecutor","Infierno +1 oleada",{h1h:1}],["Combustión Residual","Combustión +30% daño extra",{h2sg:.3}],["Meteoro","Bola de Fuego +50% daño",{bp0:.5}]]},
{n:"Cryomante",foco:"Control + crítico · Débil: daño sostenido",
 t:[["Cero Absoluto","Congelar dura +1 turno",{stb:1}],["Fractura","+40% daño crítico vs congelado",{fz:.4}],["Permafrost","Enemigos 20% más lentos",{slow:.2}]],
 h1:{s:"h1",n:"Prisión Glacial",c:50,cd:4,k:"d",a:1,m:.8,st:2,d:"80% daño en área + congela 2 turnos"},
 h2:{s:"h2",n:"Lanza de Hielo Absoluto",c:55,cd:5,k:"d",m:3.5,fx:1,st:1,d:"350% daño. Si está congelado: crítico y congela de nuevo"},
 m:[["Prisión Irrompible","Prisión congela +1 turno",{h1st:1}],["Lanza Rebotante","Lanza +2 impactos",{h2h:2}],["Nova Glacial","Congelar +50% daño",{bp1:.5}]]}],
"Clérigo":[
{n:"Hierofante",foco:"Curación, escudos y control · Débil: daño",
 t:[["Fe Inquebrantable","+25% defensa",{defp:.25}],["Manantial de Luz","Regenera 2% vida por turno",{regT:.02}],["Devoción","+25% curación y escudos",{cura:.25}]],
 h1:{s:"h1",n:"Santuario de Luz",c:50,cd:4,k:"b",t:8,red:.35,reg:.06,sh:.2,pur:1,d:"8s: -35% daño recibido, +6% vida máx por turno, escudo 20% vida máx y purga el control"},
 h2:{s:"h2",n:"Resurgir Divino",c:60,cd:6,k:"b",t:10,hl:.5,df:.3,dm:.2,pur:1,cc:1,d:"Cura 50% vida máx y 10s: +30% DEF, +20% daño e inmune a control"},
 m:[["Santuario Eterno","Santuario de Luz +50% poder",{h1p:.5}],["Luz Mayor","Resurgir Divino +30% poder",{h2p:.3}],["Pulso Bendito","Pulso Vital +50% poder",{bp0:.5}]]},
{n:"Heraldo Solar",foco:"Daño sagrado en área + buffs de daño · Débil: curación",
 t:[["Fulgor Abrasador","+15% daño",{dmg:.15}],["Juicio Radiante","+25% daño en área",{aoe:.25}],["Sed de Luz","+3 Fe por acción",{rec:3}]],
 h1:{s:"h1",n:"Nova Solar",c:50,cd:3,k:"d",a:1,h:2,m:1,esc:.05,lh:.04,d:"2 explosiones solares en área (100% c/u), +5% daño por enemigo y cura 4% de vida máx por enemigo golpeado"},
 h2:{s:"h2",n:"Ascensión Radiante",c:60,cd:5,k:"b",t:12,dm:.35,rb:.1,pur:1,d:"12s: +35% daño, 10% robo de vida y purga el control"},
 m:[["Nova Abrasadora","Nova Solar +1 explosión",{h1h:1}],["Ascensión Eterna","Ascensión Radiante +30% poder",{h2p:.3}],["Pulso Radiante","Pulso Vital +50% daño y curación",{bp0:.5}]]}]
};
var _RN={};
function ramaNodos(r){
 if(_RN[r.n])return _RN[r.n];
 var N=[],i;
 [50,54,58].forEach(function(nv,k){N.push({id:r.n+"_t"+k,nv:nv,n:r.t[k][0],d:r.t[k][1],mods:r.t[k][2]});});
 N.push({id:r.n+"_h1",nv:60,n:r.h1.n,d:r.h1.d,sk:r.h1});
 POT_RAMA.forEach(function(p,k){N.push({id:r.n+"_p"+k,nv:p[0],n:p[1],d:p[2],mods:p[3]});});
 N.push({id:r.n+"_h2",nv:80,n:r.h2.n,d:r.h2.d,sk:r.h2});
 [85,90,100].forEach(function(nv,k){N.push({id:r.n+"_m"+k,nv:nv,n:r.m[k][0],d:r.m[k][1],mods:r.m[k][2]});});
 return(_RN[r.n]=N);
}
function talEst(j){if(!j.tal)j.tal={rama:null,act:[],almas:0};if(!j.tal.act)j.tal.act=[];return j.tal;}
function ramaAct(j){
 var T=j.tal;if(!T||!T.rama)return null;
 var R=RAMAS[j.clase]||[];
 for(var i=0;i<R.length;i++)if(R[i].n===T.rama)return R[i];
 return null;
}
function talRaw(j){
 var o={},r=ramaAct(j),T=j.tal;
 if(r)ramaNodos(r).forEach(function(n){if(n.mods&&T.act.indexOf(n.id)>=0)for(var k in n.mods)o[k]=(o[k]||0)+n.mods[k];});
 return o;
}
function talMods(j){
 var o=talRaw(j);
 return new Proxy(o,{get:function(t,k){return t[k]||0;}});
}

/* ---- Apoyo (Clérigo): curación, escudos y purga de control ---- */
/* multiplicador de curación y escudos: talento "cura" x maldición de curación */
function curaMult(j){return(1+talMods(j).cura)*factorMaldicion(j,"cura");}
/* los buffs de daño escalan solo a medias con la potencia (ENF) para no desbalancear */
function potBuff(st){return 1+(st.potencia-1)*.3;}

/* ---- Bonos de rama visibles (Stats y habilidades) ---- */
var TAL_LBL={dmg:["Daño","+%"],defp:["Defensa","+%"],crit:["Crítico","+%"],critU:["Crítico vs 1 objetivo","+%"],vel:["Vel. ataque","+%"],dr:["Daño recibido","-%"],ls:["Robo de vida","%"],regT:["Regeneración (vida/turno)","%"],rec:["Recurso por acción","n"],ig:["Ignora armadura","%"],slow:["Enemigos más lentos","-%"],dbl:["Probabilidad de doble golpe","%"],clone:["Daño del clon","+%"],aoe:["Daño en área","+%"],elite:["Daño a élites y jefes","+%"],exv:["Daño a enemigos <30% vida","+%"],fz:["Crítico vs congelado","+%"],oro:["Oro","+%"],loot:["Probabilidad de botín","+%"],sg:["Daño por sangrado/quemadura","+%"],stb:["Congelar/aturdir","+t"],durx:["Duración de bendiciones","+s"],cura:["Curación y escudos","+%"]};
function bonosRama(j){
 var R=talRaw(j),o=[];
 for(var k in TAL_LBL){var v=R[k];if(!v)continue;var l=TAL_LBL[k],t=l[1];
  o.push(l[0]+" "+(t==="n"?"+"+v:t==="+t"?"+"+v+" turno":t==="+s"?"+"+(v*2)+" s":(t.charAt(0)==="-"?"−":t.charAt(0)==="+"?"+":"")+Math.round(v*100)+"%"));}
 return o;
}
var HAB_LBL={p:"poder",cd:"enfriamiento",h:"golpes",st:"turnos de estado",sg:"daño extra",ig:"ignora defensa",ex:"ejecuta",ref:"reflejo",hp:"cura",sh:"escudo",nx:"disparos",cof:"cofres",oro:"oro"};
function habBonoTxt(j,sk){
 var R=talRaw(j),a=[],k=sk.s;
 for(var s in HAB_LBL){var v=R[k+s];if(!v)continue;
  a.push(s==="p"?"+"+Math.round(v*100)+"% poder":s==="cd"?"−"+v+" CD":s==="h"||s==="nx"||s==="st"||s==="cof"?"+"+v+" "+HAB_LBL[s]:Math.round(v*100)+"% "+HAB_LBL[s]);}
 return a.length?" ["+a.join(" · ")+"]":"";
}
function baseBonoTxt(j,idx){var v=talRaw(j)["bp"+idx];return v?" [+"+Math.round(v*100)+"% daño]":"";}
function gmGlob(j,idx){
 var M=talMods(j),b=j.tb,t=0;
 if(b){t=(b.dm||0);if(b.dpl)t+=b.dpl*Math.floor((1-j.vida/calcStats(j).vidaMax)*10);}
 return (1+t)*(1+M["bp"+idx]);
}
function marcaMuerta(j,e){
 var m=e.mk;
 for(var i=0;i<m.cof;i++)dropearLoot(e,j);
 if(m.orp){var o=Math.floor(e.oro*m.orp);j.oro+=o;G.log.push("  🎯 Marca: +"+o+" oro");}
 if(m.bf)j.tb={t:20,dm:m.bf.dm,acc:0};
}
/* Almas: solo desde el nivel 50, en exploración y modo aventura, hasta 10 pisos por debajo (15 y +20% en Extremo).
   - Jefes y mini-jefes SIEMPRE liberan almas y en mayor cantidad.
   - Enemigos normales: solo a veces (prob. base 35%, +0.25% por piso, tope 55%).
   - La cantidad crece ligeramente con el piso (x1.0 en piso 1 -> x1.6 en piso 70). */
var ALMAS_CFG={normal:{prob:.35,pPiso:.0025,tope:.55,min:1,max:3},mini_jefe:{prob:1,min:8,max:12},jefe:{prob:1,min:25,max:35},cantPiso:.009};
function cosechar(j,e){
 if(j.nivel<NIV_RAMA)return;
 var ext=(j.ciclo||0)>0,p=G.aventuraPiso||j.piso;
 if(p<j.piso-(ext?15:10))return;
 var c=ALMAS_CFG[e.tipo]||ALMAS_CFG.normal;
 var prob=c.tope?Math.min(c.tope,c.prob+p*c.pPiso):c.prob;
 if(Math.random()>=prob)return;
 var b=rnd(c.min,c.max)*(1+p*ALMAS_CFG.cantPiso),n=redond(ext?b*1.2:b);
 if(n<1)return;
 talEst(j).almas+=n;
 G.log.push("  👻 "+(e.tipo==="jefe"?"¡El jefe libera ":(e.tipo==="mini_jefe"?"El mini jefe libera ":"+"))+n+" alma"+(n>1?"s":"")+(e.tipo==="jefe"||e.tipo==="mini_jefe"?"!":""));
}
