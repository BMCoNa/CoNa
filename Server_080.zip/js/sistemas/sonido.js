"use strict";
/* THE CHRONICLES OF NARADAK — sonido
   Efectos: clic, compra, venta, victoria, huida, derrota, nivel.
   Música: "pueblo" (ciudad, tienda, gremio, herrería, alquimista, hospital, castillo) y "taberna".
   Archivos en assets/audio/ (.ogg con respaldo .mp3). */
var Sonido=(function(){
 var EXT=(function(){try{var a=new Audio();return a.canPlayType('audio/ogg; codecs="vorbis"')?"ogg":"mp3";}catch(e){return "mp3";}})();
 /* Ruta de audio relativa a este script (funciona desde index.html y desde tilemap/*.html) */
 var DIR=(function(){try{var s=document.currentScript&&document.currentScript.src;if(s)return s.replace(/js\/sistemas\/sonido\.js.*$/,"assets/audio/");}catch(e){}return "assets/audio/";})();
 var mudo=false;   /* el audio siempre suena: sin botón de mudo */
 var VOL={clic:0.45,compra:0.7,venta:0.7,victoria:0.8,derrota:0.8,huida:0.7,nivel:0.8};
 var NOMBRES=["clic","compra","venta","victoria","derrota","huida","nivel"];
 var base={};

 /* ---------- Web Audio (efectos): baja latencia y fiable en WebView/iOS; se desbloquea en el primer gesto ---------- */
 var CTX=null,buf={},pend={},desbloq=false;
 function ctx(){
  if(CTX)return CTX;
  try{var C=window.AudioContext||window.webkitAudioContext;if(C)CTX=new C();}catch(e){CTX=null;}
  return CTX;
 }
 function cargarBuf(n){
  if(buf[n]!==undefined||pend[n]||!CTX)return;
  pend[n]=1;
  try{
   var x=new XMLHttpRequest();x.open("GET",DIR+n+"."+EXT);x.responseType="arraybuffer";
   x.onload=function(){
    var ko=function(){buf[n]=0;pend[n]=0;};
    if(x.status<200||x.status>=300||!x.response)return ko();
    try{var pr=CTX.decodeAudioData(x.response,function(b){buf[n]=b;pend[n]=0;},ko);if(pr&&pr.catch)pr.catch(ko);}catch(e){ko();}
   };
   x.onerror=function(){buf[n]=0;pend[n]=0;};
   x.send();
  }catch(e){buf[n]=0;pend[n]=0;}
 }
 function desbloquear(){
  var c=ctx();if(!c)return;
  try{
   if(c.state!=="running"&&c.resume){var r=c.resume();if(r&&r.catch)r.catch(function(){});}
   if(!desbloq){
    desbloq=true;
    var s=c.createBufferSource();s.buffer=c.createBuffer(1,1,22050);s.connect(c.destination);s.start(0);
    NOMBRES.forEach(cargarBuf);
   }
  }catch(e){}
 }
 ["pointerdown","touchstart","touchend","mousedown","click","keydown"].forEach(function(ev){
  try{document.addEventListener(ev,desbloquear,true);}catch(e){}
 });

 /* ---------- respaldo con <audio> ---------- */
 function cargar(n){
  if(base[n])return base[n];
  var a=new Audio();a.preload="auto";a.src=DIR+n+"."+EXT;base[n]=a;return a;
 }
 function playHtml(n){
  try{
   var b=cargar(n),a=b.cloneNode();a.volume=VOL[n];
   var p=a.play();if(p&&p.catch)p.catch(function(){});
  }catch(e){}
 }
 function play(n){
  if(mudo||!VOL[n])return;
  desbloquear();
  var c=CTX;
  if(c&&c.state==="running"&&buf[n]){
   try{
    var s=c.createBufferSource(),g=c.createGain();
    s.buffer=buf[n];g.gain.value=VOL[n];s.connect(g);g.connect(c.destination);s.start(0);
    return;
   }catch(e){}
  }
  playHtml(n);
 }
 NOMBRES.forEach(function(n){try{cargar(n);}catch(e){}});

 /* ---------- música (solo en la ventana principal) ---------- */
 /* El volumen se lleva en a._v (en iOS <audio>.volume es de solo lectura y siempre vale 1) */
 var MUS_VOL=0.32,PASO=0.035,mus={},errT={};
 var PUEBLO={city:1,gremint:1,herint:1,hospint:1,alqint:1,tienint:1,castint:1,entint:1,muint:1,oakint:1,mundoint:1,conectando:1,shop:1,gremio:1,herreria:1,alquimista:1,hospital:1,aventura:1,infinita:1,laberinto:1};
 var TABERNA={tabint:1,taberna:1};
 function pista(){
  if(typeof G==="undefined"||!G||!G.j)return null;
  if(PUEBLO[G.screen])return "pueblo";
  if(TABERNA[G.screen])return "taberna";
  return null;
 }
 function musica(n){
  if(mus[n])return mus[n];
  var a=new Audio();a.loop=true;a.preload="auto";a._v=0;a.volume=0;a.src=DIR+n+"."+EXT;mus[n]=a;return a;
 }
 function vol(a,v){a._v=v;try{a.volume=v;}catch(e){}}
 function tick(){
  var want=document.hidden?null:pista();
  ["pueblo","taberna"].forEach(function(n){
   var a=mus[n];
   if(n===want&&!mudo){
    a=musica(n);
    if(a.error){   /* archivo no cargado: reintenta cada 3 s */
     var ahora=Date.now();
     if(!errT[n]||ahora-errT[n]>3000){errT[n]=ahora;try{a.load();}catch(e){}}
     return;
    }
    if(a.paused){var p=a.play();if(p&&p.catch)p.catch(function(){});}
    vol(a,Math.min(MUS_VOL,a._v+PASO));
   }else if(a){
    var v=Math.max(0,a._v-PASO*(document.hidden||mudo?4:1));vol(a,v);
    if(v<=0&&!a.paused)a.pause();
   }
  });
 }
 if(window===window.top){
  setInterval(tick,100);
  document.addEventListener("visibilitychange",tick);
 }
 return {play:play,desbloquear:desbloquear,esMudo:function(){return false;}};
})();

(function(){
 var COMPRA=".buyItem,.buyPoc,.buyMisc,.forjarBtn,.craftearBtn,.mejorarBtn,.transmutarBtn";
 var VENTA=".sellEq,.sellMat,.sellPoc,.venderMat";
 var GENERICO="button,.btn,.classcard";
 document.addEventListener("click",function(ev){
  var t=ev.target;if(!t||!t.closest)return;
  if(t.closest(COMPRA)){Sonido.play("compra");return;}
  if(t.closest(VENTA)){Sonido.play("venta");return;}
  if(t.closest("#bHuir")){
   setTimeout(function(){if(typeof G!=="undefined"&&G.screen==="hub")Sonido.play("huida");},0);
   return;
  }
  if(t.closest(GENERICO))Sonido.play("clic");
 },true);

 function envolver(nombre,fn){
  var o=window[nombre];if(typeof o!=="function")return;
  window[nombre]=function(){var r=o.apply(this,arguments);try{fn.apply(this,arguments);}catch(e){}return r;};
 }
 envolver("finCombateVictoria",function(){Sonido.play("victoria");});
 envolver("finCombateMuerte",function(){Sonido.play("derrota");});
 if(typeof window.ganarXP==="function"){
  var gx=window.ganarXP;
  window.ganarXP=function(j,cant){
   var n0=j.nivel,r=gx.apply(this,arguments);
   try{if(j.nivel>n0)Sonido.play("nivel");}catch(e){}
   return r;
  };
 }

})();
