"use strict";
/* ============================================================
   DEMO — COMBATE EN TIEMPO REAL 2.5D (isométrico, mapa tipo Campo de Entrenamiento)
   Módulo independiente: no modifica G ni guarda partida.
   Reutiliza: CLASES, HABILIDADES, calcStats, danoMitigado, generarOleada,
   velJugador/velEnemigo, especiales de enemigos (danos.js), gmGlob, costoHab.
   Ajustes de balance rápidos: objeto TUNE. Personajes jugables: ROSTER. Mapas: MAPAS.
   Carga bajo demanda (al abrir el demo): tilemap/js/chars.js y tilemap/js/entrenamiento_assets.js.
   ============================================================ */
(function(){
var CS=32,W=960,H=704,VW=1152,VH=648,Z=1.5,TW=32,TH=16,WH=150; /* CS=unidades por celda · W,H=tamaño del mapa activo · VW,VH=lienzo · Z=zoom */
var TUNE={
 enemyDmg:1,        /* multiplicador de daño enemigo */
 enemyIntF:.5,      /* intervalo de ataque enemigo = (2s/vel) x este factor */
 playerAtkF:.35,    /* intervalo de ataque jugador = (2s/vel) x este factor */
 regen:.02,         /* % recurso máx por segundo */
 hitGain:.015,      /* % recurso máx por golpe básico */
 trampas:1,         /* multiplicador de daño de las trampas de la mazmorra (0 = sin daño de trampas) */
 pots:3, potCd:4,
 dodgeCd:1.1, dodgeDist:150, dodgeInv:.3
};
var CFG={pj:0,rama:"",ciclo:0,nivel:1,piso:1,oleadas:3,modo:"oleadas",mapa:"campo",usarSave:false,mz:false,inf:false};
/* ---------- Personajes jugables ----------
   sp = índice del sprite en tilemap/js/chars.js · clase = clase de combate (stats/habilidades de CLASES/HABILIDADES)
   mod = multiplicadores sobre las stats de la clase: hp vida · dmg daño · mov velocidad de movimiento · spd velocidad de ataque */
var ROSTER=[
 {n:"Brann",   clase:"Guerrero",sp:56,mod:{hp:1.10,dmg:1.00,mov:.97, spd:1.00}},
 {n:"Valeria", clase:"Guerrero",sp:81,mod:{hp:.95, dmg:1.10,mov:1.03,spd:1.00}},
 {n:"Gideon",  clase:"Paladin", sp:61,mod:{hp:1.12,dmg:.95, mov:.95, spd:1.00}},
 {n:"Aurelia", clase:"Paladin", sp:80,mod:{hp:1.00,dmg:1.05,mov:1.00,spd:1.05}},
 {n:"Lyra",    clase:"Arquero", sp:72,mod:{hp:1.00,dmg:1.00,mov:1.08,spd:1.05}},
 {n:"Taren",   clase:"Arquero", sp:75,mod:{hp:1.05,dmg:1.10,mov:.98, spd:.95}},
 {n:"Nyx",     clase:"Asesino", sp:48,mod:{hp:.95, dmg:1.00,mov:1.10,spd:1.08}},
 {n:"Zephyr",  clase:"Asesino", sp:73,mod:{hp:1.00,dmg:1.12,mov:1.04,spd:1.00}},
 {n:"Ignis",   clase:"Mago",    sp:76,mod:{hp:.95, dmg:1.12,mov:1.00,spd:1.00}},
 {n:"Morgana", clase:"Mago",    sp:77,mod:{hp:1.05,dmg:1.00,mov:1.05,spd:1.05}},
 {n:"Seraphine",clase:"Clérigo", sp:74,mod:{hp:1.05,dmg:.95, mov:1.00,spd:1.00}},
 {n:"Elara",   clase:"Clérigo", sp:83,mod:{hp:.95, dmg:1.08,mov:1.04,spd:1.00}}
];
var MOD_TXT={hp:"Vida",dmg:"Daño",mov:"Movim.",spd:"Vel. ataque"};
function modTxt(m){var a=[];for(var k in MOD_TXT){var v=Math.round((m[k]-1)*100);if(v)a.push(MOD_TXT[k]+" "+(v>0?"+":"−")+Math.abs(v)+"%");}return a.join(" · ")||"Equilibrado";}
/* sprite de "Usar mi personaje": el elegido en el mapa del pueblo (naradak_pc) o, si no hay, el primero de su clase */
function spPropio(clase){
 try{var v=parseInt(localStorage.getItem("naradak_pc"),10);if(v>=0&&v<CHARS.length&&CHARS_INFO[v].k==="humano")return v;}catch(e){}
 var r=ROSTER.filter(function(x){return x.clase===clase;})[0];return r?r.sp:56;
}
/* ---------- Mapas (2.5D isométrico) ----------
   ob = obstáculos rectangulares en unidades de mundo {x,y,w,h,alto}: alto=true bloquea paso y proyectiles; false solo el paso.
   props = sprites (k=clave de ENTASSETS, x,y=pie en unidades de mundo, s=escala). 1 celda = CS unidades. */
function mapaCampo(){
 var ob=[],pr=[],MQ=["maniqui1","armadura1","maniqui2","espantapajaros","armadura2"];
 function rc(b,alto){ob.push({x:b[0]*CS,y:b[1]*CS,w:(b[2]-b[0]+1)*CS,h:(b[3]-b[1]+1)*CS,alto:!!alto});}
 function put(k,x,y,s,b,alto,mir){pr.push({k:k,x:x*CS,y:y*CS,s:s,mir:!!mir,dy:0});if(b)rc(b,alto);}
 /* Zona de Combate (x 1..14): maniquíes (bloquean proyectiles), bloques de práctica, banco de trabajo */
 var mq=[[3,3],[7,3],[11,3],[5,7],[9,7]];
 mq.forEach(function(p,i){put(MQ[i%MQ.length],p[0]+.5,p[1]+.5,1.3,[p[0],p[1],p[0],p[1]],true);});
 [2.6,5.6,8.2].forEach(function(yy,i){put(i%2?"armero2":"armero1",.85,yy,1.35,[0,Math.floor(yy),0,Math.floor(yy)],false);});
 put("tiro",2.5,10.5,1.2,[2,10,2,10]);put("tiro",13.5,10.5,1.2,[13,10,13,10]);
 put("fardo2",13.6,2.6,1.1,[13,2,13,4]);put("fardo2",13.6,4.1,1.1);put("paja",13.4,13.4,1.05,[13,13,13,13]);
 put("mesa_trab",5.0,16.6,1.3,[4,16,5,16]);put("yunque",6.7,16.4,1.2);
 put("banco",11.0,17.4,1.2,[10,17,11,17]);put("barril",12.8,16.8,1.2,[12,16,12,16]);put("caja",13.2,18.6,1.1,[13,18,13,18]);
 put("e_barril1",11.9,20.0,.9,[11,20,11,20]);put("e_banco",5.6,20.6,1.0,[4,20,5,20]);
 /* Divisoria de vallas con portón central (filas 9..12) */
 [1.5,4.5,7.5,14.5,17.5,20.5].forEach(function(yy){put("e_valla",15.5,yy+.4,1.05,[15,Math.floor(yy-1.4),15,Math.min(21,Math.floor(yy+1.4))],false,true);});
 put("pilar_farol",15.5,8.9,.8);put("pilar_farol",15.5,13.2,.8);
 /* Zona de Arquería (x 16..29): 6 carriles, dianas lejanas (fila 2) y medias (fila 8) */
 var LN=[17.5,19.5,21.5,23.5,25.5,27.5];
 rc([16,0,29,1],false);
 LN.forEach(function(xx,i){var fx=Math.floor(xx);
  put("fardo2",xx,1.1,1.15);
  put(i%2?"diana2":"diana1",xx,2.3,1.5,[fx,2,fx,2],true);
  if(i%2){put(i%4===1?"diana1":"diana2",xx,8.4,1.45,[fx,8,fx,8],true);put("fardo2",xx+.05,9.3,.8);}
 });
 put("e_banco",18.5,16.2,1.0,[17,16,18,16]);put("e_banco",26.0,16.2,1.0,[25,16,26,16]);
 put("e_mesa",20.6,19.6,1.0,[19,19,21,19]);put("e_barril1",16.7,19.4,.9,[16,19,16,19]);put("e_caja",28.6,16.2,.85);
 put("e_puesto",27.3,20.4,1.0,[26,20,28,20]);put("e_librero",24.9,20.6,.95,[24,20,24,20]);put("armero2",16.9,16.1,1.3,[16,16,16,16]);
 put("pilar_farol",1.3,20.7,.8);put("pilar_farol",28.8,20.7,.8);put("pilar_farol",15.5,1.4,.8);put("pilar_farol",15.5,20.6,.8);
 return{id:"campo",nombre:"Campo de entrenamiento",cw:30,ch:22,ob:ob,props:pr,inicio:{x:9*CS,y:14.5*CS},
  dummies:[[6.5*CS,11*CS,-1],[9*CS,11*CS,0],[11.5*CS,11*CS,1]],
  lamps:[[15.5,9],[15.5,13.4],[1.3,20.7],[28.8,20.7],[15.5,1.4],[15.5,20.6]],mq:mq,lanes:LN};
}
function mapaArena(){
 var pr=[[1.3,14.7],[20.7,14.7],[1.3,1.6],[20.7,1.6]].map(function(p){return{k:"pilar_farol",x:p[0]*CS,y:p[1]*CS,s:.8,dy:0,mir:false};});
 return{id:"arena",nombre:"Arena abierta",cw:22,ch:16,ob:[],props:pr,inicio:{x:11*CS,y:11*CS},dummies:[[11*CS,6*CS,0]],
  lamps:[[1.3,14.7],[20.7,14.7],[1.3,1.6],[20.7,1.6]]};
}
var MAPAS={campo:mapaCampo(),arena:mapaArena()};
/* ---------- MAZMORRA: mapas 2.5D de piedra (Explorar Mazmorra) ----------
   Mapas por piso (pisos 6-9 repiten A/B hasta tener sus propios mapas; los mapas de jefe son distintos):
     mazA    Cripta de las Antorchas   → pisos 1, 3
     mazB    Galería de las Celdas     → pisos 2, 4
     mazC    Osario Olvidado           → pisos 6, 8
     mazD    Cámara de los Tormentos   → pisos 7, 9
     mazE    Biblioteca Maldita        → pisos impares de las decenas 11-19, 31-39, 51-59 (no jefe)
     mazF    Mina Colapsada            → pisos pares de las decenas 11-19, 31-39, 51-59 (no jefe)
     mazJefe Santuario del Guardián    → piso 5 (mini-jefe) y, por ahora, piso 10 (jefe)
   Para añadir mapas: crear un mapaMazX() y registrarlo en MAPAS; luego elegirlo en mazMapaDe().
   Trampas: M.tr(tipo,x,y,ancho,alto,{ph}) en cada mapa (tipos y balance en TRD / TUNE.trampas, más abajo). */
var MZ_OLEADAS=3; /* oleadas por piso normal (pisos 5/10 = 1 oleada con jefe · Extremo = 5 oleadas) */
function mazMapaDe(piso){
 var b=MZ_BIOMAS[Math.min(7,Math.floor((piso-1)/10)+1)]||MZ_BIOMAS[1],pe=piso%10||10;
 if(pe===5)return b.j5;if(pe===10)return b.j10;
 return b.n[(pe-1)%b.n.length];
}
function mazBase(id,nombre,cw,ch,ini,sd){
 var M={id:id,nombre:nombre,tema:"mazmorra",cw:cw,ch:ch,ob:[],props:[],lamps:[],inicio:{x:ini[0]*CS,y:ini[1]*CS},oscuro:.26,seed:sd,
  dummies:[[cw*.42*CS,ch*.5*CS,-1],[cw*.5*CS,ch*.5*CS,0],[cw*.58*CS,ch*.5*CS,1]],torN:[],torW:[],estN:[],alf:[],charcos:[],runas:[],celdas:[],trampas:[],pal:null,boss:false};
 /* rc: rectángulo de celdas [x0,y0,x1,y1] · alto=true también frena proyectiles */
 M.rc=function(b,alto){M.ob.push({x:b[0]*CS,y:b[1]*CS,w:(b[2]-b[0]+1)*CS,h:(b[3]-b[1]+1)*CS,alto:!!alto});};
 M.pil=function(cx,cy,o){M.props.push(Object.assign({d:"pilar",x:(cx+.5)*CS,y:(cy+.5)*CS,w:26,h:26,z:104},o||{}));M.rc([cx,cy,cx,cy],true);};
 M.spr=function(k,x,y,s,b,alto,mir){M.props.push({k:k,x:x*CS,y:y*CS,s:s,mir:!!mir,dy:0});if(b)M.rc(b,alto);};
 M.dec=function(d,x,y,o){M.props.push(Object.assign({d:d,x:x*CS,y:y*CS},o||{}));};
 /* blk: bloque de celdas (cx,cy = esquina; wc,hc = tamaño en celdas) con colisión */
 M.blk=function(d,cx,cy,wc,hc,alto,o){M.props.push(Object.assign({d:d,x:(cx+wc/2)*CS,y:(cy+hc/2)*CS,w:wc*CS-4,h:hc*CS-4},o||{}));M.rc([cx,cy,cx+wc-1,cy+hc-1],alto);};
 M.bra=function(x,y,col){M.props.push({d:"brasero",x:x*CS,y:y*CS});M.rc([Math.floor(x),Math.floor(y),Math.floor(x),Math.floor(y)],false);M.lamps.push([x,y,40,col||"255,150,60"]);};
 M.tN=function(x,col){M.torN.push(x);M.lamps.push([x,.5,78,col||"255,170,70"]);};
 M.tW=function(y,col){M.torW.push(y);M.lamps.push([.5,y,78,col||"255,170,70"]);};
 /* tr: trampa en celdas (tipo, x, y, ancho, alto, opciones). Tipos: pinchos · llamas · glifo · veneno (ver TRD). ph = desfase del ciclo (s) */
 M.tr=function(t,cx,cy,wc,hc,o){M.trampas.push(Object.assign({t:t,x:cx*CS,y:cy*CS,w:wc*CS,h:hc*CS},o||{}));};
 return M;
}
function mapaMazA(){
 var M=mazBase("mazA","Cripta de las Antorchas",26,18,[2.6,14.8],1717);
 M.alf=[[1,8.2,24,1.6]];
 M.charcos=[[7,10.4,1,.55],[17.5,6.6,.9,.5],[4.5,12.5,.7,.4]];
 /* pilares: dos filas de cuatro */
 [5,10,15,20].forEach(function(x){M.pil(x,4,x===10?{roto:true,z:62}:null);M.pil(x,13,x===15?{roto:true,z:62}:null);});
 /* altar central rodeable */
 M.blk("altar",12,8,2,2,false,{col:"150,90,255"});
 /* sarcófagos contra el muro norte */
 [2,8,16,22].forEach(function(x){M.blk("sarcofago",x,1,2,1,false);});
 /* provisiones en la esquina sureste */
 M.spr("caja",24.4,15.5,1.1,[24,15,24,15],false);M.spr("barril",23.4,16.5,1.2,[23,16,23,16],false);M.spr("e_barril1",24.5,16.7,.9,[24,16,24,16],false);M.spr("e_caja",22.9,15.4,.85);
 M.bra(2,8.5);M.bra(23.5,8.5);M.bra(8,16.3);M.bra(17,16.3);
 [3,9,16,22].forEach(function(x){M.tN(x);});[5,10].forEach(function(y){M.tW(y);});
 M.estN=[6.2,13,19.4];
 [[4,11],[14,15.2],[21,10.5],[9,2.9],[18.5,7.5],[11,12]].forEach(function(p){M.dec("huesos",p[0],p[1],{s:1});});
 [[3.5,5.4],[22,12.4],[12.5,15.6]].forEach(function(p,i){M.dec("escombros",p[0],p[1],{pz:mazPiezas(40+i)});});
 /* trampas */
 M.tr("pinchos",7,6,3,2,{ph:0});M.tr("pinchos",16,6,3,2,{ph:2.1});
 M.tr("glifo",8,10,2,2);M.tr("glifo",19,8,2,2);
 M.tr("llamas",12,2,1,3,{ph:1.5});
 M.tr("veneno",3,5,3,2);M.tr("veneno",21,10,3,2);
 return M;
}
function mapaMazB(){
 var M=mazBase("mazB","Galería de las Celdas",28,18,[2.6,14.8],2828);
 M.charcos=[[11,10.6,1,.55],[18,11.5,.8,.45],[5,6.5,.8,.45],[23,6.5,.7,.4]];
 /* cuatro celdas con rejas contra el muro norte (interior inaccesible) */
 [2,8,15,21].forEach(function(x){
  M.celdas.push([x,0,4,3]);
  M.rc([x,0,x+3,2],false);
  M.props.push({d:"reja",x:(x+2)*CS,y:2.95*CS,w:4*CS});
  M.dec("huesos",x+1,1.3,{s:.9});M.dec("huesos",x+3,2.1,{s:.8});
 });
 /* mesa de interrogatorio al centro */
 M.blk("mesa",12,8,4,1,false);
 [[7,7],[20,7],[7,13],[20,13]].forEach(function(p,i){M.pil(p[0],p[1],i===1?{roto:true,z:62}:null);});
 M.spr("caja",25.4,15.5,1.1,[25,15,25,15],false);M.spr("caja",26.4,15.5,1.1,[26,15,26,15],false);M.spr("barril",25.4,16.7,1.2,[25,16,25,16],false);M.spr("e_barril1",23.5,16.6,.9,[23,16,23,16],false);
 M.bra(1.5,9);M.bra(26,9);M.bra(11,16.3);M.bra(16,16.3);
 [6.5,13,19.5,26].forEach(function(x){M.tN(x);});[4,9].forEach(function(y){M.tW(y);});
 [[4,13],[24,5.4],[14,15.4],[10,12],[19,9.8]].forEach(function(p){M.dec("huesos",p[0],p[1],{s:1});});
 [[3,12.4],[25,7],[13.5,5.6]].forEach(function(p,i){M.dec("escombros",p[0],p[1],{pz:mazPiezas(60+i)});});
 /* trampas */
 M.tr("pinchos",8,4,3,2,{ph:0});M.tr("pinchos",17,4,3,2,{ph:2.2});M.tr("pinchos",13,11,2,2,{ph:1.1});
 M.tr("llamas",3,10,5,1,{ph:0,per:6.5});M.tr("llamas",20,10,5,1,{ph:3.2,per:6.5});
 M.tr("glifo",5,5,2,2);M.tr("glifo",22,13,2,2);
 M.tr("veneno",23,4,3,2);M.tr("veneno",2,6,3,2);
 return M;
}
function mapaMazC(){
 var M=mazBase("mazC","Osario Olvidado",28,20,[2.6,16.8],3939),VERDE="120,220,170";
 M.oscuro=.31;
 M.pal=["#4e5350","#474c4a","#555a57","#41464a","#4b5052"];
 M.charcos=[[8,10.6,1,.55],[19,15,.8,.45],[4.5,7,.7,.4],[23.5,11.5,.6,.35]];
 /* hilera de sarcófagos contra el muro norte (hueco central libre bajo la placa) */
 [2,5,8,18,21,24].forEach(function(x){M.blk("sarcofago",x,1,2,1,false);});
 /* fosa-osario central con resplandor verdoso, rodeable */
 M.blk("altar",13,9,2,2,false,{col:VERDE});
 /* cuatro pilares (uno roto) */
 [[6,6,0],[21,6,0],[6,13,0],[21,13,1]].forEach(function(p){M.pil(p[0],p[1],p[2]?{roto:true,z:62}:null);});
 /* sarcófagos laterales como cobertura */
 M.blk("sarcofago",3,9,2,1,false);M.blk("sarcofago",23,9,2,1,false);
 /* provisiones abandonadas en la esquina sureste */
 M.spr("caja",25.4,16.5,1.1,[25,16,25,16],false);M.spr("barril",26.4,17.5,1.2,[26,17,26,17],false);M.spr("e_barril1",24.4,17.6,.9,[24,17,24,17],false);
 M.bra(1.8,6.5,VERDE);M.bra(26,6.5,VERDE);M.bra(9,17,VERDE);M.bra(19,17,VERDE);M.bra(14,3.6,VERDE);
 [3.5,9.5,18.5,24.5].forEach(function(x){M.tN(x,"150,230,200");});[5,10].forEach(function(y){M.tW(y,"150,230,200");});
 M.estN=[6.8,21.2];
 [[4,12],[10,13.4],[17.5,12.8],[12,6.6],[16.5,6.2],[22,10.5],[7.5,3.4],[26,13],[14,16],[3.8,15]].forEach(function(p,i){M.dec("huesos",p[0],p[1],{s:.95+(i%3)*.08});});
 [[4.2,5.2],[23.5,5],[11.5,15.2],[17.8,9.5],[25,12.4]].forEach(function(p,i){M.dec("escombros",p[0],p[1],{pz:mazPiezas(100+i)});});
 /* trampas */
 M.tr("veneno",8,8,3,3);M.tr("veneno",18,8,3,3);
 M.tr("pinchos",10,5,2,2,{ph:0});M.tr("pinchos",17,5,2,2,{ph:2.1});M.tr("pinchos",13,13,2,2,{ph:1.2});
 M.tr("llamas",4,7,4,1,{ph:0});M.tr("llamas",20,15,4,1,{ph:3});
 M.tr("glifo",5,11,2,2);M.tr("glifo",22,3,2,2);
 return M;
}
function mapaMazD(){
 var M=mazBase("mazD","Cámara de los Tormentos",28,20,[2.6,16.8],4747),FUEGO="255,120,50";
 M.oscuro=.27;
 M.pal=["#575055","#4f484e","#5d565b","#494147","#554d52"];
 M.charcos=[[7,12,.8,.45],[20.5,5.8,.7,.4],[15.5,14.8,.9,.5]];
 /* alfombra raída que baja por el centro */
 M.alf=[[12.5,2,3,5.4]];
 /* cuatro mesas de tormento con grilletes */
 [[3,4],[21,4],[3,9],[22,9]].forEach(function(p){M.blk("mesa",p[0],p[1],4,1,false);});
 /* pira central y cuatro pilares (uno roto) */
 M.blk("altar",13,9,2,2,false,{col:FUEGO});
 [[9,6,0],[18,6,0],[9,13,0],[18,13,1]].forEach(function(p){M.pil(p[0],p[1],p[2]?{roto:true,z:62}:null);});
 /* dos jaulas con rejas hacia el sur (interior inaccesible) */
 [[22,14,5,3],[11,15,4,3]].forEach(function(c,i){
  M.celdas.push(c);
  M.rc([c[0],c[1],c[0]+c[2]-1,c[1]+c[3]-1],false);
  M.props.push({d:"reja",x:(c[0]+c[2]/2)*CS,y:(c[1]+c[3]-.05)*CS,w:c[2]*CS});
  M.dec("huesos",c[0]+1.2,c[1]+1.3,{s:.9});M.dec("huesos",c[0]+c[2]-1.2,c[1]+c[3]-1,{s:.8});
 });
 M.spr("caja",26.3,1.8,1.1,[26,1,26,1],false);M.spr("barril",25.3,1.9,1.2,[25,1,25,1],false);
 M.bra(1.8,7,FUEGO);M.bra(26,7,FUEGO);M.bra(7,17.2,FUEGO);M.bra(17.5,17.2,FUEGO);M.bra(11.2,9.8,FUEGO);M.bra(16.8,9.8,FUEGO);
 [3,10,17,24].forEach(function(x){M.tN(x,"255,140,60");});[5,10].forEach(function(y){M.tW(y,"255,140,60");});
 M.estN=[6.6,21.4];
 [[6,8],[11,5.2],[17,11.8],[24,7],[8,15.2],[20,15.6],[14,12.4],[4.4,12.6]].forEach(function(p,i){M.dec("huesos",p[0],p[1],{s:.9+(i%3)*.08});});
 [[5.6,6.6],[22.5,7],[13.6,5.6],[7,11.8],[18.5,17.4]].forEach(function(p,i){M.dec("escombros",p[0],p[1],{pz:mazPiezas(120+i)});});
 /* trampas */
 M.tr("llamas",12,2,1,4,{ph:0});M.tr("llamas",15,2,1,4,{ph:3});
 M.tr("llamas",6,12,4,1,{ph:1.5});M.tr("llamas",19,12,5,1,{ph:4.5});
 M.tr("pinchos",8,10,2,2,{ph:0});M.tr("pinchos",19,10,2,2,{ph:2.1});M.tr("pinchos",19,15,2,2,{ph:1.1});
 M.tr("glifo",8,2,2,2);M.tr("glifo",18,2,2,2);
 return M;
}
function mapaMazE(){
 var M=mazBase("mazE","Biblioteca Maldita",28,20,[2.6,16.8],5757),VIO="170,130,255";
 M.oscuro=.30;
 M.pal=["#524e5c","#4b4756","#59556a","#454150","#4f4b5d"];
 M.alf=[[10.5,15,7,3.2]];
 M.charcos=[[5,8,.8,.45],[22.5,8,.7,.4],[19.5,16.5,.8,.45]];
 /* estanterías: dos hileras contra el muro norte y dos pasillos de lectura */
 function est(x0,x1,y){for(var x=x0;x<=x1;x++)M.spr("e_librero",x+.5,y+.72,.95,[x,y,x,y],true);}
 est(2,9,1);est(18,25,1);
 est(6,10,6);est(17,21,6);est(7,10,13);est(17,20,13);
 /* mesas de lectura y pedestal del grimorio central */
 M.blk("mesa",7,9,3,1,false);M.blk("mesa",18,9,3,1,false);
 M.blk("altar",13,9,2,2,false,{col:VIO});
 [[3,9,0],[24,9,1]].forEach(function(p){M.pil(p[0],p[1],p[2]?{roto:true,z:62}:null);});
 /* cajas de libros en la esquina sureste */
 M.spr("caja",25.4,16.5,1.1,[25,16,25,16],false);M.spr("barril",26.4,17.5,1.2,[26,17,26,17],false);M.spr("e_caja",24.2,17.6,.85);
 M.bra(1.8,5,VIO);M.bra(26,5,VIO);M.bra(9.5,17.5,VIO);M.bra(18.5,17.5,VIO);
 [4,9.5,18.5,24].forEach(function(x){M.tN(x,"190,160,255");});[4,9].forEach(function(y){M.tW(y,"190,160,255");});
 M.estN=[6.6,21.4];
 [[4,7.5],[12,5],[16,4.6],[22,12],[11,14.8],[26,10],[8,16.4],[14,12.6]].forEach(function(p,i){M.dec("huesos",p[0],p[1],{s:.9+(i%3)*.07});});
 [[3.6,14],[24,4.2],[13.5,7.2],[20.5,15.4]].forEach(function(p,i){M.dec("escombros",p[0],p[1],{pz:mazPiezas(140+i)});});
 /* trampas: glifos arcanos, fuego entre estanterías y pinchos */
 M.tr("glifo",12,3,2,2);M.tr("glifo",3,11,2,2);M.tr("glifo",23,11,2,2);M.tr("glifo",10,16,2,2);
 M.tr("llamas",11,6,6,1,{ph:0});M.tr("llamas",11,13,6,1,{ph:3});
 M.tr("pinchos",5,3,3,2,{ph:0});M.tr("pinchos",20,3,3,2,{ph:2.1});M.tr("pinchos",13,11,2,2,{ph:1.2});
 return M;
}
function mapaMazF(){
 var M=mazBase("mazF","Mina Colapsada",28,20,[2.6,16.8],6868);
 M.oscuro=.34;
 M.pal=["#5b524a","#544b44","#625850","#4c443e","#58504a"];
 M.charcos=[[7,6,.9,.5],[15,15.5,.8,.45],[24.5,9,.6,.35]];
 /* derrumbes: dos barricadas de escombros que forman un zigzag (cubren proyectiles) */
 function roca(cx,cy,i){
  [[.3,.5],[.7,.8]].forEach(function(o,k){M.dec("escombros",cx+o[0],cy+o[1],{pz:mazPiezas(160+i*2+k).map(function(q){return{dx:q.dx*1.3,dy:q.dy*1.3,w:q.w*1.8,h:q.h,z:q.z*2.3,t:q.t};})});});
  M.rc([cx,cy,cx,cy],true);
 }
 for(var y=3;y<=9;y++)roca(9,y,y);
 for(var y2=10;y2<=16;y2++)roca(18,y2,y2+10);
 /* puntales de piedra y horno abandonado */
 [[5,4,0],[13,7,1],[14,14,0],[23,6,0]].forEach(function(p){M.pil(p[0],p[1],p[2]?{roto:true,z:62}:null);});
 M.blk("altar",13,10,2,2,false,{col:"255,150,50"});
 M.blk("mesa",21,15,3,1,false);
 /* vagoneta y cajas en la esquina noreste */
 M.spr("caja",25.4,2.6,1.1,[25,2,25,2],false);M.spr("barril",26.4,3.7,1.2,[26,3,26,3],false);M.spr("e_caja",24.2,3.5,.85);
 M.bra(2,8,"255,160,60");M.bra(26,9,"255,160,60");M.bra(10.5,17.3,"255,160,60");M.bra(21,2.6,"255,160,60");
 [4,10.5,17,24].forEach(function(x){M.tN(x,"255,160,70");});[5,10].forEach(function(y){M.tW(y,"255,160,70");});
 M.estN=[7,20.5];
 [[4,11],[12,4.4],[15,9.6],[20.5,12],[7,14.4],[24,13.4],[16,18],[11,8]].forEach(function(p,i){M.dec("huesos",p[0],p[1],{s:.9+(i%3)*.07});});
 [[3.6,6.4],[22,9.6],[12.2,15.6],[26,16.4]].forEach(function(p,i){M.dec("escombros",p[0],p[1],{pz:mazPiezas(180+i)});});
 /* trampas: gas venenoso, pinchos y bolsas de fuego */
 M.tr("veneno",2,2,3,2);M.tr("veneno",22,11,3,2);M.tr("veneno",21,4,3,2);
 M.tr("pinchos",6,10,2,2,{ph:0});M.tr("pinchos",21,7,2,2,{ph:2.1});M.tr("pinchos",11,13,2,2,{ph:1.1});
 M.tr("llamas",6,13,4,1,{ph:0});M.tr("llamas",16,2,1,5,{ph:3});M.tr("llamas",19,18,5,1,{ph:1.5});
 M.tr("glifo",24,15,2,2);
 return M;
}
function mapaMazJefe(){
 var M=mazBase("mazJefe","Santuario del Guardián",24,20,[2.6,16.8],5050);
 M.boss=true;M.oscuro=.3;
 M.pal=["#4f4a56","#48434f","#56515d","#433e4a","#4d4853"];
 M.runas=[[12,10.4,7.2]];
 M.charcos=[[4.5,12,.7,.4],[19.5,8,.7,.4]];
 /* trono-altar del guardián al fondo y cuatro pilares monumentales (dos rotos) */
 M.blk("altar",10.5,0,3,2,false,{col:"255,80,60"});
 [[5,5,0],[18,5,1],[5,14,1],[18,14,0]].forEach(function(p){M.pil(p[0],p[1],p[2]?{roto:true,z:64}:{z:122});});
 M.bra(3.2,3.2,"255,90,60");M.bra(20.5,3.2,"255,90,60");M.bra(3.2,17.5,"255,90,60");M.bra(20.5,17.5,"255,90,60");M.bra(8.6,2.6,"255,90,60");M.bra(15.4,2.6,"255,90,60");
 [4,9,15,20].forEach(function(x){M.tN(x,"255,100,70");});[5,9,13].forEach(function(y){M.tW(y,"255,100,70");});
 M.estN=[6.4,12,17.6];
 [[7,8],[17,12],[12,15.8],[9,13.5],[16,6.6],[21,15],[3.4,9.5]].forEach(function(p){M.dec("huesos",p[0],p[1],{s:1.05});});
 [[3.5,6.4],[20.4,10],[12,18],[8.5,4.4]].forEach(function(p,i){M.dec("escombros",p[0],p[1],{pz:mazPiezas(80+i)});});
 /* trampas */
 M.tr("pinchos",7,8,2,2,{ph:0});M.tr("pinchos",15,12,2,2,{ph:2.1});
 M.tr("llamas",3,10,4,1,{ph:0});M.tr("llamas",17,10,4,1,{ph:3});
 M.tr("glifo",10,6,2,2);M.tr("glifo",12,13,2,2);
 return M;
}
MAPAS.mazA=mapaMazA();MAPAS.mazB=mapaMazB();MAPAS.mazC=mapaMazC();MAPAS.mazD=mapaMazD();MAPAS.mazE=mapaMazE();MAPAS.mazF=mapaMazF();MAPAS.mazJefe=mapaMazJefe();
/* ---------- MAPAS EXTERIORES (bosques y otros biomas) ----------
   tema "exterior": suelo con losetas del pueblo (bosque) o pintado (nieve, arena, ceniza, piedra, marchito).
   Props: sprites de tilemap/js/assets.js (claves "v_<nombre>"; "@nieve|@marchito|@ceniza|@arena" = versión teñida), del muelle ("m_<nombre>") y del entrenamiento.
   Ayudantes de extBase: borde (perímetro de árboles) · esp (esparcir props sin tapar caminos ni zonas despejadas) · lago/magma/helado · fog (fogata) · cris (cristal) · spr/dec/rc.
   Selección por piso: MZ_BIOMAS (bioma = floor((piso-1)/10)+1). */
var ARB_B=["v_t0","v_t1","v_t3","v_t8"],ARB_O=["v_t2","v_t5","v_t6","v_t7","v_t4"],ARB_N=["v_t3@nieve","v_t8@nieve","v_t1@nieve","v_t0@nieve"],
 ARB_M=["v_t4@marchito","v_t9@marchito","v_t1@marchito","v_t3@marchito","v_t0@marchito"],ARB_C=["v_t9@ceniza","v_t4@ceniza"],ARB_A=["v_t9@arena"],
 ARBUS=["v_b0","v_b1","v_b2","v_b3","v_b4"],ROC=["v_r0","v_r1","v_r2"],ROC_N=["v_r0@nieve","v_r1@nieve","v_r2@nieve","v_r3@nieve"],
 ROC_C=["v_r0@ceniza","v_r1@ceniza","v_r2@ceniza","v_r3@ceniza"],ROC_A=["v_r0@arena","v_r1@arena","v_r2@arena","v_r3@arena"],FLOR=["v_f0","v_f1"];
function extBase(id,nombre,cw,ch,ini,sd,suelo,o){
 var M=Object.assign({id:id,nombre:nombre,tema:"exterior",cw:cw,ch:ch,ob:[],props:[],lamps:[],inicio:{x:ini[0]*CS,y:ini[1]*CS},oscuro:.07,seed:sd,suelo:suelo,
  camino:[],agua:[],lava:[],hielo:[],tablones:[],runas:[],dummies:[[cw*.42*CS,ch*.5*CS,-1],[cw*.5*CS,ch*.5*CS,0],[cw*.58*CS,ch*.5*CS,1]]},o||{});
 var R=seed(sd+7),pts=[],lib=[[Math.floor(ini[0])-3,Math.floor(ini[1])-3,Math.floor(ini[0])+3,Math.floor(ini[1])+3],[Math.floor(cw/2)-4,Math.floor(ch/2)-3,Math.floor(cw/2)+3,Math.floor(ch/2)+2]];
 function en(L,x,y,mg){return L.some(function(r){return x>r[0]-mg&&x<r[2]+1+mg&&y>r[1]-mg&&y<r[3]+1+mg;});}
 M.rc=function(b,alto){M.ob.push({x:b[0]*CS,y:b[1]*CS,w:(b[2]-b[0]+1)*CS,h:(b[3]-b[1]+1)*CS,alto:!!alto});};
 M.spr=function(k,x,y,s,b,alto,mir){M.props.push({k:k,x:x*CS,y:y*CS,s:s||1,mir:!!mir,dy:0});if(b)M.rc(b,alto);};
 M.dec=function(d,x,y,o){M.props.push(Object.assign({d:d,x:x*CS,y:y*CS},o||{}));};
 M.libre=function(r){lib.push(r);};
 /* arb: sprite con colisión de 1 celda en su base (col=false: solo decorativo) */
 M.arb=function(k,x,y,s,col){var cx=Math.floor(x),cy=Math.floor(y);M.spr(k,x,y,s,col===false?null:[cx,cy,cx,cy],false,R()<.5);};
 /* esp: esparce n props de ks dentro del rectángulo r (celdas), separados sep celdas, sin pisar caminos, zonas libres ni agua */
 M.esp=function(ks,n,r,sep,s0,s1,col){
  var t=0,c=0;
  while(c<n&&t<n*60){t++;var x=r[0]+R()*(r[2]-r[0]),y=r[1]+R()*(r[3]-r[1]);
   if(en(lib,x,y,.5)||en(M.camino,x,y,.2)||pts.some(function(p){return Math.hypot(p[0]-x,p[1]-y)<sep;}))continue;
   pts.push([x,y]);c++;M.arb(ks[Math.floor(R()*ks.length)],x,y,s0+R()*(s1-s0),col);}
 };
 /* borde: doble línea de árboles en el perímetro (la interior bloquea el paso) */
 M.borde=function(ks,s0,s1){
  M.rc([0,0,cw-1,0]);M.rc([0,ch-1,cw-1,ch-1]);M.rc([0,1,0,ch-2]);M.rc([cw-1,1,cw-1,ch-2]);
  function t(x,y){M.spr(ks[Math.floor(R()*ks.length)],x,y,s0+R()*(s1-s0),null,false,R()<.5);}
  var x,y;
  for(x=.4;x<cw;x+=1.1+R()*.4){t(x,.5+R()*.4);t(x,ch-.2+R()*.4);}
  for(y=1.3;y<ch;y+=1.1+R()*.4){t(.5+R()*.4,y);t(cw-.2+R()*.4,y);}
  for(x=.9;x<cw;x+=1.7+R()*.5){t(x,-.6);t(x,ch+.75);}
  for(y=1.2;y<ch;y+=1.7+R()*.5){t(-.6,y);t(cw+.75,y);}
 };
 function poza(L,a,vis){L.push(a);if(!vis)M.rc(a,false);lib.push([a[0]-1,a[1]-1,a[2]+1,a[3]+1]);}
 M.lago=function(a,vis){poza(M.agua,a,vis);};
 M.magma=function(a){poza(M.lava,a,false);M.lamps.push([(a[0]+a[2]+1)/2,(a[1]+a[3]+1)/2,6,"255,110,40"]);};
 M.helado=function(a){M.hielo.push(a);};
 M.fog=function(x,y){M.dec("fogata",x,y);M.rc([Math.floor(x),Math.floor(y),Math.floor(x),Math.floor(y)],false);M.lamps.push([x,y,26,"255,150,60"]);};
 M.cris=function(x,y,col,s){M.dec("cristal",x,y,{col:col,s:s||1});M.rc([Math.floor(x),Math.floor(y),Math.floor(x),Math.floor(y)],false);M.lamps.push([x,y,24,col]);};
 M.farol=function(x,y,col){M.spr("v_farol",x,y,1,[Math.floor(x),Math.floor(y),Math.floor(x),Math.floor(y)],false);M.lamps.push([x,y,58,col||"255,175,70"]);};
 return M;
}
function mapaBosqueA(){
 var M=extBase("bosqueA","Claro del Bosque Plateado",28,20,[2.6,16.6],3131,{t:"bosque"}),A=[1.5,1.5,26.5,18.5];
 M.camino=[[1,15,5,17],[5,13,9,16],[9,11,13,14],[13,9,18,12],[18,7,23,10],[23,4,26,8]];
 M.borde(ARB_B,.95,1.1);M.esp(ARB_B,30,A,2.5,.85,1.08);M.esp(ARBUS,16,A,1.5,.7,.9);M.esp(ROC,6,A,2.2,.8,1);
 M.esp(FLOR,22,A,.9,.8,1,false);M.esp(["v_mush"],6,A,1.5,.9,1.2,false);
 M.spr("v_log",9.2,6.4,.95,[9,6,9,6]);M.spr("v_stump",19.6,15.4,.95,[19,15,19,15]);M.spr("v_stump",7.3,3.6,.9,[7,3,7,3]);M.spr("v_r3",23.4,14.6,1.1,[23,14,24,14]);
 return M;
}
function mapaBosqueB(){
 var M=extBase("bosqueB","Sendero del Robledal",32,18,[2.6,14.8],3232,{t:"bosque"},{oscuro:.1}),A=[1.5,1.5,30.5,16.5];
 M.camino=[[1,13,5,15],[5,11,9,14],[9,9,13,12],[13,7,17,10],[17,8,21,11],[21,10,25,13],[25,8,29,12],[28,4,30,9]];
 M.borde(ARB_B,1,1.15);M.esp(ARB_B,46,A,2.1,.9,1.15);M.esp(ARBUS,20,A,1.4,.7,.95);M.esp(ROC,8,A,2,.8,1.05);M.esp(FLOR,18,A,.9,.8,1,false);M.esp(["v_mush"],8,A,1.4,.9,1.2,false);
 M.spr("v_log",15.4,15.2,.95,[15,15,15,15]);M.spr("v_log",6.5,5.6,.95,[6,5,6,5]);M.spr("v_stump",24.4,5.2,.95,[24,5,24,5]);M.spr("v_stump",11.6,3.4,.9,[11,3,11,3]);
 return M;
}
function mapaBosqueC(){
 var M=extBase("bosqueC","Arboleda Otoñal",28,20,[2.6,16.6],3333,{t:"bosque"},{oscuro:.09}),A=[1.5,1.5,26.5,18.5];
 M.camino=[[1,15,5,17],[5,12,9,16],[9,13,14,15],[14,12,18,14]];
 M.lago([19,10,23,14]);M.lago([3,3,6,5]);
 M.borde(ARB_O,.95,1.1);M.esp(ARB_O,30,A,2.4,.85,1.1);M.esp(ARBUS,14,A,1.5,.7,.9);M.esp(ROC,5,A,2.2,.8,1);M.esp(FLOR,22,A,.9,.8,1,false);M.esp(["v_mush"],10,A,1.4,.9,1.3,false);
 M.spr("v_log",16.2,5.6,.95,[16,5,16,5]);M.spr("v_stump",10.5,8.4,.95,[10,8,10,8]);M.spr("v_stump",24.4,17.2,.9,[24,17,24,17]);
 return M;
}
function mapaCampGoblin(){
 var M=extBase("campGoblin","Campamento de los Goblins",26,20,[2.6,16.6],3434,{t:"bosque"},{oscuro:.12}),A=[1.5,1.5,24.5,18.5];
 M.camino=[[1,15,5,17],[5,12,10,16],[9,9,16,13],[7,5,18,8]];
 M.fog(13,6.6);
 M.spr("v_puesto3",4.5,4.6,1,[3,4,5,4]);M.spr("v_puesto2",21.4,4.8,1,[20,4,22,4]);M.spr("v_puesto1",4.6,12.4,1,[4,12,5,12]);M.spr("v_puesto3",21.6,13.4,1,[20,13,22,13]);
 [8,9.4,10.8,15.2,16.6,18].forEach(function(x){M.spr("v_fence",x,3.1,.95,[Math.floor(x),3,Math.floor(x),3]);});
 M.spr("v_mesa",10.2,5.4,.95,[9,5,10,5]);M.farol(8.2,5.2);M.farol(18.2,5.2);
 M.spr("e_barril1",19.4,6.4,.9,[19,6,19,6]);M.spr("e_caja",20.2,7.6,.85,[20,7,20,7]);M.spr("caja",22.4,9.4,1,[22,9,22,9]);M.spr("barril",3.2,9.4,1.1,[3,9,3,9]);
 M.spr("v_log",15.6,6.8,.9,[15,6,15,6]);M.spr("v_stump",11.4,7.6,.9);
 M.dec("huesos",6.5,9,{s:1});M.dec("huesos",18,15.4,{s:1});M.dec("escombros",12,3.6,{pz:mazPiezas(34)});
 M.borde(ARB_B,.95,1.1);M.esp(ARB_B,16,A,2.6,.85,1.05);M.esp(ARBUS,10,A,1.6,.7,.9);M.esp(ROC,4,A,2.2,.8,1);M.esp(["v_mush"],5,A,1.5,.9,1.2,false);
 return M;
}
function mapaBosqueJefe(){
 var M=extBase("bosqueJefe","Corazón del Bosque",26,22,[2.6,18.6],3535,{t:"bosque"},{oscuro:.15,boss:true}),A=[1.5,1.5,24.5,20.5];
 M.runas=[[13,11,7,"90,210,110"]];M.camino=[[1,17,5,19],[5,14,9,18]];
 for(var i=0;i<12;i++){var a=i/12*Math.PI*2+.26,x=13+Math.cos(a)*9.2,y=11+Math.sin(a)*8.4;if(x<2||y<2||x>24||y>20||(x<8&&y>15))continue;M.arb(ARB_B[i%4],x,y,1.5);}
 M.borde(ARB_B,1.05,1.25);M.esp(ARB_B,10,A,3,.95,1.2);M.esp(ARBUS,10,A,1.8,.75,.95);M.esp(["v_mush"],12,A,1.6,1.1,1.5,false);M.esp(FLOR,14,A,1,.8,1,false);
 [[8.4,6.2],[17.6,6.4],[8.6,15.8],[17.4,15.6]].forEach(function(p){M.dec("fogata",p[0],p[1]);M.lamps.push([p[0],p[1],26,"90,230,130"]);});
 M.spr("v_r3",20.6,4.6,1.2,[20,4,21,4]);M.spr("v_stump",5.4,4.4,1.3,[5,4,5,4]);
 return M;
}
function mapaMina(){
 var M=extBase("mina","Mina de Cristal",26,18,[2.6,14.8],3636,{t:"piedra"},{oscuro:.24}),A=[1.5,1.5,24.5,16.5];
 M.camino=[[1,13,5,16],[5,11,10,15],[10,8,16,12],[16,5,23,9]];
 M.borde(["v_r3","v_r2","v_r1","v_r0"],1.2,1.6);M.esp(["v_r0","v_r1","v_r2","v_r3"],8,A,2.4,.9,1.2);M.esp(["v_ore0","v_ore1","v_ore2","v_ore3"],10,A,1.8,1.1,1.4);
 [[6.5,4.4,"120,170,255",1.1],[12,3.2,"190,120,255",1.3],[19.4,3.8,"120,170,255",1],[22.4,12.8,"255,140,200",1.1],[8.4,13.6,"120,255,200",1],[17,14.4,"190,120,255",1.2]].forEach(function(c){M.cris(c[0],c[1],c[2],c[3]);});
 [4.2,9.6,17.2].forEach(function(x){M.spr("e_valla",x,2.9,.9,[Math.floor(x)-1,2,Math.floor(x),2]);});
 M.spr("e_banco",14.6,15.6,1,[14,15,15,15]);M.spr("yunque",11.2,15.8,1.1,[11,15,11,15]);M.spr("e_barril1",21,15.8,.9,[21,15,21,15]);M.spr("e_caja",22.2,15.2,.85,[22,15,22,15]);M.spr("caja",3.2,9.4,1,[3,9,3,9]);M.spr("mesa_trab",4.6,5.6,1.2,[4,5,5,5]);
 M.farol(3.4,3.8,"255,170,70");M.farol(23,6.4,"255,170,70");M.farol(13.2,15.8,"255,170,70");
 M.dec("huesos",15,6,{s:.9});M.dec("escombros",9,12,{pz:mazPiezas(36)});M.dec("escombros",20.4,10.4,{pz:mazPiezas(37)});
 return M;
}
function mapaLago(){
 var M=extBase("lago","Orilla del Lago",28,20,[2.6,16.6],3737,{t:"bosque"},{oscuro:.06}),A=[1.5,1.5,13.5,18.5];
 M.camino=[[1,15,5,17],[5,12,9,16],[8,8,12,13]];
 M.lago([15,2,26,5]);M.lago([15,6,26,7],true);M.lago([15,8,26,9]);M.lago([19,10,26,17]);M.rc([25,6,26,7],false);
 M.tablones=[[11,6,24,7]];
 M.borde(ARB_B,.95,1.1);M.esp(ARB_B,16,A,2.4,.85,1.05);M.esp(ARBUS,10,A,1.5,.7,.9);M.esp(ROC,6,[1.5,1.5,26,18.5],2.2,.8,1);M.esp(FLOR,12,A,.9,.8,1,false);
 M.spr("m_bote",21.2,3.6,1,null);M.spr("m_red1",11.6,4.8,1,[11,4,11,4]);M.spr("m_red2",10.2,8.6,1,[10,8,10,8]);
 M.spr("m_barril",12.6,5.6,1,[12,5,12,5]);M.spr("m_caja",13.4,8.7,1,[13,8,13,8]);M.spr("m_cajon",14.6,5.5,.9,[14,5,15,5]);
 M.spr("m_poste",24.6,6.2,1);M.spr("m_poste",24.6,8,1);M.spr("m_farolpez",23.8,5.9,.9);M.lamps.push([23.8,5.9,60,"255,190,90"]);
 M.spr("v_stump",7,3.8,.9,[7,3,7,3]);M.spr("v_log",5.2,9.6,.95,[5,9,5,9]);
 return M;
}
function mapaNieve(){
 var M=extBase("nieve","Paso Helado",28,18,[2.6,14.8],3838,{t:"nieve"},{oscuro:.04}),A=[1.5,1.5,26.5,16.5];
 M.camino=[[1,13,5,16],[5,10,10,14],[10,8,16,12],[16,5,23,9]];
 M.helado([17,10,22,14]);
 M.borde(ARB_N,.95,1.1);M.esp(ARB_N,22,A,2.4,.85,1.05);M.esp(ROC_N,10,A,2,.8,1.15);M.esp(["v_b0@nieve","v_b1@nieve","v_b2@nieve"],10,A,1.5,.7,.9);
 M.fog(23.4,4.4);M.spr("v_stump@nieve",7,3.8,.9,[7,3,7,3]);M.spr("v_log@nieve",5.6,9.4,.95,[5,9,5,9]);M.dec("huesos",14.4,3.8,{s:1});M.dec("huesos",9.6,15,{s:.9});
 return M;
}
function mapaNieveBosque(){
 var M=extBase("nieveBosque","Pinar Nevado",28,20,[2.6,16.6],3939,{t:"nieve"},{oscuro:.07}),A=[1.5,1.5,26.5,18.5];
 M.camino=[[1,15,5,17],[5,13,9,16],[9,11,13,14],[13,9,18,12],[18,6,23,10]];
 M.borde(ARB_N,1,1.2);M.esp(ARB_N,38,A,2.2,.9,1.15);M.esp(ROC_N,6,A,2.2,.8,1.1);M.esp(["v_b0@nieve","v_b1@nieve","v_b2@nieve"],12,A,1.5,.7,.9);
 M.spr("v_log@nieve",9,5.6,.95,[9,5,9,5]);M.spr("v_stump@nieve",20.4,15.4,.95,[20,15,20,15]);M.spr("v_stump@nieve",6.4,4.4,.9,[6,4,6,4]);
 M.fog(21,13.4);M.dec("huesos",12,16,{s:.9});
 return M;
}
function mapaCeniza(){
 var M=extBase("ceniza","Llanura de Ceniza",28,20,[2.6,16.6],4040,{t:"ceniza"},{oscuro:.2}),A=[1.5,1.5,26.5,18.5];
 M.camino=[[1,15,5,17],[5,12,9,16],[9,10,14,14],[14,7,20,11]];
 M.magma([18,3,22,6]);M.magma([4,7,7,10]);M.magma([21,13,25,16]);
 M.borde(ROC_C.concat(["v_r3@ceniza"]),1.1,1.5);M.esp(ROC_C,12,A,2.1,.9,1.2);M.esp(ARB_C,8,A,2.8,.85,1.1);M.esp(["v_ore3","v_ore0"],7,A,2.2,1.1,1.4);M.esp(["v_b0@ceniza"],6,A,1.6,.7,.9);
 M.dec("huesos",12,4.4,{s:1});M.dec("huesos",16.4,16.4,{s:1.05});M.dec("huesos",8.6,12.8,{s:.9});M.dec("escombros",24,9,{pz:mazPiezas(41)});M.dec("escombros",3.4,13.4,{pz:mazPiezas(42)});
 return M;
}
function mapaDesierto(){
 var M=extBase("desierto","Dunas de Artaros",28,20,[2.6,16.6],4141,{t:"arena"},{oscuro:.02}),A=[1.5,1.5,26.5,18.5];
 M.camino=[[1,15,5,17],[5,12,10,16],[10,9,16,13],[16,6,23,10]];
 M.lago([21,12,24,14]);
 M.borde(ROC_A,1,1.4);M.esp(ROC_A,12,A,2.1,.9,1.2);M.esp(ARB_A,8,A,2.6,.85,1.1);M.esp(["v_ore2"],6,A,2.4,1.1,1.4);M.esp(["v_b2@arena"],6,A,1.6,.7,.9);
 ["v_t6","v_t7"].forEach(function(k,i){M.arb(k,20.4+i*4.4,11.4+i*.2,1.1);});M.arb("v_t6",22.4,15.4,1);
 M.spr("v_puesto2",6.6,4.6,1,[5,4,7,4]);M.spr("e_barril1",9.4,5.4,.9,[9,5,9,5]);M.spr("e_caja",4.4,6.2,.85,[4,6,4,6]);M.spr("caja",10.6,4.2,1,[10,4,10,4]);M.spr("v_stump@arena",15.4,15.6,.95,[15,15,15,15]);
 M.dec("huesos",14,4.4,{s:1.1});M.dec("huesos",24,5,{s:1});M.dec("escombros",8,12,{pz:mazPiezas(43)});
 return M;
}
function mapaMarchito(){
 var M=extBase("marchito","Bosque Marchito",28,20,[2.6,16.6],4242,{t:"marchito"},{oscuro:.2}),A=[1.5,1.5,26.5,18.5];
 M.camino=[[1,15,5,17],[5,13,9,16],[9,11,13,14],[13,9,18,12],[18,6,23,10]];
 M.borde(ARB_M,.95,1.15);M.esp(ARB_M,34,A,2.3,.85,1.1);M.esp(["v_b0@marchito","v_b1@marchito","v_b2@marchito","v_b3@marchito"],12,A,1.5,.7,.9);M.esp(["v_mush"],10,A,1.5,.9,1.3,false);
 M.spr("v_stump@marchito",9,5.6,.95,[9,5,9,5]);M.spr("v_stump@marchito",20.4,15.4,.95,[20,15,20,15]);
 [[7,10],[22,8],[14,16],[5,4.4],[24.6,15.6],[16.4,3.4]].forEach(function(p){M.dec("huesos",p[0],p[1],{s:1});});
 [[11,15.6],[20,4.6]].forEach(function(p,i){M.dec("escombros",p[0],p[1],{pz:mazPiezas(44+i)});});
 [[6,13.4],[18.4,12.4],[23.4,3.4]].forEach(function(p){M.lamps.push([p[0],p[1],20,"170,120,255"]);});
 return M;
}
MAPAS.bosqueA=mapaBosqueA();MAPAS.bosqueB=mapaBosqueB();MAPAS.bosqueC=mapaBosqueC();MAPAS.campGoblin=mapaCampGoblin();MAPAS.bosqueJefe=mapaBosqueJefe();
MAPAS.mina=mapaMina();MAPAS.lago=mapaLago();MAPAS.nieve=mapaNieve();MAPAS.nieveBosque=mapaNieveBosque();MAPAS.ceniza=mapaCeniza();MAPAS.desierto=mapaDesierto();MAPAS.marchito=mapaMarchito();
/* mapas por bioma (piso 5 = mini-jefe · piso 10 = jefe); el resto rota por piso */
var MZ_BIOMAS={
 1:{n:["bosqueA","bosqueB","bosqueC"],j5:"campGoblin",j10:"bosqueJefe"},
 2:{n:["mina","lago","mazE"],j5:"mazJefe",j10:"mazJefe"},
 3:{n:["nieve","nieveBosque","mazF"],j5:"mazJefe",j10:"mazJefe"},
 4:{n:["ceniza","mazD","mazB"],j5:"mazJefe",j10:"mazJefe"},
 5:{n:["desierto","mazC","mazA"],j5:"mazJefe",j10:"mazJefe"},
 6:{n:["marchito","mazC","mazD"],j5:"mazJefe",j10:"mazJefe"},
 7:{n:["marchito","mazE","mazD"],j5:"mazJefe",j10:"mazJefe"}
};
var D=null,RAF=0,OV=null,AC=null;
["pointerdown","touchstart","keydown"].forEach(function(e){document.addEventListener(e,function u(){try{AC=AC||new (window.AudioContext||window.webkitAudioContext)();if(AC.state==="suspended")AC.resume();}catch(x){}document.removeEventListener(e,u,true);},true);});

/* ---------- utilidades ---------- */
function clamp(v,a,b){return v<a?a:v>b?b:v;}
function rf(a,b){return a+Math.random()*(b-a);}
function angd(a,b){var d=a-b;while(d>Math.PI)d-=2*Math.PI;while(d<-Math.PI)d+=2*Math.PI;return d;}
function sfx(f,d,tp,v,sl){
 
 try{
  AC=AC||new (window.AudioContext||window.webkitAudioContext)();
  if(AC.state==="suspended"&&AC.resume)AC.resume();
  var o=AC.createOscillator(),g=AC.createGain(),t=AC.currentTime;
  o.type=tp||"square";o.frequency.setValueAtTime(f,t);
  if(sl)o.frequency.exponentialRampToValueAtTime(Math.max(30,f*sl),t+d);
  g.gain.setValueAtTime(v||.04,t);g.gain.exponentialRampToValueAtTime(.0001,t+d);
  o.connect(g);g.connect(AC.destination);o.start();o.stop(t+d);
 }catch(e){}
}

/* ---------- proyección isométrica (mundo plano -> pantalla 2:1) ---------- */
function pj(x,y){return{x:x-y,y:(x+y)*.5};}
function dirDe(a){var dx=Math.cos(a),dy=Math.sin(a),sx=dx-dy,sy=dx+dy;return Math.abs(sx)>Math.abs(sy)?(sx<0?1:2):(sy>0?0:3);} /* 0 abajo · 1 izq · 2 der · 3 arriba */
function camara(dt,snap){
 var s=pj(D.P.x,D.P.y),tx=s.x,ty=s.y-34,vw=VW/Z,vh=VH/Z,x0=-H,x1=W,y0=-WH,y1=(W+H)/2+14;

 if(D.lab&&D.lab.pan&&D.lab.pan.t>0){D.lab.pan.t-=dt;var sp0=pj(D.lab.pan.x,D.lab.pan.y);tx=sp0.x;ty=sp0.y-34;}
 tx=(x1-x0<=vw)?(x0+x1)/2:clamp(tx,x0+vw/2,x1-vw/2);ty=(y1-y0<=vh)?(y0+y1)/2:clamp(ty,y0+vh/2,y1-vh/2);
 var k=snap?1:Math.min(1,dt*6);D.cam.x+=(tx-D.cam.x)*k;D.cam.y+=(ty-D.cam.y)*k;
}
/* ratón (pantalla) -> punto del suelo; +14 px apunta al "cuerpo" del sprite y no a sus pies */
function ratonMundo(){
 var sx=(D.msx-VW/2)/Z+D.cam.x,sy=(D.msy-VH/2)/Z+D.cam.y+14;
 D.mouse.x=clamp(sx/2+sy,0,W);D.mouse.y=clamp(sy-sx/2,0,H);
}
/* WASD relativo a la pantalla (W = arriba en pantalla) -> vector unitario en el mundo */
function dirEntrada(){
 var k=D.keys,ax=(k.d||k.arrowright?1:0)-(k.a||k.arrowleft?1:0),ay=(k.s||k.arrowdown?1:0)-(k.w||k.arrowup?1:0);
 if(!ax&&!ay)return null;
 var wx=ax/2+ay,wy=ay-ax/2,l=Math.hypot(wx,wy);return{x:wx/l,y:wy/l};
}
/* ---------- navegación: campo de distancias (BFS) desde el jugador sobre la rejilla de celdas ---------- */
function navInit(){
 var cw=D.mapa.cw,ch=D.mapa.ch,b=new Uint8Array(cw*ch);
 if(D.lab)b.set(D.lab.blk);
 D.mapa.ob.forEach(function(o){
  for(var y=Math.floor(o.y/CS);y<Math.ceil((o.y+o.h)/CS);y++)for(var x=Math.floor(o.x/CS);x<Math.ceil((o.x+o.w)/CS);x++)if(x>=0&&y>=0&&x<cw&&y<ch)b[y*cw+x]=1;
 });
 D.nav={cw:cw,ch:ch,b:b,d:new Int16Array(cw*ch),q:new Int16Array(cw*ch),pc:-1};
}
function navAct(){
 var n=D.nav,px=clamp(Math.floor(D.P.x/CS),0,n.cw-1),py=clamp(Math.floor(D.P.y/CS),0,n.ch-1),pc=py*n.cw+px;
 if(pc===n.pc)return;n.pc=pc;n.d.fill(-1);
 var h=0,t=0,V=[[1,0],[-1,0],[0,1],[0,-1]];n.q[t++]=pc;n.d[pc]=0;
 while(h<t){
  var c=n.q[h++],x=c%n.cw,y=(c-x)/n.cw,dd=n.d[c]+1;
  for(var i=0;i<4;i++){var nx=x+V[i][0],ny=y+V[i][1];if(nx<0||ny<0||nx>=n.cw||ny>=n.ch)continue;var k=ny*n.cw+nx;if(n.b[k]||n.d[k]>=0)continue;n.d[k]=dd;n.q[t++]=k;}
 }
}
/* ¿segmento libre de obstáculos? soloAlto: solo cuenta los que bloquean proyectiles */
function libre(x1,y1,x2,y2,r,soloAlto){
 if(D.lab){var dd=Math.hypot(x2-x1,y2-y1),nn=Math.max(1,Math.ceil(dd/10));for(var ii=1;ii<nn;ii++)if(labBloq(x1+(x2-x1)*ii/nn,y1+(y2-y1)*ii/nn,soloAlto))return false;return true;}
 var d=Math.hypot(x2-x1,y2-y1),n=Math.ceil(d/10),ob=D.mapa.ob;
 for(var i=1;i<n;i++){
  var x=x1+(x2-x1)*i/n,y=y1+(y2-y1)*i/n;
  for(var k=0;k<ob.length;k++){var o=ob[k];if((!soloAlto||o.alto)&&x>o.x-r&&x<o.x+o.w+r&&y>o.y-r&&y<o.y+o.h+r)return false;}
 }
 return true;
}
/* ángulo de avance del enemigo: directo si hay visión; si no, hacia la celda vecina más cercana al jugador */
function dirNav(e,a,d){
 var P=D.P;if(d<CS*1.6||libre(e.x,e.y,P.x,P.y,e.r*.7))return a;
 var n=D.nav,cx=clamp(Math.floor(e.x/CS),0,n.cw-1),cy=clamp(Math.floor(e.y/CS),0,n.ch-1),bd=n.d[cy*n.cw+cx],bx=-1,by=-1;
 if(bd<0)bd=32000;
 for(var dy=-1;dy<=1;dy++)for(var dx=-1;dx<=1;dx++){
  if(!dx&&!dy)continue;var nx=cx+dx,ny=cy+dy;if(nx<0||ny<0||nx>=n.cw||ny>=n.ch)continue;
  var k=ny*n.cw+nx,v=n.d[k];if(v<0||n.b[k])continue;
  if(dx&&dy&&(n.b[cy*n.cw+nx]||n.b[ny*n.cw+cx]))continue;
  if(v<bd){bd=v;bx=nx;by=ny;}
 }
 return bx<0?a:Math.atan2((by+.5)*CS-e.y,(bx+.5)*CS-e.x);
}
/* ayuda de puntería: el apuntado se ajusta al enemigo más cercano a la línea de tiro */
function asistirAng(a){
 var P=D.P,tg=null,bd=1e9,ca=Math.cos(a),sa=Math.sin(a);
 D.E.forEach(function(e){
  var dx=e.x-P.x,dy=e.y-P.y,t=dx*ca+dy*sa;if(t<20||t>700)return;
  var perp=Math.abs(-dx*sa+dy*ca);if(perp<e.r+24&&perp<bd){bd=perp;tg=e;}
 });
 return tg?Math.atan2(tg.y-P.y,tg.x-P.x):a;
}
/* sprite de enemigo según su nombre (índices de tilemap/js/chars.js) */
var SPR_REGLAS=[
 [/Drag[oó]n/,140],[/Lich/,87],[/Rey Abisal|Se[ñn]or de Ebanos|Verdugo|Khan/,86],[/El Olvidado/,143],[/Treant|^Ent /,126],[/Rey Goblin/,114],
 [/Guardi[aá]n|Golem de Cristal|Golem de Arena|Centinela|Custodio/,147],[/Golem de Obsidiana|Elemental de Lava|Magma|Salamandra|Forjamaestro/,148],
 [/Arp[ií]a/,112],[/Elemental de Agua/,113],[/Elemental de Hielo/,116],[/Slime/,104],[/Goblin|Duende/,114],[/Champi/,109],
 [/Lobo Invernal/,128],[/Lobo/,124],[/Ara[ñn]a|Aracna|Escorpi[oó]n/,149],[/Yeti|Mamut|Gigante/,129],[/Troll/,131],
 [/Perro Infernal|Cerbero/,130],[/F[eé]nix/,108],[/G[aá]rgola/,111],[/Buitre/,142],[/Momia/,88],[/Genio|Djinni/,119],[/Naga/,122],
 [/Alma|Espectro de Luz/,120],[/Espectro|Sombra/,145],[/No-Muerto|Necr[oó]fago/,93],[/Caballero Maldito/,92],
 [/Demonio/,115],[/Aberraci[oó]n/,143],[/Cultista/,66],[/Nigromante|Brujo|Archimago|Mago/,91],[/Bandido|Ladr[oó]n/,106],[/Enano/,107]
];
var SPR_POOL=[124,125,126,131,110,106,107,114,115,121,123];
var SPR_ESC={104:1.9,105:2,108:1.5,109:2.1,112:1.25,113:1.95,114:1.2,115:1,116:1.15,117:1.1,118:1.1,119:1.1,120:1.1,121:1.15,122:1.1,123:1.1,132:1.6,135:2};
/* hoja 259908 (112-123): cuadro 48x72. SPR_TOP = px vacíos sobre la cabeza (para ubicar la barra de vida) */
var SPR_TOP={112:9,113:47,114:20,115:0,116:9,117:12,118:8,119:9,120:8,121:9,122:9,123:12};
function sprEnemigo(e){
 for(var i=0;i<SPR_REGLAS.length;i++)if(SPR_REGLAS[i][0].test(e.nombre))return SPR_REGLAS[i][1];
 var h=0;for(var k=0;k<e.nombre.length;k++)h=(h*31+e.nombre.charCodeAt(k))>>>0;
 return SPR_POOL[h%SPR_POOL.length];
}
/* texto flotante: (x,y)=pie de la entidad, lift=altura en px sobre los pies */
function txt(x,y,t,col,sz,lift){var p=pj(x,y);D.TX.push({x:p.x,y:p.y-14-(lift===undefined?24:lift)*1.2,t:t,col:col,sz:sz||14,a:0,life:.9,vx:rf(-14,14)});}

/* ---------- objetivo: selección por toque/clic y ataque directo ---------- */
function vivo(e){return !!e&&D.E.indexOf(e)>=0&&(e.vida>0||!!e.dummy);}
function masCercano(maxd){
 var P=D.P,b=null,bd=1e9;
 D.E.forEach(function(e){var d=Math.hypot(e.x-P.x,e.y-P.y);if(d<bd&&(!maxd||d<=maxd)){if(D.lab&&d>90&&!libre(P.x,P.y,e.x,e.y,4,true))return;bd=d;b=e;}});
 return b;
}
/* objetivo vigente: el fijado con un toque; si no hay, el más cercano (auto-ataque, J o pantalla táctil) */
function blanco(maxd){
 var t=D.tg;
 if(vivo(t)&&(!maxd||Math.hypot(t.x-D.P.x,t.y-D.P.y)<=maxd))return t;
 if(D.auto||D.keys.j||D.touch)return masCercano(maxd);
 return null;
}
function angA(e){return Math.atan2(e.y-D.P.y,e.x-D.P.x);}
/* enemigo bajo el puntero (prueba en pantalla: caja del sprite); gana el más cercano a cámara */
function elegirEnPantalla(){
 var sx=(D.msx-VW/2)/Z+D.cam.x,sy=(D.msy-VH/2)/Z+D.cam.y,best=null,bk=-1e9;
 D.E.forEach(function(e){
  var p=pj(e.x,e.y),al=e.alt||50,hw=Math.max(e.r*1.5,16)+8;
  if(Math.abs(sx-p.x)<=hw&&sy>=p.y-al-8&&sy<=p.y+10&&e.x+e.y>bk){bk=e.x+e.y;best=e;}
 });
 return best;
}
/* acercarse al objetivo (esquivando obstáculos) y atacar al entrar en alcance */
function atacarObjetivo(T,de,dt){
 var P=D.P,R0=({Guerrero:84,Paladin:80,Asesino:66})[D.j.clase]||80,d=Math.hypot(T.x-P.x,T.y-P.y);
 var alc=D.melee?R0*.8+T.r:420,vis=D.melee||libre(P.x,P.y,T.x,T.y,4,true),en=d<=alc&&vis;
 if(!en&&!de){
  var a0=angA(T),v=velMov()*dt,offs=[0,.6,-.6,1.2,-1.2,1.9,-1.9],i;
  for(i=0;i<offs.length;i++){
   var a=a0+offs[i];
   if(!enObs(P.x+Math.cos(a)*v*3,P.y+Math.sin(a)*v*3,P.r+2)){P.mv=true;mover(P,Math.cos(a)*v,Math.sin(a)*v);break;}
  }
 }
 if(en&&P.atkT<=0)ataque(T);
}

/* ---------- efectos visuales ---------- */
function hexA(h,a){
 var m=/^#([0-9a-f]{6})$/i.exec(h||"");if(!m)return "rgba(255,255,255,"+a+")";
 var n=parseInt(m[1],16);return "rgba("+(n>>16)+","+((n>>8)&255)+","+(n&255)+","+a+")";
}
function fx(o){if(D.FX.length>520)return o;if(o.t===undefined)o.t=0;D.FX.push(o);return o;}
function destello(col,a){D.fl={col:col,a:a};}
/* chispas lineales hacia fuera (z = altura en px) */
function chispas(x,y,n,col,v,life,z){
 for(var i=0;i<n;i++){var a=Math.random()*6.283,s=rf(.4,1)*v;fx({k:"pt2",sh:"line",x:x,y:y,z:z===undefined?18:z,vx:Math.cos(a)*s,vy:Math.sin(a)*s,vz:rf(40,130),g:260,life:rf(.5,1)*life,col:col,sz:rf(1.5,3)});}
}
/* motas luminosas ascendentes */
function motas(x,y,n,col,rad,vz,life){
 for(var i=0;i<n;i++){var a=Math.random()*6.283,r=Math.random()*rad;fx({k:"pt2",sh:"glow",x:x+Math.cos(a)*r,y:y+Math.sin(a)*r,z:rf(0,16),vx:0,vy:0,vz:vz*rf(.6,1.2),g:-10,t:-Math.random()*.25,life:life*rf(.7,1.1),col:col,sz:rf(2,4.2)});}
}
/* nubes de humo/polvo que se expanden */
function humo(x,y,n,col,rad,life,r1){
 for(var i=0;i<n;i++){var a=Math.random()*6.283,r=Math.random()*rad;fx({k:"puff",x:x+Math.cos(a)*r,y:y+Math.sin(a)*r,z:rf(2,14),vx:Math.cos(a)*rf(10,50),vy:Math.sin(a)*rf(10,50),vz:rf(8,28),g:0,t:-Math.random()*.12,life:life*rf(.75,1.15),col:col,r0:rf(6,10),r1:r1*rf(.7,1.2),al:.55});}
}
/* esquirlas de hielo */
function hielo(x,y,n,rad){
 for(var i=0;i<n;i++){var a=i/n*6.283+rf(-.2,.2),s=rad*rf(1.4,2.4);fx({k:"pt2",sh:"shard",x:x,y:y,z:8,vx:Math.cos(a)*s,vy:Math.sin(a)*s,vz:rf(60,150),g:300,rot:Math.random()*6,sp:rf(-6,6),sz:rf(2.5,4.5),life:rf(.45,.8),col:i%2?"#e8f6ff":"#8fd0f0"});}
}
/* lluvia de proyectiles que aterrizan en el instante tv */
function lluvia(cx,cy,rad,n,col,tv,w,len){
 for(var i=0;i<n;i++){
  var a=Math.random()*6.283,r=Math.sqrt(Math.random())*rad,x=cx+Math.cos(a)*r,y=cy+Math.sin(a)*r,lf=.2,dl=Math.max(0,tv-lf)+Math.random()*.07;
  (function(x,y){fx({k:"drop",x:x,y:y,H:rf(240,300),dx:rf(-40,-20),col:col,w:w||2.6,len:len||26,t:-dl,life:lf,fin:function(){fx({k:"flare",x:x,y:y,z:4,col:col,s:9,life:.2});humo(x,y,1,"#b8a888",6,.4,16);}});})(x,y);
 }
}
/* explosión de fuego */
function boom(x,y,r,col){
 fx({k:"boom",x:x,y:y,r:r*.9,col:col,life:.38});
 fx({k:"shock",x:x,y:y,r1:r,col:col,life:.4,low:true,rays:0,a0:0});
 chispas(x,y,Math.min(22,10+((r/8)|0)),col,r*3.2,.7,16);
 motas(x,y,8,col,r*.5,70,.8);
 humo(x,y,5,"#3a2a22",r*.4,.9,r*.45);
}
/* destello de impacto sobre un enemigo */
function impacto(e,col,crit){
 var z=Math.max(12,(e.alt||40)*.5);
 chispas(e.x,e.y,crit?12:6,col,crit?260:170,.45,z);
 fx({k:"flare",x:e.x,y:e.y,z:z,col:col,s:crit?26:14,life:crit?.28:.2});
}
/* pose de lanzamiento: aura, círculo rúnico y envión del sprite */
function lanzando(col){
 var P=D.P;P.castT=P.castMax=.4;P.castCol=col;P.swing=Math.max(P.swing,.22);
 fx({k:"rune",x:P.x,y:P.y,r:44,col:col,life:.5,low:true,follow:true});
}
function trailPr(p){
 if(p.sty==="fuego"){
  fx({k:"pt2",sh:"glow",x:p.x+rf(-5,5),y:p.y+rf(-5,5),z:16+rf(-4,4),vx:-p.vx*.04,vy:-p.vy*.04,vz:rf(10,50),g:0,life:rf(.3,.5),col:"#ff9a3a",sz:rf(3,6)});
  if(Math.random()<.35)fx({k:"puff",x:p.x,y:p.y,z:16,vx:0,vy:0,vz:12,g:0,life:.5,col:"#40302a",r0:5,r1:12,al:.35});
 }else fx({k:"pt2",sh:"glow",x:p.x,y:p.y,z:16,vx:0,vy:0,vz:0,g:0,life:.22,col:p.sty==="flecha"?"#cfe8a0":p.col,sz:p.sty==="tiro"?3:2.2});
}

/* dibujo de cada tipo de efecto (el lienzo ya está en coordenadas del mundo isométrico) */
var FXD={
 /* tajo en creciente: el filo barre el arco y la cola se desvanece */
 slash:function(c,f,u){
  var a0=f.a-f.arc/2,lead=Math.min(1,u*2.2),n=16,rr=f.r*(.75+.25*Math.min(1,u*2)),fade=Math.max(0,1-Math.max(0,u-.25)/.75),w=f.w||9,p0,p1,i,lx=0,ly=0;
  c.translate(0,-(f.h===undefined?14:f.h));c.lineCap="round";
  for(i=0;i<n;i++){
   var s0=i/n*lead,s1=(i+1)/n*lead,q0=f.flip?1-s0:s0,q1=f.flip?1-s1:s1,k=(i+1)/n;
   p0=pj(f.x+Math.cos(a0+f.arc*q0)*rr,f.y+Math.sin(a0+f.arc*q0)*rr);p1=pj(f.x+Math.cos(a0+f.arc*q1)*rr,f.y+Math.sin(a0+f.arc*q1)*rr);
   c.globalAlpha=Math.pow(k,1.6)*fade;c.strokeStyle=f.col;c.lineWidth=w*(.25+.75*k)*(1-u*.4);
   c.beginPath();c.moveTo(p0.x,p0.y);c.lineTo(p1.x,p1.y);c.stroke();
   c.strokeStyle="#fff";c.lineWidth=w*.28*k*(1-u*.4);c.stroke();lx=p1.x;ly=p1.y;
  }
  c.globalAlpha=fade;c.fillStyle="#fff";c.shadowColor=f.col;c.shadowBlur=10;c.beginPath();c.arc(lx,ly,w*.28,0,7);c.fill();c.shadowBlur=0;c.lineCap="butt";
 },
 /* onda expansiva en el suelo */
 shock:function(c,f,u){
  var e=1-Math.pow(1-u,2.2),r=f.r1*(.15+.85*e),al=1-u,p=pj(f.x,f.y);
  c.translate(p.x,p.y);c.scale(1.4142,.7071);
  var g=c.createRadialGradient(0,0,r*.5,0,0,r);g.addColorStop(0,hexA(f.col,0));g.addColorStop(1,hexA(f.col,.5*al));
  c.fillStyle=g;c.beginPath();c.arc(0,0,r,0,7);c.fill();
  c.strokeStyle=f.col;c.globalAlpha=al;c.lineWidth=4*(1-u)+1;c.beginPath();c.arc(0,0,r,0,7);c.stroke();
  c.strokeStyle="#fff";c.globalAlpha=al*.7;c.lineWidth=1.5;c.beginPath();c.arc(0,0,r*.96,0,7);c.stroke();
  if(f.rays){c.strokeStyle=f.col;c.globalAlpha=al*.55;c.lineWidth=2;for(var i=0;i<f.rays;i++){var a=i/f.rays*6.2832+(f.a0||0);c.beginPath();c.moveTo(Math.cos(a)*r*.35,Math.sin(a)*r*.35);c.lineTo(Math.cos(a)*r,Math.sin(a)*r);c.stroke();}}
 },
 /* círculo rúnico (hexagrama giratorio) */
 rune:function(c,f,u){
  var al=Math.max(0,u<.2?u/.2:1-(u-.2)/.8),r=f.r*(.7+.3*Math.min(1,u*3)),cx=f.follow?D.P.x:f.x,cy=f.follow?D.P.y:f.y,rot=f.t*(f.rot||2.4),i,p,t;
  c.strokeStyle=f.col;c.fillStyle=f.col;c.globalAlpha=al*.9;c.lineWidth=2;
  elip(c,cx,cy,r,false,true);elip(c,cx,cy,r*.82,false,true);
  for(t=0;t<2;t++){c.beginPath();for(i=0;i<3;i++){p=pj(cx+Math.cos(rot+t*1.0472+i*2.0944)*r*.82,cy+Math.sin(rot+t*1.0472+i*2.0944)*r*.82);if(i)c.lineTo(p.x,p.y);else c.moveTo(p.x,p.y);}c.closePath();c.stroke();}
  for(i=0;i<12;i++){var a=-rot*.6+i*.5236,q1=pj(cx+Math.cos(a)*r*.82,cy+Math.sin(a)*r*.82),q2=pj(cx+Math.cos(a)*r*.95,cy+Math.sin(a)*r*.95);c.beginPath();c.moveTo(q1.x,q1.y);c.lineTo(q2.x,q2.y);c.stroke();}
  c.globalAlpha=al*.12;elip(c,cx,cy,r,true,false);
 },
 /* rayo/haz de energía (zig = zigzag) */
 beam:function(c,f,u){
  var p1=pj(f.x1,f.y1),p2=pj(f.x2,f.y2),h=f.h===undefined?18:f.h,al=1-u*u,w=(f.w||10)*(1-u*.7),pts=[{x:p1.x,y:p1.y-h}],i;
  if(f.zig){
   var R=seed((f.sd|0)+Math.floor(f.t*40)),dx=p2.x-p1.x,dy=p2.y-p1.y,l=Math.hypot(dx,dy)||1,nx=-dy/l,ny=dx/l,n=8;
   for(i=1;i<n;i++){var o=(R()-.5)*f.zig*(1-u);pts.push({x:p1.x+dx*i/n+nx*o,y:p1.y-h+dy*i/n+ny*o});}
  }
  pts.push({x:p2.x,y:p2.y-h});
  c.globalCompositeOperation="lighter";c.lineCap="round";c.lineJoin="round";
  [[w*2.4,.25,f.col],[w,.7,f.col],[w*.4,1,"#fff"]].forEach(function(L){
   c.globalAlpha=L[1]*al;c.strokeStyle=L[2];c.lineWidth=L[0];c.beginPath();
   pts.forEach(function(q,j){if(j)c.lineTo(q.x,q.y);else c.moveTo(q.x,q.y);});c.stroke();
  });
  c.globalAlpha=al;c.fillStyle="#fff";c.beginPath();c.arc(p2.x,p2.y-h,w*.7+2,0,7);c.fill();
 },
 /* tajo en X sobre un objetivo */
 xslash:function(c,f,u){
  var p=pj(f.x,f.y),s=f.s||26,al=1-Math.max(0,u-.35)/.65;
  c.translate(p.x,p.y-(f.h||24));c.rotate(f.ro||0);c.lineCap="round";
  [[-1,-.7,1,.7,Math.min(1,u*4)],[1,-.7,-1,.7,Math.max(0,Math.min(1,(u-.12)*4))]].forEach(function(q){
   if(q[4]<=0)return;
   var x1=q[0]*s,y1=q[1]*s,x2=x1+(q[2]*s-x1)*q[4],y2=y1+(q[3]*s-y1)*q[4];
   c.globalAlpha=al;c.strokeStyle=f.col;c.lineWidth=7*(1-u*.6);c.beginPath();c.moveTo(x1,y1);c.lineTo(x2,y2);c.stroke();
   c.strokeStyle="#fff";c.lineWidth=2.4*(1-u*.5);c.stroke();
  });
 },
 /* columna de luz */
 pillar:function(c,f,u){
  var p=pj(f.x,f.y),al=u<.15?u/.15:1-(u-.15)/.85,w=(f.w||34)*(u<.15?.4+u/.15*.6:1-(u-.15)*.35),h=f.h||230;
  c.globalCompositeOperation="lighter";
  var g=c.createLinearGradient(0,p.y-h,0,p.y);g.addColorStop(0,hexA(f.col,0));g.addColorStop(.6,hexA(f.col,.45*al));g.addColorStop(1,hexA(f.col,.8*al));
  c.fillStyle=g;c.beginPath();c.moveTo(p.x-w/2,p.y);c.lineTo(p.x-w*.3,p.y-h);c.lineTo(p.x+w*.3,p.y-h);c.lineTo(p.x+w/2,p.y);c.closePath();c.fill();
  var g2=c.createLinearGradient(0,p.y-h,0,p.y);g2.addColorStop(0,"rgba(255,255,255,0)");g2.addColorStop(1,"rgba(255,255,255,"+(.85*al)+")");
  c.fillStyle=g2;c.beginPath();c.moveTo(p.x-w*.18,p.y);c.lineTo(p.x-w*.1,p.y-h);c.lineTo(p.x+w*.1,p.y-h);c.lineTo(p.x+w*.18,p.y);c.closePath();c.fill();
 },
 /* cúpula de escudo alrededor del jugador */
 dome:function(c,f,u){
  var P=D.P,p=pj(P.x,P.y),al=u<.2?u/.2:1-(u-.2)/.8,r=f.r*(.6+.4*Math.min(1,u*3));
  var g=c.createRadialGradient(p.x,p.y-26,r*.2,p.x,p.y-26,r*1.1);g.addColorStop(0,hexA(f.col,0));g.addColorStop(.75,hexA(f.col,.22*al));g.addColorStop(1,hexA(f.col,.6*al));
  c.fillStyle=g;c.beginPath();c.ellipse(p.x,p.y-26,r,r*1.25,0,0,7);c.fill();
  c.strokeStyle="#fff";c.globalAlpha=.5*al;c.lineWidth=1.5;c.beginPath();c.ellipse(p.x,p.y-26,r,r*1.25,0,3.46,4.87);c.stroke();
 },
 /* fogonazo en forma de estrella */
 flare:function(c,f,u){
  var p=pj(f.x,f.y),s=(f.s||16)*(1-u*.6);
  c.globalCompositeOperation="lighter";c.translate(p.x,p.y-(f.z||18));c.globalAlpha=1-u;
  var g=c.createRadialGradient(0,0,0,0,0,s);g.addColorStop(0,"rgba(255,255,255,1)");g.addColorStop(.35,hexA(f.col,.8));g.addColorStop(1,hexA(f.col,0));
  c.fillStyle=g;c.beginPath();c.arc(0,0,s,0,7);c.fill();
  c.strokeStyle="#fff";c.lineWidth=2*(1-u);c.beginPath();c.moveTo(-s*1.6,0);c.lineTo(s*1.6,0);c.moveTo(0,-s*1.6);c.lineTo(0,s*1.6);c.stroke();
 },
 /* núcleo de una explosión */
 boom:function(c,f,u){
  var p=pj(f.x,f.y),r=f.r*(.3+.7*(1-Math.pow(1-u,2.4))),al=1-u;
  c.globalCompositeOperation="lighter";
  var g=c.createRadialGradient(p.x,p.y-12,0,p.x,p.y-12,r*1.3);g.addColorStop(0,"rgba(255,255,255,"+al+")");g.addColorStop(.25,hexA(f.col,.85*al));g.addColorStop(1,hexA(f.col,0));
  c.fillStyle=g;c.beginPath();c.arc(p.x,p.y-12,r*1.3,0,7);c.fill();
 },
 /* partículas: sh = line (chispa) · glow (mota) · shard (esquirla) */
 pt2:function(c,f,u){
  var q=pj(f.x,f.y);c.globalAlpha=Math.max(0,1-u);
  if(f.sh==="line"){
   var sx=f.vx-f.vy,sy=(f.vx+f.vy)*.5-f.vz,l=Math.hypot(sx,sy)||1,L=3+f.sz*2.5;
   c.strokeStyle=f.col;c.lineWidth=f.sz*.8;c.lineCap="round";c.beginPath();c.moveTo(q.x,q.y-f.z);c.lineTo(q.x-sx/l*L,q.y-f.z-sy/l*L);c.stroke();
  }else if(f.sh==="shard"){
   c.translate(q.x,q.y-f.z);c.rotate((f.rot||0)+f.t*(f.sp||0));c.fillStyle=f.col;
   c.beginPath();c.moveTo(0,-f.sz*2);c.lineTo(f.sz*.8,0);c.lineTo(0,f.sz*2);c.lineTo(-f.sz*.8,0);c.closePath();c.fill();
  }else{
   c.globalCompositeOperation="lighter";c.fillStyle=f.col;c.beginPath();c.arc(q.x,q.y-f.z,f.sz*(1-u*.5),0,7);c.fill();
  }
 },
 /* nube de humo */
 puff:function(c,f,u){
  var q=pj(f.x,f.y),r=f.r0+(f.r1-f.r0)*(1-Math.pow(1-u,2)),al=f.al*(1-u)*(u<.1?u/.1:1);
  var g=c.createRadialGradient(q.x,q.y-f.z,r*.15,q.x,q.y-f.z,r);g.addColorStop(0,hexA(f.col,al));g.addColorStop(1,hexA(f.col,0));
  c.fillStyle=g;c.beginPath();c.arc(q.x,q.y-f.z,r,0,7);c.fill();
 },
 /* proyectil que cae desde el cielo (flechas, cuchillas) */
 drop:function(c,f,u){
  var e=u*u*.4+u*.6,h=f.H*(1-e),q=pj(f.x,f.y),x=q.x+f.dx*(1-e),y=q.y-h,L=f.len||22,vl=Math.hypot(f.dx,f.H)||1;
  c.globalAlpha=Math.min(1,u*6);c.lineCap="round";c.strokeStyle=f.col;c.lineWidth=f.w||2.5;
  c.beginPath();c.moveTo(x,y);c.lineTo(x+f.dx/vl*L,y-f.H/vl*L);c.stroke();
  c.strokeStyle="#fff";c.lineWidth=(f.w||2.5)*.4;c.stroke();
 },
 /* partículas de vida robada que vuelan hacia el jugador */
 drain:function(c,f,u){
  var P=D.P,a=pj(f.x1,f.y1),b=pj(P.x,P.y),i;
  c.globalCompositeOperation="lighter";c.fillStyle=f.col;
  for(i=0;i<f.n;i++){
   var s=Math.max(0,Math.min(1,u*1.3-i/f.n*.3)),e=s*s*(3-2*s),sn=Math.sin(e*3.1416);
   if(s<=0||s>=1)continue;
   c.globalAlpha=1-u*.5;c.beginPath();c.arc(a.x+(b.x-a.x)*e+sn*f.cv*(i%2?1:-1),a.y-16+(b.y-24-a.y+16)*e-sn*24,3-e*1.5,0,7);c.fill();
  }
 }
};

/* ---------- estilos de las habilidades de rama (por nombre) ---------- */
var RAMA_FX={
 "Torbellino Aniquilador":{c:"#e05030",t:"giro"},"Sentencia Final":{c:"#ffd24a",t:"ejecucion"},"Juicio Divino":{c:"#ffe080",t:"santo"},
 "Disparo de Largo Alcance":{c:"#fff0c0",t:"riel"},"Corte Sombra x7":{c:"#c070d0",t:"cortes"},"Lluvia de Cuchillas":{c:"#dcdce8",t:"cuchillas"},
 "Infierno":{c:"#ff7a30",t:"infierno"},"Combustión":{c:"#ffb040",t:"combustion"},"Prisión Glacial":{c:"#8fd0f0",t:"hielo"},
 "Lanza de Hielo Absoluto":{c:"#bfe6ff",t:"lanza"},"Trampa Alfa":{c:"#9ad060",t:"trampa"},"Sangre de Loco":{c:"#e03030",t:"furia"},
 "Cruzada Fanática":{c:"#ffe080",t:"cruzada"},"Bastión Inquebrantable":{c:"#8ab0d8",t:"bastion"},"Luz Regeneradora":{c:"#7ab88a",t:"luz"},
 "Vínculo Alfa":{c:"#9ad060",t:"vinculo"},"Posición Elevada":{c:"#f0e0a0",t:"elevada"},"Paso Espectral":{c:"#b070e0",t:"sombra"},
 "Santuario de Luz":{c:"#8ff0d0",t:"santuario"},"Resurgir Divino":{c:"#fff0a0",t:"resurgir"},"Nova Solar":{c:"#ffd060",t:"nova"},"Ascensión Radiante":{c:"#ffe8a0",t:"ascension"},
 "Marca del Condenado":{c:"#ff5030",t:"marca"},"Contrato Marcado":{c:"#e0c060",t:"marca"}
};
function rfx(sk,col){return RAMA_FX[sk.n]||{c:col,t:""};}
function fxRamaArea(sk,mCls,cen,rad,col){
 var r=rfx(sk,col),c0=r.c,x=cen.x,y=cen.y;
 if(r.t==="giro"){fx({k:"shock",x:x,y:y,r1:rad,col:c0,life:.5,low:true,rays:12,a0:0});humo(x,y,10,"#b8a080",rad*.7,.6,40);}
 else if(r.t==="santo"){fx({k:"shock",x:x,y:y,r1:rad,col:c0,life:.5,low:true,rays:16,a0:0});fx({k:"pillar",x:x,y:y,col:c0,w:70,h:300,life:.6});motas(x,y,12,c0,rad*.6,80,.9);destello("#fff2c0",.2);}
 else if(r.t==="infierno"){fx({k:"rune",x:x,y:y,r:rad,col:c0,life:1.3,low:true,rot:1.5});}
 else if(r.t==="combustion"){boom(x,y,rad,c0);fx({k:"rune",x:x,y:y,r:rad,col:c0,life:.6,low:true,rot:3});destello("#ffd890",.25);}
 else if(r.t==="hielo"){fx({k:"rune",x:x,y:y,r:rad,col:c0,life:.8,low:true});hielo(x,y,14,rad);humo(x,y,8,"#bfe6ff",rad*.6,.9,45);fx({k:"shock",x:x,y:y,r1:rad,col:c0,life:.5,low:true,rays:10,a0:0});}
 else if(r.t==="cuchillas"){fx({k:"rune",x:x,y:y,r:rad,col:c0,life:.9,low:true});}
 else if(r.t==="nova"){fx({k:"rune",x:x,y:y,r:rad,col:c0,life:.9,low:true,rot:2});fx({k:"pillar",x:x,y:y,col:c0,w:64,h:300,life:.5});motas(x,y,14,"#fff0b0",rad*.6,90,.9);destello("#fff2c0",.18);}
 else if(r.t==="trampa"){fx({k:"rune",x:x,y:y,r:rad,col:c0,life:1,low:true,rot:-1.8});fx({k:"shock",x:x,y:y,r1:rad,col:c0,life:.5,low:true,rays:0});motas(x,y,16,c0,rad*.7,60,1);}
 else fx({k:"shock",x:x,y:y,r1:rad,col:c0,life:.45,low:true,rays:8,a0:0});
 if(!mCls)D.FX.push({k:"mark",x:x,y:y,r:rad,t:0,life:.5,col:c0});
}
function fxRamaUno(sk,px,py,t,col){
 var r=rfx(sk,col),c0=r.c;
 if(r.t==="ejecucion"){fx({k:"pillar",x:t.x,y:t.y,col:c0,w:50,h:280,life:.45});fx({k:"xslash",x:t.x,y:t.y,col:c0,s:44,life:.4});fx({k:"shock",x:t.x,y:t.y,r1:90,col:c0,life:.4,low:true,rays:10,a0:0});destello("#ffe9a0",.15);}
 else if(r.t==="riel"){fx({k:"beam",x1:px,y1:py,x2:t.x,y2:t.y,col:c0,w:16,life:.3});fx({k:"flare",x:px,y:py,z:24,col:c0,s:26,life:.25});fx({k:"flare",x:t.x,y:t.y,z:20,col:c0,s:34,life:.3});D.shake=Math.max(D.shake,4);}
 else if(r.t==="lanza"){fx({k:"beam",x1:px,y1:py,x2:t.x,y2:t.y,col:c0,w:12,life:.28});hielo(t.x,t.y,10,40);fx({k:"shock",x:t.x,y:t.y,r1:80,col:c0,life:.4,low:true,rays:8,a0:0});}
 else if(r.t==="cortes"){fx({k:"rune",x:t.x,y:t.y,r:t.r+30,col:c0,life:1,low:true,rot:4});}
 else fx({k:"beam",x1:px,y1:py,x2:t.x,y2:t.y,col:c0,w:9,life:.22});
}
/* efecto por cada golpe (n) de una habilidad de varios golpes */
function fxRamaGolpe(sk,n,h,tg,cen,rad,col,mCls){
 var r=rfx(sk,col),c0=r.c,P=D.P,t=tg&&tg[0];
 if(r.t==="giro"&&cen){
  fx({k:"slash",x:cen.x,y:cen.y,a:n*Math.PI,r:rad,arc:6.2,w:16,col:c0,flip:n%2===1,life:.3,h:16});
  fx({k:"slash",x:cen.x,y:cen.y,a:n*Math.PI+1,r:rad*.7,arc:6.2,w:9,col:"#ffe0a0",flip:n%2===0,life:.25,h:10});
 }else if(r.t==="infierno"&&cen){boom(cen.x,cen.y,rad*(.55+.18*n),c0);}
 else if(r.t==="cuchillas"&&cen){lluvia(cen.x,cen.y,rad*.95,10,"#dcdce8",.2,2.2,22);}
 else if(r.t==="cortes"&&t){
  fx({k:"xslash",x:t.x+rf(-8,8),y:t.y+rf(-8,8),col:c0,s:26+n*2,ro:n*.8,life:.25});
  fx({k:"beam",x1:P.x,y1:P.y,x2:t.x,y2:t.y,col:c0,w:5,life:.1});
  if(n===h-1){fx({k:"shock",x:t.x,y:t.y,r1:80,col:c0,life:.4,low:true,rays:10,a0:0});destello("#e0b0f0",.15);}
 }else if(r.t==="lanza"&&t&&n>0){hielo(t.x,t.y,6,30);}
}
function fxRamaBuff(sk,col){
 var P=D.P,r=rfx(sk,col),c0=r.c,x=P.x,y=P.y,g0;
 fx({k:"shock",x:x,y:y,r1:90,col:c0,life:.5,low:true,rays:0});
 if(r.t==="furia"){fx({k:"shock",x:x,y:y,r1:150,col:"#ff7040",life:.6,low:true,rays:16,a0:0});chispas(x,y,18,"#ff6040",300,.6,26);motas(x,y,16,c0,26,110,.9);destello("#ff5030",.16);D.shake=Math.max(D.shake,5);}
 else if(r.t==="cruzada"){fx({k:"pillar",x:x,y:y,col:c0,w:56,h:270,life:.8});motas(x,y,16,c0,30,90,1);destello("#fff2c0",.16);}
 else if(r.t==="bastion"){fx({k:"dome",r:40,col:c0,life:1});motas(x,y,10,c0,26,50,.8);}
 else if(r.t==="santuario"){fx({k:"dome",r:44,col:c0,life:1.2});fx({k:"rune",x:x,y:y,r:120,col:c0,life:1.2,low:true,rot:1});motas(x,y,18,"#c8ffe8",34,80,1.1);}
 else if(r.t==="resurgir"){fx({k:"pillar",x:x,y:y,col:c0,w:70,h:320,life:1});fx({k:"shock",x:x,y:y,r1:170,col:c0,life:.6,low:true,rays:16,a0:0});motas(x,y,26,"#fff8d0",40,110,1.2);destello("#fff8d0",.22);}
 else if(r.t==="ascension"){fx({k:"pillar",x:x,y:y,col:c0,w:56,h:280,life:.9});fx({k:"dome",r:40,col:c0,life:1});motas(x,y,18,"#fff2c0",30,100,1);destello("#fff2c0",.16);}
 else if(r.t==="luz"){fx({k:"pillar",x:x,y:y,col:c0,w:60,h:300,life:.9});motas(x,y,22,"#c8ffd8",34,100,1.1);}
 else if(r.t==="vinculo"){motas(x,y,18,c0,40,70,1);}
 else if(r.t==="elevada"){motas(x,y,14,c0,24,90,.9);fx({k:"dome",r:34,col:c0,life:.8});}
 else if(r.t==="sombra"){humo(x,y,10,"#3a2a4a",18,.7,34);for(g0=0;g0<3;g0++)fx({k:"ghost",x:x+rf(-14,14),y:y+rf(-14,14),d:P.dir,life:.35});}
 else motas(x,y,14,c0,26,80,.9);
 D.FX.push({k:"ring",x:x,y:y,r0:20,r1:70,t:0,life:.55,col:c0,fill:false,follow:true});
}
function fxRamaMarca(sk,px,py,t,col){
 var r=rfx(sk,col),c0=r.c;
 fx({k:"beam",x1:px,y1:py,x2:t.x,y2:t.y,col:c0,w:5,life:.22});
 fx({k:"rune",x:t.x,y:t.y,r:t.r+36,col:c0,life:1.1,low:true,rot:3});
 fx({k:"pillar",x:t.x,y:t.y,col:c0,w:26,h:150,life:.5});
}

/* proyectiles: flecha · tiro (estela perforante) · fuego · orbe */
function dibujarProy(c,p){
 var q=pj(p.x,p.y),sx=p.vx-p.vy,sy=(p.vx+p.vy)*.5,l=Math.hypot(sx,sy)||1,ux=sx/l,uy=sy/l,y=q.y-16,t=D.t,s=p.sty||"orbe";
 c.fillStyle="rgba(0,0,0,.3)";c.beginPath();c.ellipse(q.x,q.y,p.r*1.3,p.r*.65,0,0,7);c.fill();
 c.save();
 if(s==="flecha"){
  var tx=q.x-ux*22,ty=y-uy*22,hx=q.x+ux*12,hy=y+uy*12;
  c.lineCap="round";c.strokeStyle="#cdb98a";c.lineWidth=2;c.beginPath();c.moveTo(tx,ty);c.lineTo(hx,hy);c.stroke();
  c.fillStyle="#eef0f6";c.beginPath();c.moveTo(hx+ux*7,hy+uy*7);c.lineTo(hx-uy*3.5,hy+ux*3.5);c.lineTo(hx+uy*3.5,hy-ux*3.5);c.closePath();c.fill();
  c.strokeStyle=p.col;c.lineWidth=1.8;c.beginPath();
  c.moveTo(tx,ty);c.lineTo(tx-ux*3-uy*4,ty-uy*3+ux*4);c.moveTo(tx,ty);c.lineTo(tx-ux*3+uy*4,ty-uy*3-ux*4);
  c.moveTo(tx+ux*5,ty+uy*5);c.lineTo(tx+ux*2-uy*4,ty+uy*2+ux*4);c.moveTo(tx+ux*5,ty+uy*5);c.lineTo(tx+ux*2+uy*4,ty+uy*2-ux*4);c.stroke();
 }else if(s==="tiro"){
  c.globalCompositeOperation="lighter";c.lineCap="round";
  [[9,.25],[5,.6],[2,1]].forEach(function(w){c.globalAlpha=w[1];c.strokeStyle=w[1]===1?"#fff":p.col;c.lineWidth=w[0];c.beginPath();c.moveTo(q.x-ux*64,y-uy*64);c.lineTo(q.x+ux*6,y+uy*6);c.stroke();});
 }else if(s==="fuego"){
  c.globalCompositeOperation="lighter";
  var r=p.r*(1.5+.18*Math.sin(t*38)),g=c.createRadialGradient(q.x,y,1,q.x,y,r*2),w2=4*Math.sin(t*50);
  g.addColorStop(0,"rgba(255,255,255,1)");g.addColorStop(.3,"rgba(255,190,80,.95)");g.addColorStop(.7,"rgba(255,90,20,.45)");g.addColorStop(1,"rgba(255,60,10,0)");
  c.fillStyle=g;c.beginPath();c.arc(q.x,y,r*2,0,7);c.fill();
  c.strokeStyle="rgba(255,150,50,.8)";c.lineWidth=3;c.lineCap="round";c.beginPath();c.moveTo(q.x,y);c.lineTo(q.x-ux*30-uy*w2,y-uy*30+ux*w2);c.stroke();
 }else{
  c.globalCompositeOperation="lighter";
  var r2=p.r*(1+.15*Math.sin(t*20+p.x)),g2=c.createRadialGradient(q.x,y,1,q.x,y,r2*2.2);
  g2.addColorStop(0,"rgba(255,255,255,.95)");g2.addColorStop(.35,hexA(p.col,.8));g2.addColorStop(1,hexA(p.col,0));
  c.fillStyle=g2;c.beginPath();c.arc(q.x,y,r2*2.2,0,7);c.fill();
 }
 c.restore();
}


/* ---------- talentos de rama en tiempo real ---------- */
/* multiplicador de daño por talentos que dependen del enemigo (Marca Fatal, Contrato Abierto, marcas) */
function mejora(e){
 var M=D.M,m=1;
 if(M.exth&&e.vida<e.vidaMax*M.exth)m*=1+M.exv;
 if(M.elite&&e.tipo!=="normal")m*=1+M.elite;
 if(e.mk)m*=1+e.mk.dm;
 return m;
}
/* rebote del próximo ataque (Posición Elevada): golpea a n enemigos cercanos al primero */
function rebotar(e0,raw,n){
 D.E.filter(function(e){return e!==e0&&Math.hypot(e.x-e0.x,e.y-e0.y)<=260;}).sort(function(a,b){return Math.hypot(a.x-e0.x,a.y-e0.y)-Math.hypot(b.x-e0.x,b.y-e0.y);}).slice(0,n).forEach(function(e){
  fx({k:"beam",x1:e0.x,y1:e0.y,x2:e.x,y2:e.y,col:"#f0e0a0",w:5,zig:16,sd:Math.floor(Math.random()*9999),life:.22});herir(e,raw,{crit:true,fc:true,kb:40,col:"#f0e0a0"});
 });
}
/* Apoyo: quita aturdimiento, silencio y ralentización del héroe */
function purgarControl(){
 var P=D.P,q=P.stunT>0||P.silT>0||P.venT>D.t;
 P.stunT=0;P.silT=0;P.venT=0;P.resStun=0;
 if(q)txt(P.x,P.y,"✨ Control purgado","#ffe9a0",13,48);
 return q;
}
/* Hab. 1 / Hab. 2 de la rama (sk = definición en RAMAS). Daño (d), buff (b) o marca (m). 1 turno ≈ 1.25 s de aturdimiento, 1.5 s de inmunidad */
function lanzarRama(sk,i){
 var P=D.P,j=D.j,st=D.st,M=D.M,k=sk.s,pw=1+M[k+"p"],px=P.x,py=P.y,mCls=(j.clase==="Guerrero"||j.clase==="Paladin"),col=CLASES[j.clase].color,fcol=rfx(sk,col).c;
 function base(){return rnd(st.atkMin,st.atkMax)*gmGlob(j,i);}
 function cur(maxd){var bt=blanco(),mx=bt?bt.x:D.mouse.x,my=bt?bt.y:D.mouse.y,dx=mx-px,dy=my-py,d=Math.hypot(dx,dy)||1,q=Math.min(1,maxd/d);return{x:px+dx*q,y:py+dy*q};}
 function cercanoCursor(){var bt=blanco(620);if(bt)return bt;var t0=null,bd=1e9;D.E.forEach(function(e){var d=Math.hypot(e.x-D.mouse.x,e.y-D.mouse.y);if(d<bd&&Math.hypot(e.x-px,e.y-py)<=620){bd=d;t0=e;}});return t0;}
 if(sk.k==="d"){
  var h=(sk.h||1)+M[k+"h"],tg,cen,rad;
  if(sk.a){
   if(mCls){
    var Tm=objMelee();
    if(Tm){
     if(!enAlcance(Tm)){sinObjMelee(Tm);return false;}
     if(j.clase==="Guerrero"){irA(Tm);px=P.x;py=P.y;cen={x:P.x,y:P.y};}else cen={x:Tm.x,y:Tm.y};
    }else cen={x:px,y:py};
    rad=175;
   }else{cen=cur(380);rad=140;}
   tg=D.E.filter(function(e){return Math.hypot(e.x-cen.x,e.y-cen.y)<=rad+e.r;});
   fxRamaArea(sk,mCls,cen,rad,col);
  }else{
   var t0=(mCls||j.clase==="Asesino")?objMelee():cercanoCursor();if(!t0||!enAlcance(t0,(mCls||j.clase==="Asesino")?0:620)){sinObjMelee(t0);return false;}
   if(mCls||j.clase==="Asesino")irA(t0,j.clase==="Asesino",0);
   px=P.x;py=P.y;tg=[t0];fxRamaUno(sk,px,py,t0,col);
  }
  var esc=1+(sk.esc||0)*tg.length,sg=1+(sk.sg||0)+M[k+"sg"]+M.sg,ig=Math.min(1,(sk.ig||0)+M[k+"ig"]+M.ig);
  var stn=sk.st?(sk.st+M[k+"st"]+M.stb)*1.25:0,cp=Math.min(60,CLASES[j.clase].crit+st.critB);
  if(sk.sdf){P.defB=-Math.floor(st.def*sk.sdf);P.defT=4;}
  for(var n=0;n<h;n++)(function(n){D.TM.push({t:n*.14,fn:function(){
   tg.forEach(function(e){
    if(D.E.indexOf(e)<0)return;
    if(j.clase==="Asesino"&&!sk.a&&n>0)irA(e,true,n);
    var cr=1;
    if(sk.cr||(sk.fx&&e.stunT>0)||(sk.ci&&Math.random()*100<cp+sk.ci*100*n))cr=st.critMult*(e.stunT>0?1+M.fz:1);
    var m=sk.m*((sk.fm&&n===h-1)?sk.fm:1)*((sk.und&&/No-Muerto|Espectro|Momia|Lich|Alma|Sombra/.test(e.nombre))?2:1);
    var dd=e.def;e.def=Math.floor(dd*(1-ig));
    herir(e,base()*m*pw*esc*cr*sg,{kb:30,col:fcol});e.def=dd;
   });
   fxRamaGolpe(sk,n,h,tg,cen,rad,col,mCls);
   sfx(280+n*30,.08,"sawtooth",.03,.6);
  }});})(n);
  D.TM.push({t:h*.14+.03,fn:function(){
   tg.forEach(function(e){
    if(D.E.indexOf(e)<0||e.dummy)return;
    if(stn)e.stunT=Math.max(e.stunT,stn*(e.tipo==="jefe"?.5:e.tipo==="mini_jefe"?.7:1));
    if(sk.sil)e.espT=e.espT.map(function(v){return Math.max(v,sk.sil*4*(/No-Muerto|Espectro|Momia|Lich|Alma|Sombra/.test(e.nombre)?2:1));});
    if(sk.dd)e.def=Math.floor(e.def*(1-sk.dd));
   });
   if(sk.lh&&tg.length){var chl=Math.floor(st.vidaMax*sk.lh*Math.min(6,tg.length)*curaMult(j));P.hp=Math.min(st.vidaMax,P.hp+chl);txt(P.x,P.y,"+"+chl,"#7ab88a",15,34);}
   var xe=M[k+"ex"];
   if(xe)D.E.slice().forEach(function(e){if(!e.dummy&&e.tipo==="normal"&&e.vida>0&&e.vida<e.vidaMax*xe){e.vida=0;txt(e.x,e.y,"Ejecutado","#ffd24a",14,40);matar(e);}});
   if(sk.rs&&tg.length&&D.E.indexOf(tg[0])<0){P.cd[i]=0;P.mp=Math.min(st.recursoMax,P.mp+sk.rs);txt(P.x,P.y,"↺ "+sk.n,"#e0c060",13,50);}
  }});
  D.shake=Math.max(D.shake,3);
 }else if(sk.k==="b"){
  if(sk.t)j.tb={n:sk.n,t:sk.t,dm:(sk.dm||0)*pw,rb:sk.rb||0,vl:sk.vl||0,vl2:sk.vl2||0,dpl:sk.dpl||0,cc:sk.cc||0,red:Math.min(.9,(sk.red||0)*pw),reg:(sk.reg||0)*pw,ref:(sk.ref||0)+M[k+"ref"],hp:M[k+"hp"],acc:0};
  if(sk.inv)P.invT=Math.max(P.invT,sk.inv*1.5);
  var sh=((sk.sh||0)+M[k+"sh"])*(sk.sh?pw:1)*(1+M.cura);if(sh){P.sh=Math.floor(st.vidaMax*sh);P.shT=8;}
  if(sk.hl){var hl=Math.floor(st.vidaMax*sk.hl*pw*curaMult(j));P.hp=Math.min(st.vidaMax,P.hp+hl);txt(px,py,"+"+hl,"#7ab88a",18,30);}
  if(sk.df){P.defB=Math.floor(st.def*sk.df*pw);P.defT=sk.t;}
  if(sk.pur)purgarControl();
  if(sk.nx)D.nx={dm:sk.nx.dm*pw,bn:sk.nx.bn||0,h:1+M[k+"nx"]};
  if(j.clase==="Clérigo"||j.clase==="Paladin"){
   var cl2=j.clase==="Clérigo",ob={col:fcol,dt:sk.t||0};
   if(sk.t){var tbA={n:sk.n,t:sk.t,dm:cl2?(sk.dm||0)*pw:0,rb:cl2?(sk.rb||0):0,cc:cl2?(sk.cc||0):0,red:Math.min(.9,(sk.red||0)*pw),reg:(sk.reg||0)*pw,ref:(sk.ref||0)+M[k+"ref"]};if(tbA.dm||tbA.rb||tbA.cc||tbA.red||tbA.reg||tbA.ref)ob.tb=tbA;}
   if(sk.df)ob.df=Math.floor(st.def*sk.df*pw);
   if(sh)ob.sf=sh;
   if(cl2&&sk.hl)ob.hf=sk.hl*pw*curaMult(j);
   if(cl2&&sk.pur)ob.pur=1;
   if(ob.tb||ob.df||ob.sf||ob.hf||ob.pur)netBuff(ob);
  }
  fxRamaBuff(sk,col);txt(px,py,sk.n,"#e0c060",13,52);
 }else{
  var t1=cercanoCursor();if(!t1){txt(px,py,"Sin objetivo","#aaa",12,30);return false;}
  t1.mk={dm:sk.dm,cof:(sk.cof||0)+M[k+"cof"],orp:(sk.orp||0)+M[k+"oro"],bf:sk.bf||null};
  fxRamaMarca(sk,px,py,t1,col);txt(t1.x,t1.y,"🎯 Marcado","#e0c060",13,50);
 }
 sfx(340,.18,"sawtooth",.04,1.8);
 return true;
}
/* ---------- selector de rama en la pantalla de configuración ---------- */
function ramasUI(){
 var box=document.getElementById("dmRamas");if(!box)return;
 var cl=ROSTER[CFG.pj].clase,R=RAMAS[cl]||[];
 if(CFG.rama&&!R.some(function(r){return r.n===CFG.rama;}))CFG.rama="";
 var h='<div style="font-size:12px;color:var(--muted);margin-bottom:6px"><b style="color:var(--text)">Rama de talentos ('+cl+')</b> · rama desde Nv 50 · Hab. 1 en Nv 60 · Hab. 2 en Nv 80 · se activan los nodos hasta el nivel elegido</div><div class="dm-ramas">';
 h+='<div class="card classcard dm-ra'+(!CFG.rama?' sel':'')+'" data-r=""><b>Sin rama</b><small>Solo la clase base</small></div>';
 R.forEach(function(r){h+='<div class="card classcard dm-ra'+(CFG.rama===r.n?' sel':'')+'" data-r="'+r.n+'"><b>'+r.n+'</b><small>'+r.foco+'</small><small style="color:var(--accent)">[4] '+r.h1.n+' · [5] '+r.h2.n+'</small></div>';});
 box.innerHTML=h+'</div>';balanceUI();
 box.querySelectorAll(".dm-ra").forEach(function(c){c.onclick=function(){
  CFG.rama=c.getAttribute("data-r");
  if(CFG.rama){var ni=document.getElementById("dmNiv");if(ni&&(parseInt(ni.value,10)||1)<NIV_RAMA)ni.value=100;}
  ramasUI();
 };});
}

/* ---------- personaje, lectura de la configuración y panel de balance ---------- */
/* arma el héroe (talentos, nivel, modificadores del personaje) igual para la vista previa y para el combate */
function prepararJ(){
 var usar=!!(CFG.usarSave&&typeof G!=="undefined"&&G&&G.j),j,r=null,sp;
 if(usar){j=JSON.parse(JSON.stringify(G.j));sp=spPropio(j.clase);}
 else{
  r=ROSTER[CFG.pj]||ROSTER[0];j=crearJugador(r.n,r.clase);j.nivel=CFG.nivel;sp=r.sp;
  if(CFG.rama&&j.nivel>=NIV_RAMA){var rr=(RAMAS[j.clase]||[]).filter(function(x){return x.n===CFG.rama;})[0];if(rr)j.tal={rama:rr.n,act:ramaNodos(rr).filter(function(n){return n.nv<=j.nivel;}).map(function(n){return n.id;}),almas:0};}
 }
 j.maldiciones=j.maldiciones||{};j.reliquias=j.reliquias||[];j.ciclo=CFG.ciclo;
 var md=r?r.mod:{hp:1,dmg:1,mov:1,spd:1},st=calcStats(j),vel=velJugador(j);
 st.vidaMax=Math.floor(st.vidaMax*md.hp);
 st.atkMin=Math.max(1,Math.floor(st.atkMin*md.dmg));st.atkMax=Math.max(1,Math.floor(st.atkMax*md.dmg));
 return{j:j,r:r,sp:sp,md:md,st:st,vel:vel,usar:usar};
}
function leerCFG(){
 var g=function(i){return document.getElementById(i);},cs=g("dmSave");
 CFG.usarSave=!!(cs&&cs.checked);
 CFG.nivel=clamp(parseInt(g("dmNiv").value,10)||1,1,100);
 CFG.piso=clamp(parseInt(g("dmPiso").value,10)||1,1,70);
 CFG.oleadas=clamp(parseInt(g("dmOle").value,10)||1,1,5);
 CFG.modo=g("dmModo").value;CFG.mapa=g("dmMapa").value;CFG.ciclo=clamp(parseInt(g("dmCiclo").value,10)||0,0,MAX_EXTREMO);
}
/* Panel: stats del héroe frente a la media de enemigos del piso/ciclo elegidos (40 muestras de generarOleada) */
function balanceUI(){
 var box=document.getElementById("dmBal");if(!box)return;
 try{
  leerCFG();
  var pj=prepararJ(),j=pj.j,st=pj.st,M=talMods(j),stub={piso:CFG.piso,ciclo:CFG.ciclo},A={n:{c:0,v:0,a:0,b:0,d:0},j:{c:0,v:0,a:0,b:0,d:0}};
  for(var i=0;i<40;i++)generarOleada(stub).forEach(function(e){var o=e.tipo==="normal"?A.n:A.j;o.c++;o.v+=e.vidaMax;o.a+=e.atkMin;o.b+=e.atkMax;o.d+=e.def;});
  var cp=Math.min(60,CLASES[j.clase].crit+st.critB)/100,hit=(st.atkMin+st.atkMax)/2*(1+cp*(st.critMult-1));
  var tj=TURNO_S/(pj.vel*pj.md.spd)*TUNE.playerAtkF,te=TURNO_S/Math.min(1.8,1+.03*CFG.ciclo)*TUNE.enemyIntF,dfs=st.def+st.redFis;
  function fila(nom,o,col){
   if(!o.c)return '';
   var V=o.v/o.c,a0=o.a/o.c,a1=o.b/o.c,D=o.d/o.c,gt=danoMitigado(hit,D),gk=Math.max(1,Math.ceil(V/gt));
   var de=Math.max(1,Math.floor(danoMitigado((a0+a1)/2,dfs)*(1-Math.min(.9,M.dr)))),gm=Math.max(1,Math.ceil(st.vidaMax/de));
   return '<div class="dm-bal-r"><b style="color:'+col+'">'+nom+'</b><span>Vida '+Math.floor(V)+' · DEF '+Math.floor(D)+' · Daño '+Math.floor(a0)+'-'+Math.floor(a1)+'</span><span>Tu golpe medio <b>'+Math.floor(gt)+'</b> → mueren en <b>'+gk+'</b> golpe'+(gk===1?'':'s')+' (~'+(gk*tj).toFixed(1)+' s)</span><span>Su golpe medio <b>'+de+'</b> → te mata en <b>'+gm+'</b> golpe'+(gm===1?'':'s')+' (~'+(gm*te).toFixed(1)+' s)</span></div>';
  }
  var pb=CFG.piso%10,jefe=(pb===5||pb===0);
  box.innerHTML='<div style="font-size:12px;margin-bottom:6px"><b style="color:var(--text)">Balance estimado</b> <span style="color:var(--muted)">· Piso '+CFG.piso+(CFG.ciclo?' · <span style="color:#e06a5a">☠ Extremo '+CFG.ciclo+'</span> (escala como piso '+(CFG.piso+70*CFG.ciclo)+', normales ×5 daño, jefes con 2 esbirros, 5 etapas)':'')+'</span></div>'
   +'<div class="dm-bal-r"><b style="color:'+CLASES[j.clase].color+'">'+j.nombre+' Nv '+j.nivel+'</b><span>Vida '+st.vidaMax+' · DEF '+dfs+' · Daño '+st.atkMin+'-'+st.atkMax+' · Crít. '+Math.round(cp*100)+'% ×'+st.critMult.toFixed(2)+'</span><span>Daño medio con crítico (sin DEF): '+Math.floor(hit)+'</span><span>Ataque cada ~'+tj.toFixed(2)+' s</span></div>'
   +fila(jefe?'Jefe / Mini-jefe':'Normal',A.j.c?A.j:A.n,'#e0c060')+(jefe&&A.n.c?fila('Esbirros',A.n,'#e08060'):'');
 }catch(e){box.innerHTML='';}
}

/* ---------- recursos (sprites de tilemap/, se cargan solo al abrir el demo) ---------- */
var BASE=(function(){var s=(document.currentScript&&document.currentScript.src)||"";return s.replace(/js\/demo\/combate_demo\.js.*$/,"");})();
var RES={ok:false,busy:false,cb:[]},CI=[],IM={},CACHE={};
function cargarScript(u,fn){var s=document.createElement("script");s.src=u;s.onload=function(){fn();};s.onerror=function(){fn(true);};document.head.appendChild(s);}
/* ---------- sprites del pueblo (tilemap/js/assets.js): limpieza de halos y versiones teñidas ---------- */
function limpiaBorde(im){
 var w=im.width,h=im.height,c=document.createElement("canvas");c.width=w;c.height=h;
 var g=c.getContext("2d");g.drawImage(im,0,0);var d=g.getImageData(0,0,w,h),p=d.data,i,n;
 function blanco(i){var r=p[i],gg=p[i+1],b=p[i+2],mx=Math.max(r,gg,b),mn=Math.min(r,gg,b);return (r+gg+b)/3>130&&mx-mn<45;}
 function borde(x,y){var j=[[1,0],[-1,0],[0,1],[0,-1]];for(var k=0;k<4;k++){var X=x+j[k][0],Y=y+j[k][1];if(X<0||Y<0||X>=w||Y>=h||p[(Y*w+X)*4+3]<=40)return true;}return false;}
 for(n=0;n<40;n++){var kill=[];
  for(var y=0;y<h;y++)for(var x=0;x<w;x++){i=(y*w+x)*4;if(p[i+3]>0&&borde(x,y)&&blanco(i))kill.push(i);}
  if(!kill.length)break;kill.forEach(function(i){p[i+3]=0;});}
 for(i=3;i<p.length;i+=4)if(p[i]<90)p[i]=0;
 g.putImageData(d,0,0);return c;
}
function limpiaSuelo(im){
 var w=im.width,h=im.height,c=document.createElement("canvas");c.width=w;c.height=h;
 var g=c.getContext("2d");g.drawImage(im,0,0);var d=g.getImageData(0,0,w,h),p=d.data,i,n,x,y;
 for(i=3;i<p.length;i+=4)if(p[i]<90)p[i]=0;
 var bad=[],good=[];
 for(i=0;i<w*h;i++){var o=i*4,r=p[o],gg=p[o+1],b=p[o+2],mx=Math.max(r,gg,b),mn=Math.min(r,gg,b);
  if(p[o+3]>0){if((r+gg+b)/3>120&&mx-mn<50)bad[i]=1;else good[i]=1;}}
 for(n=0;n<6;n++){var nw=[];
  for(y=0;y<h;y++)for(x=0;x<w;x++){i=y*w+x;if(!bad[i])continue;var sr=0,sg=0,sb=0,k=0;
   for(var dy=-1;dy<=1;dy++)for(var dx=-1;dx<=1;dx++){var X=x+dx,Y=y+dy;if(X<0||Y<0||X>=w||Y>=h)continue;var j=Y*w+X;if(good[j]){sr+=p[j*4];sg+=p[j*4+1];sb+=p[j*4+2];k++;}}
   if(k)nw.push([i,sr/k,sg/k,sb/k]);}
  if(!nw.length)break;
  nw.forEach(function(q){var o=q[0]*4;p[o]=q[1];p[o+1]=q[2];p[o+2]=q[3];p[o+3]=255;bad[q[0]]=0;good[q[0]]=1;});}
 for(i=0;i<w*h;i++)if(bad[i])p[i*4+3]=0;
 g.putImageData(d,0,0);return c;
}
function limpiaV(k,im){
 if(/^(t\d|b\d|r\d|f\d|stump|log|mush|fence)$/.test(k))return limpiaBorde(im);
 if(/^[gd]\d+$/.test(k))return limpiaSuelo(im);
 return im;
}
/* versiones teñidas (clave "v_<k>@<modo>") para los mapas de nieve, marchito, ceniza y arena */
var TINTES={nieve:["t0","t1","t3","t8","b0","b1","b2","r0","r1","r2","r3","stump","log"],marchito:["t0","t1","t3","t4","t8","t9","b0","b1","b2","b3","stump"],ceniza:["r0","r1","r2","r3","t4","t9","b0","stump"],arena:["r0","r1","r2","r3","stump","t9","b2"]};
function tintes(){for(var s in TINTES)TINTES[s].forEach(function(k){var im=IM["v_"+k];if(im&&im.width)IM["v_"+k+"@"+s]=tinte(im,s);});}
function tinte(im,modo){
 var w=im.width,h=im.height,c=document.createElement("canvas");c.width=w;c.height=h;
 var g=c.getContext("2d");g.drawImage(im,0,0);var d=g.getImageData(0,0,w,h),p=d.data;
 for(var y=0;y<h;y++)for(var x=0;x<w;x++){
  var i=(y*w+x)*4;if(p[i+3]<10)continue;
  var r=p[i],gg=p[i+1],b=p[i+2],l=r*.3+gg*.59+b*.11,t=y/h,R,G,B;
  if(modo==="nieve"){var k=Math.max(0,.72-t*.8)*(r>gg*1.08?.35:1);R=(l*.8+r*.2)*(1-k)+238*k;G=(l*.9+gg*.1)*(1-k)+245*k;B=(l*1.05+b*.1+10)*(1-k)+252*k;}
  else if(modo==="marchito"){R=l*.95+24;G=l*.82+16;B=l*.58+8;}
  else if(modo==="ceniza"){R=l*.6+12;G=l*.48+9;B=l*.46+9;}
  else{R=l*.92+64;G=l*.78+44;B=l*.52+22;}
  p[i]=Math.min(255,R);p[i+1]=Math.min(255,G);p[i+2]=Math.min(255,B);
 }
 g.putImageData(d,0,0);return c;
}
function cargarRecursos(cb){
 if(RES.ok){cb();return;}
 RES.cb.push(cb);if(RES.busy)return;RES.busy=true;
 var need=[];
 if(typeof CHARS==="undefined")need.push("tilemap/js/chars.js");
 if(typeof ENTASSETS==="undefined")need.push("tilemap/js/entrenamiento_assets.js");
 if(typeof ASSETS==="undefined")need.push("tilemap/js/assets.js");
 if(typeof MUASSETS==="undefined")need.push("tilemap/js/muelle_assets.js");
 var falta=need.length,fallo=false;
 function imgs(){
  var ks=Object.keys(ENTASSETS),vk=Object.keys(ASSETS),mk=Object.keys(MUASSETS),pend=ks.length+vk.length+mk.length+CHARS.length;
  function ok(){if(--pend===0){try{tintes();}catch(e){}RES.ok=true;RES.busy=false;var l=RES.cb;RES.cb=[];l.forEach(function(f){f();});}}
  ks.forEach(function(k){var im=new Image();im.onload=im.onerror=ok;im.src=ENTASSETS[k];IM[k]=im;});
  vk.forEach(function(k){var im=new Image();im.onload=function(){try{IM["v_"+k]=limpiaV(k,im);}catch(e){}ok();};im.onerror=ok;im.src=ASSETS[k][2];IM["v_"+k]=im;});
  mk.forEach(function(k){var im=new Image();im.onload=im.onerror=ok;im.src=MUASSETS[k];IM["m_"+k]=im;});
  CHARS.forEach(function(d,i){var im=new Image();im.onload=im.onerror=ok;im.src=d;CI[i]=im;});
 }
 function listo(e){
  if(e)fallo=true;if(--falta>0)return;
  if(fallo||typeof CHARS==="undefined"||typeof ENTASSETS==="undefined"||typeof ASSETS==="undefined"||typeof MUASSETS==="undefined"){
   RES.busy=false;RES.cb=[];
   if(OV)OV.innerHTML='<div class="demo-wrap"><div class="card" style="max-width:520px;margin:20px auto;text-align:center"><div style="color:#e06a5a;margin-bottom:10px">No se pudieron cargar los recursos de tilemap/js/ (chars, entrenamiento_assets, assets, muelle_assets)</div><button class="btn" id="dmX">Cerrar</button></div></div>';
   var x=document.getElementById("dmX");if(x)x.onclick=cerrar;return;
  }
  imgs();
 }
 if(!falta)imgs();else need.forEach(function(u){cargarScript(BASE+u,listo);});
}

/* ---------- pantalla de configuración ---------- */
function abrir(){
 cerrar();
 OV=document.createElement("div");OV.id="demoOv";OV.className="demo-ov";
 OV.innerHTML='<div class="demo-wrap"><div class="card" style="max-width:520px;margin:40px auto;text-align:center"><div class="font-disp" style="font-size:20px;color:var(--accent);margin-bottom:8px">Demo de Combate</div><div style="color:var(--muted);font-size:13px">Cargando personajes y mapa…</div></div></div>';
 document.body.appendChild(OV);
 var ov=OV;
 cargarRecursos(function(){if(OV===ov)pantallaConfig();});
}
function pantallaConfig(){
 var tieneSave=!!(typeof G!=="undefined"&&G&&G.j);
 var h='<div class="demo-wrap"><div class="card" style="max-width:780px;margin:20px auto">';
 h+='<div class="font-disp" style="font-size:22px;color:var(--accent);text-align:center;margin-bottom:4px">Demo de Combate 2.5D</div>';
 h+='<div style="text-align:center;color:var(--muted);font-size:12px;margin-bottom:14px">Tiempo real · no guarda ni altera tu partida</div>';
 if(tieneSave)h+='<label style="display:flex;gap:8px;align-items:center;font-size:13px;margin-bottom:12px;cursor:pointer"><input type="checkbox" id="dmSave" '+(CFG.usarSave?'checked':'')+'> Usar mi personaje actual ('+G.j.nombre+' · '+G.j.clase+' · Nv '+G.j.nivel+')</label>';
 h+='<div id="dmPjs" class="dm-pjs'+(CFG.usarSave&&tieneSave?' dm-off':'')+'">';
 ROSTER.forEach(function(r,i){
  h+='<div class="card classcard dm-pj'+(CFG.pj===i?' sel':'')+'" data-i="'+i+'"><canvas width="48" height="72" data-sp="'+r.sp+'"></canvas><div class="dm-pn" style="color:'+CLASES[r.clase].color+'">'+r.n+'</div><div class="dm-pc">'+r.clase+' · '+CLASES[r.clase].recNombre+'</div><div class="dm-pm">'+modTxt(r.mod)+'</div></div>';
 });
 h+='</div><div id="dmRamas" class="'+(CFG.usarSave&&tieneSave?'dm-off':'')+'" style="margin-bottom:12px"></div><div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(130px,1fr));gap:10px;margin-bottom:12px">';
 h+='<label class="dm-f">Nivel (1-100)<input type="text" id="dmNiv" value="'+CFG.nivel+'"></label>';
 h+='<label class="dm-f">Piso (1-70)<input type="text" id="dmPiso" value="'+CFG.piso+'"></label>';
 h+='<label class="dm-f">Oleadas (1-5)<input type="text" id="dmOle" value="'+CFG.oleadas+'"></label>';
 h+='<label class="dm-f">Modo<select id="dmModo"><option value="oleadas"'+(CFG.modo==="oleadas"?' selected':'')+'>Oleadas</option><option value="muneco"'+(CFG.modo==="muneco"?' selected':'')+'>Muñeco de práctica</option></select></label>';
 h+='<label class="dm-f">Dificultad<select id="dmCiclo">'+[0,1,2,3].map(function(c){return '<option value="'+c+'"'+(CFG.ciclo===c?' selected':'')+'>'+(c?'☠ Extremo '+c:'Normal')+'</option>';}).join('')+'</select></label>';
 h+='<label class="dm-f">Mapa<select id="dmMapa">'+Object.keys(MAPAS).map(function(k){return '<option value="'+k+'"'+(CFG.mapa===k?' selected':'')+'>'+MAPAS[k].nombre+'</option>';}).join('')+'</select></label>';
 h+='</div><div id="dmBal" class="dm-bal"></div><div style="font-size:11.5px;color:var(--muted);line-height:1.7;margin-bottom:14px"><b style="color:var(--text)">Controles:</b> WASD/Flechas mover (relativo a la pantalla) · Ratón apuntar · Clic izq./J atacar (al objetivo fijado o al más cercano) · Toque/clic sobre un enemigo = fijar objetivo (suelo = soltar) · Botón Atacar = auto-ataque · 1-2-3 habilidades (4-5 = Hab. de rama) · Espacio esquivar · Q poción vida · E poción recurso · P pausa<br>Piso 5/10 = mini-jefe/jefe de bioma (1 oleada). El piso define bioma y escalado de enemigos. Extremo: cada piso normal tiene 5 etapas.</div>';
 h+='<div style="display:flex;gap:10px;justify-content:center"><button class="btn btn-primary" id="dmGo" style="padding:10px 28px">Entrar al combate ▸</button><button class="btn" id="dmX">Cerrar</button></div></div></div>';
 OV.innerHTML=h;
 OV.querySelectorAll(".dm-pj canvas").forEach(function(cv){
  var sp=+cv.getAttribute("data-sp"),inf=CHARS_INFO[sp],x=cv.getContext("2d");
  x.imageSmoothingEnabled=false;if(CI[sp])x.drawImage(CI[sp],inf.w,0,inf.w,inf.h,(48-inf.w)/2,72-inf.h,inf.w,inf.h);
 });
 OV.querySelectorAll(".dm-pj").forEach(function(c){c.onclick=function(){CFG.pj=+c.getAttribute("data-i");ramasUI();OV.querySelectorAll(".dm-pj").forEach(function(x){x.classList.toggle("sel",x===c);});};});
 var cs=document.getElementById("dmSave");
 if(cs)cs.onchange=function(){document.getElementById("dmPjs").classList.toggle("dm-off",cs.checked);document.getElementById("dmRamas").classList.toggle("dm-off",cs.checked);balanceUI();};
 ramasUI();
 ["dmNiv","dmPiso"].forEach(function(i){document.getElementById(i).oninput=balanceUI;});
 ["dmCiclo","dmModo"].forEach(function(i){document.getElementById(i).onchange=balanceUI;});
 document.getElementById("dmX").onclick=cerrar;
 document.getElementById("dmGo").onclick=function(){
  leerCFG();
  iniciar();
 };
}
function cerrar(){
 if(D&&D.net){try{netFin();}catch(e){}}
 CFG.mz=false;CFG.inf=false;CFG.lab=false;CFG.net=null;
 if(RAF)cancelAnimationFrame(RAF);RAF=0;
 window.removeEventListener("keydown",kd);window.removeEventListener("keyup",ku);window.removeEventListener("blur",pausar);window.removeEventListener("pointerup",mu);window.removeEventListener("pointercancel",mu);
 D=null;if(OV&&OV.parentNode)OV.parentNode.removeChild(OV);OV=null;
}

/* ---------- inicio ---------- */
function iniciar(){
 var m=CFG.lab?CFG.labMapa:(MAPAS[CFG.mapa]||MAPAS.campo),pj=prepararJ(),j=pj.j,st=pj.st,vel=pj.vel,sp=pj.sp,md=pj.md;
 W=m.cw*CS;H=m.ch*CS;
 var M=talMods(j),hab=HABILIDADES[j.clase].slice(0,3).map(function(h,i){return Object.assign({},h,{costo:costoHab(j,h.costo),desc:h.desc+baseBonoTxt(j,i)});});
 var ra=ramaAct(j);
 if(ra&&j.tal&&j.tal.act)[ra.h1,ra.h2].forEach(function(sk){if(j.tal.act.indexOf(ra.n+"_"+sk.s)>=0)hab.push({n:sk.n,costo:costoHab(j,sk.c),desc:sk.d+habBonoTxt(j,sk),efecto:"rama",cd:Math.max(1,sk.cd-M[sk.s+"cd"]),rama:sk});});
 var stub={piso:CFG.piso,ciclo:CFG.ciclo},pe=CFG.piso%10;
 D={M:M,nx:null,mapa:m,j:j,st:st,vel:vel,hab:hab,stub:stub,bioma:getBioma(stub),t:0,estado:"play",sp:sp,movF:md.mov,spdF:md.spd,
  melee:{Guerrero:1,Paladin:1,Asesino:1}[j.clase]===1,
  P:{x:m.inicio.x,y:m.inicio.y,r:14,face:Math.PI/4,dir:0,mv:false,swing:0,hp:CFG.mz?clamp(Math.floor(j.vida)||1,1,st.vidaMax):st.vidaMax,mp:CFG.mz?clamp(Math.floor(j.recurso)||0,0,st.recursoMax):st.recursoMax,sh:0,shT:0,atkT:0,dodgeT:0,invT:0,stunT:0,silT:0,defB:0,defT:0,dashT:0,dvx:0,dvy:0,dashB:0,dashHit:null,potT:0,pv:CFG.mz?mzCuenta("vida"):TUNE.pots,pr:CFG.mz?mzCuenta("recurso"):TUNE.pots,cd:[0,0,0,0,0],hurt:0,castT:0,castMax:.4,castCol:"#fff",sw:false},
  E:[],PR:[],FX:[],TX:[],TM:[],dpsLog:[],keys:{},mouse:{x:m.inicio.x+60,y:m.inicio.y+60,down:false},msx:VW/2,msy:VH/2,cam:{x:0,y:0},
  wave:0,waves:(CFG.inf||CFG.lab?1e9:(CFG.modo==="muneco"?1:((pe===5||pe===0)?1:(CFG.ciclo>0?5:CFG.oleadas)))),waveWait:.8,banner:{t:0,txt:""},
  kills:0,dmgOut:0,dmgIn:0,hitsIn:0,hitsOut:0,maxIn:0,maxOut:0,shake:0,dummy:CFG.modo==="muneco",espera:0,tg:null,auto:false,obj:null,touch:false,fl:null,niv0:(CFG.mz&&G.j)?G.j.nivel:0};
 D.TR=trInit(m);
 D.net=CFG.net?netCrear(CFG.net):null;
 if(m.lab)labPreparar(m);
 if(D.net)netIniciar();
 OV.innerHTML='<div class="demo-wrap"><div class="demo-top"><span class="font-disp" style="color:var(--accent)">'+(CFG.inf?'Mazmorra Infinita':CFG.lab?'Laberinto de Artaros':CFG.mz?'Mazmorra':'Demo de Combate')+' · '+j.nombre+(ra?' · '+ra.n:'')+' · '+m.nombre+' · '+D.bioma.nombre+(CFG.inf?'':' · Piso '+CFG.piso)+(CFG.ciclo>0?' · ☠ Extremo '+CFG.ciclo:'')+'</span><span style="display:flex;gap:6px"><button class="btn" id="dmP" style="padding:4px 10px;font-size:12px">⏸ Pausa</button><button class="btn btn-danger" id="dmS" style="padding:4px 10px;font-size:12px">'+(CFG.mz?'Huir':'Salir')+'</button></span></div><div class="demo-stage"><canvas id="dmCv" width="'+VW+'" height="'+VH+'"></canvas><div id="dmEnd" class="demo-end" style="display:none"></div></div><div class="demo-bar" id="dmBar"></div></div>';
 D.cv=document.getElementById("dmCv");D.cx=D.cv.getContext("2d");
 D.stat=m.lab?null:estatico(m);navInit();navAct();camara(0,true);ratonMundo();
 construirBarra();
 document.getElementById("dmP").onclick=function(){alternarPausa();};
 document.getElementById("dmS").onclick=CFG.mz?mzHuir:cerrar;
 D.cv.addEventListener("pointermove",mm);
 D.cv.addEventListener("pointerdown",function(e){
  D.touch=(e.pointerType==="touch");
  if(e.button!==0||D.estado!=="play")return;
  mm(e);ratonMundo();
  if(CFG.lab&&labClic())return;
  var t=elegirEnPantalla();
  if(t){if(D.tg===t){D.tg=null;}   /* pulsar de nuevo el enemigo fijado cancela la selección */
  else{fx({k:"ring",x:t.x,y:t.y,r0:t.r+34,r1:t.r+8,life:.25,col:"#ffd24a",fill:false});D.tg=t;}}else D.tg=null;
  if(!D.touch)D.mouse.down=true;
 });
 window.addEventListener("pointerup",mu);window.addEventListener("pointercancel",mu);
 D.cv.addEventListener("contextmenu",function(e){e.preventDefault();});
 window.addEventListener("keydown",kd);window.addEventListener("keyup",ku);window.addEventListener("blur",pausar);
 if(D.dummy)spawnDummy();
 var last=performance.now();
 function loop(ts){
  if(!D)return;
  var dt=Math.min(.05,(ts-last)/1000);last=ts;
  if(D.estado==="play")actualizar(dt);
  dibujar();actualizarBarra();
  RAF=requestAnimationFrame(loop);
 }
 RAF=requestAnimationFrame(loop);
}
function mu(){if(D)D.mouse.down=false;}
function mm(e){var r=D.cv.getBoundingClientRect();D.msx=(e.clientX-r.left)*VW/r.width;D.msy=(e.clientY-r.top)*VH/r.height;}
function kd(e){
 if(!D)return;var k=e.key===" "?"space":e.key.toLowerCase();
 if(["space","arrowup","arrowdown","arrowleft","arrowright","tab"].indexOf(k)>=0)e.preventDefault();
 if(e.repeat)return;
 D.keys[k]=true;
 if(k==="p"||k==="escape"){alternarPausa();return;}
 if(D.lab&&(k==="tab"||k==="n")){D.mapaGrande=!D.mapaGrande;return;}
 if(D.estado!=="play")return;
 if(k==="1")lanzar(0);else if(k==="2")lanzar(1);else if(k==="3")lanzar(2);else if(k==="4"&&D.hab[3])lanzar(3);else if(k==="5"&&D.hab[4])lanzar(4);
 else if(k==="space")esquivar();else if(k==="q")pocion("v");else if(k==="e")pocion("r");else if(k==="f"&&D.lab)labInteractuar();
}
function ku(e){if(D)D.keys[e.key===" "?"space":e.key.toLowerCase()]=false;}
function pausar(){if(D&&D.estado==="play"&&!(D.net&&D.net.on))alternarPausa();}
function alternarPausa(){
 if(!D||(D.estado!=="play"&&D.estado!=="pausa"))return;
 if(D.net&&D.net.on&&D.estado==="play"){D.banner={t:1.6,txt:"No se puede pausar en grupo"};return;}
 D.estado=D.estado==="play"?"pausa":"play";
 var p=document.getElementById("dmEnd");
 if(D.estado==="pausa"){p.style.display="flex";p.innerHTML='<div class="card" style="text-align:center"><div class="font-disp" style="font-size:20px;color:var(--accent);margin-bottom:10px">Pausa</div><button class="btn btn-primary" id="dmR">Continuar</button></div>';document.getElementById("dmR").onclick=alternarPausa;}
 else p.style.display="none";
}

/* ---------- barra inferior ---------- */
function construirBarra(){
 var j=D.j,h='';
 h+='<div class="dm-sk" id="dmSkA"><div class="dm-ic">'+iconoSVG("espada")+'</div><div><b>Atacar</b><small>'+(D.melee?'Cuerpo a cuerpo':'A distancia')+' · va al objetivo fijado o al más cercano · tocar = auto-ataque</small></div></div>';
 D.hab.forEach(function(hb,i){
  h+='<div class="dm-sk" id="dmSk'+i+'" data-i="'+i+'"><div class="dm-ic">'+habImg(hb.n,j.clase,40)+'<div class="dm-cd" id="dmCd'+i+'"></div></div><div><b>['+(i+1)+'] '+hb.n+'</b><small>'+hb.desc+' · '+hb.costo+' '+j.recursoNombre+' · CD '+(hb.cd*TURNO_S)+' s</small></div></div>';
 });
 h+='<div class="dm-sk" id="dmSkD"><div class="dm-ic">⤳<div class="dm-cd" id="dmCdD"></div></div><div><b>[Espacio] Esquivar</b><small>Invulnerable '+TUNE.dodgeInv+' s · CD '+TUNE.dodgeCd+' s</small></div></div>';
 h+='<div class="dm-sk" id="dmSkQ"><div class="dm-ic">❤</div><div><b>[Q] Poción de Vida</b><small id="dmPq"></small></div></div>';
 h+='<div class="dm-sk" id="dmSkE"><div class="dm-ic">✦</div><div><b>[E] Poción de '+j.recursoNombre+'</b><small id="dmPe"></small></div></div>';
 if(CFG.lab){h+='<div class="dm-sk" id="dmSkF"><div class="dm-ic">⚙</div><div><b>[F] Interactuar</b><small>Palancas, cofres y la escalera de salida</small></div></div><div class="dm-sk" id="dmSkN"><div class="dm-ic">🗺</div><div><b>[Tab] Mapa</b><small>Mapa grande de la zona explorada</small></div></div>';}
 var b=document.getElementById("dmBar");b.innerHTML=h;
 if(CFG.lab){document.getElementById("dmSkF").onclick=function(){if(D&&D.estado==="play")labInteractuar();};document.getElementById("dmSkN").onclick=function(){if(D)D.mapaGrande=!D.mapaGrande;};}
 D.hab.forEach(function(hb,i){document.getElementById("dmSk"+i).onclick=function(){if(D&&D.estado==="play")lanzar(i);};});
 document.getElementById("dmSkA").onclick=function(){if(D&&D.estado==="play")D.auto=!D.auto;};
 document.getElementById("dmSkD").onclick=function(){if(D&&D.estado==="play")esquivar();};
 document.getElementById("dmSkQ").onclick=function(){if(D&&D.estado==="play")pocion("v");};
 document.getElementById("dmSkE").onclick=function(){if(D&&D.estado==="play")pocion("r");};
}
function actualizarBarra(){
 if(!D||!document.getElementById("dmCdD"))return;
 var P=D.P,ba=document.getElementById("dmSkA");
 if(ba)ba.classList.toggle("on",!!D.auto);
 D.hab.forEach(function(hb,i){
  var c=document.getElementById("dmCd"+i),s=document.getElementById("dmSk"+i);if(!c)return;
  c.style.height=(P.cd[i]>0?P.cd[i]/(hb.cd*TURNO_S)*100:0)+"%";
  s.classList.toggle("off",P.cd[i]>0||P.mp<hb.costo||P.silT>0);
 });
 document.getElementById("dmCdD").style.height=(P.dodgeT>0?P.dodgeT/TUNE.dodgeCd*100:0)+"%";
 document.getElementById("dmPq").textContent="x"+P.pv+(CFG.mz?" · inventario":" · +25% vida");
 document.getElementById("dmPe").textContent="x"+P.pr+(CFG.mz?" · inventario":" · +25% "+D.j.recursoNombre);
}

/* ---------- enemigos ---------- */
function oleada(){
 D.wave++;
 if(CFG.inf){mzInfOleada();return;}
 var l=generarOleada(D.stub);
 l.forEach(function(e,i){initEnemigo(e,i,l.length);D.E.push(e);});
 D.banner={t:2.2,txt:(l[0].tipo==="jefe"?"♛ JEFE: "+l[0].nombre:l[0].tipo==="mini_jefe"?"☠ MINI-JEFE: "+l[0].nombre:(D.stub.ciclo>0?"Etapa ":"Oleada ")+D.wave+" / "+D.waves)};
}
function initEnemigo(e,i,n){
 var big=/Golem|Troll|Gigante|Mamut|Ent |Yeti|Momia|Aberración|Cerbero|Necrófago/.test(e.nombre);
 e.r=e.tipo==="jefe"?36:e.tipo==="mini_jefe"?28:(big?22:15);
 e.vel=velEnemigo(e,D.stub);
 e.sp=(55+48*e.vel)*(e.tipo==="jefe"?.85:1)*(1-D.M.slow);
 e.ranged=e.tipoDano==="magico";e.range=e.tipo==="jefe"?330:260;
 e.atkInt=TURNO_S/e.vel*TUNE.enemyIntF;e.cd=rf(.8,1.6);
 e.st="move";e.att=null;e.stunT=0;e.flash=0;e.kx=0;e.ky=0;e.strafe=Math.random()<.5?1:-1;
 e.espT=e.esp.map(function(){return rf(1,3);});
 e.spr=sprEnemigo(e);e.ph=Math.random()*4;e.fa=0;e.mov=false;
 var x,y,t=0;
 do{x=rf(CS*1.5,W-CS*1.5);y=rf(CS*1.5,H-CS*1.5);t++;}while((Math.hypot(x-D.P.x,y-D.P.y)<300||enObs(x,y,e.r+6)||enTr(x,y,e.r+6))&&t<120);
 e.x=clamp(x,e.r,W-e.r);e.y=clamp(y,e.r,H-e.r);
 e.col=e.tipo==="jefe"?"#e07050":e.tipo==="mini_jefe"?"#e0c060":(e.tipoDano==="magico"?"#8a5ac9":"#a65a3c");
}
function spawnDummy(){
 var base=Math.max(5,Math.floor((CFG.piso+70*CFG.ciclo)*2)),KK={"-1":"espantapajaros","0":"maniqui1","1":"armadura1"};
 D.mapa.dummies.forEach(function(d){
  var df=Math.max(0,Math.floor(base*(d[2]<0?.4:d[2]>0?2.2:1)));
  D.E.push({nombre:"Muñeco DEF "+df,tipo:"normal",vida:1e9,vidaMax:1e9,atkMin:0,atkMax:0,def:df,dummy:true,dk:KK[d[2]],tipoDano:"fisico",esp:[],espT:[],r:22,x:d[0],y:d[1],sp:0,st:"move",att:null,stunT:0,flash:0,kx:0,ky:0,col:"#8a7a5a",vel:1,cd:99,atkInt:99,fa:0,mov:false,ph:0});
 });
 D.wave=1;D.banner={t:2.5,txt:D.mapa.dummies.length>1?"Muñecos: DEF baja / media / alta":"Muñeco de práctica"};
}
/* ---------- colisión con obstáculos ---------- */
function enObs(x,y,r){if(D.lab)return labBloq(x,y,false);return D.mapa.ob.some(function(o){return x>o.x-r&&x<o.x+o.w+r&&y>o.y-r&&y<o.y+o.h+r;});}
function resolver(o){
 if(D.lab){labResolver(o);return;}
 D.mapa.ob.forEach(function(b){
  var cx=clamp(o.x,b.x,b.x+b.w),cy=clamp(o.y,b.y,b.y+b.h),dx=o.x-cx,dy=o.y-cy,d=Math.hypot(dx,dy);
  if(d<o.r){
   if(d>0){o.x+=dx/d*(o.r-d);o.y+=dy/d*(o.r-d);}
   else{o.y=b.y-o.r;}
  }
 });
 o.x=clamp(o.x,o.r,W-o.r);o.y=clamp(o.y,o.r,H-o.r);
}

function iaEnemigo(e,dt){
 var P=tgtDe(e);e.tgo=P;
 e.flash=Math.max(0,e.flash-dt*4);e.mov=false;
 var kd2=Math.hypot(e.kx,e.ky);
 if(kd2>1){e.x+=e.kx*dt;e.y+=e.ky*dt;var f=Math.max(0,1-dt*9);e.kx*=f;e.ky*=f;}
 if(e.dummy)return;
 if(e.sp0===undefined)e.sp0=e.sp;e.sp=e.sp0*(e.venT>D.t?.7:1);
 e.espT=e.espT.map(function(v){return Math.max(0,v-dt);});
 if(e.stunT>0){e.stunT-=dt;e.att=null;e.st="move";return;}
 if(e.lab&&!labIA(e,dt))return;
 var dx=P.x-e.x,dy=P.y-e.y,d=Math.hypot(dx,dy)||1,a=Math.atan2(dy,dx);e.fa=a;
 if(e.st==="wind"){
  e.att.t-=dt;
  if(e.att.t<=0){resolverAtaque(e);e.st="move";e.att=null;e.cd=e.atkInt*rf(.85,1.2);}
  return;
 }
 var reach=e.r+P.r+16,rango=e.ranged?e.range:reach,am=dirNav(e,a,d),vis=!e.ranged||libre(e.x,e.y,P.x,P.y,4,true);
 if(e.ranged){
  var mv=0;
  if(d>e.range*.9||!vis)mv=1;else if(d<e.range*.55)mv=-1;
  if(mv>0){e.x+=Math.cos(am)*e.sp*dt;e.y+=Math.sin(am)*e.sp*dt;e.mov=true;}
  else if(mv<0){e.x-=Math.cos(a)*e.sp*dt;e.y-=Math.sin(a)*e.sp*dt;e.mov=true;}
  else{e.x+=Math.cos(a+Math.PI/2)*e.sp*.5*e.strafe*dt;e.y+=Math.sin(a+Math.PI/2)*e.sp*.5*e.strafe*dt;e.mov=true;}
 }else if(d>reach*.85){e.x+=Math.cos(am)*e.sp*dt;e.y+=Math.sin(am)*e.sp*dt;e.mov=true;}
 e.cd-=dt;
 if(e.cd<=0&&d<=rango+(e.ranged?0:8)&&vis)comenzarAtaque(e,a,d);
}
function comenzarAtaque(e,a,d){
 var P=e.tgo||D.P,jefe=(e.tipo==="jefe"||e.tipo==="mini_jefe"),esp=null;
 var prob=Math.min(jefe?.6:.4,(jefe?.45:.25)+.05*D.stub.ciclo);
 if(Math.random()<prob){
  var ok=[];e.esp.forEach(function(x,i){
   if(e.espT[i]>0)return;
   if(x.ef==="aturdir"&&(P.stunT>0||P.resStun>0))return;
   if(x.ef==="silencio"&&P.silT>0)return;
   ok.push(i);});
  if(ok.length){var k=ok[Math.floor(Math.random()*ok.length)];esp=e.esp[k];e.espT[k]=esp.cd*TURNO_S;}
 }
 e.st="wind";
 if(esp){
  var rad=jefe?(e.tipo==="jefe"?150:125):95;
  e.att={kind:"aoe",t:jefe?.95:.85,dur:jefe?.95:.85,esp:esp,tipo:esp.tipo,mult:esp.m,rad:rad,cx:e.ranged?P.x:e.x,cy:e.ranged?P.y:e.y};
 }else if(e.ranged){
  e.att={kind:"proj",t:.5,dur:.5,tipo:e.tipoDano,mult:1,ang:a};
 }else{
  e.att={kind:"melee",t:e.tipo==="jefe"?.6:.45,dur:e.tipo==="jefe"?.6:.45,tipo:e.tipoDano,mult:1,ang:a,rad:e.r+P.r+34};
 }
}
function resolverAtaque(e,rem){
 var P=D.P,A=e.att;
 if(A.kind==="melee"){
  var dx=P.x-e.x,dy=P.y-e.y,d=Math.hypot(dx,dy);
  if(d<=A.rad&&Math.abs(angd(Math.atan2(dy,dx),A.ang))<=Math.PI*.55)golpeAJugador(e,A.mult,A.tipo,null);
  fx({k:"slash",x:e.x,y:e.y,a:A.ang,r:A.rad,arc:Math.PI*1.1,w:8,col:COLOR_DANO[A.tipo],flip:Math.random()<.5,life:.22});sfx(160,.1,"sawtooth",.03,.6);
 }else if(A.kind==="proj"){
  if(rem)return;
  var T0=e.tgo||P,ang=Math.atan2(T0.y-e.y,T0.x-e.x),sp=e.tipo==="jefe"?360:320;
  D.PR.push({e:true,x:e.x,y:e.y,vx:Math.cos(ang)*sp,vy:Math.sin(ang)*sp,r:8,life:2.4,src:e,tipo:A.tipo,mult:1,col:COLOR_DANO[A.tipo],sty:"orbe"});sfx(420,.12,"triangle",.03,1.5);
  if(netHost()&&e.lab)netEnv({k:"proy",s:e.sid,x:e.x,y:e.y,vx:Math.cos(ang)*sp,vy:Math.sin(ang)*sp,tp:A.tipo});
 }else{
  if(Math.hypot(P.x-A.cx,P.y-A.cy)<=A.rad+P.r*.4)golpeAJugador(e,A.mult,A.tipo,A.esp);
  fx({k:"shock",x:A.cx,y:A.cy,r1:A.rad,col:COLOR_DANO[A.tipo],life:.4,low:true,rays:10,a0:Math.random()*6});humo(A.cx,A.cy,4,"#5a4a3a",A.rad*.5,.7,A.rad*.35);D.shake=Math.max(D.shake,5);sfx(110,.25,"sawtooth",.05,.5);
 }
 if(!rem&&A.kind!=="proj"&&netHost()&&e.lab)netEnv({k:"atq",s:e.sid,x:e.x,y:e.y,A:{kind:A.kind,ang:A.ang,rad:A.rad,mult:A.mult,tipo:A.tipo,cx:A.cx,cy:A.cy,ef:A.esp?A.esp.ef:null}});
}
function golpeAJugador(e,mult,tipo,esp){
 var P=D.P,st=D.st;
 if(P.invT>0){txt(P.x,P.y,"Inmune","#7ab88a",12,24);return;}
 if(tipo==="fisico"&&Math.random()*100<st.probEsq){txt(P.x,P.y,"Esquiva","#8ab0d8",13,24);return;}
 var base=Math.floor(rnd(e.atkMin,e.atkMax)*mult*TUNE.enemyDmg);
 var critE=!e.dummy&&Math.random()*100<(e.pCrit||0);if(critE)base=Math.floor(base*(e.critMult||1.5));
 var def=st.def+P.defB+(tipo==="magico"?st.redMag:st.redFis);
 var d=danoMitigado(base,def,critE);d=Math.max(Math.floor(d*(1-Math.min(.9,D.M.dr+(D.j.tb&&D.j.tb.red||0)))),Math.max(1,Math.floor(base*(critE?PISO_DANO_CRIT:PISO_DANO))));
 if(P.sh>0){if(d<=P.sh){P.sh-=d;d=0;}else{d-=P.sh;P.sh=0;}}
 P.hp-=d;P.hurt=.25;if(D.j.tb&&D.j.tb.ref&&e&&!e.dummy&&d>0)herir(e,d*D.j.tb.ref,{});D.dmgIn+=d;if(d>0){D.hitsIn++;if(d>D.maxIn)D.maxIn=d;}D.shake=Math.max(D.shake,4);
 txt(P.x,P.y,d>0?(critE?"💥"+d:String(d)):"Bloqueado",COLOR_DANO[tipo],d>0?(critE?20:16):12,24);sfx(130,.12,"square",.05,.6);
 if(esp&&!(D.j.tb&&D.j.tb.cc)){
  if(esp.ef==="silencio"){P.silT=3;txt(P.x,P.y,"🔇 Silenciado","#b070e0",13,44);}
  else if(esp.ef==="aturdir"){P.stunT=1.1;P.resStun=3.5;txt(P.x,P.y,"💫 Aturdido","#7ab8d8",13,44);}
 }
 if(!(P.hp>0))terminar(false);   /* !(>0) también atrapa NaN */
}

/* ---------- jugador ---------- */
function intAtaque(){return TURNO_S/(D.vel*D.spdF*bfRapido())*TUNE.playerAtkF;}
function bfRapido(){var tb=D.j.tb;return tb&&tb.vl2&&D.P.hp<D.st.vidaMax*.2?1.3:1;}
function velMov(){return (165+45*D.vel)*D.movF*bfRapido()*(D.P.venT>D.t?.65:1);}
function mover(o,dx,dy){
 if(D.lab){var ns=Math.max(1,Math.ceil(Math.hypot(dx,dy)/10));for(var si=0;si<ns;si++){o.x+=dx/ns;o.y+=dy/ns;resolver(o);}return;}
 o.x=clamp(o.x+dx,o.r,W-o.r);o.y=clamp(o.y+dy,o.r,H-o.r);resolver(o);}
function actualizarJugador(dt){
 var P=D.P,k=D.keys,st=D.st;
 ["atkT","dodgeT","invT","stunT","silT","potT","resStun","hurt","swing","castT"].forEach(function(n){if(P[n]>0)P[n]=Math.max(0,P[n]-dt);});
 for(var i=0;i<5;i++)if(P.cd[i]>0)P.cd[i]=Math.max(0,P.cd[i]-dt);
 if(P.defT>0){P.defT-=dt;if(P.defT<=0)P.defB=0;}
 if(P.shT>0){P.shT-=dt;if(P.shT<=0)P.sh=0;}
 P.mp=Math.min(st.recursoMax,P.mp+st.recursoMax*TUNE.regen*dt);
 if(D.tg&&!vivo(D.tg))D.tg=null;
 var T=(D.auto||k.j||D.mouse.down)?blanco():null;
 P.face=T?angA(T):Math.atan2(D.mouse.y-P.y,D.mouse.x-P.x);P.dir=dirDe(P.face);P.mv=false;D.obj=T;
 if(P.dashT>0){
  P.dashT-=dt;mover(P,P.dvx*dt,P.dvy*dt);
  if(P.dashB>0)D.E.forEach(function(e){
   if(P.dashHit.indexOf(e)>=0||Math.hypot(e.x-P.x,e.y-P.y)>e.r+P.r+8)return;
   P.dashHit.push(e);herir(e,P.dashB,{kb:120});});
  if(Math.random()<.8)D.FX.push({k:"ghost",x:P.x,y:P.y,d:P.dir,t:0,life:.25});
  if(Math.random()<.6)fx({k:"pt2",sh:"line",x:P.x,y:P.y,z:rf(8,44),vx:-P.dvx*.12,vy:-P.dvy*.12,vz:0,g:0,life:.18,col:"#ffffff",sz:2});
 }else if(P.stunT<=0){
  var de=dirEntrada();
  if(de){var v=velMov();P.mv=true;mover(P,de.x*v*dt,de.y*v*dt);}
  if(T)atacarObjetivo(T,de,dt);
  else if((D.mouse.down||k.j)&&P.atkT<=0)ataque();
 }
 /* empuje suave contra enemigos */
 D.E.forEach(function(e){
  var dx=P.x-e.x,dy=P.y-e.y,d=Math.hypot(dx,dy),mn=e.r+P.r;
  if(d<mn&&d>0){var p=(mn-d)/2;mover(P,dx/d*p,dy/d*p);e.x-=dx/d*p;e.y-=dy/d*p;}
 });
}
function ataque(T){
 var P=D.P,st=D.st,j=D.j,M=D.M,cl=CLASES[j.clase].color;
 P.atkT=intAtaque();P.swing=.16;
 if(M.dbl&&Math.random()<M.dbl)P.atkT*=.35;
 if(M.rec)P.mp=Math.min(st.recursoMax,P.mp+M.rec);
 var ang=T?angA(T):(D.melee?P.face:asistirAng(P.face)),R={Guerrero:[84,2.0],Paladin:[80,2.1],Asesino:[66,1.55]}[j.clase],nx=D.nx;
 if(nx){nx.h--;if(nx.h<=0)D.nx=null;}
 var f=gmGlob(j,-1)*(1+M.clone);
 if(D.melee){
  var ase=j.clase==="Asesino";P.sw=!P.sw;
  fx({k:"slash",x:P.x,y:P.y,a:ang,r:R[0],arc:R[1],w:ase?6:10,col:cl,flip:P.sw,life:.2});
  if(ase)fx({k:"slash",x:P.x,y:P.y,a:ang,r:R[0]*.9,arc:R[1]*.9,w:5,col:"#dcdce8",flip:!P.sw,t:-.05,life:.18});
  var hit=false,first=null;
  if(ase){ /* Asesino: el ataque básico golpea a UN solo enemigo (el objetivo si está en el cono, si no el más cercano) */
   var cand=[];cono(P.x,P.y,ang,R[0],R[1],function(e){cand.push(e);});
   var one=(T&&cand.indexOf(T)>=0)?T:cand.sort(function(a,b){return Math.hypot(a.x-P.x,a.y-P.y)-Math.hypot(b.x-P.x,b.y-P.y);})[0];
   if(one){hit=true;first=one;herir(one,rnd(st.atkMin,st.atkMax)*f*(nx?1+nx.dm:1),{crit:true,fc:!!nx,kb:90,col:cl});}
  }else cono(P.x,P.y,ang,R[0],R[1],function(e){hit=true;if(!first)first=e;herir(e,rnd(st.atkMin,st.atkMax)*f*(nx?1+nx.dm:1),{crit:true,fc:!!nx,kb:90,col:cl});});
  if(nx&&nx.bn&&first)rebotar(first,rnd(st.atkMin,st.atkMax)*f*(1+nx.dm),nx.bn);
  sfx(hit?220:300,.08,"sawtooth",.03,.5);
  if(hit)P.mp=Math.min(st.recursoMax,P.mp+st.recursoMax*TUNE.hitGain);
 }else{
  var cler=j.clase==="Clérigo",mago=j.clase==="Mago"||cler,cOrb=cler?"#ffe9a0":"#b09aff",x0=P.x+Math.cos(ang)*18,y0=P.y+Math.sin(ang)*18;
  D.PR.push({e:false,x:x0,y:y0,vx:Math.cos(ang)*(mago?560:700),vy:Math.sin(ang)*(mago?560:700),r:mago?9:5,life:.85,mult:1,basic:true,f:f,nxd:nx?{dm:nx.dm,bn:nx.bn}:null,col:mago?cOrb:"#cfe8a0",sty:mago?"orbe":"flecha",hom:T||null});
  fx({k:"flare",x:x0,y:y0,z:22,col:mago?cOrb:"#cfe8a0",s:mago?16:11,life:.14});
  sfx(mago?(cler?600:520):380,.08,"triangle",.03,mago?.7:1.4);
 }
}
function esquivar(){
 var P=D.P,k=D.keys;
 if(P.dodgeT>0||P.stunT>0||P.dashT>0)return;
 humo(P.x,P.y,3,"#b8a888",10,.35,16);
 var de=dirEntrada(),a=de?Math.atan2(de.y,de.x):P.face;
 dash(a,TUNE.dodgeDist,.2,0);P.invT=Math.max(P.invT,TUNE.dodgeInv);P.dodgeT=TUNE.dodgeCd;sfx(260,.15,"sine",.04,2);
}
function dash(a,dist,t,dmg){var P=D.P;P.dashT=t;P.dvx=Math.cos(a)*dist/t;P.dvy=Math.sin(a)*dist/t;P.dashB=dmg;P.dashHit=[];}
function pocion(t){
 if(CFG.mz){mzPocion(t);return;}
 var P=D.P,st=D.st,f=factorMaldicion(D.j,"cura");
 if(P.potT>0)return;
 if(t==="v"){if(P.pv<=0)return;P.pv--;var c=Math.floor(st.vidaMax*.25*f);P.hp=Math.min(st.vidaMax,P.hp+c);txt(P.x,P.y,"+"+c,"#7ab88a",15,24);}
 else{if(P.pr<=0)return;P.pr--;var r=Math.floor(st.recursoMax*.25*f);P.mp=Math.min(st.recursoMax,P.mp+r);txt(P.x,P.y,"+"+r,"#6a9ae8",15,24);}
 P.potT=TUNE.potCd;sfx(600,.2,"sine",.04,1.6);
}

/* ---------- daño a enemigos ---------- */
function cono(x,y,ang,rango,arc,fn){
 D.E.slice().forEach(function(e){
  var dx=e.x-x,dy=e.y-y,d=Math.hypot(dx,dy);if(d>rango+e.r)return;
  if(Math.abs(angd(Math.atan2(dy,dx),ang))<=arc/2+Math.atan2(e.r,Math.max(d,1)))fn(e);
 });
}
function circ(x,y,rad,fn){D.E.slice().forEach(function(e){if(Math.hypot(e.x-x,e.y-y)<=rad+e.r)fn(e);});}
function herir(e,raw,o){
 o=o||{};var st=D.st,j=D.j,crit=false;raw*=mejora(e);
 if(o.crit){var cp=Math.min(60,CLASES[j.clase].crit+st.critB)+(D.E.length===1?D.M.critU*100:0);if(o.fc||Math.random()*100<cp){raw*=st.critMult;crit=true;}}
 var d=danoMitigado(Math.floor(raw),Math.floor(e.def*(1-D.M.ig)),crit);
 var df=defensaEnemigo(e,d);d=df.d;
 if(df.ev==="esq"){txt(e.x+rf(-8,8),e.y,"Esquiva","#8ab0d8",13,e.r+8);sfx(300,.05,"sine",.02,1.2);return 0;}
 if(df.ev==="abs"){e.vida=Math.min(e.vidaMax,e.vida+df.cura);txt(e.x+rf(-8,8),e.y,"Absorbe +"+df.cura,"#b070e0",13,e.r+8);sfx(240,.08,"sine",.03,.8);return 0;}
 if(df.ev==="bloq")txt(e.x+rf(-8,8),e.y-12,"Bloqueo","#9aa8b8",11,e.r+8);
 e.vida-=d;e.flash=1;if(e.lab&&!e.alerta)labAlertar(e);D.dmgOut+=d;D.hitsOut++;if(d>D.maxOut)D.maxOut=d;D.dpsLog.push({t:D.t,d:d});
 var tb0=D.j.tb,lsv=D.M.ls+(tb0?(tb0.vl||0)+(tb0.rb||0):0);if(tb0)tb0.acc+=d;if(lsv)D.P.hp=Math.min(st.vidaMax,D.P.hp+Math.floor(d*lsv));
 var jf=(e.tipo==="jefe"?.2:e.tipo==="mini_jefe"?.5:1);
 if(o.kb&&!e.dummy){var a=Math.atan2(e.y-D.P.y,e.x-D.P.x);e.kx+=Math.cos(a)*o.kb*jf*4;e.ky+=Math.sin(a)*o.kb*jf*4;}
 if(o.stun&&!e.dummy)e.stunT=Math.max(e.stunT,o.stun*(e.tipo==="jefe"?.5:e.tipo==="mini_jefe"?.7:1));
 txt(e.x+rf(-8,8),e.y,String(d),crit?"#ffd24a":"#f0f0f0",crit?20:14,e.r+8);
 impacto(e,crit?"#ffd24a":(o.col||"#ffe9b0"),crit);
 if(crit)sfx(520,.1,"square",.04,1.4);else sfx(190,.06,"square",.025,.6);
 if(o.heal){var h=Math.floor(d*o.heal);D.P.hp=Math.min(st.vidaMax,D.P.hp+h);txt(D.P.x,D.P.y,"+"+h,"#7ab88a",13,24);fx({k:"drain",x1:e.x,y1:e.y,col:"#e05050",n:6,cv:16,life:.5});}
 if(netPup()&&e.lab&&!e.dummy){netEnv({k:"herida",s:e.sid,d:d,kb:o.kb||0,stun:o.stun||0,ax:D.P.x,ay:D.P.y,cr:crit?1:0});if(e.vida<1)e.vida=1;return d;}
 if(e.vida<=0&&!e.dummy)matar(e);
 return d;
}
function matar(e){
 if(e.lab&&netHost())netEnv({k:"muere",s:e.sid});
 if(e.lab&&D.lab){D.lab.kl.push(e.sid);if(e.labBoss)labJefeCae(e);else if(e.tipo==="mini_jefe")labGuardar(true);}
 if(CFG.mz&&!e.dummy)mzRecompensa(e);
 if(e.mk){if(e.mk.bf)D.j.tb={n:"Contrato",t:20,dm:e.mk.bf.dm,acc:0};if(e.mk.cof)txt(e.x,e.y,"📦 Cofre x"+e.mk.cof,"#e0c060",14,40);}
 var i=D.E.indexOf(e);if(i>=0)D.E.splice(i,1);D.kills++;if(D.tg===e)D.tg=null;
 for(var n=0;n<14;n++)D.FX.push({k:"part",x:e.x,y:e.y,vx:rf(-140,140),vy:rf(-140,140),t:0,life:rf(.3,.6),col:e.col});
 fx({k:"shock",x:e.x,y:e.y,r1:e.r*2.4,col:e.col,life:.3,low:true,rays:0});humo(e.x,e.y,3,"#6a5a4a",e.r*.5,.6,e.r*1.1);motas(e.x,e.y,5,"#d8d0ff",e.r*.4,60,.8);
 sfx(90,.25,"sawtooth",.05,.4);
}

/* ---------- habilidades ---------- */
/* Héroes melee: las habilidades de daño caen sobre el enemigo SELECCIONADO (o el más cercano si no hay selección).
   Guerrero/Paladín se abalanzan hasta él; el Asesino se teletransporta a su espalda (a cada enemigo golpeado en las cadenas). */
var MAXM=230,MAXT=320; /* alcance de habilidades melee (Guerrero/Paladín) y de teletransporte del Asesino */
function objMelee(maxd){return blanco()||masCercano(maxd||(D.j.clase==="Asesino"?MAXT:MAXM));}
function enAlcance(T,maxd){return Math.hypot(T.x-D.P.x,T.y-D.P.y)<=(maxd||(D.j.clase==="Asesino"?MAXT:MAXM))+T.r;}
function sinObjMelee(T){var P=D.P;txt(P.x,P.y,T?"Fuera de alcance":"Sin objetivo","#aaa",12,30);}
function irA(T,tele,n){
 var P=D.P,x0=P.x,y0=P.y,a=Math.atan2(T.y-y0,T.x-x0),off=T.r+P.r+(tele?4:10),d=Math.hypot(T.x-x0,T.y-y0),q;
 if(!tele&&d<=off+24)return;
 humo(x0,y0,tele?6:3,tele?"#3a2a4a":"#b8a888",12,.5,26);
 for(q=1;q<=4;q++)fx({k:"ghost",x:x0+(T.x-x0)*q/5,y:y0+(T.y-y0)*q/5,d:dirDe(a),life:.28});
 if(tele){
  var a2=a+(n||0)*2.4;
  fx({k:"beam",x1:x0,y1:y0,x2:T.x,y2:T.y,col:"#b070e0",w:7,life:.22});
  P.x=clamp(T.x+Math.cos(a2)*off,P.r,W-P.r);P.y=clamp(T.y+Math.sin(a2)*off,P.r,H-P.r);
 }else{
  P.x=clamp(T.x-Math.cos(a)*off,P.r,W-P.r);P.y=clamp(T.y-Math.sin(a)*off,P.r,H-P.r);
  chispas(P.x,P.y,6,"#ffd9a0",160,.4,18);
 }
 resolver(P);P.face=Math.atan2(T.y-P.y,T.x-P.x);
}
function lanzar(i){
 var P=D.P,h=D.hab[i],j=D.j,st=D.st,ef=h&&h.efecto,ok=true,px=P.x,py=P.y;
 if(!h||P.stunT>0||P.dashT>0)return;
 if(P.silT>0){txt(px,py,"🔇 Silenciado","#b070e0",13,30);return;}
 if(P.cd[i]>0)return;
 if(P.mp<h.costo){txt(px,py,"Sin "+j.recursoNombre,"#6a9ae8",12,30);return;}
 var M=talMods(j),bt=blanco(),ang=bt?angA(bt):asistirAng(P.face),cl=CLASES[j.clase].color;
 function B(){return rnd(st.atkMin,st.atkMax)*gmGlob(j,i);}
 function cursor(maxd){var mx=bt?bt.x:D.mouse.x,my=bt?bt.y:D.mouse.y,dx=mx-px,dy=my-py,d=Math.hypot(dx,dy)||1,k=Math.min(1,maxd/d);return{x:px+dx*k,y:py+dy*k};}
 function cercano(ref,maxd){var b=null,bd=1e9;D.E.forEach(function(e){var d=Math.hypot(e.x-ref.x,e.y-ref.y);if(d<bd&&Math.hypot(e.x-px,e.y-py)<=maxd){bd=d;b=e;}});return b;}
 function tm(fn,t){D.TM.push({t:t,fn:fn});}
 if(ef==="dano_150_stun"){
  var Tg=objMelee();
  if(!Tg||!enAlcance(Tg)){ok=false;sinObjMelee(Tg);}
  else{
  irA(Tg);px=P.x;py=P.y;ang=angA(Tg);
  fx({k:"slash",x:px,y:py,a:ang,r:118,arc:2.4,w:15,col:"#ffb060",life:.3});
  fx({k:"slash",x:px,y:py,a:ang,r:105,arc:2.2,w:10,col:"#ffe0a0",flip:true,t:-.1,life:.26});
  fx({k:"shock",x:px+Math.cos(ang)*70,y:py+Math.sin(ang)*70,r1:70,col:"#ffb060",t:-.05,life:.4,low:true,rays:8,a0:ang});
  humo(px+Math.cos(ang)*60,py+Math.sin(ang)*60,4,"#b8a080",30,.5,26);
  herir(Tg,B()*1.5,{stun:1.5,kb:150,col:"#ffb060"});
  cono(px,py,ang,115,2.4,function(e){if(e!==Tg)herir(e,B()*1.5,{stun:1.5,kb:150,col:"#ffb060"});});D.shake=4;
  }
 }else if(ef==="def_30_2t"||ef==="def_50_3t"){
  var sac=ef.indexOf("50")>=0,cd=sac?"#ffe080":"#8ab0d8";
  var bo=Math.floor(((ef.indexOf("50")>=0)?50:Math.floor(st.def*.3))*st.potencia*(1+M["bp"+i]));
  P.defB=bo;P.defT=((ef.indexOf("3t")>=0?3:2)+M.durx)*TURNO_S;
  fx({k:"shock",x:px,y:py,r1:80,col:cd,life:.5,low:true,rays:0});
  fx({k:"dome",r:36,col:cd,life:.8});motas(px,py,14,cd,24,70,.9);
  if(sac){fx({k:"pillar",x:px,y:py,col:cd,w:44,h:260,life:.7});destello("#ffe9a0",.18);}
  txt(px,py,"+"+bo+" DEF",cd,14,30);
  if(sac)netBuff({df:bo,dt:P.defT,col:cd});
 }else if(ef==="robo_vida_50"){
  var Te=objMelee();
  if(!Te||!enAlcance(Te)){ok=false;sinObjMelee(Te);}
  else{
  irA(Te);ang=angA(Te);
  fx({k:"slash",x:px,y:py,a:ang,r:122,arc:1.7,w:15,col:"#c04040",life:.3});
  fx({k:"slash",x:P.x,y:P.y,a:ang,r:100,arc:1.5,w:9,col:"#ff9080",flip:true,t:-.08,life:.24});
  chispas(P.x+Math.cos(ang)*60,P.y+Math.sin(ang)*60,8,"#c04040",200,.5,24);
  herir(Te,B(),{heal:.5,kb:100,col:"#c04040"});
  cono(P.x,P.y,ang,100,1.6,function(e){if(e!==Te)herir(e,B(),{heal:.5,kb:100,col:"#c04040"});});
  }
 }else if(ef==="escudo_vida"){
  P.sh=Math.floor(st.vidaMax*.4*st.potencia);P.shT=8;
  fx({k:"dome",r:40,col:"#8ab0d8",life:.9});
  fx({k:"shock",x:px,y:py,r1:70,col:"#8ab0d8",life:.5,low:true,rays:12,a0:0});motas(px,py,16,"#bcd8f8",26,80,1);
  txt(px,py,"Escudo "+P.sh,"#8ab0d8",14,30);
 }else if(ef==="dano_200"){
  D.PR.push({e:false,x:px,y:py,vx:Math.cos(ang)*950,vy:Math.sin(ang)*950,r:7,life:.6,raw:function(){return B()*2;},pierce:true,hit:[],col:"#f0e0a0",kb:130,sty:"tiro",hom:bt||null});
  fx({k:"beam",x1:px,y1:py,x2:px+Math.cos(ang)*260,y2:py+Math.sin(ang)*260,col:"#f0e0a0",w:5,life:.14});
  fx({k:"flare",x:px+Math.cos(ang)*20,y:py+Math.sin(ang)*20,z:24,col:"#f0e0a0",s:22,life:.2});
 }else if(ef==="aoe_75"){
  var cu0=cursor(380),mult=.45*(1+M.aoe);
  D.FX.push({k:"mark",x:cu0.x,y:cu0.y,r:120,t:0,life:1.2,col:"#9ad060"});
  fx({k:"rune",x:cu0.x,y:cu0.y,r:120,col:"#9ad060",life:1.2,low:true,rot:1.2});
  [.35,.7,1.05].forEach(function(t){
   lluvia(cu0.x,cu0.y,115,9,"#d8e8a0",t,2.6,26);
   tm(function(){fx({k:"shock",x:cu0.x,y:cu0.y,r1:120,col:"#9ad060",life:.3,low:true,rays:0});circ(cu0.x,cu0.y,120,function(e){herir(e,B()*mult,{kb:40,col:"#d8e8a0"});});sfx(300,.08,"triangle",.03,.5);},t);
  });
 }else if(ef==="aoe_140"){
  var Ta=objMelee();
  if(!Ta||!enAlcance(Ta)){ok=false;sinObjMelee(Ta);}
  else{
  var ax=Ta.x,ay=Ta.y;
  fx({k:"shock",x:ax,y:ay,r1:158,col:"#ffe080",life:.45,low:true,rays:14,a0:0});
  fx({k:"pillar",x:ax,y:ay,col:"#ffe080",w:60,h:280,life:.5});
  chispas(ax,ay,16,"#fff0b0",330,.6,22);motas(ax,ay,10,"#ffe080",60,80,.8);destello("#fff2c0",.2);
  circ(ax,ay,155,function(e){herir(e,B()*1.4*(1+M.aoe),{kb:120,col:"#ffe080"});});D.shake=5;
  }
 }else if(ef==="vida_max_75"){
  var cu=Math.floor(st.vidaMax*.75);P.hp=Math.min(st.vidaMax,P.hp+cu);
  fx({k:"pillar",x:px,y:py,col:"#7ab88a",w:56,h:290,life:.9});
  fx({k:"shock",x:px,y:py,r1:110,col:"#7ab88a",life:.6,low:true,rays:0});
  motas(px,py,24,"#c8ffd8",36,100,1.1);destello("#d0ffd8",.14);
  D.FX.push({k:"ring",x:px,y:py,r0:60,r1:10,t:0,life:.5,col:"#7ab88a",fill:false,follow:true});txt(px,py,"+"+cu,"#7ab88a",18,30);
 }else if(ef==="fuego_250"){
  D.PR.push({e:false,x:px,y:py,vx:Math.cos(ang)*520,vy:Math.sin(ang)*520,r:12,life:1.2,raw:function(){return B()*2.5;},explode:{r:95,f:.5,raw:function(){return B()*2.5;}},col:"#ff7a30",sty:"fuego",hom:bt||null});
  fx({k:"flare",x:px+Math.cos(ang)*18,y:py+Math.sin(ang)*18,z:26,col:"#ff9a3a",s:24,life:.25});
 }else if(ef==="stun_aoe"){
  fx({k:"shock",x:px,y:py,r1:188,col:"#7ab8d8",life:.5,low:true,rays:12,a0:0});
  hielo(px,py,18,188);humo(px,py,10,"#bfe6ff",60,.9,50);destello("#cfeaff",.2);
  circ(px,py,185,function(e){herir(e,B()*.7*(1+M.aoe),{stun:2,kb:60,col:"#bfe6ff"});});D.shake=4;
 }else if(ef==="punalada"){
  var t=objMelee();
  if(!t||!enAlcance(t)){ok=false;sinObjMelee(t);}
  else{
   irA(t,true,0);
   herir(t,B()*2.5,{kb:40,col:"#b070e0"});
   fx({k:"xslash",x:t.x,y:t.y,col:"#b070e0",s:34,life:.32});
   fx({k:"shock",x:t.x,y:t.y,r1:60,col:"#b070e0",life:.3,low:true,rays:0});
  }
 }else if(ef==="stun_2"){
  humo(px,py,26,"#8a8a96",120,1.1,70);humo(px,py,10,"#2a2a34",90,1.2,60);
  fx({k:"shock",x:px,y:py,r1:168,col:"#aaaab8",life:.5,low:true,rays:0});chispas(px,py,10,"#ffd080",260,.5,20);
  circ(px,py,165,function(e){if(!e.dummy)e.stunT=Math.max(e.stunT,3.5*(e.tipo==="jefe"?.5:e.tipo==="mini_jefe"?.7:1));});
  P.invT=Math.max(P.invT,2);txt(px,py,"Inmune","#7ab88a",13,30);
 }else if(ef==="atk_mult"){
  /* orden de golpes: el seleccionado primero y luego los de menor vida; si hay menos de 3 se repite el ciclo */
  var bt2=objMelee(),ls=D.E.filter(function(e){return e!==bt2&&Math.hypot(e.x-px,e.y-py)<=MAXT;}).sort(function(a,b){return a.vida-b.vida;});
  if(bt2)ls=[bt2].concat(ls);
  ls=ls.slice(0,3);
  if(!ls.length||!enAlcance(ls[0])){ok=false;sinObjMelee(ls[0]);}
  else for(var q=0;q<3;q++)(function(q){var t=ls[q%ls.length];tm(function(){
   if(D.E.indexOf(t)<0)return;
   irA(t,true,Math.floor(q/ls.length));
   fx({k:"xslash",x:t.x,y:t.y,col:"#c070d0",s:28,ro:q*.6,life:.28});
   herir(t,B(),{kb:30,col:"#c070d0"});
  },q*.18);})(q);
 }else if(ef==="inmunidad_60"){
  var de=dirEntrada();
  humo(px,py,5,"#9ab89a",12,.45,22);fx({k:"shock",x:px,y:py,r1:55,col:"#9ad060",life:.3,low:true,rays:0});
  dash(de?Math.atan2(de.y,de.x):ang,240,.22,B()*.6);P.invT=Math.max(P.invT,2);
 }else if(ef==="pulso_vital"){
  var cv=Math.floor(st.vidaMax*.25*curaMult(j)*(1+M.bp0)),cvr=175;
  P.hp=Math.min(st.vidaMax,P.hp+cv);
  fx({k:"rune",x:px,y:py,r:cvr,col:"#8ff0d0",life:.9,low:true,rot:1.4});
  fx({k:"shock",x:px,y:py,r1:cvr,col:"#ffe9a0",life:.5,low:true,rays:12,a0:0});
  fx({k:"pillar",x:px,y:py,col:"#9ff0d8",w:56,h:260,life:.7});
  motas(px,py,22,"#c8ffe8",40,100,1.1);destello("#d8fff0",.14);
  D.FX.push({k:"ring",x:px,y:py,r0:20,r1:cvr*.6,t:0,life:.5,col:"#8ff0d0",fill:false,follow:true});
  txt(px,py,"+"+cv,"#7ab88a",18,30);
  netBuff({hf:.25*curaMult(j)*(1+M.bp0),col:"#8ff0d0"});
  circ(px,py,cvr,function(e){herir(e,B()*1.1*(1+M.aoe),{kb:70,col:"#ffe9a0"});});D.shake=3;
 }else if(ef==="egida_rad"){
  var bo2=Math.floor(st.def*.4*st.potencia*(1+M.bp1)),es2=Math.floor(st.vidaMax*.2*st.potencia*(1+M.cura));
  P.defB=bo2;P.defT=(3+M.durx)*TURNO_S;P.sh=es2;P.shT=Math.max(8,P.defT);
  fx({k:"dome",r:42,col:"#8ff0d0",life:1});fx({k:"shock",x:px,y:py,r1:90,col:"#8ff0d0",life:.5,low:true,rays:12,a0:0});
  motas(px,py,16,"#c8ffe8",26,80,1);
  txt(px,py,"+"+bo2+" DEF · Escudo "+es2,"#8ff0d0",13,30);
  netBuff({df:bo2,dt:P.defT,sf:.2*st.potencia*(1+M.cura),col:"#8ff0d0"});
 }else if(ef==="pureza"){
  purgarControl();
  j.tb={n:"Pureza",t:(3+M.durx)*TURNO_S,dm:.25*potBuff(st)*(1+M.bp2),cc:1,acc:0};
  fx({k:"pillar",x:px,y:py,col:"#ffe9a0",w:50,h:260,life:.8});fx({k:"dome",r:38,col:"#ffe9a0",life:.9});
  motas(px,py,18,"#fff2c0",30,90,1);destello("#fff2c0",.14);
  txt(px,py,"✨ Purga · +"+Math.round(j.tb.dm*100)+"% daño","#ffe9a0",13,30);
  netBuff({pur:1,tb:{n:"Pureza",t:j.tb.t,dm:j.tb.dm,cc:1},col:"#ffe9a0"});
 }else if(ef==="rama"){ok=lanzarRama(h.rama,i);}else ok=false;
 if(ok){P.mp-=h.costo;P.cd[i]=h.cd*TURNO_S;lanzando(cl);sfx(340,.18,"sawtooth",.04,1.8);}
}

/* ---------- actualización ---------- */

function actualizar(dt){
 if(D.lab&&D.mapaGrande)return;
 D.t+=dt;
 ratonMundo();navAct();
 actualizarJugador(dt);
 if(D.lab)labActualizar(dt);
 if(D.net&&D.net.on)netTick(dt);
 camara(dt);
 D.j.vida=D.P.hp;
 var tb=D.j.tb;
 if(tb&&tb.t>0&&Math.random()<dt*16)motas(D.P.x,D.P.y,1,CLASES[D.j.clase].color,16,55,.7);
 if(D.nx&&Math.random()<dt*10)motas(D.P.x,D.P.y,1,"#ffe080",14,70,.6);
 if(D.M.regT)D.P.hp=Math.min(D.st.vidaMax,D.P.hp+D.st.vidaMax*D.M.regT*dt/TURNO_S);
 if(tb){tb.t-=dt;if(tb.reg)D.P.hp=Math.min(D.st.vidaMax,D.P.hp+D.st.vidaMax*tb.reg*dt/TURNO_S);
  if(tb.t<=0){if(tb.hp&&tb.acc){var hh=Math.floor(tb.acc*tb.hp);D.P.hp=Math.min(D.st.vidaMax,D.P.hp+hh);txt(D.P.x,D.P.y,"+"+hh,"#7ab88a",15,30);}D.j.tb=null;}}
 /* temporizadores diferidos */
 for(var i=D.TM.length-1;i>=0;i--){D.TM[i].t-=dt;if(D.TM[i].t<=0){var f=D.TM[i].fn;D.TM.splice(i,1);f();}}
 /* enemigos */
 var pup=netPup();
 D.E.forEach(function(e){if(pup)netPupPaso(e,dt);else iaEnemigo(e,dt);});
 for(var a=0;a<D.E.length&&!pup;a++)for(var b=a+1;b<D.E.length;b++){
  var A=D.E[a],Bn=D.E[b],dx=Bn.x-A.x,dy=Bn.y-A.y,d=Math.hypot(dx,dy),mn=A.r+Bn.r;
  if(d<mn&&d>0){var p=(mn-d)/2;if(!A.dummy){A.x-=dx/d*p;A.y-=dy/d*p;}if(!Bn.dummy){Bn.x+=dx/d*p;Bn.y+=dy/d*p;}}
 }
 if(!pup)D.E.forEach(function(e){if(!e.dummy)resolver(e);else{e.x=clamp(e.x,e.r,W-e.r);e.y=clamp(e.y,e.r,H-e.r);}});
 trActualizar(dt);
 /* proyectiles */
 for(var k=D.PR.length-1;k>=0;k--){
  var p2=D.PR[k];
  if(p2.hom&&vivo(p2.hom)&&!(p2.hit&&p2.hit.indexOf(p2.hom)>=0)){var sp0=Math.hypot(p2.vx,p2.vy),ca=Math.atan2(p2.vy,p2.vx),da=clamp(angd(Math.atan2(p2.hom.y-p2.y,p2.hom.x-p2.x),ca),-9*dt,9*dt);ca+=da;p2.vx=Math.cos(ca)*sp0;p2.vy=Math.sin(ca)*sp0;}
  var ox=p2.x,oy=p2.y;p2.x+=p2.vx*dt;p2.y+=p2.vy*dt;p2.life-=dt;
  if(p2.sty&&D.FX.length<380){p2.te=(p2.te||0)+dt;var iv=p2.sty==="fuego"?.016:.03;while(p2.te>iv){p2.te-=iv;trailPr(p2);}}
  var fuera=p2.x<-20||p2.x>W+20||p2.y<-20||p2.y>H+20,fin=p2.life<=0||fuera;
  if(!fin&&(D.lab?labRayo(ox,oy,p2.x,p2.y):D.mapa.ob.some(function(b){return b.alto&&p2.x>b.x&&p2.x<b.x+b.w&&p2.y>b.y&&p2.y<b.y+b.h;}))){fin=true;if(!p2.e&&p2.explode)boom(p2.x,p2.y,p2.explode.r,"#ff7a30");p2.explode=null;D.FX.push({k:"part",x:p2.x,y:p2.y,vx:rf(-60,60),vy:rf(-60,60),t:0,life:.25,col:"#aaa"});}
  if(p2.e){
   if(Math.hypot(D.P.x-p2.x,D.P.y-p2.y)<p2.r+D.P.r){golpeAJugador(p2.src,p2.mult,p2.tipo,null);fin=true;}
  }else if(!fin){
   for(var m=0;m<D.E.length;m++){
    var e=D.E[m];
    if(Math.hypot(e.x-p2.x,e.y-p2.y)<e.r+p2.r){
     if(p2.pierce){if(p2.hit.indexOf(e)>=0)continue;p2.hit.push(e);herir(e,p2.raw(),{kb:p2.kb});continue;}
     if(p2.basic){var rb=rnd(D.st.atkMin,D.st.atkMax)*p2.f*(p2.nxd?1+p2.nxd.dm:1);herir(e,rb,{crit:true,fc:!!p2.nxd,kb:70});if(p2.nxd&&p2.nxd.bn)rebotar(e,rb,p2.nxd.bn);}
     else herir(e,p2.raw(),{kb:90});
     if(p2.basic)D.P.mp=Math.min(D.st.recursoMax,D.P.mp+D.st.recursoMax*TUNE.hitGain);
     if(p2.explode){
      var ex=p2.explode;boom(p2.x,p2.y,ex.r,"#ff7a30");destello("#ffb060",.12);
      circ(p2.x,p2.y,ex.r,function(o){if(o!==e)herir(o,ex.raw()*ex.f,{kb:80});});D.shake=5;sfx(100,.25,"sawtooth",.05,.4);
     }
     fin=true;break;
    }
   }
  }
  if(fin){
   if(!p2.e&&p2.explode&&p2.life<=0&&!fuera)boom(p2.x,p2.y,p2.explode.r,"#ff7a30");
   D.PR.splice(k,1);
  }
 }
 /* efectos y textos */
 for(var q=D.FX.length-1;q>=0;q--){
  var x=D.FX[q];x.t+=dt;
  if(x.t>0){
   if(x.vx!==undefined){x.x+=x.vx*dt;x.y+=x.vy*dt;}
   if(x.vz!==undefined){x.z+=x.vz*dt;x.vz-=(x.g||0)*dt;if(x.z<0){x.z=0;x.vz=Math.abs(x.vz)*.2;}}
  }
  if(x.t>=x.life){if(x.fin)x.fin(x);D.FX.splice(q,1);}
 }
 for(var r=D.TX.length-1;r>=0;r--){var T=D.TX[r];T.a+=dt;T.y-=28*dt;T.x+=(T.vx||0)*dt;if(T.a>=T.life)D.TX.splice(r,1);}
 D.shake=Math.max(0,D.shake-dt*20);
 if(D.fl){D.fl.a-=dt*2.4;if(D.fl.a<=0)D.fl=null;}
 if(D.banner.t>0)D.banner.t-=dt;
 while(D.dpsLog.length&&D.t-D.dpsLog[0].t>5)D.dpsLog.shift();
 /* oleadas */
 if(!D.dummy&&!D.lab&&D.E.length===0&&D.estado==="play"){
  if(CFG.inf&&D.wave>0&&D.cobrada!==D.wave){D.cobrada=D.wave;mzInfSuperada(D.wave);}
  if(D.wave>=D.waves){terminar(true);return;}
  D.waveWait-=dt;if(D.waveWait<=0){oleada();D.waveWait=1.5;}
 }
}
function terminar(gana){
 if(D.estado!=="play")return;
 D.estado=gana?"win":"lose";
 if(CFG.mz){mzFin(gana);return;}
 var p=document.getElementById("dmEnd");p.style.display="flex";
 var dps=D.t>0?Math.floor(D.dmgOut/D.t):0;
 p.innerHTML='<div class="card" style="text-align:center;min-width:280px"><div class="font-disp" style="font-size:24px;color:'+(gana?'#7ab88a':'#e06a5a')+';margin-bottom:10px">'+(gana?'¡Victoria!':'Derrota')+'</div><div style="font-size:13px;line-height:1.8;margin-bottom:14px">Tiempo: '+D.t.toFixed(1)+' s<br>Enemigos derrotados: '+D.kills+'<br>Daño infligido: '+D.dmgOut+' ('+dps+' DPS medio · '+D.hitsOut+' golpes · medio '+(D.hitsOut?Math.floor(D.dmgOut/D.hitsOut):0)+' · máx '+D.maxOut+')<br>Daño recibido: '+D.dmgIn+' ('+D.hitsIn+' golpes · medio '+(D.hitsIn?Math.floor(D.dmgIn/D.hitsIn):0)+' · máx '+D.maxIn+')</div><div style="display:flex;gap:8px;justify-content:center;flex-wrap:wrap"><button class="btn btn-primary" id="dmAg">Repetir</button><button class="btn" id="dmCf">Configurar</button><button class="btn btn-danger" id="dmEx">Salir</button></div></div>';
 document.getElementById("dmAg").onclick=function(){iniciarMismo();};
 document.getElementById("dmCf").onclick=abrir;
 document.getElementById("dmEx").onclick=cerrar;
 sfx(gana?660:90,.5,"triangle",.06,gana?1.5:.4);
}
function iniciarMismo(){
 if(RAF)cancelAnimationFrame(RAF);RAF=0;
 window.removeEventListener("keydown",kd);window.removeEventListener("keyup",ku);window.removeEventListener("blur",pausar);window.removeEventListener("pointerup",mu);window.removeEventListener("pointercancel",mu);
 iniciar();
}

/* ---------- capa estática del mapa (suelo + paredes), recortada del estilo del Área de Entrenamiento ---------- */
function seed(s){return function(){s|=0;s=s+0x6D2B79F5|0;var t=Math.imul(s^s>>>15,1|s);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296;};}

function banner(g,u0,w,y0,h,col){
 col=col||["#26468c","#17306a"];
 g.fillStyle="#2a170a";g.fillRect(u0-.1,y0-5,w+.2,4);
 g.fillStyle="#c9923c";g.fillRect(u0-.05,y0-3,w+.1,1.2);
 g.beginPath();g.moveTo(u0,y0);g.lineTo(u0+w,y0);g.lineTo(u0+w,y0+h);g.lineTo(u0+w/2,y0+h-12);g.lineTo(u0,y0+h);g.closePath();
 var gd=g.createLinearGradient(0,y0,0,y0+h);gd.addColorStop(0,col[0]);gd.addColorStop(1,col[1]);g.fillStyle=gd;g.fill();
 g.fillStyle="#c9923c";g.fillRect(u0,y0,.035,h-5);g.fillRect(u0+w-.035,y0,.035,h-5);
 g.fillStyle="#e8c46a";g.beginPath();g.ellipse(u0+w/2,y0+h*.36,.2,8,0,0,7);g.fill();
 g.fillStyle=col[1];g.beginPath();g.ellipse(u0+w/2,y0+h*.36,.13,5,0,0,7);g.fill();
 g.fillStyle="#e8c46a";g.fillRect(u0+w/2-.03,y0+h*.36-6,.06,12);g.fillRect(u0+w/2-.12,y0+h*.36-2,.24,1.6);
}
/* ventana de madera con rejilla (como las casas de tu hoja) */
function ventana(g,u0,w,yt,h){
 var yb=yt+h;
 g.fillStyle="#3b2412";g.fillRect(u0-.1,yt-5,w+.2,h+11);
 g.fillStyle="rgba(255,225,170,.25)";g.fillRect(u0-.1,yt-5,w+.2,1);
 var gd=g.createLinearGradient(0,yt,0,yb);gd.addColorStop(0,"#5d7fae");gd.addColorStop(1,"#2c3d5e");g.fillStyle=gd;g.fillRect(u0,yt,w,h);
 g.fillStyle="rgba(190,215,255,.30)";g.fillRect(u0,yt,w,h*.38);
 g.fillStyle="#2a170a";g.fillRect(u0+w/2-.025,yt,.05,h);
 for(var i=1;i<4;i++)g.fillRect(u0,yt+h*i/4-1,w,2.2);
 g.fillStyle="#4a2e16";g.fillRect(u0-.14,yb+3,w+.28,5);g.fillStyle="rgba(255,225,170,.25)";g.fillRect(u0-.14,yb+3,w+.28,1);
}


/* ---------- MAZMORRA: objetos procedurales (se ordenan por profundidad junto a enemigos y jugador) ---------- */
var ST={t:"#7b7a84",l:"#55545d",r:"#403f48"};
function mazPiezas(s){var R=seed(s),a=[],n=5+Math.floor(R()*3);for(var i=0;i<n;i++)a.push({dx:(R()-.5)*34,dy:(R()-.5)*34,w:5+R()*9,h:5+R()*9,z:3+R()*8,t:R()});return a;}
/* caja isométrica entre las alturas z0 y z1 (x,y = esquina del suelo, w,h en unidades de mundo) */
function cajaZ(c,x,y,w,h,z0,z1,top,lf,rt){
 var A=pj(x,y),B=pj(x+w,y),C=pj(x+w,y+h),Q=pj(x,y+h);
 c.fillStyle=lf;c.beginPath();c.moveTo(Q.x,Q.y-z0);c.lineTo(C.x,C.y-z0);c.lineTo(C.x,C.y-z1);c.lineTo(Q.x,Q.y-z1);c.closePath();c.fill();
 c.fillStyle=rt;c.beginPath();c.moveTo(C.x,C.y-z0);c.lineTo(B.x,B.y-z0);c.lineTo(B.x,B.y-z1);c.lineTo(C.x,C.y-z1);c.closePath();c.fill();
 c.fillStyle=top;c.beginPath();c.moveTo(A.x,A.y-z1);c.lineTo(B.x,B.y-z1);c.lineTo(C.x,C.y-z1);c.lineTo(Q.x,Q.y-z1);c.closePath();c.fill();
 c.strokeStyle="rgba(8,6,10,.55)";c.lineWidth=1;c.beginPath();c.moveTo(Q.x,Q.y-z0);c.lineTo(Q.x,Q.y-z1);c.lineTo(A.x,A.y-z1);c.lineTo(B.x,B.y-z1);c.lineTo(C.x,C.y-z1);c.lineTo(Q.x,Q.y-z1);c.moveTo(C.x,C.y-z0);c.lineTo(C.x,C.y-z1);c.moveTo(B.x,B.y-z0);c.lineTo(B.x,B.y-z1);c.stroke();
}
/* juntas de sillería en las dos caras visibles */
function juntas(c,x,y,w,h,z0,z1,n){
 var B=pj(x+w,y),C=pj(x+w,y+h),Q=pj(x,y+h);
 c.strokeStyle="rgba(8,6,10,.38)";c.lineWidth=1;c.beginPath();
 for(var i=1;i<n;i++){var zz=z0+(z1-z0)*i/n;c.moveTo(Q.x,Q.y-zz);c.lineTo(C.x,C.y-zz);c.lineTo(B.x,B.y-zz);}
 c.stroke();
}
function sombraObj(c,x,y,r){c.fillStyle="rgba(0,0,0,.38)";elip(c,x,y,r,true);}
var PD={
 fogata:function(c,o){
  var p=pj(o.x,o.y),f=1+.12*Math.sin(D.t*11+o.x)+.08*Math.sin(D.t*17+o.y);
  sombraObj(c,o.x,o.y,17);
  for(var i=0;i<8;i++){var a=i/8*Math.PI*2,sx=p.x+Math.cos(a)*13,sy=p.y+8+Math.sin(a)*6.5;c.fillStyle=i%2?"#6a665f":"#55524c";c.beginPath();c.ellipse(sx,sy,5,3.4,0,0,7);c.fill();c.fillStyle="rgba(255,255,255,.12)";c.fillRect(sx-3,sy-3,5,1.5);}
  c.strokeStyle="#4a2e16";c.lineWidth=4;c.lineCap="round";c.beginPath();c.moveTo(p.x-9,p.y+9);c.lineTo(p.x+8,p.y+4);c.moveTo(p.x+9,p.y+9);c.lineTo(p.x-8,p.y+4);c.stroke();c.lineCap="butt";
  c.fillStyle="#d8501c";c.beginPath();c.ellipse(p.x,p.y-2,7*f,14*f,0,0,7);c.fill();
  c.fillStyle="#ff9a2e";c.beginPath();c.ellipse(p.x,p.y,5*f,10*f,0,0,7);c.fill();
  c.fillStyle="#ffe58a";c.beginPath();c.ellipse(p.x,p.y+2,2.6*f,6*f,0,0,7);c.fill();
 },
 cristal:function(c,o){
  var p=pj(o.x,o.y),s=o.s||1,col=o.col||"120,170,255",gl=.55+.25*Math.sin(D.t*2.4+o.x);
  sombraObj(c,o.x,o.y,13*s);
  [[-10,2,6,26],[0,5,8,44],[10,2,6,22],[-4,-1,5,17],[5,0,5,15]].forEach(function(q){
   var bx=p.x+q[0]*s,by=p.y+8+q[1]*s,w=q[2]*s,h=q[3]*s;
   function cont(){c.beginPath();c.moveTo(bx-w,by);c.lineTo(bx-w*.8,by-h*.78);c.lineTo(bx,by-h);c.lineTo(bx+w*.8,by-h*.78);c.lineTo(bx+w,by);c.closePath();}
   cont();c.fillStyle="rgba("+col+",.95)";c.fill();c.strokeStyle="rgba(10,10,40,.55)";c.lineWidth=1;c.stroke();
   c.fillStyle="rgba(255,255,255,.38)";c.beginPath();c.moveTo(bx-w,by);c.lineTo(bx-w*.8,by-h*.78);c.lineTo(bx,by-h);c.lineTo(bx-w*.15,by);c.closePath();c.fill();
   c.fillStyle="rgba(0,0,30,.3)";c.beginPath();c.moveTo(bx+w*.25,by);c.lineTo(bx,by-h);c.lineTo(bx+w*.8,by-h*.78);c.lineTo(bx+w,by);c.closePath();c.fill();
  });
  c.save();c.globalCompositeOperation="lighter";var gr=c.createRadialGradient(p.x,p.y-14*s,1,p.x,p.y-14*s,34*s);gr.addColorStop(0,"rgba("+col+","+(.3*gl)+")");gr.addColorStop(1,"rgba("+col+",0)");c.fillStyle=gr;c.fillRect(p.x-40*s,p.y-52*s,80*s,80*s);c.restore();
 },
 pilar:function(c,o){
  var x=o.x-o.w/2,y=o.y-o.h/2,w=o.w,h=o.h,z=o.z||104;
  sombraObj(c,o.x+4,o.y+4,w*.85);
  cajaZ(c,x-3,y-3,w+6,h+6,0,10,ST.t,ST.l,ST.r);
  cajaZ(c,x+2,y+2,w-4,h-4,10,o.roto?z:z-12,o.roto?"#8f8e99":"#6d6c76","#4c4b54","#383740");
  juntas(c,x+2,y+2,w-4,h-4,10,o.roto?z:z-12,o.roto?3:6);
  if(o.roto){cajaZ(c,x+w*.55,y+h*.7,10,8,0,6,"#6d6c76","#4c4b54","#383740");cajaZ(c,x-6,y+h*.2,8,7,0,5,"#6d6c76","#4c4b54","#383740");}
  else cajaZ(c,x-3,y-3,w+6,h+6,z-12,z,ST.t,ST.l,ST.r);
 },
 brasero:function(c,o){
  var p=pj(o.x,o.y),b=p.y-36,f=D.t*9+o.x*.1;
  sombraObj(c,o.x,o.y,15);
  cajaZ(c,o.x-10,o.y-10,20,20,0,9,ST.t,ST.l,ST.r);
  cajaZ(c,o.x-6,o.y-6,12,12,9,30,"#6d6c76","#4c4b54","#383740");
  c.fillStyle="#2b2622";c.strokeStyle="#15110e";c.lineWidth=1.5;c.beginPath();c.ellipse(p.x,b+2,17,8.5,0,0,7);c.fill();c.stroke();
  c.fillStyle="#d05a1c";c.beginPath();c.ellipse(p.x,b,13,6,0,0,7);c.fill();
  var cols=["rgba(255,110,30,.92)","rgba(255,185,60,.95)","rgba(255,245,170,.95)"];
  for(var i=0;i<3;i++){
   var w=9-i*2.6,hh=(26-i*7)*(1+.2*Math.sin(f*1.3+i*2)),sx=Math.sin(f+i)*2.5;
   c.fillStyle=cols[i];c.beginPath();c.moveTo(p.x-w,b);c.quadraticCurveTo(p.x-w+sx,b-hh*.6,p.x+sx,b-hh);c.quadraticCurveTo(p.x+w+sx,b-hh*.6,p.x+w,b);c.closePath();c.fill();
  }
 },
 sarcofago:function(c,o){
  var x=o.x-o.w/2,y=o.y-o.h/2;
  sombraObj(c,o.x+3,o.y+3,Math.max(o.w,o.h)*.6);
  cajaZ(c,x,y,o.w,o.h,0,22,"#7a7983","#55545d","#403f48");
  cajaZ(c,x+3,y+3,o.w-6,o.h-6,22,30,"#8b8a94","#5e5d66","#4a4952");
  var a=pj(x+o.w*.18,y+o.h/2),b=pj(x+o.w*.82,y+o.h/2),m=pj(x+o.w*.4,y+o.h/2),k1=pj(x+o.w*.4,y+o.h*.3),k2=pj(x+o.w*.4,y+o.h*.7);
  c.strokeStyle="rgba(20,16,24,.6)";c.lineWidth=2;c.beginPath();c.moveTo(a.x,a.y-30);c.lineTo(b.x,b.y-30);c.moveTo(k1.x,k1.y-30);c.lineTo(k2.x,k2.y-30);c.stroke();
 },
 altar:function(c,o){
  var x=o.x-o.w/2,y=o.y-o.h/2,p=pj(o.x,o.y),pulso=.55+.3*Math.sin(D.t*2.4);
  sombraObj(c,o.x+4,o.y+4,Math.max(o.w,o.h)*.62);
  cajaZ(c,x-4,y-4,o.w+8,o.h+8,0,8,ST.t,ST.l,ST.r);
  cajaZ(c,x+4,y+4,o.w-8,o.h-8,8,34,"#6d6c76","#4c4b54","#383740");
  juntas(c,x+4,y+4,o.w-8,o.h-8,8,34,3);
  cajaZ(c,x-1,y-1,o.w+2,o.h+2,34,42,ST.t,ST.l,ST.r);
  c.save();c.globalCompositeOperation="lighter";
  c.fillStyle="rgba("+(o.col||"150,90,255")+","+(pulso*.75)+")";c.beginPath();c.ellipse(p.x,p.y-42,o.w*.30,o.w*.15,0,0,7);c.fill();
  var g=c.createLinearGradient(0,p.y-42-70,0,p.y-42);g.addColorStop(0,"rgba("+(o.col||"150,90,255")+",0)");g.addColorStop(1,"rgba("+(o.col||"150,90,255")+","+(pulso*.35)+")");
  c.fillStyle=g;c.fillRect(p.x-9,p.y-42-70,18,70);c.restore();
 },
 mesa:function(c,o){
  var x=o.x-o.w/2,y=o.y-o.h/2;
  sombraObj(c,o.x+3,o.y+3,Math.max(o.w,o.h)*.55);
  cajaZ(c,x+6,y+3,9,o.h-6,0,24,"#5a3d22","#3e2814","#2e1d0e");cajaZ(c,x+o.w-15,y+3,9,o.h-6,0,24,"#5a3d22","#3e2814","#2e1d0e");
  cajaZ(c,x,y,o.w,o.h,24,31,"#7b5632","#573a1f","#432c16");
  var a=pj(x+o.w*.2,y+o.h*.5),b=pj(x+o.w*.8,y+o.h*.5);c.strokeStyle="rgba(20,10,4,.45)";c.lineWidth=1.5;c.beginPath();c.moveTo(a.x,a.y-31);c.lineTo(b.x,b.y-31);c.stroke();
  /* grilletes */
  c.strokeStyle="#9a9aa2";c.lineWidth=2;[.15,.85].forEach(function(u){var q=pj(x+o.w*u,y+o.h*.5);c.beginPath();c.arc(q.x,q.y-34,3,0,7);c.stroke();});
 },
 reja:function(c,o){
  var x0=o.x-o.w/2,y=o.y,A=pj(x0,y),B=pj(x0+o.w,y),H=94;
  c.fillStyle="rgba(6,4,8,.5)";c.beginPath();c.moveTo(A.x,A.y);c.lineTo(B.x,B.y);c.lineTo(B.x,B.y-H);c.lineTo(A.x,A.y-H);c.closePath();c.fill();
  c.lineCap="round";
  for(var x=x0;x<=x0+o.w+.1;x+=11){var p=pj(x,y);c.strokeStyle="#2a2a30";c.lineWidth=4;c.beginPath();c.moveTo(p.x,p.y);c.lineTo(p.x,p.y-H);c.stroke();c.strokeStyle="#6a6a74";c.lineWidth=1.5;c.beginPath();c.moveTo(p.x-1,p.y);c.lineTo(p.x-1,p.y-H);c.stroke();}
  [4,48,H-2].forEach(function(z){c.strokeStyle="#34343b";c.lineWidth=5;c.beginPath();c.moveTo(A.x,A.y-z);c.lineTo(B.x,B.y-z);c.stroke();c.strokeStyle="rgba(180,180,190,.35)";c.lineWidth=1.2;c.beginPath();c.moveTo(A.x,A.y-z-1.5);c.lineTo(B.x,B.y-z-1.5);c.stroke();});
  c.lineCap="butt";
 },
 huesos:function(c,o){
  var p=pj(o.x,o.y),s=o.s||1;
  c.save();c.translate(p.x,p.y+3);c.scale(s,s);c.lineCap="round";
  c.strokeStyle="#cfc7b0";c.lineWidth=3;
  [[-13,2,6,-3],[-9,6,13,4],[-4,-4,11,-8],[5,3,16,-1]].forEach(function(a){c.beginPath();c.moveTo(a[0],a[1]);c.lineTo(a[2],a[3]);c.stroke();});
  c.fillStyle="#d8d0ba";c.beginPath();c.ellipse(-3,-3,6.5,5.5,0,0,7);c.fill();c.fillRect(-6,0,7,4);
  c.fillStyle="#1a1612";c.beginPath();c.arc(-5,-3.5,1.5,0,7);c.arc(-1,-3.5,1.5,0,7);c.fill();
  c.restore();
 },
 escombros:function(c,o){
  var p=pj(o.x,o.y);
  c.fillStyle="rgba(0,0,0,.28)";c.beginPath();c.ellipse(p.x,p.y+3,22,9,0,0,7);c.fill();
  (o.pz||[]).forEach(function(q){
   var u=pj(o.x+q.dx,o.y+q.dy),sh=60+Math.floor(q.t*40);
   c.fillStyle="rgb("+sh+","+(sh-2)+","+(sh+8)+")";c.beginPath();c.moveTo(u.x-q.w/2,u.y+2);c.lineTo(u.x-q.w*.3,u.y-q.z);c.lineTo(u.x+q.w*.35,u.y-q.z*.8);c.lineTo(u.x+q.w/2,u.y+2);c.closePath();c.fill();
   c.fillStyle="rgba(255,255,255,.12)";c.beginPath();c.moveTo(u.x-q.w*.3,u.y-q.z);c.lineTo(u.x+q.w*.35,u.y-q.z*.8);c.lineTo(u.x+q.w*.2,u.y-q.z*.4);c.lineTo(u.x-q.w*.2,u.y-q.z*.5);c.closePath();c.fill();
  });
 }
};

/* ---------- MAZMORRA: trampas ----------
   Tipos (rectángulos de celdas):
     pinchos  ciclo: oculto → aviso (rojo, 0.8 s) → pinchos fuera (0.7 s). 1 golpe por activación.
     llamas   ciclo con conducto de fuego (aviso naranja 1 s, 1.5 s de llamas con daño por pulsos).
     glifo    se activa al pisarlo (jugador O enemigo): 0.6 s de aviso y explosión arcana + silencio/aturdimiento. Se recarga 7 s.
     veneno   charco: daño por pulsos y ralentiza (jugador −35 %, enemigos −30 %).
   Dañan al jugador (% de su vida máx., reducido por RD y escudo) y a los enemigos (% de su vida máx.; jefes ×.25, mini-jefes ×.5).
   Ajuste global: TUNE.trampas (0 = sin daño de trampas). Se desactivan en el modo Muñeco. */
var TRD={
 pinchos:{per:4.2,warn:.8,act:.7,pj:.09,pe:.14,col:"#e8e8f0",tag:"Pinchos"},
 llamas:{per:6,warn:1,act:1.5,tick:.4,pj:.035,pe:.05,col:"#ff8a30",tag:"Llamas"},
 glifo:{warn:.6,cool:7,pj:.15,pe:.22,col:"#c080ff",tag:"Glifo arcano"},
 veneno:{tick:.5,pj:.012,pe:.02,col:"#8ad860",tag:"Veneno"}
};
function trInit(m){
 if(D.dummy||!m.trampas)return[];
 return m.trampas.map(function(o){var r=Object.assign({},TRD[o.t],o);r.ph=o.ph||0;r.fase=0;r.hit=[];r.tk=0;r.st="arm";r.tt=0;return r;});
}
function trDentro(o,x,y,r){return x>o.x-r&&x<o.x+o.w+r&&y>o.y-r&&y<o.y+o.h+r;}
function enTr(x,y,r){return !!D.TR&&D.TR.some(function(o){return trDentro(o,x,y,r+12);});}
function trEnts(){return[D.P].concat(D.E.filter(function(e){return !e.dummy;}));}
function trFase(o){var u=(D.t+o.ph)%o.per;return u>=o.per-o.act?2:(u>=o.per-o.act-o.warn?1:0);}
function trTf(o){return((D.t+o.ph)%o.per)-(o.per-o.act);}
function trDanoJ(o){
 if(!(TUNE.trampas>0)||D.estado!=="play")return;
 var P=D.P,st=D.st;
 if(P.invT>0){txt(P.x,P.y,"Inmune","#7ab88a",12,24);return;}
 var rd=Math.min(.9,D.M.dr+(D.j.tb&&D.j.tb.red||0)),d=Math.max(1,Math.floor(st.vidaMax*o.pj*TUNE.trampas*(1-rd)));
 if(P.sh>0){if(d<=P.sh){P.sh-=d;d=0;}else{d-=P.sh;P.sh=0;}}
 P.hp-=d;P.hurt=.25;D.dmgIn+=d;if(d>0){D.hitsIn++;if(d>D.maxIn)D.maxIn=d;}
 D.shake=Math.max(D.shake,o.t==="glifo"?6:3);
 txt(P.x,P.y,d>0?String(d):"Bloqueado",o.col,16,24);txt(P.x,P.y,"⚠ "+o.tag,o.col,11,50);sfx(130,.12,"square",.05,.6);
 if(o.t==="glifo"&&!(D.j.tb&&D.j.tb.cc)){P.silT=Math.max(P.silT||0,1.5);txt(P.x,P.y,"🔇 Silenciado","#b070e0",13,64);}
 if(!(P.hp>0))terminar(false);   /* !(>0) también atrapa NaN */
}
function trDanoE(o,e){
 if(!(TUNE.trampas>0))return;
 var jf=e.tipo==="jefe"?.25:e.tipo==="mini_jefe"?.5:1,d=Math.max(1,Math.floor(e.vidaMax*o.pe*jf*TUNE.trampas));
 e.vida-=d;e.flash=1;txt(e.x+rf(-8,8),e.y,String(d),o.col,14,e.r+8);
 chispas(e.x,e.y,5,o.col,150,.4,Math.max(12,(e.alt||40)*.5));
 if(o.t==="glifo")e.stunT=Math.max(e.stunT,.9*(e.tipo==="jefe"?.4:e.tipo==="mini_jefe"?.6:1));
 if(e.vida<=0)matar(e);
}
function trAplicar(o,en){
 if(D.estado!=="play")return;
 if(en===D.P)trDanoJ(o);else if(D.E.indexOf(en)>=0&&!netPup())trDanoE(o,en);
}
function trActualizar(dt){
 if(!D.TR||!D.TR.length||D.estado!=="play")return;
 var P=D.P;
 D.TR.forEach(function(o){
  if(D.estado!=="play"||o.off)return;
  if(D.lab&&Math.hypot(P.x-(o.x+o.w/2),P.y-(o.y+o.h/2))>720)return;
  var ents=trEnts(),cx=o.x+o.w/2,cy=o.y+o.h/2,cerca=Math.hypot(P.x-cx,P.y-cy)<520;
  if(o.t==="pinchos"||o.t==="llamas"){
   var f=trFase(o),pin=o.t==="pinchos";
   if(f!==o.fase){
    if(f===2){o.hit=[];o.tk=0;if(cerca)sfx(pin?210:90,.22,pin?"square":"sawtooth",.035,pin?1.6:.5);}
    else if(f===1&&cerca)sfx(pin?420:150,.12,"triangle",.025,.8);
    o.fase=f;
   }
   if(f===2){
    if(pin){ents.forEach(function(en){if(o.hit.indexOf(en)>=0||!trDentro(o,en.x,en.y,en.r*.4))return;o.hit.push(en);trAplicar(o,en);});}
    else{
     o.tk-=dt;
     if(o.tk<=0){o.tk=o.tick;ents.forEach(function(en){if(trDentro(o,en.x,en.y,en.r*.4))trAplicar(o,en);});}
     if(Math.random()<dt*22)motas(o.x+Math.random()*o.w,o.y+Math.random()*o.h,1,"#ffb050",6,90,.6);
    }
   }
  }else if(o.t==="glifo"){
   if(o.st==="arm"){
    if(ents.some(function(en){return trDentro(o,en.x,en.y,en.r*.3);})){o.st="trig";o.tt=o.warn;if(cerca)sfx(330,.3,"triangle",.04,1.8);}
   }else if(o.st==="trig"){
    o.tt-=dt;
    if(Math.random()<dt*30)motas(cx+rf(-o.w/3,o.w/3),cy+rf(-o.h/3,o.h/3),1,"#c080ff",4,90,.5);
    if(o.tt<=0){
     boom(cx,cy,Math.min(o.w,o.h)*.6,"#b070ff");destello("#b070ff",.14);D.shake=Math.max(D.shake,6);sfx(110,.3,"sawtooth",.05,.4);
     trEnts().forEach(function(en){if(trDentro(o,en.x,en.y,en.r*.6+8))trAplicar(o,en);});
     o.st="cool";o.tt=o.cool;
    }
   }else{o.tt-=dt;if(o.tt<=0)o.st="arm";}
  }else{
   if(trDentro(o,P.x,P.y,P.r*.4))P.venT=D.t+.3;
   D.E.forEach(function(e){if(!e.dummy&&trDentro(o,e.x,e.y,e.r*.4))e.venT=D.t+.3;});
   o.tk-=dt;
   if(o.tk<=0){o.tk=o.tick;ents.forEach(function(en){if(trDentro(o,en.x,en.y,en.r*.4))trAplicar(o,en);});}
  }
 });
}
/* --- dibujado de trampas: base a ras de suelo (antes de los personajes) y llamas/rayos (después) --- */
function trPoly(c,x,y,w,h){var A=pj(x,y),B=pj(x+w,y),C=pj(x+w,y+h),Q=pj(x,y+h);c.beginPath();c.moveTo(A.x,A.y);c.lineTo(B.x,B.y);c.lineTo(C.x,C.y);c.lineTo(Q.x,Q.y);c.closePath();}
function trBlob(c,cx,cy,rx,ry,ph){c.beginPath();for(var i=0;i<=24;i++){var a=i/24*6.2832,k=1+.06*Math.sin(a*3+ph)+.04*Math.sin(a*5-ph),p=pj(cx+Math.cos(a)*rx*k,cy+Math.sin(a)*ry*k);if(i)c.lineTo(p.x,p.y);else c.moveTo(p.x,p.y);}c.closePath();}
function trDibPinchos(c,o,f){
 var nx=Math.round(o.w/CS),ny=Math.round(o.h/CS),pul=.5+.5*Math.sin(D.t*18);
 trPoly(c,o.x+2,o.y+2,o.w-4,o.h-4);c.fillStyle="rgba(14,12,18,.55)";c.fill();
 c.strokeStyle=f===1?"rgba(255,70,50,"+(.45+.4*pul)+")":"rgba(120,110,130,.5)";c.lineWidth=f===1?2.5:1.5;c.stroke();
 if(f===1){c.fillStyle="rgba(255,60,40,"+(.10+.10*pul)+")";trPoly(c,o.x+2,o.y+2,o.w-4,o.h-4);c.fill();}
 var tf=f===2?trTf(o):0,alt=f===2?Math.min(1,tf/.08)*(tf>o.act-.18?Math.max(0,(o.act-tf)/.18):1)*17:(f===1?5+4*pul:2);
 for(var i=0;i<nx;i++)for(var j=0;j<ny;j++)for(var s=0;s<4;s++){
  var p=pj(o.x+(i+(s%2?.7:.3))*CS,o.y+(j+(s<2?.3:.7))*CS);
  c.fillStyle="#0b0a0e";c.beginPath();c.ellipse(p.x,p.y,5,2.6,0,0,7);c.fill();
  if(alt>1){
   c.fillStyle=f===2?"#d9dbe6":"#9a9aa6";c.beginPath();c.moveTo(p.x-3.2,p.y);c.lineTo(p.x+3.2,p.y);c.lineTo(p.x,p.y-alt);c.closePath();c.fill();
   c.fillStyle="rgba(255,255,255,.35)";c.beginPath();c.moveTo(p.x-3.2,p.y);c.lineTo(p.x,p.y);c.lineTo(p.x,p.y-alt);c.closePath();c.fill();
  }
 }
}
function trDibLlamas(c,o,f){
 var hor=o.w>=o.h,pul=.5+.5*Math.sin(D.t*16),n=Math.round((hor?o.w:o.h)/CS);
 trPoly(c,o.x+3,o.y+3,o.w-6,o.h-6);c.fillStyle=f?"rgba(255,90,20,"+(f===1?.12+.14*pul:.25)+")":"rgba(16,12,12,.28)";c.fill();
 for(var i=0;i<n;i++){
  var p=pj(o.x+(hor?(i+.5)*CS:o.w/2),o.y+(hor?o.h/2:(i+.5)*CS));
  c.fillStyle="#0b0a0e";c.beginPath();c.ellipse(p.x,p.y,7,3.2,0,0,7);c.fill();
  c.fillStyle=f===0?"rgba(120,50,20,.35)":"rgba(255,"+(f===1?Math.round(110+80*pul):170)+",40,.9)";c.beginPath();c.ellipse(p.x,p.y,4.4,1.7,0,0,7);c.fill();
 }
 var q=pj(o.x+(hor?CS*.5:o.w/2),o.y+(hor?o.h/2:CS*.5));
 c.fillStyle="#34323a";c.strokeStyle="#15131a";c.lineWidth=1.5;c.beginPath();c.ellipse(q.x,q.y-3,11,5.5,0,0,7);c.fill();c.stroke();
 c.fillStyle=f===0?"#2a1e18":"#ff9a40";c.beginPath();c.ellipse(q.x,q.y-3.5,6,2.8,0,0,7);c.fill();
}
function trDibGlifo(c,o){
 var cx=o.x+o.w/2,cy=o.y+o.h/2,r=Math.min(o.w,o.h)/2-4,st=o.st,pul=.5+.5*Math.sin(D.t*(st==="trig"?26:3));
 var a=st==="arm"?.34+.14*pul:st==="trig"?.55+.4*pul:.12,col=st==="cool"?"110,100,120":"192,128,255";
 c.fillStyle="rgba("+col+","+(a*.35)+")";elip(c,cx,cy,r,true);
 c.strokeStyle="rgba("+col+","+a+")";c.lineWidth=2;elip(c,cx,cy,r,false,true);c.lineWidth=1.2;elip(c,cx,cy,r*.72,false,true);
 c.beginPath();
 for(var k=0;k<5;k++){var an=-Math.PI/2+k*Math.PI*4/5+(st==="trig"?D.t*3:0),p=pj(cx+Math.cos(an)*r*.7,cy+Math.sin(an)*r*.7);if(k)c.lineTo(p.x,p.y);else c.moveTo(p.x,p.y);}
 c.closePath();c.stroke();
 if(st==="trig"){var pr=1-o.tt/o.warn;c.strokeStyle="rgba(255,230,255,"+(.5+.4*pul)+")";c.lineWidth=3;elip(c,cx,cy,r*(1.15-.35*pr),false,true);}
 if(st==="cool"){
  var pr2=1-o.tt/o.cool;c.strokeStyle="rgba(192,128,255,.6)";c.lineWidth=2.5;c.beginPath();
  for(var s2=0;s2<=pr2*20;s2++){var an2=-Math.PI/2+s2/20*6.2832,pp=pj(cx+Math.cos(an2)*r*1.12,cy+Math.sin(an2)*r*1.12);if(s2)c.lineTo(pp.x,pp.y);else c.moveTo(pp.x,pp.y);}
  c.stroke();
 }
}
function trDibVeneno(c,o){
 var cx=o.x+o.w/2,cy=o.y+o.h/2,rx=o.w/2-3,ry=o.h/2-3,sd=o.x*.01;
 trBlob(c,cx,cy,rx,ry,sd);c.fillStyle="rgba(30,56,24,.55)";c.fill();
 trBlob(c,cx,cy,rx*.84,ry*.84,o.y*.01+1);c.fillStyle="rgba(96,170,60,.45)";c.fill();
 trBlob(c,cx,cy,rx,ry,sd);c.strokeStyle="rgba(150,230,100,.45)";c.lineWidth=1.5;c.stroke();
 var nb=Math.max(3,Math.round(o.w*o.h/(CS*CS)));
 for(var i=0;i<nb;i++){
  var u=(D.t*.45+i*.37)%1,p=pj(cx+Math.sin(i*12.9)*rx*.7,cy+Math.cos(i*7.7)*ry*.7);
  c.globalAlpha=Math.sin(u*Math.PI)*.8;c.fillStyle="rgba(190,255,140,.9)";c.beginPath();c.ellipse(p.x,p.y-u*10,2+3*u,1.4+2*u,0,0,7);c.fill();
 }
 c.globalAlpha=1;
}
function trSuelo(c){
 if(!D.TR||!D.TR.length)return;
 D.TR.forEach(function(o){
  if(o.off||(D.lab&&!labVista(o.x+o.w/2,o.y+o.h/2,200)))return;
  c.save();
  if(o.t==="pinchos")trDibPinchos(c,o,trFase(o));
  else if(o.t==="llamas")trDibLlamas(c,o,trFase(o));
  else if(o.t==="glifo")trDibGlifo(c,o);
  else trDibVeneno(c,o);
  c.restore();
 });
}
function trFuego(c,o){
 var tf=trTf(o),am=Math.min(1,tf/.18,Math.max(0,(o.act-tf)/.25)),hor=o.w>=o.h,n=Math.round((hor?o.w:o.h)/CS)*2,cols=["rgba(255,100,25,.9)","rgba(255,175,55,.92)","rgba(255,240,170,.95)"];
 for(var i=0;i<n;i++){
  var u=(i+.5)/n,p=pj(o.x+(hor?u*o.w:o.w/2),o.y+(hor?o.h/2:u*o.h)),f=D.t*14+i*1.7,hh=(50+16*Math.sin(f*1.3+i))*am*(1-.25*u),w=11*(1-.2*u);
  c.save();c.globalCompositeOperation="lighter";
  var g=c.createRadialGradient(p.x,p.y-8,2,p.x,p.y-8,34);g.addColorStop(0,"rgba(255,140,40,"+(.35*am)+")");g.addColorStop(1,"rgba(255,140,40,0)");c.fillStyle=g;c.fillRect(p.x-34,p.y-42,68,68);
  c.restore();
  for(var k=0;k<3;k++){var ww=w-k*3.2,h2=hh*(1-k*.27),sx=Math.sin(f+k)*3;c.fillStyle=cols[k];c.beginPath();c.moveTo(p.x-ww,p.y);c.quadraticCurveTo(p.x-ww+sx,p.y-h2*.6,p.x+sx,p.y-h2);c.quadraticCurveTo(p.x+ww+sx,p.y-h2*.6,p.x+ww,p.y);c.closePath();c.fill();}
 }
}
function trHaz(c,o){
 var p=pj(o.x+o.w/2,o.y+o.h/2),pr=Math.max(0,Math.min(1,1-o.tt/o.warn)),H=30+90*pr;
 c.save();c.globalCompositeOperation="lighter";
 var g=c.createLinearGradient(0,p.y-H,0,p.y);g.addColorStop(0,"rgba(192,128,255,0)");g.addColorStop(1,"rgba(192,128,255,"+(.5*pr)+")");
 c.fillStyle=g;c.fillRect(p.x-12*pr-4,p.y-H,(12*pr+4)*2,H);c.restore();
}
function trAlto(c){
 if(!D.TR||!D.TR.length)return;
 D.TR.forEach(function(o){
  if(o.off||(D.lab&&!labVista(o.x+o.w/2,o.y+o.h/2,200)))return;
  if(o.t==="llamas"&&trFase(o)===2)trFuego(c,o);
  else if(o.t==="glifo"&&o.st==="trig")trHaz(c,o);
 });
}

/* ---------- MAZMORRA: capa estática (suelo de losas, muros de sillería, antorchas, estandartes, portón) ---------- */
function estaticoMazmorra(m){
 var CW=m.cw,CH=m.ch,K=2,x0=-(CH*TW)-30,y0=-WH-40,w=(CW+CH)*TW+60,h=(CW+CH)*TH+WH+80;
 var cv=document.createElement("canvas");cv.width=w*K;cv.height=h*K;var g=cv.getContext("2d");
 g.scale(K,K);g.translate(-x0,-y0);g.imageSmoothingEnabled=true;
 var R=seed(m.seed||1234),pal=m.pal||["#55535b","#4d4b53","#5b5961","#494750","#53515a"];
 function pjc(x,y){return{x:(x-y)*TW,y:(x+y)*TH};}
 /* suelo */
 g.save();g.transform(TW,TH,-TW,TH,0,0);
 for(var y=0;y<CH;y++)for(var x=0;x<CW;x++){
  g.fillStyle=pal[Math.floor(R()*pal.length)];g.fillRect(x,y,1,1);
  g.strokeStyle="rgba(8,6,12,.55)";g.lineWidth=.05;g.strokeRect(x+.02,y+.02,.96,.96);
  g.fillStyle="rgba(255,255,255,.05)";g.fillRect(x+.06,y+.06,.88,.05);
  for(var n=0;n<4;n++){g.fillStyle=R()<.5?"rgba(0,0,0,"+(.07+R()*.1)+")":"rgba(255,255,255,"+(.03+R()*.05)+")";g.fillRect(x+R(),y+R(),.05+R()*.14,.04+R()*.06);}
  if(R()<.11){g.strokeStyle="rgba(0,0,0,.4)";g.lineWidth=.03;g.beginPath();var cx=x+R(),cy=y+R();g.moveTo(cx,cy);g.lineTo(cx+(R()-.5)*.6,cy+(R()-.5)*.6);g.lineTo(cx+(R()-.5)*.9,cy+(R()-.5)*.9);g.stroke();}
  if(R()<.07){g.fillStyle="rgba(60,95,55,.26)";g.fillRect(x+R()*.7,y+R()*.7,.12+R()*.2,.1+R()*.15);}
 }
 /* celdas (interior más oscuro con paja) */
 m.celdas.forEach(function(c){
  g.fillStyle="rgba(0,0,0,.42)";g.fillRect(c[0],c[1],c[2],c[3]);
  for(var i=0;i<70;i++){g.fillStyle="rgba("+(R()<.5?"150,120,60":"110,86,40")+","+(.22+R()*.25)+")";g.fillRect(c[0]+R()*c[2],c[1]+R()*c[3],.15+R()*.3,.04);}
 });
 /* alfombra raída */
 m.alf.forEach(function(a){
  g.fillStyle="#5a1a20";g.fillRect(a[0],a[1],a[2],a[3]);
  g.fillStyle="rgba(0,0,0,.18)";for(var i=0;i<a[2]*3;i++)g.fillRect(a[0]+R()*a[2],a[1]+R()*a[3],.2+R()*.5,.04);
  g.strokeStyle="#b8923a";g.lineWidth=.07;g.strokeRect(a[0]+.1,a[1]+.1,a[2]-.2,a[3]-.2);
  g.strokeStyle="rgba(184,146,58,.5)";g.lineWidth=.04;g.strokeRect(a[0]+.26,a[1]+.26,a[2]-.52,a[3]-.52);
 });
 /* charcos */
 m.charcos.forEach(function(p){
  g.fillStyle="rgba(60,95,140,.42)";g.beginPath();g.ellipse(p[0],p[1],p[2],p[3],0,0,7);g.fill();
  g.strokeStyle="rgba(170,205,240,.45)";g.lineWidth=.04;g.beginPath();g.ellipse(p[0],p[1],p[2]*.7,p[3]*.7,0,.3,2.2);g.stroke();
 });
 /* círculo ritual (mapas de jefe) */
 m.runas.forEach(function(p){
  var cx=p[0],cy=p[1],r=p[2];
  g.fillStyle="rgba(120,30,40,.16)";g.beginPath();g.ellipse(cx,cy,r,r,0,0,7);g.fill();
  g.strokeStyle="rgba(205,70,70,.55)";g.lineWidth=.1;g.beginPath();g.ellipse(cx,cy,r,r,0,0,7);g.stroke();
  g.lineWidth=.05;g.strokeStyle="rgba(205,70,70,.4)";g.beginPath();g.ellipse(cx,cy,r*.82,r*.82,0,0,7);g.stroke();g.beginPath();g.ellipse(cx,cy,r*.38,r*.38,0,0,7);g.stroke();
  for(var i=0;i<16;i++){var a=i/16*Math.PI*2,a2=a+Math.PI/16;g.beginPath();g.moveTo(cx+Math.cos(a)*r*.82,cy+Math.sin(a)*r*.82);g.lineTo(cx+Math.cos(a)*r,cy+Math.sin(a)*r);g.stroke();}
  g.beginPath();for(var k=0;k<5;k++){var aa=-Math.PI/2+k*Math.PI*4/5,px=cx+Math.cos(aa)*r*.8,py=cy+Math.sin(aa)*r*.8;if(k===0)g.moveTo(px,py);else g.lineTo(px,py);}g.closePath();g.stroke();
 });
 var gr=g.createLinearGradient(0,0,0,1.8);gr.addColorStop(0,"rgba(0,0,0,.55)");gr.addColorStop(1,"rgba(0,0,0,0)");g.fillStyle=gr;g.fillRect(0,0,CW,1.8);
 var gl=g.createLinearGradient(0,0,1.8,0);gl.addColorStop(0,"rgba(0,0,0,.55)");gl.addColorStop(1,"rgba(0,0,0,0)");g.fillStyle=gl;g.fillRect(0,0,1.8,CH);
 g.restore();
 /* muros de sillería oscura */
 function pared(len,shade){
  var s=shade,gp=g.createLinearGradient(0,-WH,0,0);
  gp.addColorStop(0,"rgb("+Math.round(58*s)+","+Math.round(56*s)+","+Math.round(66*s)+")");gp.addColorStop(1,"rgb("+Math.round(80*s)+","+Math.round(77*s)+","+Math.round(88*s)+")");
  g.fillStyle=gp;g.fillRect(0,-WH,len,WH);
  for(var row=0;row<10;row++){
   var yy=-WH+row*15,u=-(row%2)*.7;
   while(u<len){
    var bw=.7+R()*.8,a=Math.max(0,u),b=Math.min(len,u+bw);
    if(b>a){g.fillStyle="rgba("+(R()<.5?"0,0,0":"255,255,255")+","+(.04+R()*.07)+")";g.fillRect(a+.02,yy+1,b-a-.04,13);g.fillStyle="rgba(8,6,12,.55)";g.fillRect(a,yy,.04,15);}
    u+=bw;
   }
   g.fillStyle="rgba(8,6,12,.55)";g.fillRect(0,yy,len,1.2);
  }
  for(var i=0;i<len*1.6;i++){g.fillStyle="rgba(55,90,50,"+(.1+R()*.14)+")";g.fillRect(R()*len,-WH+R()*110,.06+R()*.16,8+R()*55);}
  g.fillStyle="#26242c";g.fillRect(0,-WH,len,11);g.fillStyle="rgba(255,255,255,.1)";g.fillRect(0,-WH,len,1.5);
  g.fillStyle="#26242c";g.fillRect(0,-34,len,5);g.fillStyle="rgba(255,255,255,.08)";g.fillRect(0,-34,len,1);
  for(var b2=0;b2<=len;b2+=6){g.fillStyle="#2c2a33";g.fillRect(b2-.2,-WH,.4,WH-30);g.fillStyle="rgba(255,255,255,.08)";g.fillRect(b2-.2,-WH,.06,WH-30);}
  g.fillStyle="rgba(8,6,12,"+(.2+(1-s)*.5)+")";g.fillRect(0,-30,len,30);
 }
 function antorcha(u,v){
  g.fillStyle="#2a2018";g.fillRect(u-.05,v,.1,26);g.fillStyle="#3a3a42";g.fillRect(u-.13,v+19,.26,6);
  g.fillStyle="#ff8c28";g.beginPath();g.ellipse(u,v-4,.075,10,0,0,7);g.fill();
  g.fillStyle="#ffd870";g.beginPath();g.ellipse(u,v-2,.04,6,0,0,7);g.fill();
 }
 var ROJO=["#7a1c1c","#45100f"];
 /* muro norte */
 g.save();g.transform(TW,TH,0,1,0,0);pared(CW,1);
 m.estN.forEach(function(u){banner(g,u-.42,.85,-126,62,ROJO);});
 m.torN.forEach(function(u){antorcha(u,-78);});
 (function(){
  /* placa con el nombre del mapa (en coordenadas de muro) */
  var cxu=CW/2;g.fillStyle="#1c1a20";g.fillRect(cxu-2.9,-WH+46-3,5.8,36);
  g.fillStyle="#38363f";g.fillRect(cxu-2.82,-WH+46,5.64,30);g.strokeStyle="#9a7a3a";g.lineWidth=1.5;g.strokeRect(cxu-2.82,-WH+46,5.64,30);
 })();
 g.restore();
 /* muro oeste */
 g.save();g.transform(TW,-TH,0,1,0,0);g.save();g.translate(-CH,0);pared(CH,.82);g.restore();
 m.torW.forEach(function(yv){antorcha(-yv,-78);});
 /* portón con rastrillo (salida) */
 (function(){var u0=-(CH-2.4),w=1.6,hh=104,r=w/2,ry=r*TW;
  function arco(a,c,h2,d){g.beginPath();g.moveTo(a,0);g.lineTo(a,-h2+ry);g.ellipse(a+(c-a)/2,-h2+ry,(c-a)/2,ry+d,0,Math.PI,0);g.lineTo(c,0);g.closePath();}
  arco(u0-.16,u0+w+.16,hh+7,4);g.fillStyle="#6b6a74";g.fill();
  arco(u0,u0+w,hh,0);g.fillStyle="#0c0a0e";g.fill();
  g.save();arco(u0,u0+w,hh,0);g.clip();
  g.fillStyle="#2c2c33";for(var i=1;i<8;i++)g.fillRect(u0+i*w/8-.02,-hh,.04,hh);
  g.fillRect(u0,-hh*.7,w,3.5);g.fillRect(u0,-hh*.38,w,3.5);g.fillStyle="rgba(255,255,255,.18)";for(var i2=1;i2<8;i2++)g.fillRect(u0+i2*w/8-.02,-hh,.012,hh);
  g.restore();
 })();
 g.restore();
 g.fillStyle="#1c1a20";g.fillRect(-2,-WH,4,WH);
 /* rótulo del mapa sobre el muro norte (en pantalla) */
 (function(){var p=pjc(CW/2,0);g.font="700 13px Cinzel,serif";g.textAlign="center";g.textBaseline="middle";g.fillStyle="#e2c78a";g.fillText(m.nombre.toUpperCase(),p.x,p.y-WH+46+16);})();
 return(CACHE[m.id]={cv:cv,x0:x0,y0:y0,w:w,h:h,K:K});
}

/* ---------- suelo de los mapas exteriores (bosque con losetas del pueblo; nieve/arena/ceniza/piedra/marchito pintados) ---------- */
var SUELOS={
 bosque:{fondo:"#0f180c",spr:1},
 marchito:{fondo:"#15140b",pal:["#5b5a3c","#54533a","#615f40","#4d4b33","#585639"],det:"40,30,10",luz:"230,220,150",cam:"rgba(70,50,28,.5)"},
 nieve:{fondo:"#8fa6bb",pal:["#eef3f8","#e3ebf3","#d9e4ef","#f3f7fb","#d0deec"],det:"90,120,170",luz:"255,255,255",cam:"rgba(150,175,205,.5)"},
 arena:{fondo:"#8f7344",pal:["#dcbd80","#d4b575","#e1c58a","#cfab68","#d9ba7b"],det:"120,82,36",luz:"255,240,200",cam:"rgba(170,128,66,.4)"},
 ceniza:{fondo:"#0d0909",pal:["#3b3434","#352e2e","#403838","#2f2929","#383030"],det:"0,0,0",luz:"255,110,50",cam:"rgba(20,14,14,.5)"},
 piedra:{fondo:"#0a0810",pal:["#4d4b55","#46444e","#54525c","#413f49","#4b4953"],det:"0,0,0",luz:"255,255,255",cam:"rgba(25,22,32,.4)"}
};
function estaticoExterior(m){
 var CW=m.cw,CH=m.ch,K=2,x0=-(CH*TW)-30,y0=-WH-40,w=(CW+CH)*TW+60,h=(CW+CH)*TH+WH+80,MG=3;
 var cv=document.createElement("canvas");cv.width=w*K;cv.height=h*K;var g=cv.getContext("2d");
 g.scale(K,K);g.translate(-x0,-y0);g.imageSmoothingEnabled=true;
 var R=seed(m.seed||99),T=SUELOS[m.suelo.t]||SUELOS.bosque,x,y,n;
 function enR(L,a,b){return L.some(function(r){return a>=r[0]&&a<=r[2]&&b>=r[1]&&b<=r[3];});}
 g.fillStyle=T.fondo;g.fillRect(x0,y0,w,h);
 if(T.spr){
  for(y=-MG;y<CH+MG;y++)for(x=-MG;x<CW+MG;x++){
   var cx=(x-y)*TW,cy=(x+y+1)*TH,im=IM[enR(m.camino,x,y)?"v_d"+Math.floor(R()*5):"v_g"+(R()<.55?Math.floor(R()*3):Math.floor(R()*16))];
   if(im&&im.width)g.drawImage(im,cx-im.width/2,cy-16);
   else{g.fillStyle="#4d7a3a";g.beginPath();g.moveTo(cx,cy-16);g.lineTo(cx+32,cy);g.lineTo(cx,cy+16);g.lineTo(cx-32,cy);g.closePath();g.fill();}
   if(x<0||y<0||x>=CW||y>=CH){g.fillStyle="rgba(4,10,3,.5)";g.beginPath();g.moveTo(cx,cy-16);g.lineTo(cx+32,cy);g.lineTo(cx,cy+16);g.lineTo(cx-32,cy);g.closePath();g.fill();}
  }
 }
 g.save();g.transform(TW,TH,-TW,TH,0,0);
 if(!T.spr){
  for(y=-MG;y<CH+MG;y++)for(x=-MG;x<CW+MG;x++){
   g.fillStyle=T.pal[Math.floor(R()*T.pal.length)];g.fillRect(x,y,1.03,1.03);
   if(enR(m.camino,x,y)){g.fillStyle=T.cam;g.fillRect(x,y,1.03,1.03);}
   g.strokeStyle="rgba("+T.det+",.12)";g.lineWidth=.03;g.strokeRect(x+.02,y+.02,.96,.96);
   for(n=0;n<4;n++){g.fillStyle=R()<.5?"rgba("+T.det+","+(.06+R()*.1)+")":"rgba("+T.luz+","+(.04+R()*.08)+")";g.fillRect(x+R(),y+R(),.05+R()*.16,.04+R()*.07);}
   if(R()<.06){g.strokeStyle="rgba("+T.det+",.35)";g.lineWidth=.03;g.beginPath();var qx=x+R(),qy=y+R();g.moveTo(qx,qy);g.lineTo(qx+(R()-.5)*.6,qy+(R()-.5)*.6);g.lineTo(qx+(R()-.5)*.9,qy+(R()-.5)*.9);g.stroke();}
   if(x<0||y<0||x>=CW||y>=CH){g.fillStyle="rgba(0,0,0,.45)";g.fillRect(x,y,1.03,1.03);}
  }
 }
 function rr(a,b,ww,hh,r){g.beginPath();g.moveTo(a+r,b);g.arcTo(a+ww,b,a+ww,b+hh,r);g.arcTo(a+ww,b+hh,a,b+hh,r);g.arcTo(a,b+hh,a,b,r);g.arcTo(a,b,a+ww,b,r);g.closePath();}
 var PZ={agua:["#7c9a6a","#2f6f9f","#4f9acb"],lava:["#1a0806","#c8340e","#ff8a2a"],hielo:["#9fb8cc","#8fd0e6","#cdeef8"]};
 function pozas(L,tipo){
  var cl=PZ[tipo];
  L.forEach(function(a){g.fillStyle=cl[0];rr(a[0]-.14,a[1]-.14,a[2]-a[0]+1.28,a[3]-a[1]+1.28,.55);g.fill();});
  L.forEach(function(a){
   var px=a[0],py=a[1],ww=a[2]-a[0]+1,hh=a[3]-a[1]+1,gr=g.createLinearGradient(px,py,px+ww,py+hh);gr.addColorStop(0,cl[1]);gr.addColorStop(1,cl[2]);
   g.fillStyle=gr;rr(px+.04,py+.04,ww-.08,hh-.08,.5);g.fill();
   g.strokeStyle=tipo==="lava"?"rgba(255,230,140,.45)":"rgba(255,255,255,.28)";g.lineWidth=.05;
   for(var i=0;i<ww*hh*.7;i++){var qx=px+.3+R()*(ww-.6),qy=py+.3+R()*(hh-.6);g.beginPath();g.ellipse(qx,qy,.12+R()*.3,.05+R()*.1,0,0,6.2);g.stroke();}
  });
 }
 pozas(m.agua,"agua");pozas(m.hielo,"hielo");pozas(m.lava,"lava");
 /* tablones (muelles / pasarelas) */
 m.tablones.forEach(function(a){
  var px=a[0],py=a[1],ww=a[2]-a[0]+1,hh=a[3]-a[1]+1,vert=hh>ww;
  g.fillStyle="#7a5530";g.fillRect(px,py,ww,hh);g.strokeStyle="rgba(30,16,6,.55)";g.lineWidth=.04;
  if(vert){for(var j=1;j<hh*3;j++){g.beginPath();g.moveTo(px,py+j/3);g.lineTo(px+ww,py+j/3);g.stroke();}}
  else{for(var i=1;i<ww*3;i++){g.beginPath();g.moveTo(px+i/3,py);g.lineTo(px+i/3,py+hh);g.stroke();}}
  g.fillStyle="rgba(255,225,170,.12)";g.fillRect(px,py,ww,.1);g.strokeStyle="rgba(30,16,6,.75)";g.lineWidth=.07;g.strokeRect(px,py,ww,hh);
 });
 /* círculos rituales [cx,cy,r,"r,g,b"] */
 m.runas.forEach(function(p){
  var cx=p[0],cy=p[1],r=p[2],col=p[3]||"205,70,70";
  g.fillStyle="rgba("+col+",.12)";g.beginPath();g.ellipse(cx,cy,r,r,0,0,7);g.fill();
  g.strokeStyle="rgba("+col+",.55)";g.lineWidth=.1;g.beginPath();g.ellipse(cx,cy,r,r,0,0,7);g.stroke();
  g.lineWidth=.05;g.strokeStyle="rgba("+col+",.4)";g.beginPath();g.ellipse(cx,cy,r*.82,r*.82,0,0,7);g.stroke();g.beginPath();g.ellipse(cx,cy,r*.38,r*.38,0,0,7);g.stroke();
  for(var i=0;i<16;i++){var a=i/16*Math.PI*2;g.beginPath();g.moveTo(cx+Math.cos(a)*r*.82,cy+Math.sin(a)*r*.82);g.lineTo(cx+Math.cos(a)*r,cy+Math.sin(a)*r);g.stroke();}
  g.beginPath();for(var k=0;k<5;k++){var aa=-Math.PI/2+k*Math.PI*4/5,px2=cx+Math.cos(aa)*r*.8,py2=cy+Math.sin(aa)*r*.8;if(k===0)g.moveTo(px2,py2);else g.lineTo(px2,py2);}g.closePath();g.stroke();
 });
 /* viñeta en los bordes del mapa */
 function vg(a,b,c2,d2,rx,ry,rw,rh){var gr=g.createLinearGradient(a,b,c2,d2);gr.addColorStop(0,"rgba(0,0,0,.45)");gr.addColorStop(1,"rgba(0,0,0,0)");g.fillStyle=gr;g.fillRect(rx,ry,rw,rh);}
 vg(0,0,0,2,0,0,CW,2);vg(0,CH,0,CH-2,0,CH-2,CW,2);vg(0,0,2,0,0,0,2,CH);vg(CW,0,CW-2,0,CW-2,0,2,CH);
 g.restore();
 return(CACHE[m.id]={cv:cv,x0:x0,y0:y0,w:w,h:h,K:K});
}
function estatico(m){
 if(CACHE[m.id])return CACHE[m.id];
 if(m.tema==="mazmorra")return estaticoMazmorra(m);
 if(m.tema==="exterior")return estaticoExterior(m);
 var CW=m.cw,CH=m.ch,K=2,campo=m.id==="campo",DIVX=15;
 var x0=-(CH*TW)-30,y0=-WH-40,w=(CW+CH)*TW+60,h=(CW+CH)*TH+WH+80;
 var cv=document.createElement("canvas");cv.width=w*K;cv.height=h*K;var g=cv.getContext("2d");
 g.scale(K,K);g.translate(-x0,-y0);g.imageSmoothingEnabled=true;
 var R=seed(2718);
 function pjc(x,y){return{x:(x-y)*TW,y:(x+y)*TH};}
 /* suelo de tierra apisonada */
 g.save();g.transform(TW,TH,-TW,TH,0,0);
 var palC=["#a78a5c","#9f8257","#b09263","#98794f","#a98c60","#a2845a"],palA=["#a58b5e","#9c8458","#ae9665","#97804f","#a78f62","#9f8858"];
 for(var y=0;y<CH;y++)for(var x=0;x<CW;x++){
  var pal=(campo&&x>=DIVX)?palA:palC;
  g.fillStyle=pal[Math.floor(R()*pal.length)];g.fillRect(x,y,1,1);
  if((x+y)%2===0){g.fillStyle="rgba(0,0,0,.035)";g.fillRect(x,y,1,1);}
  for(var n=0;n<5;n++){g.fillStyle=R()<.5?"rgba(60,40,15,"+(.08+R()*.1)+")":"rgba(255,235,190,"+(.05+R()*.08)+")";g.fillRect(x+R(),y+R(),.05+R()*.13,.04+R()*.05);}
  if(R()<.07){g.fillStyle="rgba(70,90,40,.35)";g.fillRect(x+R()*.8,y+R()*.8,.1,.1);}
 }
 function tablones(a,b,ww,hh,vert){
  g.fillStyle="#7a5530";g.fillRect(a,b,ww,hh);
  g.strokeStyle="rgba(30,16,6,.55)";g.lineWidth=.04;
  if(vert){for(var i=1;i<ww*3;i++){g.beginPath();g.moveTo(a+i/3,b);g.lineTo(a+i/3,b+hh);g.stroke();}}
  else{for(var j=1;j<hh*3;j++){g.beginPath();g.moveTo(a,b+j/3);g.lineTo(a+ww,b+j/3);g.stroke();}}
  g.fillStyle="rgba(255,225,170,.12)";g.fillRect(a,b,ww,.12);
  g.strokeStyle="rgba(30,16,6,.7)";g.lineWidth=.07;g.strokeRect(a,b,ww,hh);
 }
 if(campo){
  tablones(0,17.6,3.4,3.4,0);tablones(13.2,9,3.6,4,0);
  /* círculos de combate bajo los maniquíes + arena de duelo */
  g.strokeStyle="rgba(60,38,14,.5)";g.lineWidth=.07;
  m.mq.forEach(function(p){g.beginPath();g.ellipse(p[0]+.5,p[1]+.5,.85,.85,0,0,7);g.stroke();g.fillStyle="rgba(60,38,14,.10)";g.fill();});
  g.fillStyle="rgba(235,215,170,.28)";g.beginPath();g.ellipse(9,11,4.6,2.6,0,0,7);g.fill();
  g.strokeStyle="rgba(120,85,40,.6)";g.lineWidth=.06;g.beginPath();g.ellipse(9,11,4.6,2.6,0,0,7);g.stroke();
  /* carriles de arquería */
  m.lanes.forEach(function(xx){
   g.fillStyle="rgba(240,225,185,.16)";g.fillRect(xx-.8,2.8,1.6,12.2);
   g.strokeStyle="rgba(250,240,205,.45)";g.lineWidth=.045;g.setLineDash([.28,.22]);
   g.beginPath();g.moveTo(xx-.8,2.8);g.lineTo(xx-.8,15);g.moveTo(xx+.8,2.8);g.lineTo(xx+.8,15);g.stroke();g.setLineDash([]);
  });
  g.fillStyle="rgba(245,235,205,.7)";g.fillRect(DIVX+1,15.0,CW-DIVX-1,.2);
  g.fillStyle="rgba(120,60,20,.55)";g.fillRect(DIVX+1,8.9,CW-DIVX-1,.1);
  g.fillStyle="rgba(120,60,20,.45)";g.fillRect(DIVX+1,3.7,CW-DIVX-1,.1);
  g.fillStyle="rgba(0,0,0,.14)";g.fillRect(DIVX+.15,0,.7,9);g.fillRect(DIVX+.15,13,.7,CH-13);
 }else{
  g.fillStyle="rgba(235,215,170,.22)";g.beginPath();g.ellipse(CW/2,CH/2+1,6.2,3.8,0,0,7);g.fill();
  g.strokeStyle="rgba(120,85,40,.6)";g.lineWidth=.06;g.beginPath();g.ellipse(CW/2,CH/2+1,6.2,3.8,0,0,7);g.stroke();
  g.beginPath();g.ellipse(CW/2,CH/2+1,.25,.25,0,0,7);g.stroke();
 }
 var gr=g.createLinearGradient(0,0,0,1.6);gr.addColorStop(0,"rgba(0,0,0,.45)");gr.addColorStop(1,"rgba(0,0,0,0)");g.fillStyle=gr;g.fillRect(0,0,CW,1.6);
 var gl=g.createLinearGradient(0,0,1.6,0);gl.addColorStop(0,"rgba(0,0,0,.45)");gl.addColorStop(1,"rgba(0,0,0,0)");g.fillStyle=gl;g.fillRect(0,0,1.6,CH);
 g.restore();
 /* paredes de entramado: yeso + vigas de madera + zócalo de piedra */
 function pared(len,shade){
  var gp=g.createLinearGradient(0,-WH,0,0);
  gp.addColorStop(0,"rgb("+Math.round(212*shade)+","+Math.round(194*shade)+","+Math.round(156*shade)+")");
  gp.addColorStop(1,"rgb("+Math.round(232*shade)+","+Math.round(216*shade)+","+Math.round(180*shade)+")");
  g.fillStyle=gp;g.fillRect(0,-WH,len,WH);
  for(var i=0;i<140;i++){g.fillStyle="rgba("+(R()<.5?"90,70,40":"255,245,215")+","+(.03+R()*.05)+")";g.fillRect(R()*len,-WH+R()*WH,.1+R()*.35,2+R()*5);}
  /* zócalo de piedra */
  var rows=3,u;
  for(var rw=0;rw<rows;rw++){var yy=-34+rw*10;u=-(rw%2)*.5;
   while(u<len){var bw=.7+R()*.5;g.fillStyle="rgba("+(R()<.5?"0,0,0":"255,240,210")+","+(.05+R()*.07)+")";g.fillRect(Math.max(0,u)+.02,yy+1,Math.min(bw,len-Math.max(0,u))-.04,8);g.fillStyle="rgba(20,16,12,.5)";g.fillRect(Math.max(0,u),yy,.035,10);u+=bw;}}
  var gs=g.createLinearGradient(0,-34,0,0);gs.addColorStop(0,"#8d877b");gs.addColorStop(1,"#6f6a5f");
  g.globalCompositeOperation="multiply";g.fillStyle=gs;g.fillRect(0,-34,len,34);g.globalCompositeOperation="source-over";
  g.fillStyle="rgba(20,16,12,.5)";for(var r2=0;r2<=3;r2++)g.fillRect(0,-34+r2*10,len,1);
  g.fillStyle="#3b2412";g.fillRect(0,-38,len,5);g.fillStyle="rgba(255,210,140,.28)";g.fillRect(0,-38,len,1);
  /* vigas */
  g.fillStyle="#3b2412";g.fillRect(0,-WH,len,12);g.fillStyle="rgba(255,210,140,.2)";g.fillRect(0,-WH,len,1.5);
  g.fillStyle="#2e1a0a";g.fillRect(0,-WH+12,len,3);
  g.fillStyle="#3b2412";g.fillRect(0,-80,len,6);g.fillStyle="rgba(255,210,140,.18)";g.fillRect(0,-80,len,1);
  for(var b=0;b<=len;b+=3){g.fillStyle="#3b2412";g.fillRect(b-.12,-WH,.24,WH-34);g.fillStyle="rgba(255,210,140,.16)";g.fillRect(b-.12,-WH,.04,WH-34);
   if(b<len){ /* tornapuntas */
    g.strokeStyle="#3b2412";g.lineWidth=5;g.beginPath();g.moveTo(b+.12,-80);g.lineTo(b+.9,-110);g.moveTo(b+2.88,-80);g.lineTo(b+2.1,-110);g.stroke();}}
  g.fillStyle="#2e1a0a";g.fillRect(len-.24,-WH,.24,WH-34);
  g.fillStyle="rgba(15,12,10,"+(.16+(1-shade)*.5)+")";g.fillRect(0,-30,len,30);
 }
 g.save();g.transform(TW,TH,0,1,0,0);pared(CW,1);
 if(campo){
  banner(g,.45,.85,-126,62);ventana(g,1.5,.9,-118,44);ventana(g,4.5,.9,-118,44);banner(g,7.4,.85,-126,62);
  ventana(g,10.5,.9,-118,44);ventana(g,13.5,.9,-118,44);banner(g,14.55,.9,-126,62);ventana(g,16.5,.9,-118,44);
  banner(g,19.0,.85,-126,62);ventana(g,22.5,.9,-118,44);banner(g,25.5,.85,-126,62);ventana(g,27.5,.9,-118,44);
 }else{
  for(var u=1.4,i=0;u<CW-1;u+=3.4,i++){if(i%2)banner(g,u,.85,-126,62);else ventana(g,u,.9,-118,44);}
 }
 g.restore();
 g.save();g.transform(TW,-TH,0,1,0,0);g.save();g.translate(-CH,0);pared(CH,.82);g.restore();
 if(campo){
  ventana(g,-2.4,.9,-118,44);banner(g,-5.0,.85,-126,62);ventana(g,-8.5,.9,-118,44);banner(g,-11.0,.85,-126,62);
  ventana(g,-14.0,.9,-118,44);banner(g,-16.0,.85,-126,62);
  /* puerta de madera con arco de piedra (salida) */
 (function(){var u0=-19.6,w=1.6,h=104,r=w/2,ry=r*TW;
  function arco(a,c,hh,d){g.beginPath();g.moveTo(a,0);g.lineTo(a,-hh+ry);g.ellipse(a+(c-a)/2,-hh+ry,(c-a)/2,ry+d,0,Math.PI,0);g.lineTo(c,0);g.closePath();}
  arco(u0-.14,u0+w+.14,h+6,4);g.fillStyle="#9d978b";g.fill();
  arco(u0,u0+w,h,0);var gd=g.createLinearGradient(0,-h,0,0);gd.addColorStop(0,"#6b4422");gd.addColorStop(1,"#402912");g.fillStyle=gd;g.fill();
  g.save();arco(u0,u0+w,h,0);g.clip();
  g.fillStyle="rgba(0,0,0,.3)";for(var i=1;i<6;i++)g.fillRect(u0+i*w/6,-h,.03,h);
  g.fillStyle="#2a2a2e";g.fillRect(u0,-h*.62,w,4);g.fillRect(u0,-h*.28,w,4);g.fillRect(u0+w/2-.02,-h,.04,h);
  g.restore();
  g.fillStyle="#c9923c";g.beginPath();g.ellipse(u0+w*.78,-h*.4,.07,2.6,0,0,7);g.fill();
 })();
 }else{
  for(var v=-2.4,j=0;v>-CH+1;v-=3.4,j++){if(j%2)ventana(g,v,.9,-118,44);else banner(g,v,.85,-126,62);}
 }
 g.restore();
 g.fillStyle="#2a170a";g.fillRect(-2,-WH,4,WH);
 /* carteles de zona (placas colgadas, rectas) */
 function placa(wx,wy,t,col){
  var p=pjc(wx,wy),pw=156,ph=30,px=p.x-pw/2,py=p.y-WH+46;
  g.fillStyle="#2a170a";g.fillRect(px-3,py-3,pw+6,ph+6);
  var gd=g.createLinearGradient(0,py,0,py+ph);gd.addColorStop(0,"#8a6032");gd.addColorStop(1,"#6a4620");g.fillStyle=gd;g.fillRect(px,py,pw,ph);
  g.strokeStyle="#c9923c";g.lineWidth=1.5;g.strokeRect(px+2.5,py+2.5,pw-5,ph-5);
  g.fillStyle="#2a170a";g.fillRect(px+10,py-16,3,14);g.fillRect(px+pw-13,py-16,3,14);
  g.font="700 14px Cinzel,serif";g.textAlign="center";g.textBaseline="middle";g.fillStyle=col;g.fillText(t,p.x,py+ph/2+1);
 }
 if(campo){placa(7.5,0,"ZONA DE COMBATE","#f3dcae");placa(22.5,0,"ZONA DE ARQUERÍA","#f3dcae");}
 return(CACHE[m.id]={cv:cv,x0:x0,y0:y0,w:w,h:h,K:K});
}

/* ---------- dibujo 2.5D ---------- */
function elip(c,x,y,r,fill,stroke){var p=pj(x,y);c.beginPath();c.ellipse(p.x,p.y,r*1.4142,r*.7071,0,0,7);if(fill)c.fill();if(stroke)c.stroke();}
function sector(c,x,y,r,a0,a1,cerrar){
 var n=Math.max(6,Math.ceil(Math.abs(a1-a0)*8)),p;c.beginPath();
 if(cerrar){p=pj(x,y);c.moveTo(p.x,p.y);}
 for(var i=0;i<=n;i++){var a=a0+(a1-a0)*i/n;p=pj(x+Math.cos(a)*r,y+Math.sin(a)*r);if(i===0&&!cerrar)c.moveTo(p.x,p.y);else c.lineTo(p.x,p.y);}
 if(cerrar)c.closePath();
}
/* personaje/monstruo de chars.js: hoja 3 columnas (frames) x 4 filas (abajo, izq, der, arriba) */
function sprChar(c,sp,x,y,dir,frame,esc,alpha,flash){
 var im=CI[sp],inf=CHARS_INFO[sp];if(!im||!inf||!im.width)return false;
 var fw=inf.w,fh=inf.h,p=pj(x,y);
 c.save();c.translate(p.x,p.y+4);c.globalAlpha=alpha;c.imageSmoothingEnabled=false;
 if(flash&&"filter" in c)c.filter="brightness(2.4)";
 c.drawImage(im,frame*fw,dir*fh,fw,fh,-fw*esc/2,-(fh-3)*esc,fw*esc,fh*esc);
 c.restore();return true;
}
function sprProp(c,k,x,y,s,dy,mir){
 var im=IM[k],p=pj(x,y);if(!im||!im.width)return;
 c.save();c.translate(p.x,p.y+8+(dy||0));if(mir)c.scale(-1,1);
 c.imageSmoothingEnabled=k.charAt(0)==="e"||k==="pilar_farol"||k.slice(0,2)==="v_";
 c.drawImage(im,-im.width*s/2,-im.height*s,im.width*s,im.height*s);c.restore();
}
function dibujar(){
 var c=D.cx,P=D.P,S=D.stat;
 c.setTransform(1,0,0,1,0,0);c.fillStyle="#12100c";c.fillRect(0,0,VW,VH);
 var shx=D.shake>0?rf(-D.shake,D.shake):0,shy=D.shake>0?rf(-D.shake,D.shake):0;
 c.setTransform(Z,0,0,Z,VW/2-D.cam.x*Z+shx,VH/2-D.cam.y*Z+shy);
 /* capa estática (solo la parte visible) */
 var vw=VW/Z,vh=VH/Z,vx=D.cam.x-vw/2,vy=D.cam.y-vh/2;
 c.imageSmoothingEnabled=true;
 if(D.lab)labSuelo(c,vx,vy,vw,vh);
 else{var ax=Math.max(S.x0,vx),ay=Math.max(S.y0,vy),bx=Math.min(S.x0+S.w,vx+vw),by=Math.min(S.y0+S.h,vy+vh);
 if(bx>ax&&by>ay)c.drawImage(S.cv,(ax-S.x0)*S.K,(ay-S.y0)*S.K,(bx-ax)*S.K,(by-ay)*S.K,ax,ay,bx-ax,by-ay);}
 /* marcas de suelo (habilidades) y efectos a ras de suelo */
 D.FX.forEach(function(f){if(f.k==="mark"){c.strokeStyle=f.col;c.globalAlpha=.4+.3*Math.sin(f.t*18);c.lineWidth=2;elip(c,f.x,f.y,f.r,false,true);c.globalAlpha=1;}});
 D.FX.forEach(function(f){if(f.low&&f.t>=0&&FXD[f.k]){c.save();FXD[f.k](c,f,f.t/f.life);c.restore();}});
 /* anillo del objetivo (fijado = dorado; auto-ataque = blanco tenue) */
 var mt=vivo(D.tg)?D.tg:((D.auto||D.keys.j)&&vivo(D.obj)?D.obj:null);
 if(mt){
  var sel=(mt===D.tg),rr=mt.r+11+(sel?2*Math.sin(D.t*6):0);
  c.save();c.strokeStyle=sel?"#ffd24a":"rgba(255,255,255,.55)";c.lineWidth=sel?2.5:1.5;c.setLineDash([10,7]);c.lineDashOffset=-D.t*30;elip(c,mt.x,mt.y,rr,false,true);c.setLineDash([]);
  if(sel){c.globalAlpha=.16;c.fillStyle="#ffd24a";elip(c,mt.x,mt.y,rr,true,false);}
  c.restore();
 }
 /* telegrafías enemigas */
 D.E.forEach(function(e){
  if(e.st!=="wind"||!e.att)return;var A=e.att,pr=1-A.t/A.dur,cl=COLOR_DANO[A.tipo];
  c.save();c.globalAlpha=.18+.22*pr;c.fillStyle=cl;
  if(A.kind==="melee"){sector(c,e.x,e.y,A.rad,A.ang-Math.PI*.55,A.ang+Math.PI*.55,true);c.fill();}
  else if(A.kind==="aoe"){
   var ec=A.esp.ef==="silencio"?"#6a9ae8":A.esp.ef==="aturdir"?"#e0e0e0":cl;c.fillStyle=ec;elip(c,A.cx,A.cy,A.rad,true);
   c.globalAlpha=.8;c.strokeStyle=ec;c.lineWidth=2;elip(c,A.cx,A.cy,A.rad*pr,false,true);
  }else{c.globalAlpha=.4;c.strokeStyle=cl;c.lineWidth=2;var q1=pj(e.x,e.y),q2=pj(P.x,P.y);c.beginPath();c.moveTo(q1.x,q1.y-12);c.lineTo(q2.x,q2.y-12);c.stroke();}
  c.restore();
 });
 trSuelo(c);
 /* objetos, enemigos y jugador ordenados por profundidad (x+y) */
 var L=[];
 if(D.lab){
  labMuros(L,c,vx,vy,vw,vh);
  D.lab.levers.forEach(function(l){if(labVista(l.x,l.y,90))L.push({k:l.x+l.y,f:function(){PD.palanca(c,l);}});});
  D.lab.gates.forEach(function(g){if(labVista(g.x,g.y,150))L.push({k:g.x+g.y,f:function(){PD.compuerta(c,g);}});});
 }
 D.mapa.props.forEach(function(o){if(D.lab&&!labVista(o.x,o.y,110))return;L.push({k:o.x+o.y,f:function(){if(o.d&&PD[o.d])PD[o.d](c,o);else sprProp(c,o.k,o.x,o.y,o.s,o.dy,o.mir);}});});
 D.E.forEach(function(e){if(D.lab&&!labVista(e.x,e.y,90))return;L.push({k:e.x+e.y,f:function(){dibujarEnemigo(c,e);}});});
 L.push({k:P.x+P.y,f:function(){dibujarJugador(c);}});
 if(D.net&&D.net.on)for(var aid in D.net.AL)(function(A){if(!labVista(A.x,A.y,90))return;L.push({k:A.x+A.y,f:function(){dibujarAliado(c,A);}});})(D.net.AL[aid]);
 L.sort(function(a,b){return a.k-b.k;});L.forEach(function(o){o.f();});
 /* proyectiles (con sombra en el suelo) */
 D.PR.forEach(function(p){dibujarProy(c,p);});
 trAlto(c);
 /* efectos */
 D.FX.forEach(function(f){
  if(f.t<0||f.low)return;
  var u=f.t/f.life;c.save();
  if(f.k==="arc"){c.globalAlpha=.7*(1-u);c.strokeStyle=f.col;c.lineWidth=8*(1-u)+2;c.translate(0,-12);sector(c,f.x,f.y,f.r*(.7+.3*u),f.a-f.arc/2,f.a+f.arc/2,false);c.stroke();}
  else if(f.k==="ring"){var r=f.r0+(f.r1-f.r0)*u,cx=f.follow?P.x:f.x,cy=f.follow?P.y:f.y;c.globalAlpha=(f.fill?.35:.8)*(1-u);c.strokeStyle=f.col;c.fillStyle=f.col;c.lineWidth=3;elip(c,cx,cy,r,f.fill,true);}
  else if(f.k==="line"){var l1=pj(f.x1,f.y1),l2=pj(f.x2,f.y2);c.globalAlpha=1-u;c.strokeStyle=f.col;c.lineWidth=4;c.beginPath();c.moveTo(l1.x,l1.y-16);c.lineTo(l2.x,l2.y-16);c.stroke();}
  else if(f.k==="part"){var q=pj(f.x,f.y);c.globalAlpha=1-u;c.fillStyle=f.col;c.fillRect(q.x-2,q.y-10-u*8,4,4);}
  else if(f.k==="ghost"){c.fillStyle=CLASES[D.j.clase].color;c.globalAlpha=.35*(1-u);var inf=CHARS_INFO[D.sp];sprChar(c,D.sp,f.x,f.y,f.d||0,1,58/inf.h,.35*(1-u),false);}
  else if(FXD[f.k])FXD[f.k](c,f,u);
  c.restore();
 });
 luces(c);
 /* números flotantes */
 c.textAlign="center";
 D.TX.forEach(function(t){c.globalAlpha=1-Math.pow(t.a/t.life,2);c.font="bold "+Math.round(t.sz*(1+Math.max(0,1-t.a/.12)*.7))+"px Karla,sans-serif";c.lineWidth=3;c.strokeStyle="rgba(0,0,0,.8)";c.strokeText(t.t,t.x,t.y);c.fillStyle=t.col;c.fillText(t.t,t.x,t.y);});
 c.globalAlpha=1;
 /* mira (en pantalla) */
 c.setTransform(1,0,0,1,0,0);
 var mx=D.msx,my=D.msy;
 c.strokeStyle="rgba(232,220,196,.8)";c.lineWidth=1.5;c.beginPath();c.arc(mx,my,8,0,7);c.moveTo(mx-14,my);c.lineTo(mx-5,my);c.moveTo(mx+5,my);c.lineTo(mx+14,my);c.moveTo(mx,my-14);c.lineTo(mx,my-5);c.moveTo(mx,my+5);c.lineTo(mx,my+14);c.stroke();
 if(D.fl){c.save();c.globalCompositeOperation="lighter";c.globalAlpha=Math.min(.4,D.fl.a);c.fillStyle=D.fl.col;c.fillRect(0,0,VW,VH);c.restore();}
 dibujarHUD(c);
}
/* iluminación: faroles con parpadeo (mapa a escala de mundo) */
function luces(c){
 c.save();c.setTransform(1,0,0,1,0,0);c.fillStyle="rgba(10,14,30,"+(D.mapa.oscuro||.08)+")";c.fillRect(0,0,VW,VH);c.restore();
 c.save();c.globalCompositeOperation="lighter";
 var fl=.85+.15*Math.sin(D.t*9)+.06*Math.sin(D.t*23),rad=D.mapa.oscuro?150:110;
 D.mapa.lamps.forEach(function(l){
  if(D.lab&&!labVista(l[0]*CS,l[1]*CS,rad+60))return;
  var s=pj(l[0]*CS,l[1]*CS),zy=s.y-(l[2]||78),col=l[3]||"255,175,70",g=c.createRadialGradient(s.x,zy,2,s.x,zy,rad);
  g.addColorStop(0,"rgba("+col+","+(.28*fl)+")");g.addColorStop(1,"rgba("+col+",0)");c.fillStyle=g;c.fillRect(s.x-rad,zy-rad,rad*2,rad*2);
 });
 if(D.lab){var ps=pj(D.P.x,D.P.y),gp=c.createRadialGradient(ps.x,ps.y-20,4,ps.x,ps.y-20,230);gp.addColorStop(0,"rgba(255,205,140,.20)");gp.addColorStop(1,"rgba(255,205,140,0)");c.fillStyle=gp;c.fillRect(ps.x-230,ps.y-250,460,460);}
 c.restore();
}
function dibujarJugador(c){
 var P=D.P,cl=CLASES[D.j.clase].color,inf=CHARS_INFO[D.sp],esc=58/inf.h,cs=Math.cos(P.face),sn=Math.sin(P.face);
 var ox=P.swing>0?cs*5:0,oy=P.swing>0?sn*5:0,fr=P.mv?[1,0,1,2][Math.floor(D.t*8)%4]:1;
 c.save();
 c.fillStyle="rgba(0,0,0,.38)";elip(c,P.x,P.y,P.r,true);
 if(P.castT>0){var cu2=P.castT/(P.castMax||.4),q0=pj(P.x,P.y),g0=c.createRadialGradient(q0.x,q0.y-26,4,q0.x,q0.y-26,50);c.globalCompositeOperation="lighter";g0.addColorStop(0,hexA(P.castCol,.6*cu2));g0.addColorStop(1,hexA(P.castCol,0));c.fillStyle=g0;c.beginPath();c.arc(q0.x,q0.y-26,50,0,7);c.fill();c.globalCompositeOperation="source-over";}
 /* indicador de dirección en el suelo */
 var tp=pj(P.x+cs*40,P.y+sn*40),b1=pj(P.x+Math.cos(P.face+.3)*27,P.y+Math.sin(P.face+.3)*27),b2=pj(P.x+Math.cos(P.face-.3)*27,P.y+Math.sin(P.face-.3)*27);
 c.globalAlpha=.8;c.fillStyle=cl;c.beginPath();c.moveTo(tp.x,tp.y);c.lineTo(b1.x,b1.y);c.lineTo(b2.x,b2.y);c.closePath();c.fill();c.globalAlpha=1;
 if(P.sh>0){c.strokeStyle="#8ab0d8";c.globalAlpha=.7;c.lineWidth=3;elip(c,P.x,P.y,P.r+8,false,true);c.globalAlpha=1;}
 if(P.invT>0){c.strokeStyle="#7ab88a";c.globalAlpha=.6+.3*Math.sin(D.t*30);c.lineWidth=2;elip(c,P.x,P.y,P.r+13,false,true);c.globalAlpha=1;}
 function pt(d,hh){var q=pj(P.x+cs*d,P.y+sn*d);return{x:q.x,y:q.y-hh};}
 function arma(){
  c.lineCap="round";var a,b;
  if(D.j.clase==="Mago"){a=pt(10,2);b=pt(10,56);c.strokeStyle="#7a5a30";c.lineWidth=3;c.beginPath();c.moveTo(a.x,a.y);c.lineTo(b.x,b.y);c.stroke();c.fillStyle="#b09aff";c.shadowColor="#b09aff";c.shadowBlur=10;c.beginPath();c.arc(b.x,b.y-3,4,0,7);c.fill();c.shadowBlur=0;}
  else if(D.j.clase==="Clérigo"){a=pt(10,2);b=pt(10,52);c.strokeStyle="#c9b27a";c.lineWidth=3;c.beginPath();c.moveTo(a.x,a.y);c.lineTo(b.x,b.y);c.stroke();c.fillStyle="#ffe9a0";c.shadowColor="#ffe9a0";c.shadowBlur=12;c.beginPath();c.arc(b.x,b.y-4,5,0,7);c.fill();c.shadowBlur=0;c.strokeStyle="#ffe9a0";c.lineWidth=2;c.beginPath();c.moveTo(b.x-6,b.y-4);c.lineTo(b.x+6,b.y-4);c.moveTo(b.x,b.y-10);c.lineTo(b.x,b.y+2);c.stroke();}
  else if(D.j.clase==="Arquero"){var t=pt(12,40),m=pt(26,26),u=pt(12,12);c.strokeStyle="#8a5a2a";c.lineWidth=3;c.beginPath();c.moveTo(t.x,t.y);c.quadraticCurveTo(m.x,m.y,u.x,u.y);c.stroke();c.strokeStyle="rgba(240,230,200,.8)";c.lineWidth=1;c.beginPath();c.moveTo(t.x,t.y);c.lineTo(u.x,u.y);c.stroke();}
  else if(D.j.clase==="Asesino"){[.5,-.5].forEach(function(o){var q=pj(P.x+Math.cos(P.face+o)*10,P.y+Math.sin(P.face+o)*10),r=pj(P.x+Math.cos(P.face+o*.6)*28,P.y+Math.sin(P.face+o*.6)*28);c.strokeStyle="#dcdce8";c.lineWidth=2.5;c.beginPath();c.moveTo(q.x,q.y-20);c.lineTo(r.x,r.y-24);c.stroke();});}
  else{a=pt(8,20);b=pt(32,26);c.strokeStyle="#8b6a3a";c.lineWidth=4;c.beginPath();c.moveTo(a.x,a.y);c.lineTo(pt(14,21).x,pt(14,21).y);c.stroke();c.strokeStyle="#e8e8f0";c.lineWidth=3;c.beginPath();c.moveTo(pt(14,21).x,pt(14,21).y);c.lineTo(b.x,b.y);c.stroke();}
  c.lineCap="butt";
 }
 var delante=P.dir!==3;
 if(!delante)arma();
 if(!sprChar(c,D.sp,P.x+ox,P.y+oy,P.dir,fr,esc,P.stunT>0?.7:1,P.hurt>0)){var q=pj(P.x,P.y);c.fillStyle=cl;c.beginPath();c.arc(q.x,q.y-20,P.r,0,7);c.fill();}
 if(delante)arma();
 if(P.sh>0){var q3=pj(P.x,P.y),shm=.5+.5*Math.sin(D.t*5),g3=c.createRadialGradient(q3.x,q3.y-26,8,q3.x,q3.y-26,40);g3.addColorStop(0,"rgba(138,176,216,0)");g3.addColorStop(.8,"rgba(138,176,216,"+(.12+.1*shm)+")");g3.addColorStop(1,"rgba(190,220,255,"+(.45+.2*shm)+")");c.fillStyle=g3;c.beginPath();c.ellipse(q3.x,q3.y-26,34,44,0,0,7);c.fill();}
 if(P.defT>0){c.fillStyle="#8ab0d8";for(var oi=0;oi<4;oi++){var oa=D.t*2.6+oi*1.5708,oq=pj(P.x+Math.cos(oa)*26,P.y+Math.sin(oa)*26);c.globalAlpha=.9;c.beginPath();c.moveTo(oq.x,oq.y-34);c.lineTo(oq.x+4,oq.y-28);c.lineTo(oq.x,oq.y-22);c.lineTo(oq.x-4,oq.y-28);c.closePath();c.fill();}c.globalAlpha=1;}
 if(P.stunT>0){var q2=pj(P.x,P.y);c.font="16px sans-serif";c.textAlign="center";c.fillText("💫",q2.x,q2.y-inf.h*esc-6);}
 c.restore();
}
function dibujarEnemigo(c,e){
 var p=pj(e.x,e.y),alt,inf;
 c.fillStyle="rgba(0,0,0,.38)";elip(c,e.x,e.y,e.r*.95,true);
 if(e.dummy){
  var im=IM[e.dk];alt=im?im.height*1.3:60;
  c.save();if(e.flash>.5&&"filter" in c)c.filter="brightness(2)";sprProp(c,e.dk,e.x,e.y,1.3,0,false);c.restore();
 }else{
  inf=CHARS_INFO[e.spr];var esc=e.r*3.4/inf.h*(SPR_ESC[e.spr]||1);alt=(SPR_TOP[e.spr]!==undefined?inf.h-SPR_TOP[e.spr]:inf.h*.85)*esc;
  var fr=e.mov?[1,0,1,2][Math.floor(D.t*7+e.ph)%4]:1;
  if(!sprChar(c,e.spr,e.x,e.y,dirDe(e.fa||0),fr,esc,e.stunT>0?.75:1,e.flash>.5)){c.fillStyle=e.flash>0?"#fff":e.col;c.beginPath();c.arc(p.x,p.y-e.r,e.r,0,7);c.fill();}
 }
 e.alt=alt;
 if(e.stunT>0){c.font="bold 13px sans-serif";c.textAlign="center";c.fillStyle="#ffe680";for(var sj=0;sj<3;sj++){var sa=D.t*5+sj*2.094;c.fillText("✦",p.x+Math.cos(sa)*e.r*.9,p.y-alt-8+Math.sin(sa)*4);}}
 if(e.mk){c.font="14px sans-serif";c.textAlign="center";c.fillText("🎯",p.x+18,p.y-alt-20);}
 var w=Math.max(34,e.r*2.2),pct=e.dummy?1:Math.max(0,e.vida/e.vidaMax),by=p.y-alt-12;
 c.fillStyle="#000a";c.fillRect(p.x-w/2,by,w,5);c.fillStyle=e.tipo==="normal"?"#b8342c":"#e07050";c.fillRect(p.x-w/2,by,w*pct,5);
 c.strokeStyle=e.tipo==="jefe"?"#ffd24a":e.tipo==="mini_jefe"?"#e0c060":"rgba(0,0,0,.6)";c.lineWidth=1;c.strokeRect(p.x-w/2-.5,by-.5,w+1,6);
 if(e===D.tg){var my2=by-32-Math.abs(Math.sin(D.t*5))*4;c.fillStyle="#ffd24a";c.strokeStyle="rgba(0,0,0,.8)";c.lineWidth=2;c.beginPath();c.moveTo(p.x-7,my2-9);c.lineTo(p.x+7,my2-9);c.lineTo(p.x,my2+3);c.closePath();c.stroke();c.fill();}
 c.font="10px Karla,sans-serif";c.textAlign="center";c.lineWidth=3;c.strokeStyle="rgba(0,0,0,.8)";c.strokeText(e.nombre,p.x,by-4);c.fillStyle="#e8dcc4";c.fillText(e.nombre,p.x,by-4);
 if(e.st==="wind"&&e.att&&e.att.kind==="aoe"){c.font="bold 12px Karla,sans-serif";c.strokeText("⚠ "+e.att.esp.n,p.x,by-18);c.fillStyle="#ffd24a";c.fillText("⚠ "+e.att.esp.n,p.x,by-18);}
}

function barra(c,x,y,w,h,pct,col,txt){
 c.fillStyle="#000a";c.fillRect(x,y,w,h);c.fillStyle=col;c.fillRect(x,y,w*clamp(pct,0,1),h);c.strokeStyle="#c9923c55";c.lineWidth=1;c.strokeRect(x+.5,y+.5,w-1,h-1);
 if(txt){c.fillStyle="#fff";c.font="bold 10px Karla,sans-serif";c.textAlign="left";c.fillText(txt,x+5,y+h-3);}
}
function dibujarHUD(c){
 var P=D.P,st=D.st,j=D.j;
 c.textAlign="left";c.fillStyle="#e8dcc4";c.font="bold 12px Cinzel,serif";c.fillText(j.nombre+" · "+j.clase+" Nv "+j.nivel,12,18);
 barra(c,12,24,230,15,P.hp/st.vidaMax,"#b8342c","Vida "+Math.max(0,Math.ceil(P.hp))+" / "+st.vidaMax);
 if(P.sh>0)barra(c,12,24,230*clamp(P.sh/(st.vidaMax*.4),0,1),4,1,"#8ab0d8");
 barra(c,12,43,230,12,P.mp/st.recursoMax,"#3c6ab8",j.recursoNombre+" "+Math.floor(P.mp)+" / "+st.recursoMax);
 var s=[];
 if(D.j.tb&&D.j.tb.n)s.push("✦ "+D.j.tb.n+" "+Math.max(0,D.j.tb.t).toFixed(1)+"s");if(D.nx)s.push("➤ próximo ataque potenciado");if(P.defT>0)s.push("🛡 +"+P.defB+" DEF "+P.defT.toFixed(1)+"s");if(P.silT>0)s.push("🔇 "+P.silT.toFixed(1)+"s");if(P.stunT>0)s.push("💫 aturdido");if(D.auto)s.push("⚔ Auto-ataque");if(vivo(D.tg))s.push("🎯 "+D.tg.nombre);if(P.invT>0.35)s.push("✨ inmune");
 c.font="11px Karla,sans-serif";c.fillStyle="#e0c060";c.fillText(s.join("  "),12,70);
 /* DPS */
 var sum=0;D.dpsLog.forEach(function(x){sum+=x.d;});var dps=Math.floor(sum/Math.min(5,Math.max(D.t,.5)));
 c.textAlign="right";c.fillStyle="#e8dcc4";c.font="11px Karla,sans-serif";
 c.fillText("DPS (5 s): "+dps+"  ·  Daño total: "+D.dmgOut+"  ·  Recibido: "+D.dmgIn+"  ·  Golpe medio: "+(D.hitsOut?Math.floor(D.dmgOut/D.hitsOut):0)+" (máx "+D.maxOut+")",VW-12,18);
 if(D.dummy)c.fillText("Muñeco: no ataca · golpea para medir daño",VW-12,34);
 else if(CFG.lab)c.fillText("Laberinto de Artaros · Enemigos despiertos: "+D.E.filter(function(e){return e.alerta;}).length+" · Derrotados: "+D.kills,VW-12,34);
 else if(CFG.inf)c.fillText("∞ Oleada "+D.wave+" · Récord: "+recordInfinita(D.j)+" · Enemigos: "+D.E.length+" · Derrotados: "+D.kills,VW-12,34);
 else c.fillText((D.stub.ciclo>0?"☠ Etapa ":"Oleada ")+Math.min(D.wave,D.waves)+"/"+D.waves+" · Enemigos: "+D.E.length+" · Derrotados: "+D.kills,VW-12,34);
 /* barra de jefe */
 var jf=D.E.filter(function(e){return (e.tipo==="jefe"||e.tipo==="mini_jefe")&&(!D.lab||e.alerta);})[0];
 if(jf){c.textAlign="center";c.fillStyle="#e0c060";c.font="bold 12px Cinzel,serif";c.fillText((jf.tipo==="jefe"?"♛ ":"☠ ")+jf.nombre,VW/2,VH-30);barra(c,VW/2-200,VH-24,400,12,jf.vida/jf.vidaMax,"#e07050");}
 if(D.lab)labMiniHUD(c);
 /* banner */
 if(D.banner.t>0){c.globalAlpha=clamp(D.banner.t,0,1);c.textAlign="center";c.font="bold 30px Cinzel,serif";c.lineWidth=5;c.strokeStyle="#000";c.strokeText(D.banner.txt,VW/2,110);c.fillStyle="#e8c878";c.fillText(D.banner.txt,VW/2,110);c.globalAlpha=1;}
}


/* ============================================================
   EXPLORAR MAZMORRA — combate en tiempo real con la partida real
   - Usa G.j (stats, equipo, atributos, talentos, maldiciones) y el piso/ciclo actuales.
   - Cada enemigo caído da XP, botín, almas, progreso de misión (igual que antes).
   - Vida/recurso arrancan con los valores actuales; Q/E usan pociones del inventario.
   - Victoria → finCombateVictoria() · Derrota → finCombateMuerte() · Huir → -10 min y vuelves al hub.
   ============================================================ */
function mzCuenta(tipo){
 var j=G.j,n=0;if(!j)return 0;
 POCIONES.forEach(function(p){if(p.tipo===tipo||p.tipo==="full")n+=j.inventario[p.n]||0;});
 return n;
}
function mzPocion(t){
 var P=D.P,st=D.st,j=G.j,tipo=t==="v"?"vida":"recurso";
 if(P.potT>0)return;
 var cand=POCIONES.filter(function(p){return p.tipo===tipo&&(j.inventario[p.n]||0)>0;}).sort(function(a,b){return a.pct-b.pct;});
 if(!cand.length)cand=POCIONES.filter(function(p){return p.tipo==="full"&&(j.inventario[p.n]||0)>0;});
 if(!cand.length){txt(P.x,P.y,"Sin pociones","#aaa",12,30);return;}
 var f=factorMaldicion(D.j,"cura"),mx=t==="v"?st.vidaMax:st.recursoMax,cur=t==="v"?P.hp:P.mp,falta=mx-cur;
 var p=cand.filter(function(q){return Math.floor(mx*q.pct*f)>=falta;})[0]||cand[cand.length-1];
 j.inventario[p.n]--;if(j.inventario[p.n]<=0)delete j.inventario[p.n];
 if(p.tipo==="full"){P.hp=st.vidaMax;P.mp=st.recursoMax;txt(P.x,P.y,"¡Restaurado!","#e0c060",15,24);}
 else if(t==="v"){var c=Math.floor(st.vidaMax*p.pct*f);P.hp=Math.min(st.vidaMax,P.hp+c);txt(P.x,P.y,"+"+c,"#7ab88a",15,24);}
 else{var r=Math.floor(st.recursoMax*p.pct*f);P.mp=Math.min(st.recursoMax,P.mp+r);txt(P.x,P.y,"+"+r,"#6a9ae8",15,24);}
 P.potT=TUNE.potCd;P.pv=mzCuenta("vida");P.pr=mzCuenta("recurso");sfx(600,.2,"sine",.04,1.6);
}
function mzRecompensa(e){
 if(CFG.inf){mzInfRecompensa(e);return;}
 var j=G.j,n0=j.nivel;
 ganarXP(j,e.xp);
 G.log.push("☠ Derrotaste a "+e.nombre+"! ("+xpTxt(j,e.xp)+")");
 dropearLoot(e,j);cosechar(j,e);if(e.mk)marcaMuerta(j,e);
 registrarBaja(j,e.nombre,D.dmgIn===0,D.t);
 if(j.nivel>n0){D.P.hp=D.st.vidaMax;D.P.mp=D.st.recursoMax;txt(D.P.x,D.P.y,"★ Nivel "+j.nivel,"#ffe080",17,56);destello("#ffe080",.25);}
}
function mzGuardarEstado(){
 var j=G.j,st=calcStats(j);
 j.vida=clamp(Math.floor(D.P.hp)||1,1,st.vidaMax);j.recurso=clamp(Math.floor(D.P.mp),0,st.recursoMax);j.tb=null;j.nx=null;
}
function mzFin(gana){
 if(CFG.inf){mzInfFin();return;}
 if(CFG.lab){labFin(gana);return;}
 var j=G.j,pe=j.piso%10,av=!!G.aventuraPiso;
 if(gana){
  mzGuardarEstado();
  if(!av&&(j.ciclo||0)>0&&pe!==5&&pe!==0)j.etapa=5; /* Extremo: las 5 etapas ya se jugaron como oleadas */
  finCombateVictoria();
 }else{j.tb=null;j.nx=null;G.aventuraPiso=null;finCombateMuerte();}
 var p=document.getElementById("dmEnd");if(!p)return;
 p.style.display="flex";
 var dps=D.t>0?Math.floor(D.dmgOut/D.t):0,L=(G.log||[]).filter(function(l){return typeof l==="string"&&l.indexOf("--- Saqueo")!==0;}).map(function(l){return l.replace(/<[^>]*>/g,"");});
 p.innerHTML='<div class="card" style="text-align:center;min-width:280px;max-width:94%"><div class="font-disp" style="font-size:24px;color:'+(gana?'#7ab88a':'#e06a5a')+';margin-bottom:8px">'+(gana?'¡Victoria!':'Derrota')+'</div>'
  +'<div style="font-size:12px;line-height:1.7;color:var(--muted);margin-bottom:8px">Tiempo '+D.t.toFixed(1)+' s · Enemigos '+D.kills+' · Daño infligido '+D.dmgOut+' ('+dps+' DPS) · Recibido '+D.dmgIn+'</div>'
  +'<div style="max-height:190px;overflow:auto;text-align:left;font-size:12px;line-height:1.6;margin-bottom:12px;padding:8px;border:1px solid var(--border);border-radius:8px;background:rgba(0,0,0,.25)">'+L.join('<br>')+'</div>'
  +'<button class="btn btn-primary" id="dmCont" style="padding:8px 26px">Continuar</button></div>';
 document.getElementById("dmCont").onclick=function(){cerrar();render();};
 sfx(gana?660:90,.5,"triangle",.06,gana?1.5:.4);
}
function mzHuir(){
 if(!D||!CFG.mz)return;
 if(D.estado==="win"||D.estado==="lose"){cerrar();render();return;}
 if(CFG.lab){labSalir();return;}
 mzGuardarEstado();
 G.log.push("Escapaste...");G.aventuraPiso=null;avanzarTiempo(10);G.screen=salirAventura();guardar();cerrar();render();
}
/* pisoAventura (opcional): Modo Aventura — rejuega ese piso en su mapa de mazmorra (con trampas), sin avanzar en la historia */
function mazmorraExplorar(pisoAventura){
 var j=G.j;if(!j)return;
 pisoAventura=(typeof pisoAventura==="number"&&pisoAventura>0)?pisoAventura:null;
 cerrar();
 j.cooldowns=[0,0,0,0,0];j.defTemp=0;j.defTurnos=0;j.escudo=0;j.inmune=0;j.silencio=0;j.aturdido=0;j.resAturdir=0;j.tb=null;j.nx=null;
 G.aventuraPiso=pisoAventura;G.volverCastillo=!!pisoAventura;G.log=pisoAventura?["(Modo Aventura: no avanzas en la historia)"]:[];G.enemigos=null;
 CFG.mz=true;CFG.usarSave=true;CFG.piso=pisoAventura||j.piso;CFG.ciclo=j.ciclo||0;CFG.modo="oleadas";CFG.oleadas=MZ_OLEADAS;CFG.mapa=mazMapaDe(CFG.piso);
 OV=document.createElement("div");OV.id="demoOv";OV.className="demo-ov";
 OV.innerHTML='<div class="demo-wrap"><div class="card" style="max-width:520px;margin:40px auto;text-align:center"><div class="font-disp" style="font-size:20px;color:var(--accent);margin-bottom:8px">Explorar Mazmorra</div><div style="color:var(--muted);font-size:13px">Entrando a la mazmorra…</div></div></div>';
 document.body.appendChild(OV);
 var ov=OV;
 cargarRecursos(function(){if(OV===ov)iniciar();});
}
window.mazmorraExplorar=mazmorraExplorar;

/* ============================================================
   MAZMORRA INFINITA (General Kaelen, Castillo)
   - Solo mapas de mazmorra con trampas (mazA-F y mazJefe); se elige uno al azar al empezar.
   - Oleadas infinitas. Más oleada = más monstruos y más vida/daño/defensa.
   - Algunas oleadas traen jefes (con esbirros): 1 jefe al principio, hasta 7 en la oleada 200.
   - NO da experiencia ni almas: solo oro y materiales.
   - Récord (oleadas superadas) en j.infRecord. Al morir se acaba la racha y la siguiente empieza en la oleada 1.
   Ajuste de balance: constantes de MZ_INF.
   ============================================================ */
var MZ_INF={mapas:["mazA","mazB","mazC","mazD","mazE","mazF","mazJefe"],
 vida:.05,atk:.035,def:.025,       /* +% por oleada sobre la 1 (oleada 200: vida x10.9 · daño x7.9 · def x5.9) */
 extraMon:.2,maxMon:40,            /* monstruos extra por oleada (+1 cada 5) y tope de esbirros/monstruos */
 jefeDesde:5,maxJefes:7,ondaMax:200,
 oroKill:[.15,.02],                /* bonus de oro por baja = oro del enemigo x (a + b x oleada) */
 oroOla:[25,10]};                  /* oro por oleada superada = a + b x oleada */
function mzInfOro(base){var j=G.j;return Math.floor(base*factorMaldicion(j,"oro")*(1+(talMods(j).oro||0)));}
function mzInfGenerar(w){
 var j=G.j,cic=j.ciclo||0,base=clamp(j.piso||1,1,70),bi=Math.floor((base-1)/10),bio=getBioma({piso:base});
 var pn=base;if(pn%10===5||pn%10===0)pn--;if(pn<1)pn=1;
 /* ¿oleada con jefes? */
 var nJ=0;
 if(w>=MZ_INF.jefeDesde){
  var pJ=(w%10===0)?1:Math.min(.5,.1+w*.0025);
  if(Math.random()<pJ){
   var mx=Math.min(MZ_INF.maxJefes,1+Math.floor((MZ_INF.maxJefes-1)*(w-1)/(MZ_INF.ondaMax-1))),pEx=Math.min(1,.1+.9*w/MZ_INF.ondaMax);
   nJ=1;while(nJ<mx&&Math.random()<pEx)nJ++;
  }
 }
 /* monstruos normales / esbirros */
 var rg=OLEADA_RANGO[Math.min(7,bio.id)]||OLEADA_RANGO[7];
 var N=Math.min(MZ_INF.maxMon,rnd(rg[0],rg[1])+Math.floor((w-1)*MZ_INF.extraMon));
 if(nJ>0)N=Math.max(2,Math.round(N*.6));
 var norm=[],guard=0;
 while(norm.length<N&&guard++<20)norm=norm.concat(generarOleada({piso:pn,ciclo:cic}));
 norm=norm.slice(0,N);
 var out=[];
 for(var k=0;k<nJ;k++){
  var esJefe=Math.random()<Math.min(1,(w-5)/60);
  var bj=generarOleada({piso:bi*10+(esJefe?10:5),ciclo:cic})[0];
  out.push(bj);
 }
 out=out.concat(norm);
 var f=w-1,mv=1+MZ_INF.vida*f,ma=1+MZ_INF.atk*f,md=1+MZ_INF.def*f;
 out.forEach(function(e){e.vida=Math.floor(e.vida*mv);e.vidaMax=e.vida;e.atkMin=Math.floor(e.atkMin*ma);e.atkMax=Math.floor(e.atkMax*ma);e.def=Math.floor(e.def*md);});
 D.infJefes=nJ;
 return out;
}
function mzInfOleada(){
 var w=D.wave,l=mzInfGenerar(w);
 l.forEach(function(e,i){initEnemigo(e,i,l.length);D.E.push(e);});
 var nJ=D.infJefes;
 D.banner={t:2.4,txt:nJ>1?"♛ Oleada "+w+" · "+nJ+" JEFES":nJ===1?(l[0].tipo==="jefe"?"♛ Oleada "+w+" · JEFE: ":"☠ Oleada "+w+" · MINI-JEFE: ")+l[0].nombre:"∞ Oleada "+w};
}
function mzInfSuperada(w){
 var j=G.j,bio=getBioma({piso:clamp(j.piso||1,1,70)});
 var oro=mzInfOro(MZ_INF.oroOla[0]+MZ_INF.oroOla[1]*w);j.oro+=oro;
 G.log.push("✔ Oleada "+w+" superada: +"+oro+" oro");
 farmearBioma(bio.id,j,false);
 if(D.infJefes>0&&bio.material){agregarItem(j,bio.material,D.infJefes);G.log.push("  +"+D.infJefes+" "+bio.material);}
 var rec=false;
 if(w>recordInfinita(j)){guardarRecordInfinita(j,w);rec=true;D.nuevoRecord=true;guardar();}
 D.banner={t:2,txt:"✔ Oleada "+w+" superada"+(rec?" · ¡NUEVO RÉCORD!":"")};
 if(G.log.length>400)G.log=G.log.slice(-200);
}
function mzInfRecompensa(e){
 var j=G.j,w=D.wave;
 G.log.push("☠ Derrotaste a "+e.nombre+"!");
 dropearLoot(e,j);
 var b=mzInfOro((e.oro||0)*(MZ_INF.oroKill[0]+MZ_INF.oroKill[1]*w));
 if(b>0){j.oro+=b;G.log.push("  +"+b+" oro (Mazmorra Infinita)");}
 if(e.mk)marcaMuerta(j,e);
 registrarBaja(j,e.nombre,D.dmgIn===0,D.t);
 if(G.log.length>400)G.log=G.log.slice(-200);
}
function mzInfFin(){
 var j=G.j,st=calcStats(j),sup=Math.max(0,D.wave-1),rec=recordInfinita(j);
 /* materiales ganados en la racha (inventario actual - inventario inicial; las pociones gastadas no cuentan) */
 var gan=[],tot=0;
 Object.keys(j.inventario||{}).forEach(function(k){var d=(j.inventario[k]||0)-((CFG.inv0||{})[k]||0);if(d>0){gan.push([k,d]);tot+=d;}});
 gan.sort(function(a,b){return b[1]-a[1];});
 var oro=j.oro-(CFG.oro0||0);
 avanzarTiempo(40);
 j.tb=null;j.nx=null;j.vida=st.vidaMax;j.recurso=st.recursoMax;
 G.aventuraPiso=null;G.screen=salirAventura();
 guardar();render();
 var p=document.getElementById("dmEnd");if(!p)return;
 p.style.display="flex";
 p.innerHTML='<div class="card" style="text-align:center;min-width:280px;max-width:94%"><div class="font-disp" style="font-size:22px;color:#e06a5a;margin-bottom:6px">Has caído en la Mazmorra Infinita</div>'
  +'<div style="font-size:13px;line-height:1.8;margin-bottom:8px">Oleadas superadas: <b>'+sup+'</b> · Récord: <b style="color:var(--accent)">'+rec+'</b>'+(D.nuevoRecord?' <span style="color:#7ab88a">· ¡NUEVO RÉCORD!</span>':'')+'<br>Oro ganado: <b>'+oro+'</b> · Materiales: <b>'+tot+'</b> · Enemigos: '+D.kills+' · Tiempo '+D.t.toFixed(1)+' s</div>'
  +'<div style="max-height:150px;overflow:auto;text-align:left;font-size:12px;line-height:1.6;margin-bottom:12px;padding:8px;border:1px solid var(--border);border-radius:8px;background:rgba(0,0,0,.25)">'+(gan.length?gan.slice(0,14).map(function(x){return "+"+x[1]+" "+x[0];}).join("<br>")+(gan.length>14?"<br>… y "+(gan.length-14)+" materiales más":""):"Sin materiales en esta racha.")+'</div>'
  +'<div style="font-size:11px;color:var(--muted);margin-bottom:10px">Vida y '+j.recursoNombre+' restaurados. La próxima racha empieza en la oleada 1.</div>'
  +'<button class="btn btn-primary" id="dmRe" style="padding:8px 22px;margin-right:8px">Reintentar</button><button class="btn" id="dmCont" style="padding:8px 22px">Volver al Castillo</button></div>';
 document.getElementById("dmCont").onclick=function(){cerrar();render();};
 document.getElementById("dmRe").onclick=function(){cerrar();mazmorraInfinita();};
 sfx(90,.5,"triangle",.06,.4);
}
function mazmorraInfinita(){
 var j=G.j;if(!j)return;
 cerrar();
 j.cooldowns=[0,0,0,0,0];j.defTemp=0;j.defTurnos=0;j.escudo=0;j.inmune=0;j.silencio=0;j.aturdido=0;j.resAturdir=0;j.tb=null;j.nx=null;
 G.aventuraPiso=null;G.volverCastillo=true;G.log=["(Mazmorra Infinita: sin experiencia, solo oro y materiales)"];G.enemigos=null;
 CFG.oro0=j.oro;CFG.inv0=JSON.parse(JSON.stringify(j.inventario||{}));
 CFG.mz=true;CFG.inf=true;CFG.usarSave=true;CFG.piso=clamp(j.piso||1,1,70);CFG.ciclo=j.ciclo||0;CFG.modo="oleadas";CFG.oleadas=3;
 CFG.mapa=MZ_INF.mapas[Math.floor(Math.random()*MZ_INF.mapas.length)];
 OV=document.createElement("div");OV.id="demoOv";OV.className="demo-ov";
 OV.innerHTML='<div class="demo-wrap"><div class="card" style="max-width:520px;margin:40px auto;text-align:center"><div class="font-disp" style="font-size:20px;color:var(--accent);margin-bottom:8px">Mazmorra Infinita</div><div style="color:var(--muted);font-size:13px">Descendiendo a las profundidades…</div></div></div>';
 document.body.appendChild(OV);
 var ov=OV;
 cargarRecursos(function(){if(OV===ov)iniciar();});
}
window.mazmorraInfinita=mazmorraInfinita;


/* ============================================================
   LABERINTO DE ARTAROS — Mazmorras del Reino de Artaros
   - Mapa enorme (≈105×77 celdas) generado por semilla: red de pasillos de 3 celdas + salas, criptas, osarios,
     cámaras de tormento, bibliotecas, bloques de celdas (calabozos) y cámaras del tesoro.
   - Sistemas de palanca: compuertas por color (1 palanca, varias palancas, temporizadas, de celdas = emboscada,
     y palancas que desactivan trampas). Las trampas son las del juego (TRD: pinchos · llamas · glifo · veneno).
   - Enemigos dormidos que despiertan por cercanía real (distancia de camino, no atraviesan muros). Jefe final.
   - Minimapa isométrico: solo muestra la zona explorada (niebla). Tab / N = mapa grande. F = interactuar.
   - Progreso guardado en j.lab (semilla + explorado + palancas + cofres + bajas): puedes salir y volver.
   Ajustes rápidos: objeto LB.
   ============================================================ */
var LB={NX:26,NY:19,N:4,ALTO:80,K:2,escala:.6,aggro:11,suelta:30,tiempo:24,
 col:[{n:"roja",c:"#e0483c",r:"224,72,60"},{n:"azul",c:"#4a8ae0",r:"74,138,224"},{n:"verde",c:"#58c070",r:"88,192,112"},{n:"dorada",c:"#e8c040",r:"232,192,64"},
  {n:"violeta",c:"#b070e0",r:"176,112,224"},{n:"naranja",c:"#f09030",r:"240,144,48"},{n:"cian",c:"#40d0d0",r:"64,208,208"},{n:"rosa",c:"#e070b0",r:"224,112,176"},{n:"plateada",c:"#b8c0d0",r:"184,192,208"}]};
/* temas de suelo/muro: 0 pasillo · 1 cripta · 2 celdas · 3 osario · 4 tormentos · 5 biblioteca · 6 santuario · 7 tesoro */
var LBT=[
 {n:"Pasillos",pal:["#55535b","#4d4b53","#5b5961","#494750","#53515a"],top:"#7b7a84",l:"#55545d",r:"#403f48",luz:"255,170,70"},
 {n:"Cripta",pal:["#4f4f58","#48484f","#55555e","#434249","#4d4c55"],top:"#767580",l:"#4f4e59",r:"#3b3a44",luz:"255,170,70"},
 {n:"Calabozos",pal:["#575055","#4f484e","#5d565b","#494147","#554d52"],top:"#7a7078",l:"#58505a",r:"#423a44",luz:"255,150,80"},
 {n:"Osario",pal:["#4e5350","#474c4a","#555a57","#41464a","#4b5052"],top:"#6f7a76",l:"#4d5753",r:"#39433f",luz:"150,230,200"},
 {n:"Cámara de tormentos",pal:["#5a5054","#524850","#605559","#4a4046","#584e52"],top:"#82706f",l:"#5e4c4c",r:"#473636",luz:"255,130,60"},
 {n:"Biblioteca",pal:["#524e5c","#4b4756","#59556a","#454150","#4f4b5d"],top:"#7a7790",l:"#575470",r:"#413e56",luz:"190,160,255"},
 {n:"Santuario del Guardián",pal:["#4f4a56","#48434f","#56515d","#433e4a","#4d4853"],top:"#7a6a78",l:"#5a4a5a",r:"#432f43",luz:"255,100,70"},
 {n:"Cámara del tesoro",pal:["#5b5648","#524d41","#625c4c","#4a4538","#58533f"],top:"#8a8168",l:"#645c46",r:"#4a4331",luz:"255,200,90"}
];
var LBN={vest:"Vestíbulo",jefe:"Santuario del Guardián",tesoro:"Cámara del tesoro",cripta:"Cripta",osario:"Osario",tormentos:"Cámara de tormentos",biblioteca:"Biblioteca",celdas:"Calabozos",almacen:"Almacén",arena:"Sala de guardia",palancas:"Cámara del mecanismo",sala:"Sala"};
var LBTEMA={vest:1,jefe:6,tesoro:7,cripta:1,osario:3,tormentos:4,biblioteca:5,celdas:2,almacen:0,arena:1,palancas:1,sala:1,nodo:0};

function labGenerar(sd){
 var R=seed(sd),NX=LB.NX,NY=LB.NY,N=LB.N,cw=NX*N+1,ch=NY*N+1;
 function ri(a,b){return a+Math.floor(R()*(b-a+1));}
 function elige(a){return a[Math.floor(R()*a.length)];}
 function baraja(a){for(var i=a.length-1;i>0;i--){var k=Math.floor(R()*(i+1)),t=a[i];a[i]=a[k];a[k]=t;}return a;}
 function I(x,y){return y*cw+x;}
 var T=new Uint8Array(cw*ch).fill(1),TM=new Uint8Array(cw*ch),RG=new Int16Array(cw*ch).fill(-1);
 var nodo=new Int16Array(NX*NY).fill(-1),regs=[],edges=[],gates=[],levers=[],chests=[],spawns=[],props=[],lamps=[],trampas=[];
 var M0={id:"lab",nombre:"Laberinto de Artaros",tema:"mazmorra",lab:true,cw:cw,ch:ch,ob:[],props:props,lamps:lamps,trampas:trampas,oscuro:.36,seed:sd,
  T:T,TM:TM,RG:RG,regs:regs,edges:edges,gates:gates,levers:levers,chests:chests,spawns:spawns,dummies:[],boss:false,runas:[],salida:null,inicio:null};
 /* ---- regiones: vestíbulo, santuario del jefe, salas aleatorias y nodos de pasillo ---- */
 function nuevaReg(i0,j0,w,h,tipo){
  var r={id:regs.length,i0:i0,j0:j0,w:w,h:h,tipo:tipo,x0:N*i0+1,y0:N*j0+1,x1:N*(i0+w)-1,y1:N*(j0+h)-1,ady:[],tree:[],padre:-1,eP:-1,prof:0,zona:0,puertas:[],host:0,pasillo:false};
  for(var a=0;a<w;a++)for(var b=0;b<h;b++)nodo[(j0+b)*NX+i0+a]=r.id;
  for(var y=r.y0;y<=r.y1;y++)for(var x=r.x0;x<=r.x1;x++){T[I(x,y)]=0;RG[I(x,y)]=r.id;}
  r.aw=r.x1-r.x0+1;r.ah=r.y1-r.y0+1;r.area=r.aw*r.ah;r.cx=(r.x0+r.x1+1)/2;r.cy=(r.y0+r.y1+1)/2;
  regs.push(r);return r;
 }
 function libreN(i0,j0,w,h){if(i0<0||j0<0||i0+w>NX||j0+h>NY)return false;for(var a=0;a<w;a++)for(var b=0;b<h;b++)if(nodo[(j0+b)*NX+i0+a]>=0)return false;return true;}
 var vest=nuevaReg(0,NY-2,2,2,"vest"),boss=nuevaReg(NX-4,0,4,3,"jefe");
 M0.inicio={x:vest.cx*CS,y:vest.cy*CS};
 var TAM=[[2,2],[2,2],[2,2],[3,2],[2,3],[3,2],[2,3],[3,3],[4,2],[2,4],[3,3],[1,2],[2,1],[3,3]];
 for(var t0=0;t0<1200&&regs.length<44;t0++){var s0=elige(TAM),i0=ri(0,NX-s0[0]),j0=ri(0,NY-s0[1]);if(libreN(i0,j0,s0[0],s0[1]))nuevaReg(i0,j0,s0[0],s0[1],"sala");}
 for(var jj=0;jj<NY;jj++)for(var ii=0;ii<NX;ii++)if(nodo[jj*NX+ii]<0){var rn=nuevaReg(ii,jj,1,1,"nodo");rn.pasillo=true;}
 /* ---- adyacencias entre regiones ---- */
 var cand={};
 function addCand(i,j,i2,j2,dir){var a=nodo[j*NX+i],b=nodo[j2*NX+i2];if(a===b)return;var k=a<b?a+"_"+b:b+"_"+a;(cand[k]=cand[k]||[]).push({a:a,b:b,i:i,j:j,dir:dir});}
 for(var j1=0;j1<NY;j1++)for(var i1=0;i1<NX;i1++){if(i1+1<NX)addCand(i1,j1,i1+1,j1,"h");if(j1+1<NY)addCand(i1,j1,i1,j1+1,"v");}
 Object.keys(cand).forEach(function(k){var p=k.split("_"),a=+p[0],b=+p[1];regs[a].ady.push(b);regs[b].ady.push(a);});
 function abrir(c,braid){
  var tiles=[],axis,k;
  if(c.dir==="h"){var x=N*(c.i+1);for(k=1;k<=3;k++)tiles.push([x,N*c.j+k]);axis="y";}
  else{var y=N*(c.j+1);for(k=1;k<=3;k++)tiles.push([N*c.i+k,y]);axis="x";}
  tiles.forEach(function(q){T[I(q[0],q[1])]=0;RG[I(q[0],q[1])]=c.a;});
  var e={id:edges.length,a:c.a,b:c.b,tiles:tiles,axis:axis,gate:-1,braid:!!braid};
  edges.push(e);regs[c.a].puertas.push(e.id);regs[c.b].puertas.push(e.id);return e;
 }
 /* ---- árbol de expansión (retroceso aleatorio = pasillos largos y sinuosos) ---- */
 var vis=new Uint8Array(regs.length),stk=[vest.id];vis[vest.id]=1;
 var conectados={};
 while(stk.length){
  var cur=stk[stk.length-1],rc=regs[cur],opts=rc.ady.filter(function(x){return !vis[x];});
  if(!opts.length){stk.pop();continue;}
  var nx=elige(opts),kk=cur<nx?cur+"_"+nx:nx+"_"+cur,cc=elige(cand[kk]),ee=abrir(cc,false);
  vis[nx]=1;regs[nx].padre=cur;regs[nx].prof=rc.prof+1;regs[nx].eP=ee.id;rc.tree.push(nx);stk.push(nx);conectados[kk]=1;
 }
 /* ---- camino principal inicio → jefe y compuertas ---- */
 var path=[],q0=boss.id;while(q0>=0){path.push(q0);q0=regs[q0].padre;}path.reverse();
 var KP=path.length-1,enPath={};path.forEach(function(id){enPath[id]=1;});
 function nuevaCompuerta(e,col,need,tipo,main){
  var t=e.tiles,g={id:gates.length,e:e.id,col:col,need:need,tipo:tipo,main:!!main,axis:e.axis,tiles:t,x:(t[1][0]+.5)*CS,y:(t[1][1]+.5)*CS,reg:-1,celda:false};
  t.forEach(function(q){T[I(q[0],q[1])]=4;});e.gate=g.id;gates.push(g);return g;
 }
 var gi=[Math.max(3,Math.round(KP*.2)),Math.round(KP*.42),Math.round(KP*.65),KP-1];
 for(var u=1;u<4;u++)if(gi[u]<=gi[u-1])gi[u]=gi[u-1]+1;
 if(gi[3]<=gi[2])gi[3]=gi[2]+1;
 var NEED=[1,1,2,3],main=[];
 for(var g0=0;g0<4;g0++){var eg=edges[regs[path[gi[g0]+1]].eP];main.push(nuevaCompuerta(eg,g0,NEED[g0],"perm",true));}
 /* zonas: nº de compuertas principales cruzadas desde el vestíbulo */
 (function z(id,zn){regs[id].zona=zn;regs[id].tree.forEach(function(h){var e=edges[regs[h].eP],g=e.gate>=0?gates[e.gate]:null;z(h,zn+(g&&g.main?1:0));});})(vest.id,0);
 /* ---- cámaras del tesoro (hojas del árbol fuera del camino, tras una compuerta) ---- */
 var hojas=baraja(regs.filter(function(r){return r.tree.length===0&&!enPath[r.id]&&r.tipo!=="vest"&&r.tipo!=="jefe";}));
 hojas.sort(function(a,b){return (b.area>=20?1:0)-(a.area>=20?1:0);});
 var extraCol=[4,5,6,7],vaults=[];
 for(var h0=0;h0<hojas.length&&vaults.length<3;h0++){
  var hr=hojas[h0];if(hr.area<9)continue;
  var ev=edges[hr.eP];if(ev.gate>=0)continue;
  var gv=nuevaCompuerta(ev,extraCol.shift(),1,vaults.length%2===1?"tiempo":"perm",false);gv.reg=hr.id;hr.tipo="tesoro";vaults.push(hr);
 }
 /* ---- lazos (bucles) solo dentro de la misma zona: las compuertas siguen siendo cuellos de botella ---- */
 Object.keys(cand).forEach(function(k){
  if(conectados[k])return;var c=elige(cand[k]),a=regs[c.a],b=regs[c.b];
  if(a.zona!==b.zona||a.tipo==="tesoro"||b.tipo==="tesoro"||a.tipo==="jefe"||b.tipo==="jefe")return;
  if(R()<.15){abrir(c,true);conectados[k]=1;}
 });
 /* ---- tipos de sala ---- */
 var salas=baraja(regs.filter(function(r){return r.tipo==="sala";}));
 var pesoT=["cripta","cripta","cripta","osario","osario","tormentos","tormentos","biblioteca","biblioteca","almacen","arena","arena"];
 /* bloques de celdas: salas anchas con muro libre de puertas (se decide con los huecos reales) */
 var celdasReg=[];
 function lado(r){ /* x de celdas posibles junto al muro norte: ninguna puerta puede tocar su franja (3 filas) */
  var xs=[],x,dq=[];r.puertas.forEach(function(id){edges[id].tiles.forEach(function(q){dq.push(q);});});
  for(x=r.x0;x+2<=r.x1;x+=4){
   var ok=true;
   dq.forEach(function(q){for(var yy=r.y0;yy<=r.y0+2;yy++)for(var xx=x;xx<=x+2;xx++)if(Math.abs(q[0]-xx)+Math.abs(q[1]-yy)===1)ok=false;});
   if(ok)xs.push(x);
  }
  return xs;
 }
 for(var s1=0;s1<salas.length&&celdasReg.length<2;s1++){
  var rs=salas[s1];if(rs.aw<11||rs.ah<7||rs.tipo!=="sala")continue;
  var l0=lado(rs);if(l0.length>=2){rs.tipo="celdas";rs.celdasLado=0;rs.celdasX=l0;celdasReg.push(rs);}
 }
 salas.forEach(function(r){if(r.tipo==="sala")r.tipo=elige(pesoT);});
 regs.forEach(function(r){r.tema=LBTEMA[r.tipo]||0;for(var y=r.y0;y<=r.y1;y++)for(var x=r.x0;x<=r.x1;x++)TM[I(x,y)]=r.tema;});
 /* ---- reservas (entradas), ocupación y conectividad ---- */
 var RS=new Uint8Array(cw*ch),OC=new Uint8Array(cw*ch);
 edges.forEach(function(e){e.tiles.forEach(function(q){for(var dy=-1;dy<=1;dy++)for(var dx=-1;dx<=1;dx++){var x=q[0]+dx,y=q[1]+dy;if(x>=0&&y>=0&&x<cw&&y<ch)RS[I(x,y)]=1;}});});
 var pas=0;for(var pi=0;pi<T.length;pi++)if(T[pi]===0||T[pi]===4)pas++;
 var Q=new Int32Array(cw*ch),SEEN=new Int32Array(cw*ch),MK=0,s0i=I(Math.floor(vest.cx),Math.floor(vest.cy));
 function alcanza(){
  MK++;var h=0,t=0,n=0;Q[t++]=s0i;SEEN[s0i]=MK;
  while(h<t){var c=Q[h++],nb=[c+1,c-1,c+cw,c-cw];n++;for(var k=0;k<4;k++){var m=nb[k];if(SEEN[m]!==MK&&(T[m]===0||T[m]===4)){SEEN[m]=MK;Q[t++]=m;}}}
  return n;
 }
 for(var sy0=-1;sy0<=1;sy0++)for(var sx0=-1;sx0<=1;sx0++)OC[I(Math.floor(vest.cx)+sx0,Math.floor(vest.cy)+sy0)]=1;
 function libreP(x,y){return x>0&&y>0&&x<cw-1&&y<ch-1&&T[I(x,y)]===0&&!RS[I(x,y)]&&!OC[I(x,y)];}
 function libreR(x,y,w,h){for(var b=0;b<h;b++)for(var a=0;a<w;a++)if(!libreP(x+a,y+b))return false;return true;}
 /* poner: bloquea celdas (val 2 = bajo, 3 = alto) si no corta ningún camino */
 function poner(x,y,w,h,val){
  if(!libreR(x,y,w,h))return false;
  var a,b;for(b=0;b<h;b++)for(a=0;a<w;a++){T[I(x+a,y+b)]=val;}
  pas-=w*h;
  if(alcanza()!==pas){for(b=0;b<h;b++)for(a=0;a<w;a++)T[I(x+a,y+b)]=0;pas+=w*h;return false;}
  for(b=0;b<h;b++)for(a=0;a<w;a++)OC[I(x+a,y+b)]=1;
  return true;
 }
 function ocupar(x,y,w,h){for(var b=0;b<h;b++)for(var a=0;a<w;a++)OC[I(x+a,y+b)]=1;}
 function lampa(x,y,z,col){lamps.push([x,y,z||40,col||"255,150,60"]);}
 function prop(o){props.push(o);}
 function centro(x,y,w,h){return{x:(x+w/2)*CS,y:(y+h/2)*CS};}
 /* ---- palancas ---- */
 function paredCerca(x,y){return T[I(x,y-1)]===1||T[I(x-1,y)]===1;}
 function sitioPalanca(r){
  var L=[],x,y;
  for(y=r.y0;y<=r.y1;y++)for(x=r.x0;x<=r.x1;x++)if(libreP(x,y)&&paredCerca(x,y)&&(r.pasillo||x===r.x0||y===r.y0||x===r.x1||y===r.y1))L.push([x,y]);
  baraja(L);
  for(var k=0;k<L.length;k++)if(poner(L[k][0],L[k][1],1,1,2))return L[k];
  return null;
 }
 function anfitrion(maxZ,pref,lejos,excl){
  var L=regs.filter(function(r){return r.zona<=maxZ&&!r.host&&r.tipo!=="vest"&&r.tipo!=="jefe"&&r.tipo!=="tesoro"&&r.tipo!=="celdas"&&(!excl||excl.indexOf(r.id)<0);});
  var pz=L.filter(function(r){return r.zona===pref;});if(pz.length)L=pz;
  L=L.map(function(r){var d=Math.abs(r.cx-lejos.x)+Math.abs(r.cy-lejos.y);return{r:r,s:(r.tree.length===0?3:0)+(enPath[r.id]?0:2)+d/60+R()};}).sort(function(a,b){return b.s-a.s;});
  for(var k=0;k<L.length&&k<8;k++){var sp=sitioPalanca(L[k].r);if(sp){L[k].r.host=1;return{r:L[k].r,p:sp};}}
  return null;
 }
 function nuevaPalanca(host,gl,tipo,col,extra){
  var lv={id:levers.length,reg:host.r.id,tx:host.p[0],ty:host.p[1],g:gl,tipo:tipo,col:col,x:(host.p[0]+.5)*CS,y:(host.p[1]+.5)*CS};
  if(extra)for(var k in extra)lv[k]=extra[k];
  levers.push(lv);host.r.tipoPal=true;return lv;
 }
 var guardias=[]; /* hosts con guardián */
 main.forEach(function(g,gx){
  var gp={x:g.x/CS,y:g.y/CS},zs=[[0],[1,0],[2,1,0],[3,2,1]][gx],ex=[];
  for(var n=0;n<g.need;n++){
   var pref=zs[Math.min(n,zs.length-1)],h=anfitrion(gx,pref,gp,ex);
   if(!h)h=anfitrion(gx+1,pref,gp,ex);
   if(h){ex.push(h.r.id);nuevaPalanca(h,[g.id],"abrir",g.col);guardias.push(h.r);}
  }
 });
 vaults.forEach(function(vr){
  var g=gates[edges[vr.eP].gate],h=anfitrion(vr.zona,vr.zona,{x:vr.cx,y:vr.cy},[vr.id]);
  if(!h)h=anfitrion(vr.zona+1,vr.zona,{x:vr.cx,y:vr.cy},[vr.id]);
  if(h){nuevaPalanca(h,[g.id],g.tipo==="tiempo"?"tiempo":"abrir",g.col);guardias.push(h.r);}
 });
 /* ---- bloques de celdas (calabozos): paredes, compuertas por celda y palanca de emboscada ---- */
 var cellCol=extraCol.slice();
 celdasReg.forEach(function(r){
  var col=cellCol.shift();if(col===undefined)col=5;
  var cel=[],gl=[];
  r.celdasX.forEach(function(x){
   var y=r.y0;
   for(var yy=0;yy<2;yy++)for(var xx=0;xx<3;xx++){T[I(x+xx,y+yy)]=0;OC[I(x+xx,y+yy)]=1;}
   /* paredes divisorias a la derecha de cada celda */
   if(x+3<=r.x1){for(var d=0;d<3;d++){if(T[I(x+3,y+d)]===0){T[I(x+3,y+d)]=1;pas--;}OC[I(x+3,y+d)]=1;}}
   if(x-1>=r.x0){for(var d2=0;d2<3;d2++){if(T[I(x-1,y+d2)]===0){T[I(x-1,y+d2)]=1;pas--;}OC[I(x-1,y+d2)]=1;}}
   var gt=[[x,y+2],[x+1,y+2],[x+2,y+2]];
   var g={id:gates.length,e:-1,col:col,need:1,tipo:"perm",main:false,axis:"x",tiles:gt,x:(x+1.5)*CS,y:(y+2.5)*CS,reg:r.id,celda:true};
   gt.forEach(function(q){T[I(q[0],q[1])]=4;OC[I(q[0],q[1])]=1;});
   gates.push(g);gl.push(g.id);cel.push({x:x,y:y,g:g.id});
  });
  /* las celdas ocupadas por la franja quedan bajo 'OC'; se recalcula el total transitable */
  pas=0;for(var pi2=0;pi2<T.length;pi2++)if(T[pi2]===0||T[pi2]===4)pas++;
  r.celdas=cel;
  /* franja libre debajo de las compuertas (fila y0+3) para no sellarla */
  for(var x2=r.x0;x2<=r.x1;x2++)OC[I(x2,r.y0+3)]=1;
  var sp=null,cand2=[];
  for(var xx2=r.x0+1;xx2<=r.x1-1;xx2++)cand2.push([xx2,r.y1]);
  baraja(cand2);
  for(var c3=0;c3<cand2.length&&!sp;c3++)if(libreP(cand2[c3][0],cand2[c3][1])&&poner(cand2[c3][0],cand2[c3][1],1,1,2))sp=cand2[c3];
  if(sp){r.host=1;nuevaPalanca({r:r,p:sp},gl,"jaula",col);}
 });
 /* ---- interior de salas ---- */
 var temaCol={1:"255,170,70",3:"150,230,200",4:"255,140,60",5:"190,160,255",6:"255,90,60",7:"255,200,90",2:"255,150,80",0:"255,170,70"};
 function bra(x,y,col){var c=centro(x,y,1,1);if(poner(x,y,1,1,2)){prop({d:"brasero",x:c.x,y:c.y});lampa(x+.5,y+.5,40,col);return true;}return false;}
 function pilar(x,y,roto){var c=centro(x,y,1,1);if(poner(x,y,1,1,3)){prop({d:"pilar",x:c.x,y:c.y,w:26,h:26,z:roto?60:LB.ALTO+14,roto:!!roto});return true;}return false;}
 function bloque(d,x,y,w,h,val,o){var c=centro(x,y,w,h);if(poner(x,y,w,h,val||2)){prop(Object.assign({d:d,x:c.x,y:c.y,w:w*CS-4,h:h*CS-4},o||{}));return true;}return false;}
 function sprite(k,x,y,val,s,dy){if(poner(x,y,1,1,val===undefined?2:val)){prop({k:k,x:(x+.5)*CS,y:(y+.72)*CS,s:s||1,dy:dy||0,mir:false});return true;}return false;}
 function deco(r,n,tipo){for(var k=0;k<n;k++){var x=ri(r.x0,r.x1),y=ri(r.y0,r.y1);if(T[I(x,y)]!==0)continue;prop({d:tipo,x:(x+.2+R()*.6)*CS,y:(y+.2+R()*.6)*CS,s:.85+R()*.3,pz:tipo==="escombros"?mazPiezas(ri(1,999)):null});}}
 function cofre(x,y,r){
  if(!poner(x,y,1,1,2))return false;
  var c=chests.length;chests.push({id:c,tx:x,ty:y,x:(x+.5)*CS,y:(y+.62)*CS,reg:r.id,q:r.tipo==="tesoro"?2:1});
  prop({d:"cofre",x:(x+.5)*CS,y:(y+.62)*CS,ci:c});r.cofres=(r.cofres||0)+1;return true;
 }
 function bordeL(r){var L=[],x,y;for(x=r.x0;x<=r.x1;x++){L.push([x,r.y0]);L.push([x,r.y1]);}for(y=r.y0+1;y<r.y1;y++){L.push([r.x0,y]);L.push([r.x1,y]);}return baraja(L);}
 function cofreEn(r,n){var L=bordeL(r);for(var k=0;k<L.length&&n>0;k++)if(cofre(L[k][0],L[k][1],r))n--;}
 function interior(r,f){var L=[],x,y;for(y=r.y0;y<=r.y1;y++)for(x=r.x0;x<=r.x1;x++)L.push([x,y]);baraja(L);for(var k=0;k<L.length;k++)f(L[k][0],L[k][1]);}
 regs.forEach(function(r){
  var col=temaCol[r.tema]||"255,170,70",x,y,k;
  if(r.pasillo){return;}
  if(r.tipo==="vest"){
   bra(r.x0,r.y0+r.ah-1,col);bra(r.x1,r.y0+r.ah-1,col);bra(r.x1,r.y0,col);
   var bl=bordeL(r).filter(function(q){return T[I(q[0],q[1]-1)]===1||T[I(q[0]-1,q[1])]===1;});
   for(var qi=0;qi<bl.length&&!M0.salida;qi++){var sx=bl[qi][0],sy=bl[qi][1];if(poner(sx,sy,1,1,2)){M0.salida={tx:sx,ty:sy,x:(sx+.5)*CS,y:(sy+.62)*CS};prop({d:"escalera",x:(sx+.5)*CS,y:(sy+.62)*CS});}}
   var fc=centro(r.x0+5,r.y0+2,1,1);if(poner(r.x0+5,r.y0+2,1,1,2)){prop({d:"fogata",x:fc.x,y:fc.y});lampa(r.x0+5.5,r.y0+2.5,30,"255,170,80");}
   return;
  }
  if(r.tipo==="jefe"){
   M0.runas=[[(r.x0+r.x1+1)/2,(r.y0+r.y1+1)/2+1,5.2]];
   pilar(r.x0+2,r.y0+2,false);pilar(r.x1-2,r.y0+2,true);pilar(r.x0+2,r.y1-2,true);pilar(r.x1-2,r.y1-2,false);
   bloque("altar",Math.floor(r.cx)-1,r.y0,3,2,2,{col:"255,80,60"});
   bra(r.x0,r.y0+4,col);bra(r.x1,r.y0+4,col);bra(r.x0,r.y1,col);bra(r.x1,r.y1,col);
   deco(r,10,"huesos");deco(r,4,"escombros");return;
  }
  if(r.tipo==="tesoro"){
   bra(r.x0,r.y0,col);bra(r.x1,r.y1,col);cofreEn(r,Math.min(4,Math.max(2,Math.floor(r.area/9))));deco(r,3,"huesos");return;
  }
  if(r.tipo==="cripta"){
   for(x=r.x0;x+1<=r.x1;x+=3)bloque("sarcofago",x,r.y0,2,1,2);
   pilar(r.x0+2,r.y0+3,false);pilar(r.x1-2,r.y0+3,R()<.5);if(r.ah>=7){pilar(r.x0+2,r.y1-2,R()<.5);pilar(r.x1-2,r.y1-2,false);}
   bra(r.x0,r.y1,col);bra(r.x1,r.y1,col);deco(r,6,"huesos");deco(r,2,"escombros");
  }else if(r.tipo==="osario"){
   bloque("altar",Math.floor(r.cx)-1,Math.floor(r.cy)-1,2,2,2,{col:"120,220,170"});
   for(k=0;k<3;k++)bloque("sarcofago",ri(r.x0,r.x1-1),ri(r.y0,r.y1),2,1,2);
   bra(r.x0,r.y0+1,col);bra(r.x1,r.y1,col);deco(r,12,"huesos");deco(r,3,"escombros");
  }else if(r.tipo==="tormentos"){
   for(k=0;k<3;k++)bloque("mesa",ri(r.x0,r.x1-2),ri(r.y0+1,r.y1-1),3,1,2);
   bloque("altar",Math.floor(r.cx)-1,Math.floor(r.cy),2,2,2,{col:"255,120,50"});
   pilar(r.x0+1,r.y0+1,false);pilar(r.x1-1,r.y1-1,true);bra(r.x0,r.y1,col);bra(r.x1,r.y0,col);deco(r,8,"huesos");deco(r,2,"escombros");
  }else if(r.tipo==="biblioteca"){
   for(x=r.x0;x<=r.x1;x++)sprite("e_librero",x,r.y0,3,.95);
   for(x=r.x0+1;x<=r.x1-1;x++){if(R()<.7)sprite("e_librero",x,Math.floor(r.cy),3,.95);}
   bloque("mesa",r.x0+1,r.y1-1,3,1,2);bra(r.x0,r.y1,col);bra(r.x1,r.y1,col);deco(r,3,"escombros");
  }else if(r.tipo==="almacen"){
   interior(r,function(x,y){if(R()<.14&&paredCerca(x,y)||R()<.04){var kk=elige(["caja","barril","e_caja","e_barril1"]);sprite(kk,x,y,2,kk.charAt(0)==="e"?.85:1.1);}});
   bra(r.x1,r.y1,col);
  }else if(r.tipo==="arena"){
   pilar(r.x0+1,r.y0+1,false);pilar(r.x1-1,r.y0+1,false);pilar(r.x0+1,r.y1-1,true);pilar(r.x1-1,r.y1-1,false);
   bloque("altar",Math.floor(r.cx),Math.floor(r.cy),2,2,2,{col:"255,150,60"});bra(r.x0,r.y1,col);deco(r,5,"huesos");
  }else if(r.tipo==="palancas"){
   pilar(r.x0+1,r.y0+1,R()<.5);pilar(r.x1-1,r.y1-1,false);bra(r.x1,r.y0,col);deco(r,4,"huesos");
  }else if(r.tipo==="celdas"){
   r.celdas.forEach(function(c,i){
    var m=i%3;
    for(var b=0;b<2;b++)for(var a=0;a<3;a++)T[I(c.x+a,c.y+b)]=0;
    if(m===1){OC[I(c.x+1,c.y)]=0;cofre(c.x+1,c.y,r);}
    prop({d:"huesos",x:(c.x+.6+R()*1.8)*CS,y:(c.y+.5+R()*.9)*CS,s:.9});
   });
   bloque("mesa",r.x0+1,r.y0+5<r.y1?r.y0+5:r.y1-1,3,1,2);bra(r.x0,r.y1,col);bra(r.x1,r.y1,col);deco(r,5,"huesos");
  }
  /* cofres de sala (≈45 %) */
  if(r.tipo!=="celdas"&&r.tipo!=="palancas"&&R()<.45)cofreEn(r,1);
 });
 /* cofres en pasillos sin salida (nodos hoja) */
 regs.forEach(function(r){
  if(!r.pasillo||r.tree.length||r.host||enPath[r.id]||r.prof<4)return;
  if(R()<.55){var L=bordeL(r);for(var k=0;k<L.length;k++)if(!RS[I(L[k][0],L[k][1])]&&cofre(L[k][0],L[k][1],r))break;}
 });
 /* ---- trampas (las del juego) ---- */
 function libreTR(x,y,w,h){for(var b=0;b<h;b++)for(var a=0;a<w;a++){var tx=x+a,ty=y+b;if(!(tx>0&&ty>0&&tx<cw-1&&ty<ch-1&&T[I(tx,ty)]===0&&!OC[I(tx,ty)]))return false;}return true;}
 function trampa(tipo,x,y,w,h,o,estricto){
  if(!(estricto?libreR(x,y,w,h):libreTR(x,y,w,h)))return false;
  ocupar(x,y,w,h);var tr=Object.assign({t:tipo,x:x*CS,y:y*CS,w:w*CS,h:h*CS},o||{});trampas.push(tr);return true;
 }
 function trampaRand(r,tipo,w,h,o){for(var k=0;k<24;k++){var x=ri(r.x0,r.x1-w+1),y=ri(r.y0,r.y1-h+1);if(trampa(tipo,x,y,w,h,o,true))return true;}return false;}
 var TIPOS=["pinchos","pinchos","llamas","glifo","veneno"];
 /* palancas que desactivan trampas: sectores de trampas en las 3 regiones anteriores a cada compuerta principal */
 [1,2,3].forEach(function(gx,ix){
  var g=main[gx],ids=[],k;
  for(k=1;k<=4&&gi[gx]-k>=1;k++){var rr=regs[path[gi[gx]-k+1]];if(rr&&rr.tipo!=="vest")ids.push(rr);}
  var grupo=ix,cnt=0;
  ids.forEach(function(rr){
   if(!rr.pasillo)return;
   var x=rr.x0,y=rr.y0,t1=trampas.length;
   if(trampa("llamas",x,y,3,1,{ph:cnt*2.5,g:grupo})||trampa("pinchos",x,y,3,2,{ph:cnt*2.1,g:grupo}))cnt++;
   if(trampas.length>t1)trampas[trampas.length-1].g=grupo;
  });
  if(cnt>=2){
   var gp={x:g.x/CS,y:g.y/CS},h=anfitrion(gx,gx-1,gp,[]);
   if(h)nuevaPalanca(h,[],"trampas",8,{grupo:grupo});
   else trampas.forEach(function(tr){if(tr.g===grupo)delete tr.g;});
  }else trampas.forEach(function(tr){if(tr.g===grupo)delete tr.g;});
 });
 regs.forEach(function(r){
  if(r.tipo==="vest"||r.tipo==="tesoro")return;
  var fuerza=Math.min(1,r.prof/ (KP+4)*1.4+.15),n,k;
  if(r.pasillo){
   if(r.prof<3||r.host||R()>.13+fuerza*.2)return;
   var tp=elige(["pinchos","pinchos","llamas","veneno","glifo"]);
   if(tp==="pinchos")trampa("pinchos",r.x0,r.y0+(R()<.5?0:1),3,2,{ph:R()*4});
   else if(tp==="llamas")trampa("llamas",r.x0,r.y0+1,3,1,{ph:R()*5});
   else if(tp==="veneno")trampa("veneno",r.x0,r.y0,3,3);
   else trampa("glifo",r.x0,r.y0,2,2);
   return;
  }
  n=r.tipo==="jefe"?3:Math.max(1,Math.round(r.area/30)+(R()<.5?1:0));
  for(k=0;k<n;k++){
   var tp2=r.tipo==="tormentos"?elige(["llamas","llamas","pinchos","glifo"]):r.tipo==="biblioteca"?elige(["glifo","glifo","llamas","pinchos"]):r.tipo==="osario"?elige(["veneno","veneno","pinchos","glifo"]):r.tipo==="cripta"?elige(["pinchos","glifo","veneno","llamas"]):elige(TIPOS);
   if(tp2==="pinchos")trampaRand(r,"pinchos",R()<.5?2:3,2,{ph:R()*4});
   else if(tp2==="llamas"){if(R()<.5)trampaRand(r,"llamas",4,1,{ph:R()*5});else trampaRand(r,"llamas",1,3,{ph:R()*5});}
   else if(tp2==="glifo")trampaRand(r,"glifo",2,2);
   else trampaRand(r,"veneno",3,2);
  }
 });
 /* ---- enemigos ---- */
 var maxProf=1;regs.forEach(function(r){if(r.prof>maxProf)maxProf=r.prof;});
 function sp(t,x,y,r,o){var s={id:spawns.length,t:t,x:(x+.5)*CS,y:(y+.5)*CS,reg:r.id,prof:r.prof/maxProf};if(o)for(var k in o)s[k]=o[k];spawns.push(s);return s;}
 function libreSp(x,y){return x>0&&y>0&&x<cw-1&&y<ch-1&&T[I(x,y)]===0&&!RS[I(x,y)]&&!OC[I(x,y)];}
 function enSala(r,n,t,o){var L=[],x,y;for(y=r.y0;y<=r.y1;y++)for(x=r.x0;x<=r.x1;x++)if(libreSp(x,y))L.push([x,y]);baraja(L);
  for(var k=0;k<n&&k<L.length;k++){sp(t,L[k][0],L[k][1],r,o);OC[I(L[k][0],L[k][1])]=1;}}
 regs.forEach(function(r){
  if(r.tipo==="vest")return;
  if(r.tipo==="jefe"){
   var bx=Math.floor(r.cx),by=r.y0+3;var b=sp("j",bx,by,r);b.boss=true;OC[I(bx,by)]=1;
   enSala(r,3,"n");return;
  }
  if(r.tipo==="tesoro"){enSala(r,1,"m");return;}
  if(r.tipo==="celdas"){
   r.celdas.forEach(function(c,i){if(i%3===1)return;var s=sp(i%3===2?"m":"n",c.x+1,c.y,r,{cell:c.g});OC[I(c.x+1,c.y)]=1;if(i%3===0){sp("n",c.x,c.y+1,r,{cell:c.g});}});
   enSala(r,2,"n");return;
  }
  if(r.pasillo){if(r.prof>=2&&R()<.14+r.prof/maxProf*.08)enSala(r,R()<.35?2:1,"n");return;}
  var n=Math.max(1,Math.round(r.area/15)),k;
  if(r.tipo==="arena"){enSala(r,1,"m");n=Math.max(2,n-1);}
  if(r.tipo==="palancas"||r.host){enSala(r,1,"m");n=Math.max(1,n-1);}
  enSala(r,Math.min(n,6),"n");
 });
 /* ---- antorchas en las caras visibles de los muros (cara sur y cara este) ---- */
 var tor={},nT=0;
 function antorcha(x,y,cara,th){
  var kx=Math.floor(x/5),ky=Math.floor(y/5),key=kx+"_"+ky;if(tor[key])return;tor[key]=1;
  var col=LBT[th].luz;
  if(cara==="s"){prop({d:"antorcha",x:(x+.5)*CS,y:(y+1.02)*CS,f:"s"});lampa(x+.5,y+1.15,62,col);}
  else{prop({d:"antorcha",x:(x+1.02)*CS,y:(y+.5)*CS,f:"e"});lampa(x+1.15,y+.5,62,col);}
  nT++;
 }
 var posT=[];
 for(var yy=1;yy<ch-1;yy++)for(var xx=1;xx<cw-1;xx++){
  if(T[I(xx,yy)]!==1)continue;
  if(T[I(xx,yy+1)]===0&&!RS[I(xx,yy+1)])posT.push([xx,yy,"s",TM[I(xx,yy+1)]]);
  if(T[I(xx+1,yy)]===0&&!RS[I(xx+1,yy)])posT.push([xx,yy,"e",TM[I(xx+1,yy)]]);
 }
 baraja(posT);
 posT.forEach(function(p){if(R()<(p[3]===0?.22:.35))antorcha(p[0],p[1],p[2],p[3]);});

 M0.camino=path;M0.gi=gi;M0.main=main;M0.vest=vest.id;M0.boss=boss.id;M0.kp=KP;
 return M0;
}
/* ¿se puede completar? Simula: alcanzar palancas, abrir compuertas, llegar al jefe. */
function labResoluble(M){
 var cw=M.cw,ch=M.ch,T=M.T,open={},pulled={},cnt={},ch2=true,vis;
 var s=Math.floor(M.inicio.y/CS)*cw+Math.floor(M.inicio.x/CS);
 function flood(){
  vis=new Uint8Array(cw*ch);var q=[s],h=0;vis[s]=1;
  while(h<q.length){var c=q[h++],nb=[c+1,c-1,c+cw,c-cw];for(var k=0;k<4;k++){var m=nb[k];if(vis[m])continue;var t=T[m];if(t===0||(t===4&&gateAt(m)))vis[m]=1,q.push(m);}}
 }
 var gmap={};M.gates.forEach(function(g){g.tiles.forEach(function(q){gmap[q[1]*cw+q[0]]=g.id;});});
 function gateAt(m){var g=gmap[m];return g!==undefined&&open[g];}
 while(ch2){
  ch2=false;flood();
  M.levers.forEach(function(l){
   if(pulled[l.id])return;
   var m=l.ty*cw+l.tx;if(!(vis[m+1]||vis[m-1]||vis[m+cw]||vis[m-cw]))return;
   pulled[l.id]=1;ch2=true;
   l.g.forEach(function(g){cnt[g]=(cnt[g]||0)+1;if(cnt[g]>=M.gates[g].need)open[g]=1;});
  });
 }
 var b=M.spawns.filter(function(x){return x.boss;})[0];
 if(!b)return false;
 var ok=vis[Math.floor(b.y/CS)*cw+Math.floor(b.x/CS)]===1;
 M.gates.forEach(function(g){if(!g.celda&&!open[g.id])ok=false;});
 return ok;
}
/* genera con la semilla dada; si el resultado no es válido prueba semillas consecutivas */
function labMapa(sd){
 for(var k=0;k<40;k++){
  var M=labGenerar(sd+k);
  if(M.kp>=14&&M.levers.length>=8&&labResoluble(M)){M.seed=sd+k;return M;}
 }
 return labGenerar(sd);
}

/* ---------- LABERINTO: ejecución (colisiones por rejilla, compuertas, palancas, niebla, IA) ---------- */
function labBloq(x,y,alto){
 var L=D.lab,cx=Math.floor(x/CS),cy=Math.floor(y/CS);
 if(cx<0||cy<0||cx>=L.cw||cy>=L.ch)return true;
 return (alto?L.alt:L.blk)[cy*L.cw+cx]===1;
}
function labResolver(o){
 var L=D.lab,cw=L.cw,ch=L.ch,blk=L.blk;
 for(var it=0;it<3;it++){
  var cx0=Math.floor((o.x-o.r)/CS),cx1=Math.floor((o.x+o.r)/CS),cy0=Math.floor((o.y-o.r)/CS),cy1=Math.floor((o.y+o.r)/CS),mov=false;
  for(var cy=cy0;cy<=cy1;cy++)for(var cx=cx0;cx<=cx1;cx++){
   if(!(cx<0||cy<0||cx>=cw||cy>=ch||blk[cy*cw+cx]))continue;
   var bx=cx*CS,by=cy*CS,px=clamp(o.x,bx,bx+CS),py=clamp(o.y,by,by+CS),dx=o.x-px,dy=o.y-py,d=Math.hypot(dx,dy);
   if(d<o.r&&d>0){o.x+=dx/d*(o.r-d);o.y+=dy/d*(o.r-d);mov=true;}
   else if(d===0){
    /* centro dentro de un bloque: salir por el lado libre más cercano */
    var opts=[[o.x-bx,-1,0],[bx+CS-o.x,1,0],[o.y-by,0,-1],[by+CS-o.y,0,1]].sort(function(a,b){return a[0]-b[0];}),k;
    for(k=0;k<4;k++){var nx=cx+opts[k][1],ny=cy+opts[k][2];if(nx>=0&&ny>=0&&nx<cw&&ny<ch&&!blk[ny*cw+nx]){o.x+=opts[k][1]*(opts[k][0]+o.r);o.y+=opts[k][2]*(opts[k][0]+o.r);mov=true;break;}}
   }
  }
  if(!mov)break;
 }
 o.x=clamp(o.x,o.r,W-o.r);o.y=clamp(o.y,o.r,H-o.r);
}
/* rayo entre dos puntos (proyectiles): ¿toca un muro alto? */
function labRayo(x1,y1,x2,y2){
 var d=Math.hypot(x2-x1,y2-y1),n=Math.max(1,Math.ceil(d/8));
 for(var i=1;i<=n;i++)if(labBloq(x1+(x2-x1)*i/n,y1+(y2-y1)*i/n,true))return true;
 return false;
}
function labVista(x,y,m){var s=pj(x,y);return Math.abs(s.x-D.cam.x)<VW/Z/2+m&&Math.abs(s.y-D.cam.y)<VH/Z/2+m;}
function labTile(x,y){return{x:Math.floor(x/CS),y:Math.floor(y/CS)};}
/* ---- compuertas ---- */
function labNavTiles(g){
 if(!D.nav)return;g.tiles.forEach(function(q){var k=q[1]*D.lab.cw+q[0];D.nav.b[k]=D.lab.blk[k];});D.nav.pc=-1;
}
function labAbrir(g,mudo){
 if(g.abierta)return;g.abierta=true;if(mudo)g.anim=1;
 g.tiles.forEach(function(q){D.lab.blk[q[1]*D.lab.cw+q[0]]=0;});labNavTiles(g);
 if(g.celda)D.E.forEach(function(e){if(e.lab&&e.cell===g.id){e.alerta=true;e.cd=Math.max(e.cd,.6);}});
}
function labCerrar(g){
 g.abierta=false;g.tiles.forEach(function(q){D.lab.blk[q[1]*D.lab.cw+q[0]]=1;});labNavTiles(g);
}
function labConocer(x,y,r){ /* marca como explorada una zona (p. ej. donde se abrió una compuerta) */
 var L=D.lab;
 for(var dy=-r;dy<=r;dy++)for(var dx=-r;dx<=r;dx++){var tx=x+dx,ty=y+dy;if(tx<0||ty<0||tx>=L.cw||ty>=L.ch)continue;labMarca(ty*L.cw+tx);}
}
function labPalanca(l,mudo,remoto){
 var L=D.lab,G0=L.gates;
 if(l.on&&l.tipo!=="tiempo")return;
 l.on=true;
 var col=LB.col[l.col],txtB="";
 if(l.tipo==="abrir"||l.tipo==="tiempo"){
  l.g.forEach(function(id){
   var g=G0[id];
   if(l.tipo==="tiempo"){g.pulled=1;g.timer=LB.tiempo;l.cd=LB.tiempo;labAbrir(g,mudo);txtB="Compuerta "+col.n+" abierta "+LB.tiempo+" s";}
   else{g.pulled++;if(g.pulled>=g.need){labAbrir(g,mudo);txtB="¡Compuerta "+col.n+" abierta!";}else txtB="Compuerta "+col.n+": "+g.pulled+"/"+g.need+" palancas";}
   if(!mudo&&D.lab.pan===null&&!D.E.some(function(e){return e.alerta;}))L.pan={x:g.x,y:g.y,t:1.9};
   if(!mudo)labConocer(Math.floor(g.x/CS),Math.floor(g.y/CS),2);
  });
 }else if(l.tipo==="jaula"){
  l.g.forEach(function(id){labAbrir(G0[id],mudo);});txtB="¡Las celdas se abren!";
  if(!mudo){L.pan=null;}
 }else if(l.tipo==="trampas"){
  D.TR.forEach(function(o){if(o.g===l.grupo)o.off=true;});txtB="Las trampas del pasillo quedan desactivadas";
 }
 if(!mudo){
  D.banner={t:2.4,txt:txtB};D.shake=Math.max(D.shake,5);sfx(110,.35,"sawtooth",.05,.5);sfx(260,.15,"square",.03,1.4);
  L.dirty=true;if(l.tipo!=="tiempo")L.pl.push(l.id);labGuardar(true);
  if(!remoto&&D.net&&D.net.on)netEnv({k:"palanca",id:l.id});
 }
}
function labCofre(c,remoto){
 if(c.abierto)return;c.abierto=true;
 var j=G.j,base=clamp(j.piso||1,1,70),bio=getBioma({piso:base}),q=c.q,k;
 var oro=mzInfOro((30+base*10)*(.8+Math.random()*.8)*q);j.oro+=oro;
 txt(c.x,c.y,"📦 +"+oro+" oro","#e0c060",16,40);
 G.log.push("📦 Abres un cofre: +"+oro+" de oro");
 for(k=0;k<q+1;k++)farmearBioma(bio.id,j,false);
 if(bio.material&&Math.random()<.35*q){agregarItem(j,bio.material,1);G.log.push("  +1 "+bio.material);}
 chispas(c.x,c.y,14,"#ffd24a",160,.6,24);sfx(520,.2,"triangle",.05,1.5);
 D.lab.co.push(c.id);labGuardar(true);
 if(!remoto&&D.net&&D.net.on)netEnv({k:"cofre",id:c.id});
}
function labInteractuar(){
 var p=D.lab&&D.lab.prox;if(!p||D.estado!=="play")return;
 if(p.t==="p")labPalanca(p.o,false);
 else if(p.t==="c")labCofre(p.o);
 else if(p.t==="s")labSalir();
}
function labProximo(){
 var L=D.lab,P=D.P,best=null,bd=76;
 L.levers.forEach(function(l){
  var ok=!l.on||(l.tipo==="tiempo"&&l.cd<=0);if(!ok)return;
  var d=Math.hypot(l.x-P.x,l.y-P.y);if(d<bd){bd=d;best={t:"p",o:l,x:l.x,y:l.y,txt:"Accionar palanca "+LB.col[l.col].n+(l.tipo==="jaula"?" (abre las celdas)":l.tipo==="tiempo"?" (temporizada)":l.tipo==="trampas"?" (desactiva trampas)":"")};}
 });
 L.chests.forEach(function(c){if(c.abierto)return;var d=Math.hypot(c.x-P.x,c.y-P.y);if(d<bd){bd=d;best={t:"c",o:c,x:c.x,y:c.y,txt:"Abrir cofre"};}});
 var s=L.m.salida;if(s){var d2=Math.hypot(s.x-P.x,s.y-P.y);if(d2<bd){bd=d2;best={t:"s",o:s,x:s.x,y:s.y,txt:"Subir la escalera (salir y guardar)"};}}
 L.prox=best;
}
/* ---- niebla / exploración ---- */
function labMarca(i){
 var L=D.lab;if(L.ex[i])return;L.ex[i]=1;L.exN++;labMMPix(i);
}
function labMMPix(i){
 var L=D.lab,g=L.mmg,cx=i%L.cw,cy=(i-cx)/L.cw,t=L.m.T[i],k=4,X=(cx-cy+L.ch)*k,Y=(cx+cy)*k/2,col;
 if(t===1)col="#3a3748";
 else if(t===4)col="#b09a60";
 else col=["#8d8a99","#8f8c9c","#9a8c92","#7f948a","#9c8686","#8e8aa8","#a08888","#a89c70"][L.m.TM[i]]||"#8d8a99";
 g.fillStyle=col;g.beginPath();g.moveTo(X,Y);g.lineTo(X+k,Y+k/2);g.lineTo(X,Y+k);g.lineTo(X-k,Y+k/2);g.closePath();g.fill();
 if(t===1){g.fillStyle="#555266";g.beginPath();g.moveTo(X,Y);g.lineTo(X+k,Y+k/2);g.lineTo(X,Y+k/2);g.lineTo(X-k,Y+k/2);g.closePath();g.fill();}
}
function labRevelar(){
 var L=D.lab,P=D.P,px=Math.floor(P.x/CS),py=Math.floor(P.y/CS),R0=9,cw=L.cw,ch=L.ch,alt=L.alt,dx,dy;
 for(dy=-R0;dy<=R0;dy++)for(dx=-R0;dx<=R0;dx++){
  if(dx*dx+dy*dy>R0*R0+2)continue;
  var tx=px+dx,ty=py+dy;if(tx<0||ty<0||tx>=cw||ty>=ch)continue;
  var i=ty*cw+tx;if(L.ex[i])continue;
  var d=Math.hypot(dx,dy),n=Math.max(1,Math.ceil(d*2)),ok=true,s;
  for(s=1;s<n;s++){var sx=Math.floor(px+.5+dx*s/n),sy=Math.floor(py+.5+dy*s/n);if((sx!==tx||sy!==ty)&&alt[sy*cw+sx]){ok=false;break;}}
  if(ok)labMarca(i);
 }
 /* al entrar en una sala se revela completa */
 var r=L.m.RG[py*cw+px];
 if(r>=0&&!L.regDone[r]){
  var rg=L.m.regs[r];L.regDone[r]=1;
  if(!rg.pasillo&&rg.tipo!=="jefe"){for(var y=rg.y0-1;y<=rg.y1+1;y++)for(var x=rg.x0-1;x<=rg.x1+1;x++)if(x>=0&&y>=0&&x<cw&&y<ch)labMarca(y*cw+x);}
 }
}
function labPack(ex){
 var s="",b=0,n=0;
 for(var i=0;i<ex.length;i++){b=(b<<1)|ex[i];n++;if(n===8){s+=String.fromCharCode(b);b=0;n=0;}}
 if(n){b<<=(8-n);s+=String.fromCharCode(b);}
 try{return btoa(s);}catch(e){return "";}
}
function labUnpack(str,ex){
 if(!str)return;var s;try{s=atob(str);}catch(e){return;}
 for(var i=0;i<ex.length;i++){var by=s.charCodeAt(i>>3)||0;ex[i]=(by>>(7-(i&7)))&1;}
}
/* ---- guardado del progreso (j.lab) ---- */
function labGuardar(suave,posicion){
 var j=G.j;if(!j||!j.lab||!D||!D.lab)return;
 var now=Date.now();if(suave&&now-(D.lab.tG||0)<4000)return;D.lab.tG=now;
 var L=j.lab;L.ex=labPack(D.lab.ex);L.kl=D.lab.kl.slice();L.pl=D.lab.pl.slice();L.co=D.lab.co.slice();
 if(posicion===false){L.px=null;L.py=null;}else{L.px=Math.round(D.P.x);L.py=Math.round(D.P.y);}
 try{mzGuardarEstado();guardar();}catch(e){}
}
/* ---- enemigos ---- */
function labCrearEnemigo(sp){
 var N=D&&D.net,_R=Math.random;
 if(N){Math.random=seed((N.seed*31+sp.id*7919+1)|0);}   /* en grupo todos los navegadores generan exactamente el mismo enemigo */
 try{return labCrearEnemigo0(sp,N);}finally{Math.random=_R;}
}
function labCrearEnemigo0(sp,N){
 var j=G.j,cic=N?N.ciclo:(j.ciclo||0),base=clamp((N?N.piso:j.piso)||1,1,70),bi=Math.floor((base-1)/10),pn=base,e,l;
 if(pn%10===5||pn%10===0)pn--;if(pn<1)pn=1;
 if(sp.t==="j"){l=generarOleada({piso:bi*10+10,ciclo:cic});e=l[0];}
 else if(sp.t==="m"){l=generarOleada({piso:bi*10+5,ciclo:cic});e=l[0];}
 else{l=generarOleada({piso:pn,ciclo:cic});e=l[Math.floor(Math.random()*l.length)];}
 var f=sp.t==="j"?1.15:1+LB.escala*sp.prof;
 e.vida=Math.floor(e.vida*f);e.vidaMax=e.vida;e.atkMin=Math.floor(e.atkMin*(1+(f-1)*.7));e.atkMax=Math.floor(e.atkMax*(1+(f-1)*.7));e.def=Math.floor(e.def*(1+(f-1)*.6));
 initEnemigo(e,0,1);e.x=sp.x;e.y=sp.y;
 e.lab=true;e.sid=sp.id;e.reg=sp.reg;e.cell=sp.cell===undefined?-1:sp.cell;e.alerta=false;e.labBoss=!!sp.boss;
 return e;
}
function labAlertar(e){
 if(e.alerta)return;e.alerta=true;e.cd=Math.max(e.cd,.5);txt(e.x,e.y,"!","#ff6a4a",18,e.r+34);
 D.E.forEach(function(o){
  if(!o.lab||o.alerta||o.reg!==e.reg||(o.cell>=0&&!D.lab.gates[o.cell].abierta))return;
  if(Math.hypot(o.x-e.x,o.y-e.y)<300){o.alerta=true;o.cd=Math.max(o.cd,.5+Math.random()*.4);}
 });
}
function labIA(e,dt){
 var P=e.tgo||D.P,L=D.lab,d=Math.hypot(P.x-e.x,P.y-e.y);
 if(e.cell>=0&&!L.gates[e.cell].abierta)return false;
 if(!e.alerta){
  if(d>LB.aggro*CS*1.4)return false;
  var n=D.nav,cx=clamp(Math.floor(e.x/CS),0,n.cw-1),cy=clamp(Math.floor(e.y/CS),0,n.ch-1),pd=n.d[cy*n.cw+cx];
  if((pd>=0&&pd<=LB.aggro-3&&d<(LB.aggro-1)*CS)||(d<CS*8&&libre(e.x,e.y,P.x,P.y,4,true)))labAlertar(e);
  else return false;
 }else if(d>LB.suelta*CS){e.alerta=false;return false;}
 return true;
}
function labJefeCae(e){
 D.banner={t:3,txt:"♛ ¡"+e.nombre+" ha caído!"};D.shake=10;destello("#ffe080",.4);
 D.TM.push({t:2.6,fn:function(){terminar(true);}});
}
/* ---- preparar la partida del laberinto ---- */
function labPreparar(m){
 var j=G.j,Lj=j.lab,n=m.cw*m.ch,i;
 var L={m:m,cw:m.cw,ch:m.ch,blk:new Uint8Array(n),alt:new Uint8Array(n),ex:new Uint8Array(n),exN:0,gates:[],levers:[],chests:[],kl:(Lj.kl||[]).slice(),pl:[],co:[],prox:null,regDone:{},pan:null,tG:0,floorN:0};
 for(i=0;i<n;i++){var t=m.T[i];L.blk[i]=t?1:0;L.alt[i]=(t===1||t===3)?1:0;if(t===0||t===4)L.floorN++;}
 L.wt=new Uint8Array(n);
 for(i=0;i<n;i++)if(m.T[i]===1){var x=i%m.cw,nb=[i+m.cw,i+1,i-m.cw,i-1],k;L.wt[i]=0;for(k=0;k<4;k++)if(m.T[nb[k]]!==1&&nb[k]>=0&&nb[k]<n){L.wt[i]=m.TM[nb[k]];break;}}
 L.gates=m.gates.map(function(g){return Object.assign({},g,{abierta:false,anim:0,pulled:0,timer:0});});
 L.levers=m.levers.map(function(l){return Object.assign({},l,{on:false,ang:0,cd:0});});
 L.chests=m.chests.map(function(c){return Object.assign({},c,{abierto:false});});
 var mm=document.createElement("canvas");mm.width=(m.cw+m.ch)*4+8;mm.height=(m.cw+m.ch)*2+8;L.mm=mm;L.mmg=mm.getContext("2d");
 D.lab=L;
 /* estado guardado */
 labUnpack(Lj.ex,L.ex);for(i=0;i<n;i++)if(L.ex[i]){L.exN++;labMMPix(i);}
 (Lj.pl||[]).forEach(function(id){var l=L.levers[id];if(!l)return;l.on=true;l.ang=1;if(l.tipo==="abrir"){l.g.forEach(function(gid){var g=L.gates[gid];g.pulled++;if(g.pulled>=g.need)labAbrirInicial(g);});}
  else if(l.tipo==="jaula")l.g.forEach(function(gid){labAbrirInicial(L.gates[gid]);});
  else if(l.tipo==="trampas")D.TR.forEach(function(o){if(o.g===l.grupo)o.off=true;});L.pl.push(id);});
 (Lj.co||[]).forEach(function(id){if(L.chests[id]){L.chests[id].abierto=true;L.co.push(id);}});
 function labAbrirInicial(g){g.abierta=true;g.anim=1;g.tiles.forEach(function(q){L.blk[q[1]*L.cw+q[0]]=0;});}
 /* enemigos */
 m.spawns.forEach(function(sp){
  if(L.kl.indexOf(sp.id)>=0)return;
  var e=labCrearEnemigo(sp);if(sp.cell!==undefined&&L.gates[sp.cell].abierta)e.alerta=false;D.E.push(e);
 });
 var gx=Lj.px,gy=Lj.py;
 if(gx!=null&&gy!=null&&!labBloq(gx,gy)){D.P.x=gx;D.P.y=gy;}
 else{D.P.x=m.inicio.x;D.P.y=m.inicio.y;}
}
function labActualizar(dt){
 var L=D.lab,P=D.P;
 labResolver(P);
 L.gates.forEach(function(g){
  g.anim=clamp(g.anim+(g.abierta?1:-1)*dt*1.1,0,1);
  if(g.tipo==="tiempo"&&g.abierta&&g.timer>0){
   g.timer-=dt;
   if(g.timer<=0){
    var lv=L.levers.filter(function(l){return l.g.indexOf(g.id)>=0;})[0];
    labCerrar(g);g.pulled=0;if(lv){lv.on=false;lv.cd=0;}D.banner={t:1.6,txt:"La compuerta "+LB.col[g.col].n+" se cierra"};sfx(90,.3,"sawtooth",.04,.5);
   }
  }
 });
 L.levers.forEach(function(l){l.ang+=((l.on?1:-1)-l.ang)*Math.min(1,dt*8);if(l.cd>0)l.cd-=dt;});
 if(L.pan&&L.pan.t<=0)L.pan=null;
 var tx=Math.floor(P.x/CS),ty=Math.floor(P.y/CS);
 if(tx!==L.ltx||ty!==L.lty){L.ltx=tx;L.lty=ty;labRevelar();}
 labProximo();
}

/* ---------- LABERINTO: sprites de suelo y muro (en caché, supermuestreados x2) ---------- */
var LBS=null;
function labSprites(){
 if(LBS)return LBS;
 var K=LB.K,A=LB.ALTO;LBS={f:[],w:[]};
 LBT.forEach(function(T,th){
  LBS.f[th]=[];LBS.w[th]=[];
  for(var v=0;v<4;v++){
   var cv=document.createElement("canvas");cv.width=68*K;cv.height=36*K;var g=cv.getContext("2d"),R=seed(th*131+v*17+7);
   g.scale(K,K);g.translate(34,2);g.transform(32,16,-32,16,0,0);
   g.fillStyle=T.pal[Math.floor(R()*T.pal.length)];g.fillRect(-.04,-.04,1.08,1.08);
   g.strokeStyle="rgba(8,6,12,.55)";g.lineWidth=.05;g.strokeRect(.02,.02,.96,.96);
   g.fillStyle="rgba(255,255,255,.05)";g.fillRect(.06,.06,.88,.05);
   for(var n=0;n<4;n++){g.fillStyle=R()<.5?"rgba(0,0,0,"+(.07+R()*.1)+")":"rgba(255,255,255,"+(.03+R()*.05)+")";g.fillRect(R(),R(),.05+R()*.14,.04+R()*.06);}
   if(R()<.18){g.strokeStyle="rgba(0,0,0,.4)";g.lineWidth=.03;g.beginPath();var cx=R(),cy=R();g.moveTo(cx,cy);g.lineTo(cx+(R()-.5)*.6,cy+(R()-.5)*.6);g.lineTo(cx+(R()-.5)*.9,cy+(R()-.5)*.9);g.stroke();}
   if(R()<.1){g.fillStyle="rgba(60,95,55,.26)";g.fillRect(R()*.7,R()*.7,.12+R()*.2,.1+R()*.15);}
   if(th===3&&R()<.5){g.fillStyle="rgba(215,205,180,.55)";g.fillRect(R()*.8,R()*.8,.12,.05);}
   if(th===4&&R()<.4){g.fillStyle="rgba(110,20,20,.38)";g.beginPath();g.ellipse(.2+R()*.6,.2+R()*.6,.1+R()*.12,.07+R()*.08,0,0,7);g.fill();}
   if(th===7&&R()<.5){g.fillStyle="rgba(230,190,70,.35)";g.fillRect(R()*.8,R()*.8,.06,.06);}
   if(th===6&&R()<.3){g.fillStyle="rgba(150,30,40,.18)";g.fillRect(0,0,1,1);}
   LBS.f[th][v]=cv;
  }
  for(var w=0;w<3;w++){
   var c2=document.createElement("canvas");c2.width=64*K;c2.height=(32+A)*K;var q=c2.getContext("2d"),R2=seed(th*977+w*31+3);
   q.scale(K,K);
   function F(u,vv){return[32*u,16+16*u+A*vv];}     /* cara izquierda (sur) */
   function Rr(u,vv){return[32+32*u,32-16*u+A*vv];} /* cara derecha (este) */
   var gl=q.createLinearGradient(0,16,0,32+A);gl.addColorStop(0,T.l);gl.addColorStop(1,"#1c1a22");
   q.fillStyle=gl;q.beginPath();q.moveTo(0,16);q.lineTo(32,32);q.lineTo(32,32+A);q.lineTo(0,16+A);q.closePath();q.fill();
   var gr=q.createLinearGradient(0,16,0,32+A);gr.addColorStop(0,T.r);gr.addColorStop(1,"#121016");
   q.fillStyle=gr;q.beginPath();q.moveTo(32,32);q.lineTo(64,16);q.lineTo(64,16+A);q.lineTo(32,32+A);q.closePath();q.fill();
   var rows=7,row,u;
   q.lineWidth=1;
   for(var side=0;side<2;side++){
    var P=side?Rr:F;
    for(row=1;row<rows;row++){var a=P(0,row/rows),b=P(1,row/rows);q.strokeStyle="rgba(8,6,12,.5)";q.beginPath();q.moveTo(a[0],a[1]);q.lineTo(b[0],b[1]);q.stroke();}
    for(row=0;row<rows;row++){
     u=(row%2)*.25+R2()*.12;
     while(u<1){var p1=P(u,row/rows),p2=P(u,(row+1)/rows);q.strokeStyle="rgba(8,6,12,.4)";q.beginPath();q.moveTo(p1[0],p1[1]);q.lineTo(p2[0],p2[1]);q.stroke();
      q.fillStyle=R2()<.5?"rgba(255,255,255,.04)":"rgba(0,0,0,.07)";var p3=P(Math.min(1,u+.45),row/rows),p4=P(Math.min(1,u+.45),(row+1)/rows);q.beginPath();q.moveTo(p1[0],p1[1]);q.lineTo(p3[0],p3[1]);q.lineTo(p4[0],p4[1]);q.lineTo(p2[0],p2[1]);q.closePath();q.fill();
      u+=.5;}
    }
    for(var mo=0;mo<(w===1?5:2);mo++){var mu=R2(),ma=P(mu,0),mh=10+R2()*A*.5;q.fillStyle="rgba(55,90,50,"+(.12+R2()*.14)+")";q.fillRect(ma[0]-1,ma[1],2+R2()*3,mh);}
   }
   var tg=q.createLinearGradient(0,0,64,32);tg.addColorStop(0,T.top);tg.addColorStop(1,"#4a4854");
   q.fillStyle=tg;q.beginPath();q.moveTo(32,0);q.lineTo(64,16);q.lineTo(32,32);q.lineTo(0,16);q.closePath();q.fill();
   q.strokeStyle="rgba(8,6,12,.55)";q.lineWidth=1.2;q.stroke();
   q.strokeStyle="rgba(255,255,255,.18)";q.beginPath();q.moveTo(1,16.5);q.lineTo(32,31.5);q.lineTo(63,16.5);q.stroke();
   q.strokeStyle="rgba(8,6,12,.7)";q.beginPath();q.moveTo(32,32);q.lineTo(32,32+A);q.stroke();
   q.fillStyle="rgba(0,0,0,.35)";var ao=q.createLinearGradient(0,32+A-18,0,32+A);ao.addColorStop(0,"rgba(0,0,0,0)");ao.addColorStop(1,"rgba(0,0,0,.45)");q.fillStyle=ao;
   q.beginPath();q.moveTo(0,16+A-18);q.lineTo(32,32+A-18);q.lineTo(64,16+A-18);q.lineTo(64,16+A);q.lineTo(32,32+A);q.lineTo(0,16+A);q.closePath();q.fill();
   LBS.w[th][w]=c2;
  }
 });
 return LBS;
}
function labRangoVista(vx,vy,vw,vh){
 var cs=[[vx,vy],[vx+vw,vy],[vx,vy+vh+LB.ALTO+40],[vx+vw,vy+vh+LB.ALTO+40]],x0=1e9,x1=-1e9,y0=1e9,y1=-1e9;
 cs.forEach(function(p){var x=p[1]+p[0]/2,y=p[1]-p[0]/2;x0=Math.min(x0,x);x1=Math.max(x1,x);y0=Math.min(y0,y);y1=Math.max(y1,y);});
 return{x0:Math.max(0,Math.floor(x0/CS)-1),x1:Math.min(D.lab.cw-1,Math.ceil(x1/CS)+1),y0:Math.max(0,Math.floor(y0/CS)-1),y1:Math.min(D.lab.ch-1,Math.ceil(y1/CS)+1)};
}
function labSuelo(c,vx,vy,vw,vh){
 var S=labSprites(),L=D.lab,m=L.m,r=labRangoVista(vx,vy,vw,vh),tx,ty;
 c.imageSmoothingEnabled=true;
 for(ty=r.y0;ty<=r.y1;ty++)for(tx=r.x0;tx<=r.x1;tx++){
  var i=ty*L.cw+tx;if(m.T[i]===1)continue;
  var ax=(tx-ty)*CS,ay=(tx+ty)*CS/2;
  if(ax<vx-40||ax>vx+vw+40||ay<vy-20||ay>vy+vh+40)continue;
  c.drawImage(S.f[m.TM[i]][(tx*7+ty*13+((tx*ty)&3))&3],ax-34,ay-2,68,36);
 }
 /* círculo ritual del santuario */
 m.runas.forEach(function(p){if(!labVista(p[0]*CS,p[1]*CS,200))return;
  c.save();c.strokeStyle="rgba(205,70,70,.5)";c.lineWidth=3;elip(c,p[0]*CS,p[1]*CS,p[2]*CS,false,true);c.lineWidth=1.6;elip(c,p[0]*CS,p[1]*CS,p[2]*CS*.78,false,true);elip(c,p[0]*CS,p[1]*CS,p[2]*CS*.36,false,true);
  c.fillStyle="rgba(120,30,40,.12)";elip(c,p[0]*CS,p[1]*CS,p[2]*CS,true,false);c.restore();});
}
function labMuros(Ls,c,vx,vy,vw,vh){
 var S=labSprites(),L=D.lab,m=L.m,r=labRangoVista(vx,vy,vw,vh),P=D.P,ps=pj(P.x,P.y),pk=P.x+P.y,A=LB.ALTO,tx,ty;
 for(ty=r.y0;ty<=r.y1;ty++)for(tx=r.x0;tx<=r.x1;tx++){
  var i=ty*L.cw+tx;if(m.T[i]!==1)continue;
  var ax=(tx-ty)*CS,ay=(tx+ty)*CS/2;
  if(ax<vx-40||ax>vx+vw+40||ay<vy-20||ay>vy+vh+A+40)continue;
  (function(ax,ay,i,tx,ty){
   var key=(tx+ty+1)*CS,th=L.wt[i],sp=S.w[th][(tx*5+ty*11)%3];
   Ls.push({k:key,f:function(){
    var oc=key>pk+2&&ps.x>ax-30&&ps.x<ax+30&&ps.y-30>ay-A&&ps.y-30<ay+34;
    if(oc)c.globalAlpha=.3;
    c.drawImage(sp,ax-32,ay-A,64,32+A);
    if(oc)c.globalAlpha=1;
   }});
  })(ax,ay,i,tx,ty);
 }
}
/* ---------- LABERINTO: objetos procedurales ---------- */
PD.antorcha=function(c,o){
 var p=pj(o.x,o.y),f=D.t*10+o.x*.13,fl=1+.14*Math.sin(f)+.08*Math.sin(f*2.3),z=46,sx=o.f==="s"?0:0;
 c.fillStyle="#2a2018";c.fillRect(p.x-2,p.y-z,4,13);
 c.fillStyle="#3a3a42";c.fillRect(p.x-5,p.y-z+9,10,4);
 c.fillStyle="#ff8c28";c.beginPath();c.ellipse(p.x+sx,p.y-z-4,4.4*fl,9*fl,0,0,7);c.fill();
 c.fillStyle="#ffd870";c.beginPath();c.ellipse(p.x+sx,p.y-z-2,2.4*fl,5.5*fl,0,0,7);c.fill();
};
PD.escalera=function(c,o){
 var x=o.x-14,y=o.y-14;sombraObj(c,o.x,o.y,18);
 for(var i=0;i<4;i++)cajaZ(c,x,y+i*3,28,28-i*3,i*5,i*5+5,"#8a8994","#5e5d68","#45444e");
 var p=pj(o.x,o.y);c.fillStyle="#e8c878";c.font="bold 13px Karla,sans-serif";c.textAlign="center";c.fillText("▲",p.x,p.y-30);
};
PD.cofre=function(c,o){
 var ch=D.lab.chests[o.ci],ab=ch&&ch.abierto,x=o.x-12,y=o.y-9;
 sombraObj(c,o.x+2,o.y+2,16);
 cajaZ(c,x,y,24,18,0,12,"#8a5a2c","#6a4220","#4e3016");
 if(!ab){cajaZ(c,x-1,y-1,26,20,12,19,"#a06a34","#7a4c24","#5a3818");}
 else{
  var p=pj(o.x,o.y);c.fillStyle="#1a0f06";c.beginPath();c.ellipse(p.x,p.y-12,12,6,0,0,7);c.fill();
  c.save();c.globalCompositeOperation="lighter";var g=c.createRadialGradient(p.x,p.y-14,1,p.x,p.y-14,24);g.addColorStop(0,"rgba(255,210,90,.35)");g.addColorStop(1,"rgba(255,210,90,0)");c.fillStyle=g;c.fillRect(p.x-26,p.y-40,52,52);c.restore();
 }
 var q=pj(o.x,o.y);c.fillStyle="#e0b84a";c.fillRect(q.x-2,q.y-(ab?4:11),4,5);
 if(!ab&&D.lab.prox&&D.lab.prox.o===ch)halo(c,o.x,o.y);
};
function halo(c,x,y){c.save();c.strokeStyle="rgba(255,230,140,"+(.5+.3*Math.sin(D.t*6))+")";c.lineWidth=2;elip(c,x,y,24,false,true);c.restore();}
PD.palanca=function(c,l){
 var p=pj(l.x,l.y),col=LB.col[l.col],pv={x:p.x,y:p.y-30};
 sombraObj(c,l.x,l.y,14);
 cajaZ(c,l.x-11,l.y-11,22,22,0,10,ST.t,ST.l,ST.r);cajaZ(c,l.x-6,l.y-6,12,12,10,30,"#6d6c76","#4c4b54","#383740");
 var tipX=pv.x+l.ang*17,tipY=pv.y-15+Math.abs(l.ang)*-2+(1-Math.abs(l.ang))*0;
 c.lineCap="round";c.strokeStyle="#2a2a30";c.lineWidth=5;c.beginPath();c.moveTo(pv.x,pv.y);c.lineTo(tipX,tipY);c.stroke();
 c.strokeStyle="#9a9aa4";c.lineWidth=2;c.beginPath();c.moveTo(pv.x,pv.y);c.lineTo(tipX,tipY);c.stroke();c.lineCap="butt";
 c.fillStyle=col.c;c.beginPath();c.arc(tipX,tipY,5,0,7);c.fill();c.strokeStyle="rgba(0,0,0,.6)";c.lineWidth=1;c.stroke();
 c.save();c.globalCompositeOperation="lighter";var gl=.35+(l.on?.25:.12*Math.sin(D.t*3));var g=c.createRadialGradient(tipX,tipY,1,tipX,tipY,22);g.addColorStop(0,"rgba("+col.r+","+gl+")");g.addColorStop(1,"rgba("+col.r+",0)");c.fillStyle=g;c.fillRect(tipX-24,tipY-24,48,48);c.restore();
 if(l.tipo==="tiempo"&&l.cd>0){c.fillStyle="#fff";c.font="bold 11px Karla,sans-serif";c.textAlign="center";c.fillText(Math.ceil(l.cd)+"s",p.x,p.y-52);}
 if(D.lab.prox&&D.lab.prox.o===l)halo(c,l.x,l.y);
};
PD.compuerta=function(c,g){
 var col=LB.col[g.col],t=g.tiles,hor=g.axis==="x",x0=t[0][0]*CS,y0=t[0][1]*CS,w=hor?3*CS:CS,h=hor?CS:3*CS,A=LB.ALTO,
  zt=A-16,zb=g.anim*zt,n=hor?10:10,i;
 /* dintel */
 cajaZ(c,x0,y0,w,h,A-14,A,"#6d6c76","#4c4b54","#383740");
 /* barrotes */
 if(zb<zt-3){
  c.lineCap="round";
  for(i=0;i<=n;i++){
   var px=hor?x0+i*w/n:x0+h*0+CS/2,py=hor?y0+CS/2:y0+i*h/n,s=pj(px,py);
   c.strokeStyle="#22222a";c.lineWidth=4;c.beginPath();c.moveTo(s.x,s.y-zb);c.lineTo(s.x,s.y-zt);c.stroke();
   c.strokeStyle="#7a7a86";c.lineWidth=1.4;c.beginPath();c.moveTo(s.x-1,s.y-zb);c.lineTo(s.x-1,s.y-zt);c.stroke();
  }
  var a=hor?pj(x0,y0+CS/2):pj(x0+CS/2,y0),b=hor?pj(x0+w,y0+CS/2):pj(x0+CS/2,y0+h);
  [zt*.25,zt*.62].forEach(function(z){var zz=Math.max(z,zb+2);c.strokeStyle="#34343c";c.lineWidth=4;c.beginPath();c.moveTo(a.x,a.y-zz);c.lineTo(b.x,b.y-zz);c.stroke();});
  c.lineCap="butt";
 }
 /* gema de color + contador */
 var m=pj(x0+w/2,y0+h/2);
 c.fillStyle=col.c;c.beginPath();c.arc(m.x,m.y-A+7,6,0,7);c.fill();c.strokeStyle="rgba(0,0,0,.7)";c.lineWidth=1.2;c.stroke();
 c.save();c.globalCompositeOperation="lighter";var gr=c.createRadialGradient(m.x,m.y-A+7,1,m.x,m.y-A+7,26);gr.addColorStop(0,"rgba("+col.r+",.4)");gr.addColorStop(1,"rgba("+col.r+",0)");c.fillStyle=gr;c.fillRect(m.x-28,m.y-A-20,56,54);c.restore();
 if(g.need>1&&!g.abierta){for(i=0;i<g.need;i++){c.fillStyle=i<g.pulled?col.c:"#26242c";c.beginPath();c.arc(m.x+(i-(g.need-1)/2)*11,m.y-A+22,3.4,0,7);c.fill();c.strokeStyle="#000";c.lineWidth=1;c.stroke();}}
 if(g.tipo==="tiempo"&&g.abierta&&g.timer>0){c.fillStyle="#fff";c.font="bold 12px Karla,sans-serif";c.textAlign="center";c.strokeStyle="#000";c.lineWidth=3;c.strokeText(Math.ceil(g.timer)+"s",m.x,m.y-A-6);c.fillText(Math.ceil(g.timer)+"s",m.x,m.y-A-6);}
};
/* ---------- LABERINTO: HUD (minimapa con niebla, aviso de interacción) ---------- */
function labMMxy(tx,ty){var L=D.lab;return{x:(tx-ty+L.ch)*4,y:(tx+ty)*2};}
function labIconos(c,s){
 var L=D.lab,m=L.m;
 function vis(tx,ty){return L.ex[ty*L.cw+tx]===1;}
 L.gates.forEach(function(g){var tx=g.tiles[1][0],ty=g.tiles[1][1];if(!vis(tx,ty))return;var p=labMMxy(tx+.5,ty+.5);c.fillStyle=g.abierta?"rgba(255,255,255,.35)":LB.col[g.col].c;c.fillRect(p.x-3,p.y-3,6,6);c.strokeStyle="#000";c.lineWidth=1;c.strokeRect(p.x-3,p.y-3,6,6);});
 L.levers.forEach(function(l){if(!vis(l.tx,l.ty))return;var p=labMMxy(l.tx+.5,l.ty+.5);c.fillStyle=LB.col[l.col].c;c.beginPath();c.arc(p.x,p.y,3.4,0,7);c.fill();c.strokeStyle=l.on?"#fff":"#000";c.lineWidth=1.2;c.stroke();});
 L.chests.forEach(function(ch){if(ch.abierto||!vis(ch.tx,ch.ty))return;var p=labMMxy(ch.tx+.5,ch.ty+.5);c.fillStyle="#f0d060";c.fillRect(p.x-2,p.y-2,4,4);});
 var b=m.spawns.filter(function(x){return x.boss;})[0];
 if(b&&vis(Math.floor(b.x/CS),Math.floor(b.y/CS))&&!L.kl.some(function(id){return id===b.id;})){var p2=labMMxy(b.x/CS,b.y/CS);c.fillStyle="#e05040";c.font="bold 13px Karla,sans-serif";c.textAlign="center";c.fillText("☠",p2.x,p2.y+4);}
 var sa=m.salida;if(sa){var p3=labMMxy(sa.tx+.5,sa.ty+.5);c.fillStyle="#70d890";c.beginPath();c.moveTo(p3.x,p3.y-4);c.lineTo(p3.x+4,p3.y+3);c.lineTo(p3.x-4,p3.y+3);c.closePath();c.fill();}
 var pp=labMMxy(D.P.x/CS,D.P.y/CS);
 c.fillStyle="rgba(255,255,255,.35)";c.beginPath();c.arc(pp.x,pp.y,6+1.5*Math.sin(D.t*5),0,7);c.fill();c.fillStyle="#fff";c.beginPath();c.arc(pp.x,pp.y,3,0,7);c.fill();c.strokeStyle="#c9923c";c.lineWidth=1.2;c.stroke();
}
function labMiniHUD(c){
 var L=D.lab,pp=labMMxy(D.P.x/CS,D.P.y/CS),big=!!D.mapaGrande,mw=L.mm.width,mh=L.mm.height,pw,ph,px0,py0,s;
 if(big){s=Math.min((VW-60)/mw,(VH-110)/mh);pw=mw*s;ph=mh*s;px0=(VW-pw)/2;py0=(VH-ph)/2-6;}
 else{s=.85;pw=232;ph=150;px0=VW-pw-10;py0=46;}
 c.save();
 if(big){c.fillStyle="rgba(4,3,8,.82)";c.fillRect(0,0,VW,VH);}
 c.fillStyle="rgba(8,6,12,"+(big?.9:.72)+")";c.fillRect(px0-4,py0-4,pw+8,ph+8);
 c.strokeStyle="#c9923c";c.lineWidth=1.5;c.strokeRect(px0-4,py0-4,pw+8,ph+8);
 c.beginPath();c.rect(px0,py0,pw,ph);c.clip();
 if(big)c.translate(px0,py0);else c.translate(px0+pw/2-pp.x*s,py0+ph/2-pp.y*s);
 c.scale(s,s);c.imageSmoothingEnabled=true;
 c.drawImage(L.mm,0,0);labIconos(c,s);
 if(big){
  c.font="bold 9px Karla,sans-serif";c.textAlign="center";c.fillStyle="rgba(240,230,200,.85)";c.strokeStyle="rgba(0,0,0,.8)";c.lineWidth=2.5;
  L.m.regs.forEach(function(r){if(r.pasillo||r.tipo==="sala"||r.tipo==="vest")return;if(!L.ex[Math.floor(r.cy)*L.cw+Math.floor(r.cx)])return;
   var p=labMMxy(r.cx,r.cy),nm=LBN[r.tipo]||"";c.strokeText(nm,p.x,p.y+3);c.fillText(nm,p.x,p.y+3);});
 }
 c.restore();
 c.save();c.textAlign=big?"center":"left";c.font="bold 11px Karla,sans-serif";c.fillStyle="#e0c060";
 var pct=Math.floor(L.exN/L.floorN*100);
 if(big){c.fillText("MAPA EXPLORADO "+pct+"% · ☠ jefe · ● palanca · ▪ compuerta · ▪ dorado cofre · ▲ salida · [Tab] o clic para cerrar",VW/2,py0+ph+22);}
 else{c.fillText("Explorado "+pct+"% · [Tab] mapa",px0,py0+ph+16);}
 c.restore();
 if(!big&&L.prox){c.save();c.textAlign="center";c.font="bold 15px Karla,sans-serif";c.lineWidth=4;c.strokeStyle="rgba(0,0,0,.85)";c.fillStyle="#ffe090";var t="[F] "+L.prox.txt;c.strokeText(t,VW/2,VH-62);c.fillText(t,VW/2,VH-62);c.restore();}
}
/* ---------- LABERINTO EN GRUPO ----------
   Solo los miembros del mismo grupo comparten laberinto (instancia propia: semilla, enemigos, palancas, cofres). Quien juega solo tiene su entorno.
   - Mismo laberinto y mismos enemigos: la semilla y el piso/ciclo vienen del servidor (labCrearEnemigo es determinista con esa semilla).
   - El ANFITRIÓN (host) simula la IA de los enemigos y envía su estado ~10 veces/s; el resto los ve como "marionetas" y envía su daño al anfitrión.
     Si el anfitrión sale, el servidor nombra otro y este continúa la simulación.
   - Los ataques enemigos se evalúan en cada cliente contra su propio jugador (ataques cuerpo a cuerpo/área y proyectiles se difunden).
   - Muertes de enemigos, palancas y cofres se difunden a todos; cada uno recibe su botín. */
function netPup(){return !!(D&&D.net&&D.net.on&&!D.net.host);}
function netHost(){return !!(D&&D.net&&D.net.on&&D.net.host);}
function netEnv(o,a){var H=window.OnlineHub;if(!H||!D||!D.net||!D.net.on)return;o.t="lab_ev";if(a!=null)o.a=a;H.enviar(o);}
/* Buffs de apoyo (Paladín: defensa · Clérigo: todos): se reparten a los aliados del grupo. Solo viaja la parte de buff (el daño no se aplica a los aliados). */
function netBuff(o){if(D&&D.net&&D.net.on){o.k="buff";o.ax=D.P.x;o.ay=D.P.y;o.ar=175;netEnv(o);}}   /* solo lo reciben los aliados dentro de 175 de radio del lanzador */
function netBuffRecibido(m){
 var P=D.P,st=D.st,j=D.j;if(!P||!st||P.hp<=0||D.estado!=="play")return;
 if(m.ar>0&&Math.hypot(P.x-m.ax,P.y-m.ay)>m.ar)return;
 var px=P.x,py=P.y,c0=m.col||"#ffe9a0";
 if(m.hf>0){var hl=Math.floor(st.vidaMax*m.hf);P.hp=Math.min(st.vidaMax,P.hp+hl);txt(px,py,"+"+hl,"#7ab88a",18,30);}
 if(m.df>0){P.defB=Math.floor(m.df);P.defT=m.dt||6;txt(px,py,"+"+P.defB+" DEF",c0,14,44);}
 if(m.sf>0){P.sh=Math.floor(st.vidaMax*m.sf);P.shT=Math.max(8,m.dt||8);txt(px,py,"Escudo "+P.sh,"#8ab0d8",13,58);}
 if(m.pur)purgarControl();
 if(m.tb){var b=m.tb;j.tb={n:b.n,t:b.t,dm:b.dm||0,rb:b.rb||0,vl:b.vl||0,vl2:b.vl2||0,dpl:b.dpl||0,cc:b.cc||0,red:b.red||0,reg:b.reg||0,ref:b.ref||0,hp:0,acc:0};txt(px,py,"✦ "+b.n,c0,13,70);}
 fx({k:"dome",r:38,col:c0,life:.9});fx({k:"shock",x:px,y:py,r1:90,col:c0,life:.5,low:true,rays:0});motas(px,py,14,c0,26,80,.9);
 sfx(420,.2,"sine",.04,1.6);
}
function netCrear(r){return{on:true,id:r.id,host:r.host===r.id,piso:r.piso,ciclo:r.ciclo,seed:r.seed,AL:{},idx:{},tP:0,tS:0,unsub:null};}
function netIniciar(){
 var N=D.net,H=window.OnlineHub;
 D.E.forEach(function(e){if(e.lab)N.idx[e.sid]=e;});
 if(!H){N.on=false;return;}
 N.unsub=H.suscribir(netRecibe,true);
 D.banner={t:3,txt:"👥 Laberinto de grupo"};
}
function netApagar(){var N=D&&D.net;if(!N||!N.on)return;N.on=false;N.AL={};if(N.unsub){try{N.unsub();}catch(e){}N.unsub=null;}if(D)D.banner={t:2.5,txt:"Has dejado de estar sincronizado con el grupo"};}
function netFin(){var N=D&&D.net;if(!N)return;var H=window.OnlineHub,on=N.on;netApagar();if(on&&H)H.labSalir();}
function tgtDe(e){
 var P=D.P;if(!(D.net&&D.net.on))return P;
 var best=P,bd=P.hp>0?Math.hypot(P.x-e.x,P.y-e.y):1e9,AL=D.net.AL;
 for(var id in AL){var A=AL[id];if(A.hp<=0)continue;var d=Math.hypot(A.x-e.x,A.y-e.y);if(d<bd&&d<CS*12&&libre(e.x,e.y,A.x,A.y,4,true)){bd=d;best=A;}}
 return best;
}
function netPupPaso(e,dt){
 e.flash=Math.max(0,e.flash-dt*4);e.mov=!!e.mov;
 if(e.nx!==undefined){var k=Math.min(1,dt*14);e.x+=(e.nx-e.x)*k;e.y+=(e.ny-e.y)*k;}
 if(e.st==="wind"&&e.att)e.att.t=Math.max(0,e.att.t-dt);
}
function netSnap(forzar,a){
 var l=[];
 D.E.forEach(function(e){
  if(!e.lab)return;
  if(!e.alerta&&!forzar)return;
  var it={s:e.sid,x:Math.round(e.x*10)/10,y:Math.round(e.y*10)/10,v:Math.ceil(e.vida),a:e.alerta?1:0,f:Math.round((e.fa||0)*100)/100,m:e.mov?1:0};
  if(e.st==="wind"&&e.att){var A=e.att;it.w={k:A.kind,t:Math.round(A.t*100)/100,d:A.dur,r:A.rad,cx:A.cx,cy:A.cy,g:A.ang,y:A.tipo,e:A.esp?A.esp.ef:null};}
  else{var key=it.x+"|"+it.y+"|"+it.v+"|"+it.a+"|"+it.m+"|"+it.f;if(!forzar&&e._ls===key)return;e._ls=key;}
  l.push(it);
 });
 if(l.length)netEnv({k:"s",E:l},a);
}
function netTick(dt){
 var N=D.net,P=D.P;
 N.tP-=dt;if(N.tP<=0){N.tP=.1;netEnv({k:"p",x:Math.round(P.x),y:Math.round(P.y),f:Math.round(P.face*100)/100,d:P.dir,m:P.mv?1:0,h:Math.round(P.hp),H:D.st.vidaMax,s:D.sp,n:D.j.nombre,c:D.j.clase,l:D.j.nivel});}
 if(N.host){N.tS-=dt;if(N.tS<=0){N.tS=.1;netSnap(false);}}
 for(var id in N.AL){var A=N.AL[id];if(D.t-A.t>5){delete N.AL[id];continue;}var k=Math.min(1,dt*12);A.x+=(A.tx-A.x)*k;A.y+=(A.ty-A.y)*k;}
}
function netAscender(){ /* este cliente es ahora el anfitrión: reanuda la IA desde el estado de las marionetas */
 D.E.forEach(function(e){if(e.st==="wind"){e.st="move";e.att=null;e.cd=Math.max(e.cd||0,.8);}e.nx=undefined;});
 D.banner={t:2.5,txt:"Ahora eres el anfitrión del grupo"};
}
function netRecibe(m){
 if(!D||!D.net||!D.net.on)return;
 var N=D.net;
 if(m.t==="hub_cerrado"){netApagar();return;}
 if(m.t==="lab_host"){var h0=N.host;N.host=(m.id===N.id);if(N.host&&!h0)netAscender();return;}
 if(m.t==="lab_pedir"){if(N.host){netEnv({k:"estado",kl:D.lab.kl.slice(),pl:D.lab.pl.slice(),co:D.lab.co.slice()},m.id);netSnap(true,m.id);}return;}
 if(m.t==="g_estado"){
  var lb=m.grupo&&m.grupo.lab;if(!lb||lb.en.indexOf(N.id)<0){netApagar();return;}
  for(var id in N.AL)if(lb.en.indexOf(+id)<0)delete N.AL[id];
  return;
 }
 if(m.t!=="lab_ev")return;
 var e,A;
 switch(m.k){
  case"p":
   A=N.AL[m.de];if(!A)A=N.AL[m.de]={id:m.de,x:m.x,y:m.y,tx:m.x,ty:m.y,r:14,face:0,dir:0,mv:false,hp:1,hpMax:1,sp:m.s,nombre:"",clase:"",nivel:1,t:D.t};
   A.tx=m.x;A.ty=m.y;A.face=m.f;A.dir=m.d;A.mv=!!m.m;A.hp=m.h;A.hpMax=m.H;if(m.s!=null)A.sp=m.s;if(m.n)A.nombre=m.n;if(m.c)A.clase=m.c;if(m.l)A.nivel=m.l;A.t=D.t;break;
  case"s":
   (m.E||[]).forEach(function(it){
    var q=N.idx[it.s];if(!q||D.E.indexOf(q)<0)return;
    q.nx=it.x;q.ny=it.y;if(!q.pq){q.x=it.x;q.y=it.y;q.pq=1;}
    q.vida=it.v;q.alerta=!!it.a;q.fa=it.f;q.mov=!!it.m;
    if(it.w){q.st="wind";q.att={kind:it.w.k,t:it.w.t,dur:it.w.d,rad:it.w.r,cx:it.w.cx,cy:it.w.cy,ang:it.w.g,tipo:it.w.y,esp:it.w.e?{ef:it.w.e}:null};}
    else if(q.st==="wind"){q.st="move";q.att=null;}
   });break;
  case"herida":
   if(!N.host)break;e=N.idx[m.s];if(!e||D.E.indexOf(e)<0||e.vida<=0)break;
   e.vida-=m.d;e.flash=1;if(e.lab&&!e.alerta)labAlertar(e);
   if(m.kb&&!e.dummy){var a0=Math.atan2(e.y-m.ay,e.x-m.ax),jf=(e.tipo==="jefe"?.2:e.tipo==="mini_jefe"?.5:1);e.kx+=Math.cos(a0)*m.kb*jf*4;e.ky+=Math.sin(a0)*m.kb*jf*4;}
   if(m.stun&&!e.dummy)e.stunT=Math.max(e.stunT,m.stun*(e.tipo==="jefe"?.5:e.tipo==="mini_jefe"?.7:1));
   txt(e.x+rf(-8,8),e.y,String(m.d),m.cr?"#ffd24a":"#f0f0f0",m.cr?20:14,e.r+8);
   if(e.vida<=0)matar(e);break;
  case"muere":
   e=N.idx[m.s];if(e&&D.E.indexOf(e)>=0){e.vida=0;matar(e);}break;
  case"atq":
   e=N.idx[m.s];if(!e||D.E.indexOf(e)<0)break;
   var ox=e.x,oy=e.y,st0=e.st,at0=e.att;
   e.x=m.x;e.y=m.y;e.att={kind:m.A.kind,ang:m.A.ang,rad:m.A.rad,mult:m.A.mult,tipo:m.A.tipo,cx:m.A.cx,cy:m.A.cy,esp:m.A.ef?{ef:m.A.ef}:null};
   resolverAtaque(e,true);
   e.x=ox;e.y=oy;e.att=null;e.st="move";break;
  case"proy":
   e=N.idx[m.s];if(!e)break;
   D.PR.push({e:true,x:m.x,y:m.y,vx:m.vx,vy:m.vy,r:8,life:2.4,src:e,tipo:m.tp,mult:1,col:COLOR_DANO[m.tp],sty:"orbe"});break;
  case"buff":netBuffRecibido(m);break;
  case"palanca":{var l=D.lab.levers[m.id];if(l&&(!l.on||l.tipo==="tiempo"))labPalanca(l,false,true);break;}
  case"cofre":{var c=D.lab.chests[m.id];if(c&&!c.abierto)labCofre(c,true);break;}
  case"estado":{
   (m.kl||[]).forEach(function(sid){var q=N.idx[sid],i=q?D.E.indexOf(q):-1;if(i>=0)D.E.splice(i,1);if(D.lab.kl.indexOf(sid)<0)D.lab.kl.push(sid);});
   (m.pl||[]).forEach(function(id){var l2=D.lab.levers[id];if(l2&&!l2.on){labPalanca(l2,true,true);if(D.lab.pl.indexOf(id)<0)D.lab.pl.push(id);}});
   (m.co||[]).forEach(function(id){var c2=D.lab.chests[id];if(c2&&!c2.abierto){c2.abierto=true;if(D.lab.co.indexOf(id)<0)D.lab.co.push(id);}});
   labGuardar(true);break;}
 }
}
function dibujarAliado(c,A){
 var inf=CHARS_INFO[A.sp];if(!inf)return;
 var esc=58/inf.h,fr=A.mv?[1,0,1,2][Math.floor(D.t*8)%4]:1,q=pj(A.x,A.y),y0=q.y-inf.h*esc-12;
 c.save();
 c.fillStyle="rgba(0,0,0,.38)";elip(c,A.x,A.y,A.r,true);
 if(!sprChar(c,A.sp,A.x,A.y,A.dir,fr,esc,A.hp<=0?.4:1,false)){c.fillStyle="#9fd0ff";c.beginPath();c.arc(q.x,q.y-20,A.r,0,7);c.fill();}
 c.font="bold 11px Karla,sans-serif";c.textAlign="center";c.lineWidth=3;c.strokeStyle="rgba(0,0,0,.85)";c.fillStyle="#9fd0ff";
 var nm=(A.nombre||"Aliado");c.strokeText(nm,q.x,y0);c.fillText(nm,q.x,y0);
 c.fillStyle="rgba(0,0,0,.7)";c.fillRect(q.x-20,y0+3,40,5);c.fillStyle="#4caf50";c.fillRect(q.x-20,y0+3,40*Math.max(0,Math.min(1,A.hp/(A.hpMax||1))),5);
 c.restore();
}
/* datos del jugador para el panel de grupo (lo lee OnlineHub) */
window.labOnlineInfo=function(){if(!D||!D.lab||!D.P||!D.st)return null;return{hp:Math.max(0,Math.round(D.P.hp)),hpMax:D.st.vidaMax,mp:Math.round(D.P.mp),mpMax:D.st.recursoMax};};

/* ---------- LABERINTO: fin, salida y entrada ---------- */
function labSalir(){
 if(!D||!D.lab)return;
 labGuardar(false);
 G.log.push("Subes las escaleras del Laberinto de Artaros.");avanzarTiempo(10);G.aventuraPiso=null;G.screen="laberinto";guardar();cerrar();render();
}
function labFin(gana){
 var j=G.j,base=clamp(j.piso||1,1,70),bio=getBioma({piso:base}),log=[],dps=D.t>0?Math.floor(D.dmgOut/D.t):0;
 if(gana){
  mzGuardarEstado();avanzarTiempo(60);
  var oro=mzInfOro(300+base*60);j.oro+=oro;log.push("+"+oro+" de oro (tesoro del Guardián)");
  for(var k=0;k<3;k++)farmearBioma(bio.id,j,false);
  if(bio.material){agregarItem(j,bio.material,3);log.push("+3 "+bio.material);}
  j.labHechos=(j.labHechos||0)+1;j.lab=null;guardar();
 }else{
  if(j.lab){labGuardar(false,false);}
  finCombateMuerte();
 }
 G.screen="laberinto";render();
 var p=document.getElementById("dmEnd");if(!p)return;
 p.style.display="flex";
 var L=(G.log||[]).filter(function(l){return typeof l==="string"&&l.indexOf("--- Saqueo")!==0;}).slice(-14).map(function(l){return l.replace(/<[^>]*>/g,"");});
 p.innerHTML='<div class="card" style="text-align:center;min-width:280px;max-width:94%"><div class="font-disp" style="font-size:24px;color:'+(gana?'#7ab88a':'#e06a5a')+';margin-bottom:8px">'+(gana?'¡Laberinto superado!':'Has caído en el Laberinto')+'</div>'
  +'<div style="font-size:12px;line-height:1.7;color:var(--muted);margin-bottom:8px">Tiempo '+D.t.toFixed(0)+' s · Enemigos '+D.kills+' · Explorado '+Math.floor(D.lab.exN/D.lab.floorN*100)+'% · Daño '+D.dmgOut+' ('+dps+' DPS) · Recibido '+D.dmgIn
  +(gana?'':'<br>Tu progreso en el laberinto se conserva; reapareces en la entrada con una maldición.')+'</div>'
  +'<div style="max-height:190px;overflow:auto;text-align:left;font-size:12px;line-height:1.6;margin-bottom:12px;padding:8px;border:1px solid var(--border);border-radius:8px;background:rgba(0,0,0,.25)">'+log.concat(L).join('<br>')+'</div>'
  +'<button class="btn btn-primary" id="dmCont" style="padding:8px 26px">Continuar</button></div>';
 document.getElementById("dmCont").onclick=function(){cerrar();render();};
 sfx(gana?660:90,.5,"triangle",.06,gana?1.5:.4);
}
function labOverlay(txt){
 var o=document.createElement("div");o.id="demoOv";o.className="demo-ov";
 o.innerHTML='<div class="demo-wrap"><div class="card" style="max-width:520px;margin:40px auto;text-align:center"><div class="font-disp" style="font-size:20px;color:var(--accent);margin-bottom:8px">Laberinto de Artaros</div><div style="color:var(--muted);font-size:13px">'+txt+'</div></div></div>';
 document.body.appendChild(o);return o;
}
function mazmorraLaberinto(nuevo){
 var j=G.j;if(!j)return;
 cerrar();
 var H=window.OnlineHub;
 if(H&&H.conectado()&&H.enGrupo()){
  /* en grupo: el servidor da la semilla/piso/ciclo de la instancia del grupo (si ya existe, te unes a ella) */
  OV=labOverlay("Reuniendo al grupo…");var ov=OV;
  H.labEntrar({seed:(j.lab&&j.lab.g&&!nuevo)?(j.lab.o||j.lab.s):Math.floor(Math.random()*1e9)+1,piso:clamp(j.piso||1,1,70),ciclo:j.ciclo||0},function(r){
   if(OV!==ov)return;
   labArrancar(nuevo,r);
  });
  return;
 }
 OV=labOverlay("Descendiendo a las mazmorras…");
 labArrancar(nuevo,null);
}
function labArrancar(nuevo,r){
 var j=G.j;
 j.cooldowns=[0,0,0,0,0];j.defTemp=0;j.defTurnos=0;j.escudo=0;j.inmune=0;j.silencio=0;j.aturdido=0;j.resAturdir=0;j.tb=null;j.nx=null;
 if(r){
  /* expedición de grupo: tu expedición en solitario se guarda aparte y se recupera al volver a jugar solo */
  if(j.lab&&!j.lab.g){j.labPersonal=j.lab;j.lab=null;}
  if(!j.lab||j.lab.o!==r.seed)j.lab={g:1,o:r.seed,s:r.seed,ex:"",kl:[],pl:[],co:[],px:null,py:null};
 }else{
  if(j.labPersonal&&(!j.lab||j.lab.g)){j.lab=j.labPersonal;j.labPersonal=null;}
  if(nuevo||!j.lab||j.lab.g)j.lab={s:Math.floor(Math.random()*1e9)+1,ex:"",kl:[],pl:[],co:[],px:null,py:null};
 }
 G.aventuraPiso=null;G.volverCastillo=false;G.log=["(Laberinto de Artaros: sin avanzar en la historia)"];G.enemigos=null;
 var M=labMapa(j.lab.s);j.lab.s=M.seed;
 CFG.mz=true;CFG.lab=true;CFG.inf=false;CFG.usarSave=true;CFG.piso=r?r.piso:clamp(j.piso||1,1,70);CFG.ciclo=r?r.ciclo:(j.ciclo||0);CFG.modo="oleadas";CFG.oleadas=1;CFG.labMapa=M;CFG.mapa="campo";CFG.net=r||null;
 var ov=OV;
 cargarRecursos(function(){if(OV===ov)iniciar();});
}
window.mazmorraLaberinto=mazmorraLaberinto;

function labClic(){
 var L=D.lab;
 if(D.mapaGrande){D.mapaGrande=false;return true;}
 if(D.msx>VW-250&&D.msx<VW-2&&D.msy>40&&D.msy<210){D.mapaGrande=true;return true;}
 var pr=L.prox;
 if(pr&&Math.hypot(pr.x-D.mouse.x,pr.y-D.mouse.y)<70){labInteractuar();return true;}
 return false;
}

/* ---------- entrada desde el menú / hub (sin tocar render.js) ---------- */
window.demoCombateAbrir=abrir;
function btnDemo(extra){var b=document.createElement("button");b.className="btn"+(extra||"");b.id="bDemoCmb";return b;}
if(typeof renderTitle==="function"){
 var _rt=renderTitle;
 renderTitle=function(){
  _rt();
  var s=document.getElementById("bSalir");if(!s||document.getElementById("bDemoCmb"))return;
  var b=btnDemo();b.style.cssText="font-size:16px;padding:12px 28px";b.innerHTML=iconoSVG("espada")+"Demo de Combate";b.onclick=abrir;
  s.parentNode.insertBefore(b,s);
 };
}
})();
