"use strict";
/* CUENTA — las partidas viven en el SERVIDOR (server/datos/), una cuenta por usuario.
   Se carga lo primero en index.html y en cada mapa (tilemap/*.html).
   - Sin sesión -> /login.html.
   - Página principal: descarga del servidor los datos "naradak_*" del usuario y los deja en localStorage
     (que pasa a ser solo una copia de trabajo para el juego, que sigue usando localStorage tal cual).
   - Todas las páginas (también los mapas en iframe): cada setItem/removeItem de "naradak_*" se envía al servidor. */
(function(){
 var K_AUTH="nrdk_auth",K_USER="nrdk_cache_user",RE=/^naradak_[A-Za-z0-9_]{1,48}$/;
 var esTop=(window.top===window),LS,proto=Storage.prototype,setO=proto.setItem,remO=proto.removeItem,getO=proto.getItem,keyO=proto.key;
 try{LS=window.localStorage;getO.call(LS,"x");}catch(e){document.write('<p style="font:16px sans-serif;color:#e8dcc4;background:#12100c;padding:20px">Este navegador bloquea el almacenamiento local; es necesario para iniciar sesión.</p>');return;}

 function L(k){try{return getO.call(LS,k);}catch(e){return null;}}
 function S(k,v){try{setO.call(LS,k,v);}catch(e){}}
 function R(k){try{remO.call(LS,k);}catch(e){}}
 function clavesLocales(){var r=[],n=0;try{n=LS.length;}catch(e){}for(var i=0;i<n;i++){var k=keyO.call(LS,i);if(k&&RE.test(k))r.push(k);}return r;}

 /* ---- sesión ---- */
 function leerAuth(){try{var a=JSON.parse(L(K_AUTH)||"null");return a&&a.t&&a.u?a:null;}catch(e){return null;}}
 if(esTop){      /* el cliente APK entrega la sesión por el hash (#auth=) y por la query (?nrdk_auth=): según el WebView uno de los dos puede perderse */
  try{var h=new URLSearchParams((location.hash||"").slice(1)),qs=new URLSearchParams(location.search||""),
    t=h.get("auth")||qs.get("nrdk_auth"),u=h.get("u")||qs.get("nrdk_u");
   if(t&&u){S(K_AUTH,JSON.stringify({t:t,u:u}));
    qs.delete("nrdk_auth");qs.delete("nrdk_u");var rq=qs.toString();
    history.replaceState(null,"",location.pathname+(rq?"?"+rq:""));}}catch(e){}
 }
 var auth=leerAuth(),bloqueado=false;
 function irLogin(){
  bloqueado=true;
  if(esTop){var next=location.pathname+location.search;location.replace("/login.html?next="+encodeURIComponent(next));}
 }
 function sesionCaducada(){R(K_AUTH);irLogin();}
 if(!auth){irLogin();return;}

 function http(metodo,ruta,cuerpo,asinc){
  var x=new XMLHttpRequest();x.open(metodo,"/api"+ruta,!!asinc);
  x.setRequestHeader("Authorization","Bearer "+auth.t);
  if(cuerpo!=null)x.setRequestHeader("Content-Type","application/json");
  return x;
 }

 /* ---- subida al servidor (cola con retardo) ---- */
 var cola={},borrar=[],timer=null,estado="ok",pill=null;
 function pintaEstado(){if(!pill)return;var p=pill.firstChild;if(p)p.style.background=estado==="ok"?"#7bbf6a":estado==="subiendo"?"#c9923c":"#d05a5a";pill.title=estado==="ok"?"Guardado en el servidor":estado==="subiendo"?"Guardando…":"Sin conexión con el servidor: reintentando";}
 function encola(k,v){if(bloqueado)return;if(v===null){delete cola[k];if(borrar.indexOf(k)<0)borrar.push(k);}else{cola[k]=v;var i=borrar.indexOf(k);if(i>=0)borrar.splice(i,1);}estado="subiendo";pintaEstado();clearTimeout(timer);timer=setTimeout(flush,400);}
 function hayCola(){for(var k in cola)return true;return borrar.length>0;}
 function flush(){
  clearTimeout(timer);timer=null;
  if(!hayCola()||bloqueado){if(!hayCola()){estado="ok";pintaEstado();}return;}
  var env={set:cola,del:borrar};cola={};borrar=[];
  var x=http("PUT","/datos",1,true);
  x.onload=function(){
   if(x.status===401){sesionCaducada();return;}
   if(x.status>=200&&x.status<300){if(hayCola())timer=setTimeout(flush,400);else{estado="ok";pintaEstado();}}
   else if(x.status===400||x.status===413){estado="error";pintaEstado();try{console.warn("Guardado rechazado:",x.responseText);}catch(e){}}
   else fallo(env);
  };
  x.onerror=x.ontimeout=function(){fallo(env);};
  x.send(JSON.stringify(env));
 }
 function fallo(env){   /* devuelve a la cola lo que no se haya sobrescrito y reintenta */
  for(var k in env.set)if(!(k in cola)&&borrar.indexOf(k)<0)cola[k]=env.set[k];
  env.del.forEach(function(k){if(!(k in cola)&&borrar.indexOf(k)<0)borrar.push(k);});
  estado="error";pintaEstado();clearTimeout(timer);timer=setTimeout(flush,4000);
 }
 function flushSync(){   /* usado al cerrar sesión */
  if(!hayCola())return true;
  var env={set:cola,del:borrar};cola={};borrar=[];
  try{var x=http("PUT","/datos",1,false);x.send(JSON.stringify(env));return x.status>=200&&x.status<300;}catch(e){return false;}
 }
 function alSalirDePagina(){   /* último intento al cerrar/ocultar la página */
  if(!hayCola()||bloqueado)return;
  var env={set:cola,del:borrar},body=JSON.stringify(env);cola={};borrar=[];
  var ok=false;
  try{ok=navigator.sendBeacon("/api/datos?t="+encodeURIComponent(auth.t),body);}catch(e){}
  if(!ok){try{fetch("/api/datos",{method:"PUT",keepalive:body.length<60000,headers:{"Authorization":"Bearer "+auth.t,"Content-Type":"application/json"},body:body});}catch(e){}}
 }
 window.addEventListener("pagehide",alSalirDePagina);
 document.addEventListener("visibilitychange",function(){if(document.visibilityState==="hidden")alSalirDePagina();});

 /* ---- interceptar el guardado del juego ---- */
 proto.setItem=function(k,v){setO.call(this,k,v);if(this===LS&&RE.test(k))encola(k,String(v));};
 proto.removeItem=function(k){remO.call(this,k);if(this===LS&&RE.test(k))encola(k,null);};

 /* ---- carga inicial desde el servidor (solo página principal) ---- */
 if(esTop){
  var x=http("GET","/datos",null,false),res=null;
  try{x.send();}catch(e){}
  if(x.status===401){sesionCaducada();return;}
  if(x.status!==200){
   bloqueado=true;
   document.write('<div style="font:16px Georgia,serif;color:#e8dcc4;background:#12100c;min-height:100vh;padding:28px;text-align:center"><h2 style="color:#c9923c">Sin conexión con el servidor</h2><p>No se pudieron cargar tus partidas. Comprueba que el servidor esté iniciado y vuelve a intentarlo.</p><p><button onclick="location.reload()" style="font:inherit;padding:10px 18px;background:#c9923c;border:0;border-radius:8px">Reintentar</button> <a href="/login.html" style="color:#c9923c;margin-left:12px">Cambiar de cuenta</a></p></div>');
   try{window.stop();}catch(e){}
   return;
  }
  try{res=JSON.parse(x.responseText);}catch(e){res={claves:{}};}
  var srv=res.claves||{},local=clavesLocales(),srvTiene=Object.keys(srv).some(function(k){return /^naradak_slot_/.test(k);});
  var localTiene=local.some(function(k){return /^naradak_slot_/.test(k)&&L(k);});
  var subir=null;
  if(L(K_USER)===null&&!srvTiene&&localTiene&&confirm("Se encontraron partidas guardadas en este dispositivo.\n\n¿Subirlas a la cuenta \""+auth.u+"\"?\n(Aceptar = subirlas · Cancelar = empezar de cero)")){
   subir={};local.forEach(function(k){var v=L(k);if(v!==null)subir[k]=v;});
   srv=subir;
  }
  local.forEach(R);                                   /* la copia local pasa a ser la de ESTE usuario */
  for(var k in srv)S(k,srv[k]);
  S(K_USER,auth.u);
  if(subir){var xs=http("PUT","/datos",1,false);try{xs.send(JSON.stringify({set:subir,del:[]}));}catch(e){}}
 }

 /* ---- cerrar sesión ---- */
 function cerrarSesion(){
  flushSync();bloqueado=true;
  try{var xs=http("POST","/salir",1,false);xs.send("{}");}catch(e){}   /* libera la cuenta en el servidor */
  clavesLocales().forEach(R);S(K_USER,"-");R(K_AUTH);   /* "-" = copia local vaciada (no es partida antigua) */
  location.href="/login.html?salir=1";
 }
 /* Reserva un nombre de personaje único en el servidor. cb(ok, mensajeError) */
 function reservarNombre(nombre,cb){
  var x=http("POST","/personaje",1,true);
  x.onload=function(){
   var d=null;try{d=JSON.parse(x.responseText);}catch(e){}
   if(x.status===401){sesionCaducada();cb(false,"Sesión caducada.");return;}
   if(x.status>=200&&x.status<300)cb(true,"",d&&d.nombre);
   else cb(false,(d&&d.error)||"No se pudo comprobar el nombre. Inténtalo de nuevo.");
  };
  x.onerror=x.ontimeout=function(){cb(false,"No se pudo contactar con el servidor.");};
  x.send(JSON.stringify({nombre:nombre}));
 }
 /* Latido: mantiene viva la sesión en el servidor (una cuenta = una sesión). Si otra sesión la sustituye, vuelve al login. */
 if(esTop)setInterval(function(){
  if(bloqueado)return;
  var x=http("GET","/yo",null,true);
  x.onload=function(){if(x.status===401)sesionCaducada();};
  x.send();
 },15000);
 window.nrdkCuenta={usuario:auth.u,token:auth.t,cerrarSesion:cerrarSesion,guardarYa:flush,reservarNombre:reservarNombre};

 /* ---- distintivo de cuenta (solo ventana principal) ---- */
 if(esTop)document.addEventListener("DOMContentLoaded",function(){
  var d=document.createElement("div");d.id="nrdkCuenta";
  d.style.cssText="position:fixed;left:6px;bottom:6px;z-index:99990;display:flex;align-items:center;gap:6px;padding:3px 8px;border-radius:12px;background:rgba(18,16,12,.78);border:1px solid rgba(201,146,60,.3);color:#e8dcc4;font:11px Georgia,serif;opacity:.6";
  var p=document.createElement("span");p.style.cssText="width:8px;height:8px;border-radius:50%;background:#7bbf6a;display:inline-block";
  var n=document.createElement("span");n.textContent=auth.u;n.style.cssText="max-width:90px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap";
  var b=document.createElement("button");b.textContent="Salir";b.style.cssText="font:inherit;background:none;border:0;color:#c9923c;cursor:pointer;padding:0 0 0 4px;text-decoration:underline";
  b.onclick=function(){if(confirm("¿Cerrar la sesión de \""+auth.u+"\"?"))cerrarSesion();};
  d.appendChild(p);d.appendChild(n);d.appendChild(b);document.body.appendChild(d);pill=d;pintaEstado();
  d.onmouseenter=function(){d.style.opacity=1;};d.onmouseleave=function(){d.style.opacity=.6;};
 });
})();
