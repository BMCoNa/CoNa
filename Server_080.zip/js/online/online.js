"use strict";
function onlineWsUrl(){return (location.protocol==="https:"?"wss://":"ws://")+location.host+"/ws";}

/* Comprueba que el servidor responde (estado + WebSocket). cb(ok, mensaje, info) */
function onlineProbar(cb){
 var hecho=false;
 function fin(ok,msg,info){if(hecho)return;hecho=true;clearTimeout(tm);try{if(ws)ws.close();}catch(e){}cb(ok,msg,info);}
 var ws=null,info=null,tm=setTimeout(function(){fin(false,"El servidor no responde. Comprueba que esté iniciado y que estés en la misma red.");},6000);
 if(location.protocol.indexOf("http")!==0){fin(false,"Abre el juego desde el servidor local (http://IP:8080), no desde un archivo. Inicia el servidor con server/iniciar.bat o server/iniciar.sh.");return;}
 fetch("/api/estado",{cache:"no-store"}).then(function(r){return r.json();}).then(function(e){
  info=e;
  if(e&&e.jugadores>=e.max){fin(false,"Servidor lleno ("+e.max+" jugadores). Inténtalo más tarde.",e);return;}
  try{ws=new WebSocket(onlineWsUrl());}catch(x){fin(false,"No se pudo abrir la conexión con el servidor.");return;}
  ws.onopen=function(){try{ws.send(JSON.stringify({t:"ping"}));}catch(x){}};
  ws.onmessage=function(m){var d;try{d=JSON.parse(m.data);}catch(x){return;}if(d&&d.t==="pong")fin(true,"",info);};
  ws.onerror=function(){fin(false,"No se pudo conectar con el servidor. ¿Está iniciado (node server/servidor.js)?");};
  ws.onclose=function(){fin(false,"El servidor cerró la conexión.");};
 }).catch(function(){fin(false,"No se encontró el servidor local. Inícialo con server/iniciar.bat (Windows) o sh server/iniciar.sh y abre http://IP:8080.");});
}

/* Pantalla de conexión -> Ciudad de Oakhaven */
function onlineIrOakhaven(volver){
 if(!G.j)return;
 G.desdeOak=false;try{localStorage.removeItem("naradak_oak_pos");}catch(e){}   /* llegada en barco: aparece en la plaza */
 try{guardar();}catch(e){}                       /* el mapa de Oakhaven lee nombre/clase/nivel del último guardado */
 var t0=Date.now();
 G.onl={fase:"conectando",msg:"",volver:volver||G.screen,info:null,t:t0};
 G.screen="conectando";render();
 onlineProbar(function(ok,msg,info){
  if(G.screen!=="conectando"||!G.onl||G.onl.t!==t0)return;
  var espera=Math.max(0,900-(Date.now()-t0));
  setTimeout(function(){
   if(G.screen!=="conectando"||!G.onl||G.onl.t!==t0)return;
   if(ok){G.onl.fase="ok";G.onl.info=info;try{OnlineHub.conectar();}catch(e){}render();
    setTimeout(function(){if(G.screen==="conectando"&&G.onl&&G.onl.t===t0){G.screen="oakint";render();}},1100);}
   else{G.onl.fase="error";G.onl.msg=msg;render();}
  },espera);
 });
}
function onlineAbrir(){onlineIrOakhaven("hub");}
function renderConectando(){
 var o=G.onl||{fase:"error",msg:"",volver:"hub"},h='<div style="max-width:460px;margin:12vh auto 0;text-align:center"><div class="card" style="padding:28px 22px">';
 h+='<div class="font-disp" style="font-size:22px;color:var(--accent);margin-bottom:14px">🌐 Modo Online</div>';
 if(o.fase==="conectando"){
  h+='<div style="font-size:42px;margin-bottom:10px;animation:flick 1.4s infinite">⛵</div><div style="font-size:16px;margin-bottom:6px">Conectando con el servidor…</div><div style="font-size:12px;color:var(--muted)">Preparando la travesía hacia Oakhaven</div>';
  h+='<div style="margin-top:18px"><button class="btn" id="bOnCancel" style="font-size:12px;padding:6px 14px">Cancelar</button></div>';
 }else if(o.fase==="ok"){
  var n=o.info&&o.info.jugadores!=null?' · '+o.info.jugadores+'/'+o.info.max+' jugadores conectados':'';
  h+='<div style="font-size:42px;margin-bottom:10px">✅</div><div style="font-size:16px;margin-bottom:6px;color:#9ad08a">Conectado al servidor</div><div style="font-size:12px;color:var(--muted)">Entrando a la Ciudad de Oakhaven…'+n+'</div>';
 }else{
  h+='<div style="font-size:42px;margin-bottom:10px">⚠</div><div style="font-size:14px;margin-bottom:16px;color:#e08080;line-height:1.5">'+(o.msg||"No se pudo conectar.")+'</div>';
  h+='<div style="display:flex;gap:10px;justify-content:center;flex-wrap:wrap"><button class="btn btn-primary" id="bOnRetry">Reintentar</button><button class="btn" id="bOnCancel">Volver</button></div>';
 }
 h+='</div></div>';
 el.innerHTML=h;
 var c=document.getElementById("bOnCancel"),r=document.getElementById("bOnRetry");
 if(c)c.onclick=function(){var v=(G.onl&&G.onl.volver)||"hub";G.onl=null;G.screen=v;render();};
 if(r)r.onclick=function(){onlineIrOakhaven(o.volver);};
}
/* Gremio: pestaña "Misiones en grupo" */
function onlineGrupoHTML(){
 var H=window.OnlineHub,g=H&&H.grupo&&H.grupo();
 var h='<div class="card" style="background:rgba(0,0,0,.25)"><div class="font-disp" style="color:var(--accent);margin-bottom:6px">👥 Grupos y Raid</div>';
 if(g)h+='<div style="font-size:13px;margin-bottom:8px">'+(g.raid?'Raid':'Grupo')+' activo: <b>'+g.miembros.length+'/'+g.max+'</b> jugadores. Al entrar al Laberinto de Artaros, solo tu grupo comparte el mismo laberinto.</div>';
 else h+='<div style="font-size:13px;color:var(--muted);margin-bottom:8px">En Oakhaven (Modo Online) habla con otro jugador y elige <b>Invitar a grupo</b>. Solo los miembros del mismo grupo comparten el laberinto y las mazmorras.</div>';
 return h+'</div>';
}

/* =====================================================================================================
   OnlineHub — conexión online persistente + grupos/raid + chat privado + comercio
   API (la usan oakhaven_mapa.js y combate_demo.js): conectar, cerrar, conectado, id, suscribir(fn,sinReplay), enviar(o), tocar,
   enGrupo, grupo, esLider, invitar(id), comerciar(id), susurrar(id), labEntrar(params,cb), labSalir.
   ===================================================================================================== */
var OnlineHub=(function(){
 var H={},ws=null,miId=0,subs=[],jug={},grupo=null,deseado=false,tInput=Date.now(),lastLugar="",offGrace=0,
  chats={},nombres={},sinLeer={},chatCur=0,ofertas=[],trade=null,menuId=0,uiHtml="",reco=null,tickInfo=0;
 function esc(t){return String(t==null?"":t).replace(/[&<>"']/g,function(c){return{"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c];});}
 function mk(tag,css,html){var e=document.createElement(tag);if(css)e.style.cssText=css;if(html!=null)e.innerHTML=html;return e;}
 var CSSB="font-family:Karla,sans-serif;color:#f5e6c0;background:rgba(20,12,4,.92);border:2px solid #5a4a2a;border-radius:6px;box-shadow:0 2px 12px rgba(0,0,0,.6)";
 var CSSBTN="font-family:Cinzel,serif;font-size:12px;padding:6px 10px;background:#8b6f47;color:#f5f1e8;border:2px solid #5a4a2a;border-radius:4px;cursor:pointer";
 function J(){return(typeof G!=="undefined"&&G&&G.j)?G.j:null;}
 function labInfo(){try{return window.labOnlineInfo?window.labOnlineInfo():null;}catch(e){return null;}}
 function activo(){return document.visibilityState!=="hidden"&&Date.now()-tInput<60000;}
 H.tocar=function(){tInput=Date.now();};
 ["pointerdown","keydown","touchstart"].forEach(function(ev){window.addEventListener(ev,H.tocar,true);});
 H.conectado=function(){return !!ws&&ws.readyState===1;};
 H.id=function(){return miId;};
 H.grupo=function(){return grupo;};
 H.enGrupo=function(){return !!grupo;};
 H.esLider=function(){return !!grupo&&grupo.lider===miId;};
 H.esMiembro=function(id){return !!grupo&&grupo.miembros.some(function(m){return m.id===id;});};
 H.jugador=function(id){return jug[id]||null;};
 H.enviar=function(o){if(ws&&ws.readyState===1){try{ws.send(JSON.stringify(o));}catch(e){}}};
 H.suscribir=function(fn,sinReplay){
  subs.push(fn);
  if(!sinReplay&&miId){try{var l=[];for(var k in jug)l.push(jug[k]);fn({t:"bienvenido",id:miId,jugadores:l,replay:true});}catch(e){}}
  return function(){var i=subs.indexOf(fn);if(i>=0)subs.splice(i,1);};
 };
 function emitir(m){for(var i=subs.length-1;i>=0;i--){try{subs[i](m);}catch(e){subs.splice(i,1);}}}

 /* ---- datos propios ---- */
 function miInfo(){
  var j=J();if(!j)return null;
  var o={t:"info",nivel:j.nivel||1,clase:j.clase||"",rn:j.recursoNombre||"",act:activo()},li=labInfo(),st=null;
  if(li){o.hp=li.hp;o.hpMax=li.hpMax;o.mp=li.mp;o.mpMax=li.mpMax;}
  else{try{st=calcStats(j);}catch(e){}o.hp=Math.round(j.vida||0);o.hpMax=st?st.vidaMax:o.hp;o.mp=Math.round(j.recurso||0);o.mpMax=st?st.recursoMax:o.mp;}
  return o;
 }
 function enviarInfo(){var o=miInfo();if(o)H.enviar(o);}
 function lugarAct(){return labInfo()?"laberinto":(typeof G!=="undefined"&&G?(G.screen==="oakint"?"oakhaven":G.screen==="mundoint"?"mundo":""):"");}
 function enLinea(){return !!labInfo()||(typeof G!=="undefined"&&G&&["oakint","mundoint","laberinto","conectando"].indexOf(G.screen)>=0);}

 /* ---- conexión ---- */
 H.conectar=function(){deseado=true;if(ws&&(ws.readyState===0||ws.readyState===1))return;abrir();};
 H.cerrar=function(){deseado=false;clearTimeout(reco);var w=ws;ws=null;if(w){try{w.close();}catch(e){}}limpiar();};
 function limpiar(){miId=0;jug={};if(grupo){grupo=null;}trade=null;ofertas=[];menuId=0;pintar();pintarOfertas();pintarTrade();}
 function abrir(){
  var j=J()||{},w;
  try{w=new WebSocket(onlineWsUrl());}catch(e){return;}
  ws=w;
  w.onopen=function(){
   if(ws!==w)return;
   var av=4;try{var v=parseInt(localStorage.getItem("naradak_pc"),10);if(v>=0)av=v;}catch(e){}
   H.enviar({t:"hola",tk:(window.nrdkCuenta&&window.nrdkCuenta.token)||"",nombre:j.nombre||"Aventurero",clase:j.clase||"",nivel:j.nivel||1,avatar:av,lugar:lugarAct()||"oakhaven",x:0,y:0});
   lastLugar=lugarAct();enviarInfo();
  };
  w.onmessage=function(e){if(ws!==w)return;var m;try{m=JSON.parse(e.data);}catch(x){return;}onMsg(m);emitir(m);};
  w.onclose=function(){if(ws!==w)return;ws=null;limpiar();emitir({t:"hub_cerrado"});if(deseado)reco=setTimeout(function(){if(deseado&&enLinea())abrir();},3000);};
  w.onerror=function(){};
 };
 setInterval(function(){
  if(!ws)return;
  if(!enLinea()){if(!offGrace)offGrace=Date.now();else if(Date.now()-offGrace>6000){offGrace=0;H.cerrar();}return;}
  offGrace=0;
  var lg=lugarAct();if(lg&&lg!==lastLugar&&ws.readyState===1){lastLugar=lg;H.enviar({t:"lugar",lugar:lg});}
  if(++tickInfo>=1){tickInfo=0;enviarInfo();}
 },1000);

 /* ---- mensajes del servidor ---- */
 function onMsg(m){
  switch(m.t){
   case"bienvenido":miId=m.id;jug={};(m.jugadores||[]).forEach(function(p){jug[p.id]=p;nombres[p.id]=p.nombre;});break;
   case"entra":if(m.jugador){jug[m.jugador.id]=m.jugador;nombres[m.jugador.id]=m.jugador.nombre;}break;
   case"sale":delete jug[m.id];break;
   case"lugar":if(jug[m.id]){jug[m.id].lugar=m.lugar;if(m.x!=null){jug[m.id].x=m.x;jug[m.id].y=m.y;}}break;
   case"mueve":if(jug[m.id]){jug[m.id].x=m.x;jug[m.id].y=m.y;}break;
   case"info":if(jug[m.id])jug[m.id].nivel=m.nivel;break;
   case"g_estado":
    var antes=grupo;grupo=m.grupo||null;if(!grupo)menuId=0;
    if(antes&&!grupo)aviso(m.motivo==="expulsado"?"Has sido expulsado del grupo.":m.motivo==="disuelto"?"El grupo se ha disuelto.":"Has abandonado el grupo.");
    else if(!antes&&grupo)aviso("Te has unido al "+(grupo.raid?"raid":"grupo")+".");
    pintar();break;
   case"g_info":
    if(grupo)grupo.miembros.forEach(function(q){if(q.id===m.id){q.nivel=m.nivel;q.hp=m.hp;q.hpMax=m.hpMax;q.mp=m.mp;q.mpMax=m.mpMax;q.rn=m.rn;q.act=m.act;if(m.clase)q.clase=m.clase;}});
    pintar();break;
   case"g_invitacion":ofertas.push({k:"g",de:m.de,nombre:m.nombre,txt:m.nombre+" (Nv "+(m.nivel||1)+") te invita a su grupo.",t:Date.now()});pintarOfertas();break;
   case"c_solicitud":ofertas.push({k:"c",de:m.de,nombre:m.nombre,txt:m.nombre+" quiere comerciar contigo.",t:Date.now()});pintarOfertas();break;
   case"g_aviso":aviso(m.msg);break;
   case"susurro":chatAdd(m.de,m.nombre,false,m.texto);break;
   case"c_abrir":trade={con:m.con,nombre:m.nombre,mia:{oro:0,items:{}},suya:{oro:0,items:{}},okMia:false,okSuya:false};nombres[m.con]=m.nombre;pintarTrade(true);break;
   case"c_estado":if(trade){trade.mia=m.mia;trade.suya=m.suya;trade.okMia=m.okMia;trade.okSuya=m.okSuya;pintarTrade();}break;
   case"c_cancelado":if(trade){aviso("Comercio cancelado"+(m.motivo==="desconectado"?": el otro jugador se desconectó.":"."));trade=null;pintarTrade();}break;
   case"c_fin":aplicarComercio(m);trade=null;pintarTrade();break;
   case"error":aviso("⚠ "+m.msg);if(m.fatal){deseado=false;clearTimeout(reco);}break;   /* cuenta ya conectada / sesión no válida: no reintentar */
  }
 }

 /* ---- avisos ---- */
 var toastBox=null;
 function aviso(txt){
  if(!toastBox){toastBox=mk("div","position:fixed;left:50%;top:56px;transform:translateX(-50%);z-index:99996;pointer-events:none;display:flex;flex-direction:column;align-items:center;gap:4px");document.body.appendChild(toastBox);}
  var d=mk("div",CSSB+";padding:6px 12px;font-size:13px;max-width:80vw;text-align:center",esc(txt));toastBox.appendChild(d);
  while(toastBox.children.length>4)toastBox.removeChild(toastBox.firstChild);
  setTimeout(function(){if(d.parentNode)d.parentNode.removeChild(d);},5000);
 }
 H.aviso=aviso;

 /* ---- panel del grupo (izquierda) ---- */
 var panel=null;
 function barra(v,max,col){var pc=max>0?Math.max(0,Math.min(100,v/max*100)):0;return '<div style="position:relative;height:9px;background:#1a120a;border:1px solid #3a2a14;border-radius:2px;overflow:hidden"><div style="width:'+pc+'%;height:100%;background:'+col+'"></div></div>';}
 function listaPanel(){
  if(!grupo)return null;
  var yo=miInfo()||{},j=J()||{},l=[];
  grupo.miembros.forEach(function(q){
   if(q.id===miId)l.unshift({id:q.id,nombre:j.nombre||q.nombre,clase:j.clase||q.clase,nivel:yo.nivel||q.nivel,hp:yo.hp,hpMax:yo.hpMax,mp:yo.mp,mpMax:yo.mpMax,rn:yo.rn||q.rn,act:activo(),yo:true});
   else l.push(q);
  });
  return l;
 }
 var panelOculto=false;
 H.ocultarPanel=function(v){panelOculto=!!v;if(panelOculto&&panel)panel.style.display="none";else{uiHtml="";pintar();}};
 function pintar(){
  if(panelOculto&&typeof G!=="undefined"&&G&&G.screen!=="mundoint")panelOculto=false;
  if(panelOculto){if(panel)panel.style.display="none";return;}
  var l=listaPanel();
  if(!l){if(panel){panel.style.display="none";}uiHtml="";return;}
  if(!panel){
   panel=mk("div","position:fixed;left:8px;top:92px;width:178px;max-height:calc(100vh - 190px);overflow:auto;z-index:99990;"+CSSB+";padding:6px;font-size:12px");
   panel.addEventListener("click",function(e){
    var b=e.target.closest("[data-og]");if(!b)return;e.stopPropagation();
    var a=b.getAttribute("data-og"),id=parseInt(b.getAttribute("data-id"),10)||0;
    if(a==="menu")menuId=menuId===id?0:id;
    else if(a==="salir"){H.enviar({t:"g_salir"});menuId=0;}
    else if(a==="raid"){H.enviar({t:"g_raid",on:!(grupo&&grupo.raid)});menuId=0;}
    else if(a==="susurro"){menuId=0;H.susurrar(id);}
    else if(a==="comerciar"){menuId=0;H.comerciar(id);}
    else if(a==="expulsar"){H.enviar({t:"g_expulsar",id:id});menuId=0;}
    else if(a==="lider"){H.enviar({t:"g_lider",id:id});menuId=0;}
    else if(a==="cerrar")menuId=0;
    uiHtml="";pintar();
   });
   panel.addEventListener("pointerdown",function(e){e.stopPropagation();});
   document.body.appendChild(panel);
  }
  var h='<div style="font-family:Cinzel,serif;color:#e8c9a0;font-size:12px;margin-bottom:5px;display:flex;justify-content:space-between"><span>'+(grupo.raid?'⚔ Raid':'👥 Grupo')+'</span><span>'+grupo.miembros.length+'/'+grupo.max+'</span></div>';
  l.forEach(function(q){
   var lid=q.id===grupo.lider;
   h+='<div data-og="menu" data-id="'+q.id+'" style="cursor:pointer;padding:4px 5px;margin-bottom:4px;border:1px solid '+(q.yo?'#e8c9a0':'#5a4a2a')+';border-radius:4px;background:rgba(0,0,0,.35)">'
    +'<div style="display:flex;justify-content:space-between;align-items:center;gap:4px"><b style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap">'+(lid?'♛ ':'')+esc(q.nombre)+(q.yo?' (tú)':'')+'</b><span style="color:#e8c9a0;white-space:nowrap">Nv '+(q.nivel||1)+'</span></div>'
    +'<div style="font-size:10px;color:#b8a888;display:flex;justify-content:space-between"><span>'+esc(q.clase||"")+'</span><span style="color:'+(q.act?'#7ad07a':'#8a8a8a')+'">● '+(q.act?'activo':'inactivo')+'</span></div>'
    +barra(q.hp||0,q.hpMax||0,'#c0392b')+'<div style="font-size:9px;text-align:center;margin-top:-1px">❤ '+Math.round(q.hp||0)+'/'+Math.round(q.hpMax||0)+'</div>'
    +barra(q.mp||0,q.mpMax||0,'#3a78d0')+'<div style="font-size:9px;text-align:center;margin-top:-1px">'+esc(q.rn||'Recurso')+' '+Math.round(q.mp||0)+'/'+Math.round(q.mpMax||0)+'</div>';
   if(menuId===q.id){
    h+='<div style="display:flex;flex-direction:column;gap:3px;margin-top:5px">';
    if(q.yo){
     if(grupo.lider===miId)h+='<button style="'+CSSBTN+'" data-og="raid" data-id="0">'+(grupo.raid?'Volver a grupo':'Convertir en raid')+'</button>';
     h+='<button style="'+CSSBTN+';background:#8b3a2a" data-og="salir" data-id="0">Abandonar el '+(grupo.raid?'raid':'grupo')+'</button>';
    }else{
     h+='<button style="'+CSSBTN+'" data-og="susurro" data-id="'+q.id+'">💬 Chat privado</button><button style="'+CSSBTN+'" data-og="comerciar" data-id="'+q.id+'">🤝 Comerciar</button>';
     if(grupo.lider===miId)h+='<button style="'+CSSBTN+'" data-og="lider" data-id="'+q.id+'">♛ Dar liderazgo</button><button style="'+CSSBTN+';background:#8b3a2a" data-og="expulsar" data-id="'+q.id+'">✖ Expulsar</button>';
    }
    h+='<button style="'+CSSBTN+';background:#4a3a24" data-og="cerrar" data-id="0">Cerrar</button></div>';
   }
   h+='</div>';
  });
  panel.style.display="block";
  if(h!==uiHtml){uiHtml=h;panel.innerHTML=h;}
 }
 setInterval(pintar,500);

 /* ---- invitaciones y propuestas ---- */
 var ofBox=null;
 function pintarOfertas(){
  var ahora=Date.now();ofertas=ofertas.filter(function(o){return ahora-o.t<40000;});
  if(!ofBox){ofBox=mk("div","position:fixed;left:50%;top:100px;transform:translateX(-50%);z-index:99997;display:flex;flex-direction:column;gap:6px;align-items:center");document.body.appendChild(ofBox);}
  ofBox.innerHTML="";
  ofertas.forEach(function(o){
   var d=mk("div",CSSB+";padding:10px 14px;font-size:13px;text-align:center;max-width:86vw","<div style='margin-bottom:8px'>"+(o.k==="g"?"👥 ":"🤝 ")+esc(o.txt)+"</div>");
   var a=mk("button",CSSBTN+";margin-right:8px","Aceptar"),r=mk("button",CSSBTN+";background:#8b3a2a","Rechazar");
   function resp(ok){ofertas.splice(ofertas.indexOf(o),1);H.enviar({t:o.k==="g"?"g_resp":"c_resp",de:o.de,ok:ok});pintarOfertas();}
   a.onclick=function(){resp(true);};r.onclick=function(){resp(false);};
   d.appendChild(a);d.appendChild(r);ofBox.appendChild(d);
  });
 }
 setInterval(function(){if(ofertas.length)pintarOfertas();},5000);

 /* ---- acciones sobre otros jugadores (las llama el diálogo de Oakhaven y el panel) ---- */
 H.invitar=function(id){
  if(!H.conectado())return;
  if(H.esMiembro(id)){aviso("Ya está en tu grupo.");return;}
  H.enviar({t:"g_invitar",id:id});
 };
 H.comerciar=function(id){if(!H.conectado())return;if(trade){aviso("Ya estás comerciando.");return;}H.enviar({t:"c_pedir",id:id});};
 H.susurrar=function(id){if(!id)return;chatCur=id;sinLeer[id]=0;if(!chats[id])chats[id]=[];pintarChat(true);};

 /* ---- chat privado ---- */
 var chatWin=null;
 function chatAdd(id,nombre,mio,txt){
  nombres[id]=nombre||nombres[id]||"Jugador";(chats[id]=chats[id]||[]).push({m:mio,t:txt});if(chats[id].length>60)chats[id].shift();
  if(!mio){if(!chatWin||chatWin.style.display==="none"||chatCur!==id)sinLeer[id]=(sinLeer[id]||0)+1;if(!chatCur||chatWin&&chatWin.style.display==="none")chatCur=id;aviso("💬 "+(nombre||"Jugador")+": "+txt);}
  pintarChat(false);
 }
 function pintarChat(abrir){
  if(!chatWin){
   chatWin=mk("div","position:fixed;left:196px;top:92px;width:270px;max-width:calc(100vw - 210px);z-index:99991;display:none;"+CSSB+";font-size:13px");
   chatWin.addEventListener("pointerdown",function(e){e.stopPropagation();});
   document.body.appendChild(chatWin);
  }
  if(abrir)chatWin.style.display="block";
  if(chatWin.style.display==="none")return;
  var ids=Object.keys(chats),h='<div style="display:flex;justify-content:space-between;align-items:center;padding:4px 6px;border-bottom:1px solid #5a4a2a;font-family:Cinzel,serif;color:#e8c9a0"><span>💬 Chat privado</span><span data-c="x" style="cursor:pointer;padding:0 4px">✕</span></div>';
  h+='<div style="display:flex;flex-wrap:wrap;gap:3px;padding:4px 6px">';
  ids.forEach(function(k){h+='<span data-c="tab" data-id="'+k+'" style="cursor:pointer;padding:2px 6px;border-radius:3px;font-size:11px;background:'+(+k===chatCur?'#8b6f47':'#3a2a14')+'">'+esc(nombres[k]||"Jugador")+(sinLeer[k]?' <b style="color:#ffd24a">('+sinLeer[k]+')</b>':'')+'</span>';});
  h+='</div><div id="ogCL" style="height:130px;overflow:auto;padding:4px 8px;font-size:12px;line-height:1.5">';
  (chats[chatCur]||[]).forEach(function(c){h+='<div style="color:'+(c.m?'#9fd0ff':'#f5e6c0')+'"><b>'+(c.m?'Tú':esc(nombres[chatCur]||"Jugador"))+':</b> '+esc(c.t)+'</div>';});
  h+='</div><div style="padding:5px"><input id="ogCI" maxlength="200" placeholder="Mensaje privado…" autocomplete="off" style="width:100%;box-sizing:border-box;padding:5px;background:#120a04;color:#f5e6c0;border:1px solid #5a4a2a;border-radius:3px"></div>';
  var teniaFoco=document.activeElement&&document.activeElement.id==="ogCI",v=teniaFoco?document.activeElement.value:"";
  chatWin.innerHTML=h;
  var inp=chatWin.querySelector("#ogCI"),log=chatWin.querySelector("#ogCL");log.scrollTop=log.scrollHeight;
  if(teniaFoco||abrir){inp.value=v;inp.focus();}
  inp.addEventListener("keydown",function(e){
   e.stopPropagation();
   if(e.key==="Enter"){var t=inp.value.trim();if(t&&chatCur){H.enviar({t:"susurro",a:chatCur,texto:t});chatAdd(chatCur,nombres[chatCur],true,t);}inp.value="";}
   else if(e.key==="Escape"){inp.blur();}
  });
  inp.addEventListener("keyup",function(e){e.stopPropagation();});
  chatWin.onclick=function(e){var t=e.target.closest("[data-c]");if(!t)return;var a=t.getAttribute("data-c");
   if(a==="x")chatWin.style.display="none";else if(a==="tab"){chatCur=parseInt(t.getAttribute("data-id"),10);sinLeer[chatCur]=0;pintarChat(true);}};
 }

 /* ---- comercio ---- */
 var trWin=null,trTimer=0;
 function invDisp(){var j=J(),r={};if(!j||!j.inventario)return r;for(var k in j.inventario)if(typeof j.inventario[k]==="number"&&j.inventario[k]>0)r[k]=j.inventario[k];return r;}
 function txtOferta(o){var a=[];if(o.oro)a.push("💰 "+o.oro+" oro");for(var k in o.items)a.push(esc(k)+" ×"+o.items[k]);(o.eq||[]).forEach(function(e){a.push("⚔ "+esc(e.n)+(e.rareza?" <span style='color:#e0c060'>("+esc(e.rareza)+")</span>":"")+(e.mejora?" +"+e.mejora:""));});return a.length?a.join("<br>"):"<i style='color:#8a7a60'>(nada)</i>";}
 function bolsaEq(){var j=J();return j&&Array.isArray(j.bolsaEq)?j.bolsaEq:[];}
 function enviarOferta(){
  if(!trade)return;var j=J(),oro=Math.max(0,Math.min(j?j.oro||0:0,Math.floor(+(trWin.querySelector("#ogTO")||{}).value||0))),items={},inv=invDisp();
  trWin.querySelectorAll("[data-it]").forEach(function(i){var k=i.getAttribute("data-it"),n=Math.max(0,Math.min(inv[k]||0,Math.floor(+i.value||0)));if(n>0)items[k]=n;});
  var eq=[],bq=bolsaEq();trWin.querySelectorAll("[data-eq]").forEach(function(i){if(!i.checked)return;var it=bq[parseInt(i.getAttribute("data-eq"),10)];if(it)eq.push(it);});
  H.enviar({t:"c_oferta",oro:oro,items:items,eq:eq});
 }
 function pintarTrade(nuevo){
  if(!trade){if(trWin)trWin.style.display="none";return;}
  if(!trWin){trWin=mk("div","position:fixed;left:50%;top:50%;transform:translate(-50%,-50%);width:min(560px,94vw);max-height:86vh;overflow:auto;z-index:99998;"+CSSB+";padding:12px;font-size:13px");
   trWin.addEventListener("pointerdown",function(e){e.stopPropagation();});document.body.appendChild(trWin);}
  var ya=!nuevo&&trWin.style.display==="block"&&trWin.getAttribute("data-con")===String(trade.con);
  trWin.style.display="block";trWin.setAttribute("data-con",String(trade.con));
  if(!ya){
   var inv=invDisp(),j=J()||{},h='<div style="font-family:Cinzel,serif;color:#e8c9a0;font-size:16px;margin-bottom:8px">🤝 Comercio con '+esc(trade.nombre)+'</div><div style="display:flex;gap:10px;flex-wrap:wrap"><div style="flex:1;min-width:220px"><b>Tu oferta</b><div style="margin:6px 0">💰 Oro (tienes '+(j.oro||0)+'): <input id="ogTO" type="number" min="0" max="'+(j.oro||0)+'" value="0" style="width:90px;background:#120a04;color:#f5e6c0;border:1px solid #5a4a2a"></div><div style="max-height:200px;overflow:auto;border:1px solid #3a2a14;padding:4px">';
   var ks=Object.keys(inv),bq=bolsaEq();if(!ks.length&&!bq.length)h+='<i style="color:#8a7a60">Sin objetos en el inventario.</i>';
   ks.forEach(function(k){h+='<div style="display:flex;justify-content:space-between;align-items:center;gap:6px;padding:2px 0"><span>'+esc(k)+' (×'+inv[k]+')</span><input type="number" min="0" max="'+inv[k]+'" value="0" data-it="'+esc(k)+'" style="width:60px;background:#120a04;color:#f5e6c0;border:1px solid #5a4a2a"></div>';});
   if(bq.length){h+='<div style="margin-top:6px;border-top:1px solid #3a2a14;padding-top:4px"><b>⚔ Equipo en la bolsa</b></div>';bq.forEach(function(it,ix){h+='<label style="display:flex;align-items:center;gap:6px;padding:2px 0;cursor:pointer"><input type="checkbox" data-eq="'+ix+'"><span>'+esc(it.n)+(it.rareza?' <span style="color:#e0c060">('+esc(it.rareza)+')</span>':'')+(it.mejora?' +'+it.mejora:'')+'</span></label>';});}
   h+='</div></div><div style="flex:1;min-width:200px"><b>Oferta de '+esc(trade.nombre)+'</b><div id="ogTS" style="margin-top:6px;padding:6px;border:1px solid #3a2a14;min-height:90px"></div><div id="ogTK" style="margin-top:6px;font-size:12px"></div></div></div>'
    +'<div style="margin-top:10px;display:flex;gap:8px;justify-content:flex-end"><button id="ogTC" style="'+CSSBTN+'">Confirmar</button><button id="ogTX" style="'+CSSBTN+';background:#8b3a2a">Cancelar</button></div>';
   trWin.innerHTML=h;
   trWin.oninput=function(){clearTimeout(trTimer);trTimer=setTimeout(enviarOferta,250);};
   trWin.querySelector("#ogTC").onclick=function(){if(trade)H.enviar({t:"c_conf",ok:!trade.okMia});};
   trWin.querySelector("#ogTX").onclick=function(){H.enviar({t:"c_cancelar"});trade=null;pintarTrade();};
  }
  trWin.querySelector("#ogTS").innerHTML=txtOferta(trade.suya);
  trWin.querySelector("#ogTK").innerHTML=(trade.okSuya?'<span style="color:#7ad07a">✔ '+esc(trade.nombre)+' ha confirmado</span>':'<span style="color:#b8a888">'+esc(trade.nombre)+' aún no confirma</span>')+(trade.okMia?'<br><span style="color:#7ad07a">✔ Has confirmado (cambiar la oferta anula la confirmación)</span>':'');
  trWin.querySelector("#ogTC").textContent=trade.okMia?"Quitar confirmación":"Confirmar";
 }
 function aplicarComercio(m){
  var j=J();if(!j)return;
  var da=m.da||{oro:0,items:{}},rec=m.recibe||{oro:0,items:{}};
  j.inventario=j.inventario||{};
  j.oro=Math.max(0,(j.oro||0)-Math.min(da.oro||0,j.oro||0))+(rec.oro||0);
  for(var k in da.items){var q=Math.min(da.items[k],j.inventario[k]||0);j.inventario[k]=(j.inventario[k]||0)-q;if(j.inventario[k]<=0)delete j.inventario[k];}
  for(var k2 in rec.items){j.inventario[k2]=(j.inventario[k2]||0)+rec.items[k2];}
  if((da.eq&&da.eq.length)||(rec.eq&&rec.eq.length)){
   var bq=Array.isArray(j.bolsaEq)?j.bolsaEq:(j.bolsaEq=[]);
   (da.eq||[]).forEach(function(e){for(var q=0;q<bq.length;q++)if(bq[q]&&bq[q].n===e.n&&(bq[q].mejora||0)===(e.mejora||0)){bq.splice(q,1);break;}});
   (rec.eq||[]).forEach(function(e){bq.push(e);});
  }
  try{guardar();}catch(e){}
  aviso("🤝 Comercio completado con "+(nombres[m.con]||"el jugador")+".");
 }

 /* ---- laberinto de grupo ---- */
 H.labEntrar=function(params,cb){
  if(!H.conectado()||!grupo){cb(null);return;}
  var hecho=false,off=null,tm=setTimeout(function(){if(hecho)return;hecho=true;if(off)off();cb(null);},4000);
  off=H.suscribir(function(m){if(m.t==="lab_inicio"&&!hecho){hecho=true;clearTimeout(tm);off();cb(m.error?null:m);}},true);
  H.enviar({t:"lab_unir",seed:params.seed,piso:params.piso,ciclo:params.ciclo});
  H.enviar({t:"lugar",lugar:"laberinto"});lastLugar="laberinto";
 };
 H.labSalir=function(){H.enviar({t:"lab_salir"});};
 return H;
})();
window.OnlineHub=OnlineHub;
