"use strict";
/* Íconos de habilidades (base + rama). Archivos en assets/hab/ */
var HAB_ICONO={
"Golpe Brutal": "golpe_brutal",
"Postura de Acero": "postura_de_acero",
"Ejecutar": "ejecutar",
"Bola de Fuego": "bola_de_fuego",
"Congelar": "congelar",
"Barrera Arcana": "barrera_arcana",
"Tiro Certero": "tiro_certero",
"Lluvia de Flechas": "lluvia_de_flechas",
"Paso Espectral": "paso_espectral",
"Golpe Sagrado": "golpe_sagrado",
"Sentencia de Luz": "sentencia_de_luz",
"Bendición de Poderío": "bendicion_de_poderio",
"Golpe Espectral": "golpe_espectral",
"Bomba de Humo": "bomba_de_humo",
"Asesinato Múltiple": "asesinato_multiple",
"Torbellino Aniquilador": "torbellino_aniquilador",
"Sangre de Loco": "sangre_de_loco",
"Sentencia Final": "sentencia_final",
"Marca del Condenado": "marca_del_condenado",
"Juicio Divino": "juicio_divino",
"Cruzada Fanática": "cruzada_fanatica",
"Bastión Inquebrantable": "bastion_inquebrantable",
"Luz Regeneradora": "luz_regeneradora",
"Vínculo Alfa": "vinculo_alfa",
"Trampa Alfa": "trampa_alfa",
"Disparo de Largo Alcance": "disparo_de_largo_alcance",
"Posición Elevada": "posicion_elevada",
"Corte Sombra x7": "corte_sombra_x7",
"Paso Espectral Ninja": "paso_espectral_ninja",
"Lluvia de Cuchillas": "lluvia_de_cuchillas",
"Contrato Marcado": "contrato_marcado",
"Infierno": "infierno",
"Combustión": "combustion",
"Prisión Glacial": "prision_glacial",
"Lanza de Hielo Absoluto": "lanza_de_hielo_absoluto",
"Pulso Vital": "pulso_vital",
"Égida Radiante": "egida_radiante",
"Plegaria de Pureza": "plegaria_de_pureza",
"Santuario de Luz": "santuario_de_luz",
"Resurgir Divino": "resurgir_divino",
"Nova Solar": "nova_solar",
"Ascensión Radiante": "ascension_radiante"
};
function habImg(n,clase,sz){
 var k=(n==="Paso Espectral"&&clase==="Asesino")?"Paso Espectral Ninja":n,f=HAB_ICONO[k];
 if(!f)return"";
 sz=sz||36;
 return'<img class="habIco" src="assets/hab/'+f+'.png" width="'+sz+'" height="'+sz+'" alt="">';
}
