"use strict";
/* RECETAS DE ALQUIMIA */
/* ---------- RECETAS ---------- */
var RECETAS_ALQUIMISTA = {
 "Poción de Vida":{ing:{"Fragmento de Hierro":2,"Gel de Slime":1},oro:20,efecto:"Cura 25% vida"},
 "Poción de Vida Mayor":{ing:{"Esencia de Cristal":2,"Polvo Arcano":1},oro:50,efecto:"Cura 50% vida"},
 "Poción de Vida Superior":{ing:{"Escama Gélida":2,"Piel Invernal":1},oro:80,efecto:"Cura 75% vida"},
 "Poción de Recurso":{ing:{"Fibra Vegetal":2},oro:20,efecto:"Recupera 25% recurso"},
 "Poción de Recurso Mayor":{ing:{"Fragmento de Gema":2},oro:50,efecto:"Recupera 50% recurso"},
 "Poción de Recurso Superior":{ing:{"Hielo Eterno":2},oro:80,efecto:"Recupera 75% recurso"},
 "Poción Élfica Antigua":{ing:{"Escama Gélida":3,"Piel Invernal":2,"Hielo Eterno":3},oro:300,efecto:"Recupera tus Stats"},
 "Núcleo de Hierro":{ing:{"Fragmento de Hierro":5},oro:100,efecto:"Material de forja"},
 "Esencia de Cristal Pura":{ing:{"Esencia de Cristal":5,"Fragmento de Gema":1},oro:300,efecto:"Material de forja raro"},
 "Núcleo de Lava Mejorado":{ing:{"Núcleo de Lava":5,"Polvo Ígneo":2},oro:500,efecto:"Material de forja épico"}
};
/* Origen (bioma menor donde cae) y rareza máxima de cada material */
var MAT_INFO={};
(function(){
 function add(n,b,r){var c=MAT_INFO[n];if(!c||b<c.b||(b===c.b&&r>c.r))MAT_INFO[n]={b:b,r:r};}
 for(var id in BIOMAS){var B=BIOMAS[id],bi=parseInt(id,10);
  B.monstruos.forEach(function(m){(TABLA_LOOT[m]||[]).slice(1).forEach(function(d){add(d[0],bi,d[2]);});});
  [B.mini,B.jefe].forEach(function(m){(TABLA_LOOT_JEFES[m]||[]).slice(1).forEach(function(d){add(d[0],bi,d[2]);});});
  (LOOT_BIOMA[id]?LOOT_BIOMA[id].drops:[]).forEach(function(d){add(d[0],bi,d[2]);});
  add(B.material,bi,0);
 }
})();
function precioMaterial(n){
 var i=MAT_INFO[n];if(i)return PRECIOS_MAT_GREMIO[i.b][i.r];
 var rc=RECETAS_ALQUIMISTA[n];
 if(rc){var t=0;for(var k in rc.ing)t+=precioMaterial(k)*rc.ing[k];return Math.max(1,t);}
 var pp=profPrecio(n);if(pp)return pp;
 if(TAB_PRECIO[n])return TAB_PRECIO[n];
 return PRECIOS_MAT_GREMIO[1][0];
}
function infoMaterial(n){
 var i=MAT_INFO[n];
 if(i)return RARIDAD[i.r]+" · "+BIOMAS[i.b].nombre;
 if(TAB_UNICOS[n])return "Único · "+BIOMAS[TAB_UNICOS[n]].nombre;
 return(RECETAS_ALQUIMISTA[n]||PROF_OUT[n])?"Crafteado":"Material";
}
