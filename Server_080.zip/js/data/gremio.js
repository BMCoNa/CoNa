"use strict";
/* Rangos y misiones del gremio */
/* ---------- RANGOS ---------- */
var RANGOS_GREMIO = {1:{n:"F",req_piso:1,recompensa:500},2:{n:"E",req_piso:10,recompensa:1000},3:{n:"D",req_piso:20,recompensa:2000},4:{n:"C",req_piso:30,recompensa:3500},5:{n:"B",req_piso:40,recompensa:5500},6:{n:"A",req_piso:50,recompensa:8000},7:{n:"S",req_piso:60,recompensa:10500}};
/* Precio fijo de compra del gremio: [bioma de origen][rareza] -> Común, Poco Común, Raro, Épico, Legendario */
var PRECIOS_MAT_GREMIO = {
 1:[3,8,18,45,120],
 2:[6,15,36,90,240],
 3:[10,25,60,150,400],
 4:[16,40,96,245,640],
 5:[24,62,144,360,960],
 6:[34,85,204,510,1360],
 7:[48,125,288,720,1920]
};
/* ---------- GRUPOS de misiones (7 × 25 = 175).
   Formato compacto: [tipo, obj, oro, cond, tag] ---------- */
function _m(tipo,obj,oro,cond,tag){return {tipo:tipo,obj:obj,oro:Math.round(oro),cond:cond||null,tag:tag||""};}
var GRUPOS = {};
(function(){
 var g1=[
 _m("caza",{"Araña Gigante":2,"Goblin Explorador":1},80),_m("caza",{"Duende Tramposo":2},80),_m("caza",{"Bandido del Bosque":2,"Slime Verde":1},80),_m("caza",{"Champiñón Venenoso":1,"Lobo Salvaje":1},80),_m("caza",{"Ent Joven":1},144,null,"JEFE"),
 _m("entrega",{"Gel de Slime":3,"Seda de Araña":2},96),_m("entrega",{"Colmillo de Lobo":2,"Cuchilla de Goblin":1},96),_m("entrega",{"Corteza de Ent":2,"Espora Venenosa":1},96),_m("entrega",{"Cuero Goblin":1,"Mecanismo de Trampa":1},96),_m("entrega",{"Madera Ancestral":1,"Polvo de Suerte":1},172,null,"JEFE"),
 _m("recoleccion",{"Esencia del Bosque":1},88),_m("recoleccion",{"Esencia del Bosque":1,"Fibra Vegetal":2},88),_m("recoleccion",{"Madera de Silverleaf":1,"Esencia del Bosque":1},88),_m("recoleccion",{"Esencia del Bosque":1,"Fragmento de Hierro":1},88),_m("recoleccion",{"Esencia del Bosque":2},88),
 _m("caza",{"Rey Goblin":1},144,null,"JEFE"),_m("caza",{"Rey Goblin":2},144,null,"JEFE"),_m("caza",{"Treant Ancestral":1},144,null,"JEFE"),_m("caza",{"Treant Ancestral":2},216,null,"JEFE"),_m("caza",{"Treant Ancestral":1,"Rey Goblin":2},240,null,"EPICA"),
 _m("entrega",{"Lingote Goblin":1},172,null,"JEFE"),_m("entrega",{"Esencia de Conquista":1},172,null,"JEFE"),_m("entrega",{"Semilla del Ancestro":1},172,null,"JEFE"),_m("entrega",{"Madera Ancestral":1},172,null,"JEFE"),_m("entrega",{"Corteza Legendaria":1},400,null,"LEGENDARIA")];
 GRUPOS[1]={rango:"F",nombre:"Silverleaf Forests",emoji:"Bosque",misiones:g1};
 var g2=[
 _m("caza",{"Espectro de Luz":1,"Ladrón de Eldroria":1},120),_m("caza",{"Elemental de Agua":2},120),_m("caza",{"Custodio":2},120),_m("caza",{"Centinela Arcano":2},120),_m("caza",{"Golem de Cristal":1},216,null,"JEFE"),
 _m("entrega",{"Esencia de Cristal":2,"Polvo Luminoso":1},144),_m("entrega",{"Hilo de Cristal":1,"Esencia de Agua":1},144),_m("entrega",{"Pergamino en Blanco":2,"Gemas Robadas":1},144),_m("entrega",{"Runa Arcana":1,"Fragmento de Escudo":1},144),_m("entrega",{"Núcleo de Maná":1,"Runa Rúnica":1},259,null,"JEFE"),
 _m("recoleccion",{"Núcleo Arcano":2},132),_m("recoleccion",{"Núcleo Arcano":1,"Fragmento de Gema":2},132),_m("recoleccion",{"Polvo Arcano":1,"Núcleo Arcano":1},132),_m("recoleccion",{"Esencia de Cristal":2,"Núcleo Arcano":1},132),_m("recoleccion",{"Núcleo Arcano":2},132),
 _m("caza",{"Archimago Traidor":1},216,null,"JEFE"),_m("caza",{"Archimago Traidor":2},216,null,"JEFE"),_m("caza",{"Guardián de Eldroria":1},216,null,"JEFE"),_m("caza",{"Guardián de Eldroria":2},324,null,"JEFE"),_m("caza",{"Guardián de Eldroria":1,"Archimago Traidor":2},360,null,"EPICA"),
 _m("entrega",{"Papel Prohibido":1},259,null,"JEFE"),_m("entrega",{"Esencia Arcana Mayor":1},259,null,"JEFE"),_m("entrega",{"Cristal Puro":1},259,null,"JEFE"),_m("entrega",{"Núcleo de Eldroria":1},259,null,"JEFE"),_m("entrega",{"Alma de Eldroiria":1},500,null,"LEGENDARIA")];
 GRUPOS[2]={rango:"E",nombre:"Eldroria",emoji:"Cristal",misiones:g2};
 /* Grupos 3-7: mismo patrón, monstruos/materiales de cada bioma, oro escalado */
 var plantilla=function(id,monstruos,mat,mini,jefe,baseOro){
  var m=[];
  m.push(_m("caza",(function(){var o={};o[monstruos[0]]=4;o[monstruos[1]]=2;return o;})(),baseOro));
  m.push(_m("caza",(function(){var o={};o[monstruos[2]]=3;return o;})(),baseOro));
  m.push(_m("caza",(function(){var o={};o[monstruos[3]]=2;return o;})(),baseOro));
  m.push(_m("caza",(function(){var o={};o[monstruos[4]]=3;return o;})(),baseOro));
  m.push(_m("caza",(function(){var o={};o[monstruos[5]]=1;return o;})(),baseOro*1.8,null,"JEFE"));
  for(var e=0;e<4;e++){var o={};o[mat]=10+e*3;o["Fragmento de Cristal"]=5; m.push(_m("entrega",o,baseOro*1.2));}
  var o2={};o2[mat]=2; m.push(_m("entrega",o2,baseOro*2.2,null,"JEFE"));
  for(var r=0;r<5;r++){var or={};or[mat]=5+r*2; m.push(_m("recoleccion",or,baseOro*1.1));}
  m.push(_m("caza",(function(){var o={};o[mini]=1;return o;})(),baseOro*1.8,null,"JEFE"));
  m.push(_m("caza",(function(){var o={};o[mini]=2;return o;})(),baseOro*1.8,null,"JEFE"));
  m.push(_m("caza",(function(){var o={};o[jefe]=1;return o;})(),baseOro*1.8,null,"JEFE"));
  m.push(_m("caza",(function(){var o={};o[jefe]=1;return o;})(),baseOro*2.7,{max_seg:180},"JEFE"));
  m.push(_m("caza",(function(){var o={};o[jefe]=1;o[mini]=2;return o;})(),baseOro*3,null,"EPICA"));
  for(var f=0;f<4;f++){var of={};of[mat]=1+f; m.push(_m("entrega",of,baseOro*2.2,null,"JEFE"));}
  m.push(_m("entrega",(function(){var o={};o[mat]=1;return o;})(),baseOro*5,null,"LEGENDARIA"));
  return m;
 };
 var nombres=["Nersaz","Ignisgarde","Artaros","Ghaela","Ebanos"];
 var rangos=["D","C","B","A","S"];
 for(var g=3;g<=7;g++){
  var b=BIOMAS[g];
  GRUPOS[g]={rango:rangos[g-3],nombre:b.nombre,emoji:b.emoji,misiones:plantilla(g,b.monstruos,b.material,b.mini,b.jefe,80+g*40)};
 }
})();
