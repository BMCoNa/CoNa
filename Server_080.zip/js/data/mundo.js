"use strict";
/* Biomas, enemigos, jefes y maldiciones */
/* ---------- config.py: BIOMAS (7) ---------- */
var BIOMAS = {
 1:{id:1,nombre:"Silverleaf Forests",region:"NARADAK",color:"#5a9a5a",emoji:"Bosque",monstruos:["Slime Verde","Goblin Explorador","Lobo Salvaje","Araña Gigante","Duende Tramposo","Ent Joven","Bandido del Bosque","Champiñón Venenoso"],material:"Fragmento de Hierro",mini:"Rey Goblin",jefe:"Treant Ancestral"},
 2:{id:2,nombre:"Eldroria",region:"NARADAK",color:"#5a9ac9",emoji:"Cristal",monstruos:["Aprendiz de Mago","Golem de Cristal","Centinela Arcano","Espectro de Luz","Araña de Cristal","Ladrón de Eldroria","Elemental de Agua","Custodio"],material:"Esencia de Cristal",mini:"Archimago Traidor",jefe:"Guardián de Eldroria"},
 3:{id:3,nombre:"Nersaz",region:"NERSAZ",color:"#7ab8d8",emoji:"Hielo",monstruos:["Yeti","Troll de Hielo","Lobo Invernal","Gigante de Nieve","Elemental de Hielo","Bandido Nersaziano","Arpía Gélida","Mamut Espectral"],material:"Escama Gélida",mini:"Archimago Gélido",jefe:"Rey Lich de Ezgar"},
 4:{id:4,nombre:"Ignisgarde",region:"IGNISGARDE",color:"#c95a3c",emoji:"Fuego",monstruos:["Salamandra","Enano de Fuego","Elemental de Lava","Perro Infernal","Golem de Obsidiana","Cultista del Fuego","Ave Fénix Caída","Magma Viviente"],material:"Núcleo de Lava",mini:"Forjamaestro de Ignis",jefe:"Dragón de Ignisgarde"},
 5:{id:5,nombre:"Artaros",region:"ARTAROS",color:"#c9a25a",emoji:"Arena",monstruos:["Bandido del Desierto","Escorpión Gigante","Momia","Genio de Arena","Buitre Mutante","Naga del Desierto","Golem de Arena","Djinni Salvaje"],material:"Lingote de Opalo",mini:"Señor de las Dunas",jefe:"Khan de los Korban"},
 6:{id:6,nombre:"Ghaela",region:"THE ABYSSAL KEEP",color:"#8a5ac9",emoji:"Abismo",monstruos:["No-Muerto","Espectro","Caballero Maldito","Nigromante","Gárgola Sombría","Araña del Abismo","Alma en Pena","Sombra Viviente"],material:"Alma Sombría",mini:"Verdugo de Ghaela",jefe:"Rey Abisal de Ghaela"},
 7:{id:7,nombre:"Ebanos",region:"EBANOS",color:"#a8325a",emoji:"Oscuridad",monstruos:["Demonio Menor","Necrófago","Cultista Malakor","Cerbero Infernal","Aracna Demoníaca","Brujo de Ebanos","Aberración","Alma Condenada"],material:"Fragmento Malakor",mini:"Señor de Ebanos",jefe:"El Olvidado"}
};
/* ---------- STATS_BASE_ENEMIGOS ---------- */
var STATS_ENEM = {"Goblin":[.7,.8,.6],"Lobo":[.9,1.1,.7],"Araña":[.5,1.0,.4],"Duende":[.6,1.2,.5],"Ent":[2.0,.9,1.5],"Bandido":[.8,1.0,.7],"Slime":[1.2,.5,.8],"Champiñón":[1.0,.8,1.0],"Mago":[.6,1.8,.5],"Golem":[2.2,1.0,1.8],"Centinela":[1.5,1.2,1.3],"Espectro":[.7,1.4,.6],"Elemental":[1.1,1.3,.9],"Custodio":[1.4,1.0,1.2],"Ladrón":[.7,1.3,.6],"Yeti":[1.6,1.2,1.1],"Troll":[1.9,1.1,1.0],"Gigante":[2.5,1.4,1.2],"Arpía":[.7,1.2,.5],"Mamut":[3.0,1.3,1.4],"Salamandra":[1.0,1.3,.8],"Enano":[1.2,1.0,1.2],"Perro":[.8,1.2,.6],"Cultista":[.7,1.5,.6],"Fénix":[.9,1.6,.7],"Magma":[1.4,1.1,1.0],"Escorpión":[1.1,1.2,.8],"Momia":[1.3,.9,1.0],"Genio":[.8,1.7,.6],"Buitre":[.6,1.0,.5],"Naga":[1.2,1.3,.9],"Djinni":[.9,1.6,.8],"No-Muerto":[1.0,.9,.9],"Caballero":[1.6,1.2,1.4],"Nigromante":[.7,1.7,.6],"Gárgola":[1.8,1.0,1.5],"Alma":[.8,1.2,.7],"Sombra":[.7,1.4,.6],"Demonio":[1.3,1.5,1.1],"Necrófago":[1.4,1.1,1.0],"Cerbero":[1.7,1.3,1.0],"Aracna":[.9,1.4,.8],"Brujo":[.7,1.8,.6],"Aberración":[1.5,1.4,1.1]};
/* ---------- JEFES (reliquias) ---------- */
var JEFES_REL = {5:{n:"Corona Goblin",efecto:"+10 Vida",vida:10},10:{n:"Orbe Helado",efecto:"+15 Recurso",recurso:15},15:{n:"Escama Dragón",efecto:"+5 Atk +5 Def",atk:5,def:5},20:{n:"Alma de Eldroiria",efecto:"+40 Recurso +10 Atk",recurso:40,atk:10},30:{n:"Orbe de Hielo Sacro",efecto:"+20 Def",def:20},40:{n:"Aliento Ignis",efecto:"+30 Atk +50 Recurso",atk:30,recurso:50},50:{n:"Tributo de los Korban",efecto:"+150 Vida",vida:150},60:{n:"Esencia de Ghaela",efecto:"+50 Atk +50 Def +50 Recurso",atk:50,def:50,recurso:50},65:{n:"Bendición de Ebanos",efecto:"+100 Atk +200 Vida",atk:100,vida:200},70:{n:"Bendición de Bulak",efecto:"+1000 Vida +400 Recurso +100 Atk +100 Def",vida:1000,recurso:400,atk:100,def:100}};
/* ---------- MALDICIONES ---------- */
var MALDICIONES = {
 "Maldición de Debilidad":{desc:"-15% de Daño",efecto:"atk",valor:.15},
 "Maldición de Fragilidad":{desc:"-15% de Defensa",efecto:"def",valor:.15},
 "Maldición de Sangrado":{desc:"-20% de Vida máxima",efecto:"vida",valor:.20},
 "Maldición del Vacío":{desc:"-20% de Recurso máximo",efecto:"recurso",valor:.20},
 "Maldición de Avaricia":{desc:"-25% de Oro ganado",efecto:"oro",valor:.25},
 "Maldición del Olvido":{desc:"-25% de XP ganada",efecto:"xp",valor:.25},
 "Maldición del Pesar":{desc:"Las pociones curan 50% menos",efecto:"cura",valor:.50}
};
var POCIONES = [
 {n:"Poción de Vida",desc:"Recupera 25% de Vida",precio:50,tipo:"vida",pct:.25},
 {n:"Poción de Recurso",desc:"Recupera 25% de Recurso",precio:50,tipo:"recurso",pct:.25},
 {n:"Poción de Vida Mayor",desc:"Recupera 50% de Vida",precio:120,tipo:"vida",pct:.50},
 {n:"Poción de Recurso Mayor",desc:"Recupera 50% de Recurso",precio:120,tipo:"recurso",pct:.50},
 {n:"Poción de Vida Superior",desc:"Recupera 75% de Vida",precio:180,tipo:"vida",pct:.75},
 {n:"Poción de Recurso Superior",desc:"Recupera 75% de Recurso",precio:180,tipo:"recurso",pct:.75},
 {n:"Poción Élfica Antigua",desc:"Recupera el 100% de todo",precio:1000,tipo:"full",pct:1}
];
/* TEMPORAL: poción de pruebas. Poner DEBUG_REJUV=false para inhabilitarla */
var DEBUG_REJUV=false;
if(DEBUG_REJUV){
 POCIONES.push({n:"Poción de Rejuvenecimiento",desc:"[TEMP] +1000 XP",precio:100,tipo:"xp",pct:0});
 POCIONES.push({n:"Poción de Almas",desc:"[TEMP] +100 almas",precio:100,tipo:"almas",pct:0});
}
