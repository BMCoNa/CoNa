"use strict";
/* Clases, atributos y habilidades */
/* ---------- CLASES ---------- */
var CLASES = {
 "Guerrero":{vida:200,atk:[18,26],def:15,rec:120,recNombre:"Furia",crit:10,color:"#c96a3c"},
 "Mago":{vida:140,atk:[14,22],def:9,rec:200,recNombre:"Maná",crit:15,color:"#6a5acd"},
 "Arquero":{vida:170,atk:[10,14],def:12,rec:150,recNombre:"Energía",crit:20,color:"#5a9a5a"},
 "Paladin":{vida:250,atk:[14,18],def:22,rec:180,recNombre:"Maná",crit:12,color:"#c9a23c"},
 "Asesino":{vida:160,atk:[10,16],def:10,rec:120,recNombre:"Energía",crit:35,color:"#8a4a8a"},
 "Clérigo":{vida:190,atk:[10,14],def:14,rec:210,recNombre:"Fe",crit:8,color:"#5fc9b8"}
};
/* Clases que usan daño mágico (Mago y Clérigo): ataque por INT/ENF, crítico por ENF y reducción mágica del enemigo */
function esMagica(clase){return clase==="Mago"||clase==="Clérigo";}
/* ============================================================
   ATRIBUTOS (clases.js): FUE AGI INT PER EVA ENF
   - Base por clase + nivel (primarios +2/nv, secundarios +1/nv) + equipo.
   - Bonos planos (daño, vida, recurso, defensa) usan solo lo GANADO sobre la  base de clase (la base ya está incluida en las stats de la clase).
   - Golpe, esquiva e iniciativa usan el atributo total.
   ---- ATRIBUTOS ----
  - FUE => FUERZA ==> Vida y daño físico
  - AGI => AGILIDAD ==> Daño y crítico físico
  - INT => INTELECTO ==> Daño mágico y recurso
  - PER => PERCEPCION ==> Goloe, crítico e iniciativa
  - EVA => EVASION ==> Esquiva y reducción física
  - ENF => ENFOQUE ==> Crítico, reducción mágica y potencia de buff 
   ============================================================ */
var ATTR_KEYS=["fue","agi","int","per","eva","enf"];
var ATTR_NOMBRE={fue:"FUE",agi:"AGI",int:"INT",per:"PER",eva:"EVA",enf:"ENF"};
var ATTR_DESC={fue:"Vida y daño físico",agi:"Daño físico y crítico físico",int:"Daño mágico y recurso",per:"Golpe, crítico e iniciativa",eva:"Esquiva y reducción física",enf:"Reducción mágica, crítico mágico y potencia de buffs"};
var ATTR_CLASES={
 "Guerrero":{base:{fue:8,agi:6,int:1,per:5,eva:6,enf:4},pri:["fue","agi","eva"],sec:["per","enf","int"]},
 "Paladin":{base:{fue:7,agi:2,int:5,per:4,eva:4,enf:8},pri:["fue","enf","int"],sec:["per","eva","agi"]},
 "Arquero":{base:{fue:4,agi:8,int:2,per:8,eva:5,enf:3},pri:["agi","per","eva"],sec:["fue","enf","int"]},
 "Asesino":{base:{fue:4,agi:8,int:1,per:6,eva:8,enf:3},pri:["agi","per","eva"],sec:["fue","enf","int"]},
 "Mago":{base:{fue:1,agi:3,int:9,per:5,eva:3,enf:9},pri:["int","enf","per"],sec:["agi","eva","fue"]},
 "Clérigo":{base:{fue:3,agi:3,int:7,per:5,eva:4,enf:10},pri:["enf","int","eva"],sec:["per","fue","agi"]}
};
/* Reparto de atributos por slot: índices en "pri" de la clase, y factor de tamaño */
var ATTR_SLOT={pecho:[0,1,2],piernas:[0,1],guantes:[2,0],botas:[1,2],arma:[0,1],accesorio:[2,1]};
var ATTR_SLOT_F={pecho:1,piernas:.8,guantes:.6,botas:.6,arma:.8,accesorio:.6};
var ATTR_POS_F=[1,.7,.5];
function attrItem(clase,slot,nivel,mult){
 var d=ATTR_CLASES[clase],idx=ATTR_SLOT[slot];if(!d||!idx)return null;
 var amt=nivel*mult*(ATTR_SLOT_F[slot]||.6),o={};
 idx.forEach(function(k,pos){o[d.pri[k]]=Math.max(1,Math.round(amt*ATTR_POS_F[pos]));});
 return o;
}
/* Armaduras de tienda: multiplicador 1 */
function attrDeItem(a){return a[1]==="armadura"?attrItem(a[2],a[3],a[9],1):undefined;}
/* Recetas de Forja: rareza Raro x1.5, Épico x2, Legendario x2.5 */
function attrForja(a){return attrItem(a[2],a[3],a[9],1.5+0.5*(a[8]-2));}
/* Atributos de un item (compatible con partidas antiguas sin campo attr) */
function itemAttr(it){
 if(!it)return{};
 if(it.attr)return it.attr;
 if(!it.clase||!ATTR_CLASES[it.clase])return{};
 if(it.tipo==="armadura")return attrItem(it.clase,it.slot,it.nivel||1,/Forjad/.test(it.n||"")?2:1)||{};
 if(/Forjad/.test(it.n||""))return attrItem(it.clase,it.slot,it.nivel||1,2)||{};
 return{};
}
function attrTxt(o){var a=[];ATTR_KEYS.forEach(function(k){if(o&&o[k])a.push(ATTR_NOMBRE[k]+" +"+o[k]);});return a.join(", ");}
function atributos(j){
 var d=ATTR_CLASES[j.clase]||ATTR_CLASES["Guerrero"],L=Math.max(0,j.nivel-1),t={},g={};
 ATTR_KEYS.forEach(function(k){var lv=(d.pri.indexOf(k)>=0?2:1)*L;g[k]=lv;t[k]=d.base[k]+lv;});
 for(var s in j.equipo){var a=itemAttr(j.equipo[s]);for(var k in a){if(t[k]===undefined)continue;t[k]+=a[k];g[k]+=a[k];}}
 return{t:t,g:g,base:d.base};
}
function derivados(j){
 var A=atributos(j),t=A.t,g=A.g,mago=esMagica(j.clase);
 var dmgFis=Math.floor(g.fue*0.9+g.agi*0.5),dmgMag=Math.floor(g.int*1.0+g.enf*0.2);
 var inicG=Math.floor(g.per*2+g.agi*1.5+Math.max(0,j.nivel-1));
 return{
  A:A,
  dano:mago?dmgMag:dmgFis,
  vidaB:g.fue*12,
  recB:g.int*10+g.enf*2,
  defB:Math.floor(g.eva*0.9)+Math.floor(g.enf*1.0),
  redFis:Math.floor(g.eva*0.9),
  redMag:Math.floor(g.enf*1.0),
  probGolpe:Math.min(95,75+t.per*0.9),
  probEsq:Math.min(35,t.eva*0.5),
  critB:Math.floor(g.per*0.5),
  critMult:2+((mago?g.enf:g.agi)*0.8)/100,
  potencia:1+g.enf*0.015,
  iniciativa:Math.floor(t.per*2+t.agi*1.5+j.nivel),
  inicG:inicG
 };
}
function atributosHTML(j){
 var D=derivados(j),A=D.A,c=CLASES[j.clase],d=ATTR_CLASES[j.clase];
 var h='<div class="card" style="margin-bottom:12px"><div class="font-disp" style="color:var(--accent);margin-bottom:10px">Atributos</div><div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:6px 12px;font-size:13px">';
 ATTR_KEYS.forEach(function(k){
  var pri=d.pri.indexOf(k)>=0,gan=A.g[k];
  h+='<div title="'+ATTR_DESC[k]+'"><span style="font-weight:700;color:'+(pri?'#e0c060':'var(--text)')+'">'+ATTR_NOMBRE[k]+' '+A.t[k]+'</span> <span style="color:#7ab88a;font-size:11px">'+(gan?'(+'+gan+')':'')+'</span><div style="font-size:10px;color:var(--muted)">'+ATTR_DESC[k]+'</div></div>';});
 h+='</div><div style="margin-top:10px;font-size:12px;color:var(--muted);line-height:1.7">';
 h+='Primarios: '+d.pri.map(function(k){return ATTR_NOMBRE[k];}).join(", ")+' · Secundarios: '+d.sec.map(function(k){return ATTR_NOMBRE[k];}).join(", ")+'<br>';
 h+='Golpe '+Math.floor(D.probGolpe)+'% · Esquiva '+Math.floor(D.probEsq*10)/10+'% · Crítico '+Math.min(60,c.crit+D.critB)+'% (x'+D.critMult.toFixed(2)+') · Potencia de buffs x'+D.potencia.toFixed(2)+' · Iniciativa '+D.iniciativa;
 h+='<br>Bonos por atributos: daño +'+D.dano+' · vida +'+D.vidaB+' · '+j.recursoNombre+' +'+D.recB+' · Red. física +'+D.redFis+' (vs daño <span style="color:#e05050">físico</span>) · Red. mágica +'+D.redMag+' (vs daño <span style="color:#b070e0">mágico</span>)';
 return h+'</div></div>';
}
/* ---------- HABILIDADES (3 por clase) ---------- */
var HABILIDADES = {
 "Guerrero":[
  {n:"Golpe Brutal",costo:30,desc:"150% daño + aturde 1 turno",efecto:"dano_150_stun",cd:2},
  {n:"Postura de Acero",costo:40,desc:"+30% Defensa por 2 turnos",efecto:"def_30_2t",cd:3},
  {n:"Ejecutar",costo:50,desc:"Robo de vida 50%",efecto:"robo_vida_50",cd:3}],
 "Mago":[
  {n:"Bola de Fuego",costo:40,desc:"250% daño a 1 objetivo",efecto:"fuego_250",cd:2},
  {n:"Congelar",costo:35,desc:"Aturde a todos + 70% daño",efecto:"stun_aoe",cd:3},
  {n:"Barrera Arcana",costo:60,desc:"Escudo = 40% vida máx",efecto:"escudo_vida",cd:3}],
 "Arquero":[
  {n:"Tiro Certero",costo:30,desc:"200% daño a 1 objetivo",efecto:"dano_200",cd:2},
  {n:"Lluvia de Flechas",costo:50,desc:"75% daño en área",efecto:"aoe_75",cd:3},
  {n:"Paso Espectral",costo:40,desc:"Inmune 1 turno + 60% daño",efecto:"inmunidad_60",cd:3}],
 "Paladin":[
  {n:"Golpe Sagrado",costo:30,desc:"140% daño en área",efecto:"aoe_140",cd:2},
  {n:"Sentencia de Luz",costo:40,desc:"+50 DEF por 3 turnos",efecto:"def_50_3t",cd:3},
  {n:"Bendición de Poderío",costo:60,desc:"Recupera 75% vida máx",efecto:"vida_max_75",cd:3}],
 "Asesino":[
  {n:"Golpe Espectral",costo:30,desc:"250% daño por la espalda",efecto:"punalada",cd:2},
  {n:"Bomba de Humo",costo:45,desc:"Aturde 2 turnos",efecto:"stun_2",cd:3},
  {n:"Asesinato Múltiple",costo:60,desc:"3 ataques de 100% daño",efecto:"atk_mult",cd:3}],
 "Clérigo":[
  {n:"Pulso Vital",costo:40,desc:"Onda de luz en área: 110% daño sagrado y te cura 25% de la vida máx",efecto:"pulso_vital",cd:2},
  {n:"Égida Radiante",costo:45,desc:"+40% Defensa y escudo = 20% vida máx por 3 turnos",efecto:"egida_rad",cd:3},
  {n:"Plegaria de Pureza",costo:50,desc:"Purga aturdimiento y silencio, inmune a control y +25% daño 3 turnos",efecto:"pureza",cd:3}]
};