"use strict";
/* Tipos de daño y ataques especiales */
/* ============================================================
   TIPOS DE DAÑO Y ATAQUES ESPECIALES DE ENEMIGOS
   - Físico (rojo): reducido por DEF + reducción física (EVA); se puede esquivar (EVA).
   - Mágico (morado): reducido por DEF + reducción mágica (ENF); no se esquiva.
   - Especiales: daño ×N, Silencio (sin habilidades 2 turnos) y Aturdir (pierdes 1 turno).
   ============================================================ */
var COLOR_DANO={fisico:"#e05050",magico:"#b070e0"};
/* Monstruos de daño mágico (el resto es físico) */
var MONSTRUOS_MAGICOS=["Aprendiz de Mago","Centinela Arcano","Espectro de Luz","Elemental de Agua","Custodio","Elemental de Hielo","Arpía Gélida","Mamut Espectral","Elemental de Lava","Cultista del Fuego","Ave Fénix Caída","Magma Viviente","Genio de Arena","Naga del Desierto","Djinni Salvaje","Espectro","Nigromante","Alma en Pena","Sombra Viviente","Brujo de Ebanos","Cultista Malakor","Aracna Demoníaca","Alma Condenada","Demonio Menor","Aberración","Salamandra"];
/* Jefes y mini-jefes: tipo base + 3 especiales (silencio, aturdir, daño) acordes a su nombre */
function _sp(n,ef,tipo,m){return {n:n,ef:ef,tipo:tipo,m:m,cd:3};}
var ESPECIALES_JEFE={
 "Rey Goblin":{tipo:"fisico",esp:[_sp("Grito Ensordecedor","silencio","fisico",1.0),_sp("Porrazo del Rey","aturdir","fisico",1.1),_sp("Saqueo Real","dano","fisico",2.0)]},
 "Treant Ancestral":{tipo:"fisico",esp:[_sp("Raíces Asfixiantes","silencio","magico",1.0),_sp("Golpe de Corteza","aturdir","fisico",1.2),_sp("Furia del Bosque","dano","fisico",2.0)]},
 "Archimago Traidor":{tipo:"magico",esp:[_sp("Sello de Silencio","silencio","magico",1.0),_sp("Rayo Paralizante","aturdir","magico",1.1),_sp("Traición Arcana","dano","magico",2.0)]},
 "Guardián de Eldroria":{tipo:"magico",esp:[_sp("Runa de Mutismo","silencio","magico",1.0),_sp("Puño de Cristal","aturdir","fisico",1.2),_sp("Pulso Arcano","dano","magico",2.1)]},
 "Archimago Gélido":{tipo:"magico",esp:[_sp("Ventisca Muda","silencio","magico",1.0),_sp("Prisión de Hielo","aturdir","magico",1.1),_sp("Lanza de Escarcha","dano","magico",2.1)]},
 "Rey Lich de Ezgar":{tipo:"magico",esp:[_sp("Susurro Mortal","silencio","magico",1.0),_sp("Mirada de la Tumba","aturdir","magico",1.2),_sp("Ola de Muerte","dano","magico",2.3)]},
 "Forjamaestro de Ignis":{tipo:"fisico",esp:[_sp("Humo Asfixiante","silencio","fisico",1.0),_sp("Martillazo Fundido","aturdir","fisico",1.2),_sp("Hierro Candente","dano","fisico",2.1)]},
 "Dragón de Ignisgarde":{tipo:"fisico",esp:[_sp("Rugido Ensordecedor","silencio","fisico",1.0),_sp("Coletazo","aturdir","fisico",1.2),_sp("Aliento de Fuego","dano","magico",2.3)]},
 "Señor de las Dunas":{tipo:"fisico",esp:[_sp("Tormenta de Arena","silencio","fisico",1.0),_sp("Golpe de Dunas","aturdir","fisico",1.2),_sp("Filo del Desierto","dano","fisico",2.1)]},
 "Khan de los Korban":{tipo:"fisico",esp:[_sp("Cuerno de Guerra","silencio","fisico",1.0),_sp("Carga Bárbara","aturdir","fisico",1.2),_sp("Tajo del Khan","dano","fisico",2.2)]},
 "Verdugo de Ghaela":{tipo:"fisico",esp:[_sp("Capucha del Verdugo","silencio","fisico",1.0),_sp("Golpe de Hacha","aturdir","fisico",1.2),_sp("Ejecución","dano","fisico",2.3)]},
 "Rey Abisal de Ghaela":{tipo:"magico",esp:[_sp("Canto Abisal","silencio","magico",1.0),_sp("Grilletes del Abismo","aturdir","magico",1.1),_sp("Marea Abisal","dano","magico",2.2)]},
 "Señor de Ebanos":{tipo:"magico",esp:[_sp("Pacto de Mudez","silencio","magico",2.0),_sp("Cadenas Infernales","aturdir","fisico",2.5),_sp("Llama Demoníaca","dano","magico",3.0)]},
 "El Olvidado":{tipo:"magico",esp:[_sp("Olvido","silencio","magico",3.0),_sp("Vacío Absoluto","aturdir","magico",3.5),_sp("Eco del Olvido","dano","magico",4.0)]}
};
/* Especial propio de enemigos normales (según su nombre); por defecto, golpe fuerte de su tipo */
var ESPECIAL_NORMAL=[
 [/Araña|Aracna/,"Telaraña Paralizante","aturdir","fisico",1.0],
 [/Golem|Troll|Gigante|Mamut|Yeti|Ent |Cerbero/,"Aplastar","aturdir","fisico",1.2],
 [/Mago|Nigromante|Brujo|Cultista|Custodio|Centinela/,"Maleficio Mudo","silencio","magico",1.0],
 [/Espectro|Alma|Sombra|Fantasma/,"Lamento Espectral","silencio","magico",1.0],
 [/Elemental|Magma|Fénix|Salamandra|Genio|Djinni|Demonio|Aberración|Arpía|Naga/,"Estallido Elemental","dano","magico",1.7],
 [/Lobo|Perro|Escorpión|Buitre|Champiñón/,"Mordisco Feroz","dano","fisico",1.7]
];
function tipoDanoEnemigo(nombre){
 if(ESPECIALES_JEFE[nombre])return ESPECIALES_JEFE[nombre].tipo;
 return MONSTRUOS_MAGICOS.indexOf(nombre)>=0?"magico":"fisico";
}
function especialesEnemigo(e){
 if(ESPECIALES_JEFE[e.nombre])return ESPECIALES_JEFE[e.nombre].esp.map(function(x){return Object.assign({},x);});
 var tipo=tipoDanoEnemigo(e.nombre);
 for(var i=0;i<ESPECIAL_NORMAL.length;i++){var r=ESPECIAL_NORMAL[i];if(r[0].test(e.nombre))return [{n:r[1],ef:r[2],tipo:r[3],m:r[4],cd:4}];}
 return [{n:tipo==="magico"?"Descarga Arcana":"Golpe Brutal",ef:"dano",tipo:tipo,m:1.6,cd:4}];
}
/* ============================================================
   DEFENSAS Y CRÍTICO DE ENEMIGOS (porcentajes %, se calculan al armar el enemigo)
   - Crítico: su golpe hace x critMult (y su piso de daño sube al 20%).
   - Esquivar: el golpe del jugador no hace daño.
   - Absorber: el golpe no hace daño y el enemigo se cura ABS_CURA del daño anulado.
   - Bloquear: el golpe hace BLOQ_RED menos de daño.
   Base por tipo + bonos por nombre + crecimiento por bioma (e.bid; en Extremo +7 por ciclo).
   ============================================================ */
var ABS_CURA=.25,BLOQ_RED=.5;
var DEF_ENEM_BASE={normal:{crit:4,esq:3,bloq:5,abs:2,cm:1.5},mini_jefe:{crit:8,esq:4,bloq:10,abs:4,cm:1.6},jefe:{crit:12,esq:5,bloq:12,abs:5,cm:1.75}};
var DEF_ENEM_CAP={crit:40,esq:25,bloq:35,abs:20};
var DEF_ENEM_NOM=[
 [/Ladrón|Lobo|Araña|Duende|Arpía|Salamandra|Buitre|Perro|Escorpión|Genio|Djinni|Naga/,"esq",6],
 [/Golem|Ent |Caballero|Gárgola|Centinela|Custodio|Enano|Troll|Gigante|Mamut|Yeti|Momia/,"bloq",10],
 [/Mago|Espectro|Alma|Sombra|Elemental|Magma|Fénix|Nigromante|Brujo|Cultista|Demonio|Aberración|Aracna/,"abs",6],
 [/Bandido|Cultista|Verdugo|Cerbero|Demonio|Duende|Ladrón|Escorpión/,"crit",4]
];
function statsDefEnemigo(e){
 var b=DEF_ENEM_BASE[e.tipo]||DEF_ENEM_BASE.normal,bid=Math.max(1,e.bid||1),g=0.8*(bid-1);
 var r={crit:b.crit+g,esq:b.esq+g*.6,bloq:b.bloq+g,abs:b.abs+g*.5};
 DEF_ENEM_NOM.forEach(function(x){if(x[0].test(e.nombre))r[x[1]]+=x[2];});
 for(var k in r)r[k]=Math.round(Math.min(DEF_ENEM_CAP[k],Math.max(0,r[k]))*10)/10;
 e.pCrit=r.crit;e.pEsq=r.esq;e.pBloq=r.bloq;e.pAbs=r.abs;e.critMult=b.cm;
 return e;
}
/* Tirada defensiva del enemigo ante un golpe de daño d: {d,ev:"esq"|"abs"|"bloq"|null,cura} */
function defensaEnemigo(e,d){
 if(!e||e.dummy||d<=0)return {d:d,ev:null,cura:0};
 var r=Math.random()*100,pe=e.pEsq||0,pa=e.pAbs||0,pb=e.pBloq||0;
 if(r<pe)return {d:0,ev:"esq",cura:0};r-=pe;
 if(r<pa)return {d:0,ev:"abs",cura:Math.floor(d*ABS_CURA)};r-=pa;
 if(r<pb)return {d:Math.max(1,Math.floor(d*(1-BLOQ_RED))),ev:"bloq",cura:0};
 return {d:d,ev:null,cura:0};
}
function armarEnemigo(e){
 e.tipoDano=tipoDanoEnemigo(e.nombre);
 e.esp=especialesEnemigo(e);
 e.espCd=e.esp.map(function(){return 0;});
 statsDefEnemigo(e);
 return e;
}
/* Modo Aventura: al salir (victoria o huida) se vuelve al interior del Castillo en vez del hub */
function salirAventura(){var r=!!G.volverCastillo;G.volverCastillo=false;if(r)G.msg="";return r?"castint":"hub";}
/* Récord PERMANENTE de la Mazmorra Infinita (máxima oleada superada).
   Se guarda en la partida (j.infRecord) y también en un almacén aparte del navegador, así que sobrevive a muertes,
   partidas nuevas, otros slots y borrados de slot. Nunca baja. */
var REC_INF_KEY="naradak_inf_record";
function recordInfinita(j){
 var g=0;try{g=parseInt(localStorage.getItem(REC_INF_KEY),10)||0;}catch(e){}
 var r=Math.max(g,(j&&j.infRecord)||0);
 if(j&&(j.infRecord||0)<r)j.infRecord=r;
 return r;
}
function guardarRecordInfinita(j,w){
 if(w<=recordInfinita(j))return;
 if(j)j.infRecord=w;
 try{localStorage.setItem(REC_INF_KEY,String(w));}catch(e){}
}
function finCombateVictoria(){
 var j=G.j;
 avanzarTiempo(40);
 var pisoEnBioma=j.piso%10;if(pisoEnBioma===0)pisoEnBioma=10;
 var bioma=getBioma(j);
 G.log.push("🏆 ¡VICTORIA!");
 profOnVictoria(j);
 if(G.aventuraPiso){
  var pisoObj=G.aventuraPiso;G.aventuraPiso=null;
  var oroBase=Math.floor((30+pisoObj*15)*0.7*factorMaldicion(j,"oro"));
  var xpBase=Math.floor((10+pisoObj*8)*0.7);
  j.oro+=oroBase;
  if(j.nivel>=NIVEL_MAX){var fmB=famaDeXP(xpBase);ganarFama(j,fmB);xpBase=fmB;}else j.xp+=xpBase;
  G.log.push("+"+oroBase+" Oro (-30%) | "+(j.nivel>=NIVEL_MAX?"+"+xpBase+" Fama":"+"+xpBase+" Exp (-30%)"));
  farmearBioma(getBioma({piso:pisoObj}).id,j,true);
  G.msg="Aventura completada. +"+oroBase+" oro, +"+xpBase+(j.nivel>=NIVEL_MAX?" fama.":" XP.");
  guardar();G.screen=salirAventura();render();return;
 }
 if(pisoEnBioma===10){
  var st=calcStats(j);j.vida=st.vidaMax;j.recurso=st.recursoMax;
  G.log.push("Derrotaste al jefe. Vida y "+j.recursoNombre+" restaurados.");
  if(JEFES_REL[j.piso]){var rel=JEFES_REL[j.piso];if(!j.reliquias.some(function(r){return r.n===rel.n;})){j.reliquias.push(rel);G.log.push("♛ ¡RELIQUIA OBTENIDA! "+rel.n+" — "+rel.efecto);}}
 }
 if(Math.random()<(pisoEnBioma===5||pisoEnBioma===10?1:0.5)){var mat=bioma.material;agregarItem(j,mat,1);G.log.push("+1 "+mat);}
 if(j.piso===70){if((j.ciclo||0)>=MAX_EXTREMO)j.fin=true;guardar();G.screen="creditos";render();return;}
 if((j.ciclo||0)>0&&pisoEnBioma!==5&&pisoEnBioma!==10){
  var et=j.etapa||1;
  if(et<5){j.etapa=et+1;G.log.push("✔ Etapa "+et+"/5 completada.");G.msg="Etapa "+et+"/5 completada. Piso "+j.piso+": siguiente etapa "+j.etapa+"/5.";guardar();G.screen="hub";render();return;}
 }
 j.etapa=1;
 var biomaAnt=bioma.nombre;j.piso++;checkAutoRango(j);
 var biomaNuevo=getBioma(j).nombre;
 if(biomaAnt!==biomaNuevo)G.log.push("♕ HAS ENTRADO A: "+biomaNuevo.toUpperCase());
 else G.log.push("Avanzas al piso "+j.piso+".");
 guardar();
 G.msg="Victoria en el piso. Avanzas al piso "+j.piso+".";
 G.screen="hub";render();
}
var MAX_EXTREMO=3;
function iniciarExtremo(j){
 if((j.ciclo||0)>=MAX_EXTREMO)return;
 j.ciclo=(j.ciclo||0)+1;j.piso=1;j.etapa=1;
 j.misiones_seq={grupo:1,indice:0,estado:"disponible",prog:{},completadas:0};
 j.gremio={rango:1,misiones_completadas:0};
 var st=calcStats(j);j.vida=st.vidaMax;j.recurso=st.recursoMax;
 j.cooldowns=[0,0,0];j.defTemp=0;j.defTurnos=0;j.escudo=0;j.inmune=0;
 G.aventuraPiso=null;G.log=["☠ MODO EXTREMO "+j.ciclo+": el mundo se reinicia con tu nivel y equipo."];
 G.msg="☠ MODO EXTREMO "+j.ciclo+". Empiezas desde el piso 1: cada piso tiene 5 etapas y los jefes traen 2 esbirros.";
 guardar();
}
function renderCreditos(){
 var j=G.j,d=0;
 function ln(t,st){d+=0.7;return '<div style="animation:credUp .9s ease both;animation-delay:'+d.toFixed(1)+'s;'+(st||'')+'">'+t+'</div>';}
 var h='<div style="max-width:560px;margin:0 auto;padding:40px 14px;text-align:center">';
 h+=ln('<div class="font-disp" style="font-size:clamp(26px,5vw,42px);font-weight:900;color:var(--accent)">THE CHRONICLES<br>OF NARADAK</div>','margin-bottom:6px');
 h+=ln('El despertar de los Titanes','font-style:italic;color:var(--muted);margin-bottom:26px');
 h+=ln('El Olvidado ha caído.','font-size:18px;color:#e0c060;margin-bottom:26px');
 h+=ln('<span style="color:var(--muted);font-size:12px;letter-spacing:.3em;text-transform:uppercase">Héroe</span><br>'+j.nombre+' el '+j.clase+' · Nv '+j.nivel+((j.ciclo||0)>0?' · Modo Extremo '+j.ciclo:''),'margin-bottom:22px');
 h+=ln('<span style="color:var(--muted);font-size:12px;letter-spacing:.3em;text-transform:uppercase">Un juego de</span><br>Dark Wolf Studios','margin-bottom:22px');
 h+=ln('<span style="color:var(--muted);font-size:12px;letter-spacing:.3em;text-transform:uppercase">Diseño y desarrollo</span><br>Brian Gongora Suárez','margin-bottom:22px');
 h+=ln('Gracias por jugar.','font-size:16px;color:#d8c8a0;margin-bottom:26px');
 var fin=(j.ciclo||0)>=MAX_EXTREMO;
 h+=ln(fin?'<div class="font-disp" style="font-size:24px;color:#e06a5a;margin-bottom:14px">FIN DEL JUEGO</div><div style="font-size:13px;color:var(--muted);margin-bottom:14px">Completaste el Modo Extremo '+MAX_EXTREMO+'/'+MAX_EXTREMO+'.</div><button class="btn btn-primary" id="bCredMenu" style="padding:12px 22px">Volver al menú principal</button>':'<div style="display:flex;gap:12px;justify-content:center;flex-wrap:wrap"><button class="btn btn-primary" id="bExtremo" style="padding:12px 22px">☠ Seguir jugando: Modo Extremo '+((j.ciclo||0)+1)+'/'+MAX_EXTREMO+'</button><button class="btn" id="bCredMenu" style="padding:12px 22px">Volver al menú principal</button></div><div style="font-size:11px;color:var(--muted);margin-top:10px">Modo Extremo: reinicias desde el piso 1 con tu nivel y equipo. Enemigos más fuertes, 5 etapas por piso y jefes con 2 esbirros.</div>');
 h+='</div>';
 el.innerHTML=h;
 var bx=document.getElementById("bExtremo");if(bx)bx.onclick=function(){iniciarExtremo(G.j);G.screen="hub";render();};
 document.getElementById("bCredMenu").onclick=function(){guardar();G.screen="title";render();};
}
function finCombateMuerte(){
 var j=G.j;G.volverCastillo=false;
 avanzarTiempo(90);
 G.log.push("☠ HAS MUERTO.");
 j.vida=1;
 maldicionPorMuerte(j);
 guardar();
 G.msg="Has caído en combate. El Olvidado te ha marcado con una maldición. Ve al Hospital para purgarla.";
 G.screen="hub";render();
}
