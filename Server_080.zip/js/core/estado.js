"use strict";
/* Estado global G, guardado multi-slot, hooks de misiones */
/* ============================================================
   MOTOR DEL JUEGO
   ============================================================ */
var G = {screen:"title", j:null, enemigos:[], log:[], target:0, shopTab:"armas", shopStock:null, msg:"", gremioTab:"campana", herreriaTab:"arma", alquimistaTab:"pocion", aventuraPiso:null, combateInicio:0, combateSinDano:true};
var SAVE_KEY = "naradak_save_v2";
function rnd(a,b){return Math.floor(Math.random()*(b-a+1))+a;}
function pick(arr){return arr[Math.floor(Math.random()*arr.length)];}
function getBioma(j){var id=Math.floor((j.piso-1)/10)+1; return BIOMAS[id]||BIOMAS[7];}
function factorMaldicion(j,efecto){var f=1.0; for(var n in MALDICIONES){var d=MALDICIONES[n]; if(d.efecto===efecto && j.maldiciones[n]) f*=(1-d.valor);} return f;}
/* Rango de daño: parte del rango base de la clase (nivel 1) y crece hasta RANGO_DANO_MAX (40%) en RANGO_DANO_NIV (nivel 20).
   Daño mínimo = daño máximo x (1 - rango). Ej.: máximo 100 en nivel 20+ -> mínimo 60. */
var RANGO_DANO_MAX=.40,RANGO_DANO_NIV=20;
function rangoDano(j,bA,bAmax){
 var r0=bAmax>0?Math.max(0,1-bA/bAmax):0,t=Math.min(1,Math.max(0,((j.nivel||1)-1)/(RANGO_DANO_NIV-1)));
 return r0+(RANGO_DANO_MAX-r0)*t;
}
/* Costo de recurso de habilidades: +4% por nivel sobre el costo base (nivel 1 = costo base) */
var COSTO_HAB_NIV=.04;
function costoHab(j,c){return Math.max(1,Math.round(c*(1+((j.nivel||1)-1)*COSTO_HAB_NIV)));}
/* Aumento de daño por nivel: 1 = original (+22.5 de ataque por nivel). Menor = más difícil. */
var DANO_NIV_F=.20;
/* Factores de balance (1 = original): aporte del equipo al ataque, y vida/defensa ganadas por nivel */
var EQUIPO_ATK_F=1,EQUIPO_DEF_F=1,VIDA_NIV_F=.80,DEF_NIV_F=.5;
function calcStats(j){
 var c=CLASES[j.clase];
 var bA=c.atk[0],bAmax=c.atk[1],bD=c.def,bV=c.vida,bR=c.rec;
 var bA2=0,bD2=0,bV2=0,bR2=0;
 for(var s in j.equipo){var it=j.equipo[s]||{}; bA2+=(it.atk||0)*EQUIPO_ATK_F;bD2+=(it.def||0)*EQUIPO_DEF_F;bV2+=it.vida||0;bR2+=it.recurso||0;}
 for(var i=0;i<j.reliquias.length;i++){var r=j.reliquias[i]; bA2+=r.atk||0;bD2+=r.def||0;bV2+=r.vida||0;bR2+=r.recurso||0;}
 var at=derivados(j);bA2+=at.dano;bV2+=at.vidaB;bR2+=at.recB;
 var nb=(j.nivel-1)*15;
 var atkMax=Math.floor((bAmax+bA2+nb*1.5*DANO_NIV_F+profBuff(j,"atk"))*factorMaldicion(j,"atk")*(1+talMods(j).dmg));
 var atkMin=Math.floor(atkMax*(1-rangoDano(j,bA,bAmax)));
 var def=Math.floor((bD+bD2+nb*DEF_NIV_F+profBuff(j,"def"))*factorMaldicion(j,"def")*(1+talMods(j).defp));
 var vmax=Math.floor((bV+bV2+nb*2*VIDA_NIV_F)*factorMaldicion(j,"vida"));
 var rmax=Math.floor((bR+bR2+nb)*factorMaldicion(j,"recurso"));
 if(j.vida>vmax)j.vida=vmax; if(j.recurso>rmax)j.recurso=rmax;
 return {atkMin:atkMin,atkMax:atkMax,def:def,vidaMax:vmax,recursoMax:rmax,probGolpe:at.probGolpe,probEsq:at.probEsq,redFis:at.redFis,redMag:at.redMag,critB:at.critB+Math.round(talMods(j).crit*100),critMult:at.critMult,potencia:at.potencia,iniciativa:at.iniciativa,inicG:at.inicG};
}
/* ---------- FAMA y TÍTULOS (nivel máximo) ----------
   Al llegar al nivel 100 se deja de ganar XP: cada XP que se ganaría se convierte en una pequeña cantidad de fama
   (FAMA_RATIO). Al llenar 10 000 / 50 000 / 100 000 de fama se obtiene un título; cada título sustituye al anterior. */
var NIVEL_MAX=100,FAMA_RATIO=.05,FAMA_MAX=100000;
var FAMA_TITULOS=[{f:10000,n:"Renombrado"},{f:50000,n:"Héroe de Naradak"},{f:100000,n:"Leyenda Inmortal"}];
function tituloPorFama(f){var t=null;f=f||0;for(var i=0;i<FAMA_TITULOS.length;i++)if(f>=FAMA_TITULOS[i].f)t=FAMA_TITULOS[i];return t;}
function tituloJ(j){var t=tituloPorFama(j&&j.fama);return t?t.n:"";}
function sigFama(j){var f=(j&&j.fama)||0;for(var i=0;i<FAMA_TITULOS.length;i++)if(f<FAMA_TITULOS[i].f)return FAMA_TITULOS[i];return null;}
function famaDeXP(x){return Math.max(1,Math.floor(x*FAMA_RATIO));}
function xpTxt(j,x){return j.nivel>=NIVEL_MAX?"+"+famaDeXP(x)+" Fama":"+"+x+" XP";}
function ganarFama(j,cant){
 cant=Math.floor(cant);if(!(cant>0))return 0;
 var antes=j.fama||0,t0=tituloPorFama(antes);
 j.fama=Math.min(FAMA_MAX,antes+cant);cant=j.fama-antes;if(cant<=0)return 0;
 G.log.push("✦ +"+cant+" Fama");
 var t1=tituloPorFama(j.fama);
 if(t1&&t1!==t0){j.titulo=t1.n;G.log.push("🏅 ¡Nuevo título: "+t1.n+"!");G.msg="🏅 ¡Has obtenido el título «"+t1.n+"»!";}
 return cant;
}
function ganarXP(j,cant){
 cant=Math.floor(cant*factorMaldicion(j,"xp"));
 if(j.nivel>=NIVEL_MAX){j.xp=0;ganarFama(j,famaDeXP(cant));return;}   /* nivel máximo: sin XP, solo fama */
 j.xp+=cant;
 var need=j.nivel*100;
 while(j.nivel<NIVEL_MAX&&j.xp>=need){j.xp-=need; j.nivel++; var st=calcStats(j); j.vida=st.vidaMax; j.recurso=st.recursoMax; G.log.push("★ ¡SUBISTE A NIVEL "+j.nivel+"! Vida y "+j.recursoNombre+" restaurados."); need=j.nivel*100;}
 if(j.nivel>=NIVEL_MAX)j.xp=0;
}
var PISO_DANO=0.20,PISO_DANO_CRIT=0.30; /* daño mínimo recibido (fracción del ataque) */
function danoMitigado(atk,def,crit){if(def<0)def=0;var mit=100/(100+def);var d=atk*mit;var mn=atk*(crit?PISO_DANO_CRIT:PISO_DANO);return Math.max(1,Math.floor(Math.max(d,mn)));}
function crearJugador(nombre,clase){
 var c=CLASES[clase];
 function eq(slot){var a=ITEMS.find(function(i){return i[1]===(slot==="arma"?"arma":"armadura")&&i[2]===clase&&i[3]===slot&&i[9]===1;}); return itemObj(a);}
 return {nombre:nombre,clase:clase,nivel:1,xp:0,piso:1,oro:100,vida:c.vida,recurso:c.rec,recursoNombre:c.recNombre,
  equipo:{arma:eq("arma"),pecho:eq("pecho"),piernas:eq("piernas"),guantes:eq("guantes"),botas:eq("botas"),accesorio:{n:"Ninguno",atk:0,def:0,vida:0,recurso:0}},
  inventario:{"Poción de Vida":5,"Poción de Recurso":2},reliquias:[],cooldowns:[0,0,0],defTemp:0,defTurnos:0,escudo:0,inmune:0,maldiciones:{},
  gremio:{rango:1,misiones_completadas:0},misiones_seq:{grupo:1,indice:0,estado:"disponible",prog:{},completadas:0}};
}
function checkAutoRango(j){
 if(!j.gremio)j.gremio={rango:1,misiones_completadas:0};
 while(j.gremio.rango<7){
  var sig=RANGOS_GREMIO[j.gremio.rango+1];
  if(j.piso>=sig.req_piso){
   j.gremio.rango++; j.oro+=sig.recompensa;
   G.log.push("⬆ ¡Ascenso automático del Gremio! Rango "+sig.n+" · +"+sig.recompensa+" oro.");
   G.msg="⬆ El Gremio te ha ascendido automáticamente a RANGO "+sig.n+". Recompensa: +"+sig.recompensa+" oro.";
  }else break;
 }
}
/* ---------- guardado multi-slot (5) ---------- */
var SLOTS=5;
function slotKey(n){return "naradak_slot_"+n;}
function slotLeer(n){try{var s=localStorage.getItem(slotKey(n));return s?JSON.parse(s):null;}catch(e){return null;}}
function slotMigrar(){try{
 if(localStorage.getItem("naradak_slots_migrado"))return;
 var old=localStorage.getItem(SAVE_KEY)||localStorage.getItem("naradak_save_v1");
 if(old&&!localStorage.getItem(slotKey(1)))localStorage.setItem(slotKey(1),old);
 localStorage.setItem("naradak_slots_migrado","1");
}catch(e){}}
function slotLibre(){for(var i=1;i<=SLOTS;i++){if(!slotLeer(i))return i;}return 0;}
function guardar(){try{
 if(!G.j)return;
 if(!G.slot)G.slot=slotLibre()||1;
 G.j.savedAt=Date.now();
 localStorage.setItem(slotKey(G.slot),JSON.stringify(G.j));
}catch(e){}}
function cargar(n){try{
 var j=slotLeer(n);
 if(!j)return null;
 if(!j.gremio)j.gremio={rango:1,misiones_completadas:0};
 if(!j.misiones_seq)j.misiones_seq={grupo:1,indice:0,estado:"disponible",prog:{},completadas:0};
 if(!j.cooldowns)j.cooldowns=[0,0,0];
 if(typeof j.avatar==="number"){try{localStorage.setItem("naradak_pc",j.avatar);}catch(e){}} /* personaje elegido de ESTA partida */
 if(typeof mapaReset==="function")mapaReset();
 if(!j.equipo.accesorio)j.equipo.accesorio={n:"Ninguno",atk:0,def:0,vida:0,recurso:0};
 return j;
}catch(e){return null;}}
function haySave(){slotMigrar();for(var i=1;i<=SLOTS;i++){if(slotLeer(i))return true;}return false;}
/* ---------- misiones del gremio (hooks) ---------- */
function mEst(j){if(!j.misiones_seq)j.misiones_seq={grupo:1,indice:0,estado:"disponible",prog:{},completadas:0};return j.misiones_seq;}
function mActual(j){var es=mEst(j);var g=GRUPOS[es.grupo];return g?(g.misiones[es.indice]||null):null;}
function esMaterial(n){return !POCIONES.some(function(p){return p.n===n;})&&!/Poci[oó]n/i.test(n)&&!PROF_CONS[n];}
function tieneEntrega(j,m){for(var k in m.obj){if((j.inventario[k]||0)<m.obj[k])return false;}return true;}
function reservadoEntrega(j,item){var es=mEst(j);if(es.estado!=="activa")return 0;var m=mActual(j);return(m&&m.tipo==="entrega"&&m.obj[item])?m.obj[item]:0;}
function progMision(j,k){var es=mEst(j),m=mActual(j);if(m&&m.tipo==="entrega")return Math.min(j.inventario[k]||0,m.obj[k]);return es.prog[k]||0;}
function mCheck(j){
 var es=mEst(j); var m=mActual(j);
 if(!m||es.estado!=="activa"||m.tipo==="entrega")return;
 var ok=true; for(var k in m.obj){if((es.prog[k]||0)<m.obj[k])ok=false;}
 if(ok){es.estado="lista"; G.log.push("📜 ¡Objetivos de misión completados! Reclámala en el Gremio."); G.msg="📜 ¡Objetivos de misión completados! Ve al Gremio a reclamar tu recompensa.";}
}
function registrarBaja(j,nombreEnemigo,sinDano,duracion){
 var es=mEst(j); if(es.estado!=="activa")return;
 var m=mActual(j); if(!m||m.tipo!=="caza"||!(nombreEnemigo in m.obj))return;
 if((es.prog[nombreEnemigo]||0)>=m.obj[nombreEnemigo])return;
 if(m.cond==="sin_dano"&&!sinDano){G.log.push("📜 "+nombreEnemigo+" abatido, pero la misión exige SIN RECIBIR DAÑO...");return;}
 if(m.cond&&typeof m.cond==="object"&&duracion>m.cond.max_seg){G.log.push("📜 "+nombreEnemigo+" abatido, pero superaste el límite de tiempo...");return;}
 es.prog[nombreEnemigo]=(es.prog[nombreEnemigo]||0)+1;
 G.log.push("📜 Misión: "+nombreEnemigo+" "+es.prog[nombreEnemigo]+"/"+m.obj[nombreEnemigo]);
 mCheck(j);
}
/* Recolección: cuenta todo material obtenido mientras la misión está activa */
function registrarRecoleccion(j,item,cant){
 var es=mEst(j); if(es.estado!=="activa")return;
 var m=mActual(j); if(!m||m.tipo!=="recoleccion"||!(item in m.obj))return;
 if((es.prog[item]||0)>=m.obj[item])return;
 es.prog[item]=Math.min(m.obj[item],(es.prog[item]||0)+(cant||1));
 G.log.push("📜 Misión: "+item+" "+es.prog[item]+"/"+m.obj[item]);
 mCheck(j);
}
/* Única vía para añadir objetos al inventario (loot, farmeo, victoria) */
function agregarItem(j,item,cant){
 cant=cant||1;
 j.inventario[item]=(j.inventario[item]||0)+cant;
 registrarRecoleccion(j,item,cant);
}
/* Vender materiales al gremio: única vía de venta */
function venderMaterial(j,nombre,cant){
 var disp=(j.inventario[nombre]||0)-reservadoEntrega(j,nombre);
 cant=Math.min(cant,disp); if(!(cant>0))return 0;
 var precio=precioMaterial(nombre);
 j.inventario[nombre]-=cant; if(j.inventario[nombre]<=0)delete j.inventario[nombre];
 j.oro+=precio*cant; avanzarTiempo(3); guardar(); return cant;
}
/* Completar misión: entrega (activa/lista) consume materiales; caza/recolección exigen estado "lista" */
function completarMision(j){
 var es=mEst(j),m=mActual(j); if(!m)return false;
 if(m.tipo==="entrega"){
  if(es.estado!=="activa"&&es.estado!=="lista")return false;
  if(!tieneEntrega(j,m)){G.msg="Te faltan materiales para entregar.";return false;}
  for(var k in m.obj){j.inventario[k]-=m.obj[k];if(j.inventario[k]<=0)delete j.inventario[k];}
 }else if(es.estado!=="lista")return false;
 avanzarTiempo(15);
 j.oro+=m.oro;ganarXP(j,Math.floor(m.oro*0.4));es.completadas++;j.gremio.misiones_completadas++;es.indice++;es.prog={};
 G.msg="🏆 Misión completada: +"+m.oro+" oro.";
 if(es.indice>=25){if(es.grupo<7){es.grupo++;es.indice=0;es.estado="disponible";G.msg="¡Secuencia completada! Nueva desbloqueada: "+GRUPOS[es.grupo].nombre;}else{es.estado="fin";G.msg="💀 ENTREGASTE EL ALMA DEL OLVIDADO. FIN DEL JUEGO.";}}
 else es.estado="disponible";
 return true;
}
