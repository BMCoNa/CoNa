"use strict";
/* ============================================================
   VELOCIDADES DE COMBATE (2 s = 1 turno). El combate se juega en tiempo real en js/demo/combate_demo.js;
   aquí solo quedan las velocidades base y renderInventory.
   intervalo de acción = 2 s ÷ velocidad
   velocidad jugador = base de clase × (1 + 0.004 × (AGI − 10))
   ============================================================ */
var TURNO_S=2.0;
var VEL_BASE={Guerrero:1.0,Paladin:.85,Arquero:1.25,Asesino:1.8,Mago:.9,"Clérigo":.95};
var VEL_ENEMIGO=[
 [/Lobo|Perro|Escorpión|Buitre|Duende|Ladrón|Bandido|Arpía|Salamandra|Espectro|Sombra|Naga|Djinni|Genio/,1.35],
 [/Golem|Troll|Gigante|Mamut|Ent |Yeti|Momia|Aberración|Cerbero|Necrófago/,.7],
 [/Mago|Nigromante|Brujo|Cultista|Elemental|Magma|Fénix|Alma|Custodio|Centinela/,.95]
];
function velJugador(j){var A=atributos(j).t;return (VEL_BASE[j.clase]||1)*(1+0.004*(A.agi-10))*(1+talMods(j).vel);}
function velEnemigo(e,j){
 var v=1.0;
 if(e.tipo==="jefe")v=.8;else if(e.tipo==="mini_jefe")v=.9;
 else for(var i=0;i<VEL_ENEMIGO.length;i++){if(VEL_ENEMIGO[i][0].test(e.nombre)){v=VEL_ENEMIGO[i][1];break;}}
 return Math.min(1.8,v*(1+0.03*((j&&j.ciclo)||0)));
}
function renderInventory(){
 var j=G.j,st=calcStats(j);
 var h=hudHTML(j)+atributosHTML(j)+'<div class="card" style="margin-bottom:12px"><div class="font-disp" style="color:var(--accent);margin-bottom:10px">'+iconoSVG('bolsa')+'Equipo</div>';
 var slots={arma:"Arma",pecho:"Pecho",piernas:"Piernas",guantes:"Guantes",botas:"Botas",accesorio:"Accesorio",casco:"Casco",capa:"Capa",amuleto:"Amuleto"};
 for(var s in slots){var it=j.equipo[s]||{n:"Ninguno"};var bonus=[];if(it.atk)bonus.push("ATK +"+it.atk);if(it.def)bonus.push("DEF +"+it.def);if(it.vida)bonus.push("VIDA +"+it.vida);if(it.recurso)bonus.push(j.recursoNombre+" +"+it.recurso);var _at=attrTxt(itemAttr(it));if(_at)bonus.push(_at);
  h+='<div style="display:flex;justify-content:space-between;padding:6px 0;border-bottom:1px dashed var(--border);font-size:13px"><span style="color:var(--muted)">'+slots[s]+'</span><span style="font-weight:600">'+(it.n&&it.n!=="Ninguno"?itemImg(it.n,30):'')+it.n+(bonus.length?' <span style="color:var(--muted);font-weight:400">('+bonus.join(", ")+')</span>':'')+'</span></div>';}
 if(j.reliquias.length)h+='<div style="margin-top:10px;font-size:12px;color:#c9a25a">♛ Reliquias: '+j.reliquias.map(function(r){return r.n+" ("+r.efecto+")";}).join(", ")+'</div>';
 h+='</div>'+equipoGuardadoHTML(j)+'<div class="card" style="margin-bottom:12px"><div class="font-disp" style="color:var(--accent);margin-bottom:10px">'+iconoSVG('pocion')+'Consumibles</div>';
 var hay=false;
 Object.keys(j.inventario).forEach(function(nombre){
  var esPoc=POCIONES.some(function(p){return p.n===nombre;})||/Poci[oó]n/i.test(nombre)||!!PROF_CONS[nombre];
  if(!esPoc)return;
  hay=true;
  var p=POCIONES.find(function(x){return x.n===nombre;})||{desc:"Consumible"};
  h+='<div style="display:flex;justify-content:space-between;align-items:center;padding:5px 0;font-size:13px"><span>'+itemImg(nombre,32)+nombre+' x'+j.inventario[nombre]+' <span style="color:var(--muted);font-size:11px">— '+p.desc+'</span></span><button class="btn usarPoc" data-poc="'+nombre+'" style="padding:4px 10px;font-size:12px">Usar</button></div>';
 });
 if(!hay)h+='<div style="color:var(--muted);font-size:13px">Sin consumibles.</div>';
 h+='</div><button class="btn" id="bBack">← Volver</button>';
 el.innerHTML=h;
 document.querySelectorAll(".equiparGuard").forEach(function(b){b.onclick=function(){
  var lista=b.getAttribute("data-src")==="p"?profEst(j).equipo:equipoBolsa(j),i=parseInt(b.getAttribute("data-idx"),10),it=lista[i];
  if(!it)return;
  var cur=j.equipo[slotDeItem(it)];if(cur&&cur.n===it.n)return;
  lista.splice(i,1);equiparItem(j,it);guardar();render();
 };});
 document.querySelectorAll(".usarPoc").forEach(function(b){b.onclick=function(){usarPocion(G.j,b.getAttribute("data-poc"));render();};});
 document.getElementById("bBack").onclick=function(){G.screen="hub";render();};
}
