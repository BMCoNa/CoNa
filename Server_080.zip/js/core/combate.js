"use strict";
/* Generación de enemigos, botín, maldiciones y pociones */
/* ---------- combate ---------- */
function statsEnemigoPorNombre(nombre){for(var k in STATS_ENEM){if(nombre.toLowerCase().indexOf(k.toLowerCase())>=0)return STATS_ENEM[k];}return [1,1,1];}
function _normalEnemigo(nb,bioma,multB,multP,pe){
 var st=statsEnemigoPorNombre(nb),en={nombre:nb,tipo:"normal"};
 en.vida=Math.floor((80+multP*2+pe*1.2)*st[0]*multB*1.2);en.vidaMax=en.vida;
 en.atkMin=Math.floor((15+multP+pe*0.28)*st[1]*multB*1.2*0.9);en.atkMax=Math.floor((15+multP+pe*0.28)*st[1]*multB*1.2*1.1);
 en.def=Math.floor((15+multP+pe*0.45)*st[2]*multB*1.15);en.xp=15+pe*2;en.oro=8+pe*2;en.stun=0;
 return en;
}
/* Multiplicador de vida de todos los monstruos (normales, mini-jefes y jefes) */
var ENEM_VIDA_F=1.75;
function generarOleada(j){
 var l=_generarOleadaBase(j),bid=getBioma(j).id+7*(j.ciclo||0);l.forEach(function(e){e.bid=bid;e.vida=Math.floor(e.vida*ENEM_VIDA_F);e.vidaMax=e.vida;armarEnemigo(e);});
 if((j.ciclo||0)>0)l.forEach(function(e){if(e.tipo==="normal"){e.atkMin*=5;e.atkMax*=5;}});/* Extremo: monstruos normales x5 daño (no jefes ni mini-jefes) */
 return l;
}
/* Monstruos por oleada normal según el bioma: [mínimo, máximo] (el mínimo sube con el bioma) */
var OLEADA_RANGO={1:[1,5],2:[2,7],3:[3,10],4:[4,10],5:[7,15],6:[8,16],7:[10,18]};
function _generarOleadaBase(j){
 var bioma=getBioma(j); var pisoEnBioma=j.piso%10; if(pisoEnBioma===0)pisoEnBioma=10;
 /* Modo Extremo: cada ciclo escala como si se añadieran 7 biomas / 70 pisos */
 var ciclo=j.ciclo||0,pe=j.piso+70*ciclo;
 var multB=(bioma.id+7*ciclo)*1.2, multP=pisoEnBioma;
 if(pisoEnBioma===10){
  var e={nombre:bioma.jefe,tipo:"jefe"};
  e.vida=Math.floor((300+pe*20)*multB*1.15);e.vidaMax=e.vida;
  e.atkMin=Math.floor((50+pe*2)*multB*1.15);e.atkMax=Math.floor((50+pe*3)*multB*1.15);
  e.def=Math.floor((70+pe)*multB*1.15);e.xp=100+pe*5;e.oro=200+pe*10;e.stun=0;
  var lj=[e];
  if(ciclo>0){for(var k=0;k<2;k++)lj.push(_normalEnemigo(pick(bioma.monstruos),bioma,multB,multP,pe));}
  return lj;
 }else if(pisoEnBioma===5){
  var e2={nombre:bioma.mini,tipo:"mini_jefe"};
  e2.vida=Math.floor((200+pe*12)*multB*1.15);e2.vidaMax=e2.vida;
  e2.atkMin=Math.floor((35+pe)*multB*1.15);e2.atkMax=Math.floor((35+pe*1.5)*multB*1.15);
  e2.def=Math.floor((45+Math.floor(pe/2))*multB*1.15);e2.xp=60+pe*3;e2.oro=120+pe*5;e2.stun=0;
  var lm=[e2];
  if(ciclo>0){for(var k2=0;k2<2;k2++)lm.push(_normalEnemigo(pick(bioma.monstruos),bioma,multB,multP,pe));}
  return lm;
 }else{
  var rg=OLEADA_RANGO[Math.min(7,bioma.id)]||OLEADA_RANGO[7],num=rnd(rg[0],rg[1]),enemigos=[],tipos;
  if(Math.random()<0.7){var sh=bioma.monstruos.slice().sort(function(){return Math.random()-0.5;});tipos=[];for(var q=0;q<num;q++)tipos.push(sh[q%sh.length]);}
  else{tipos=[];for(var t=0;t<num;t++)tipos.push(pick(bioma.monstruos));}
  for(var i=0;i<tipos.length;i++)enemigos.push(_normalEnemigo(tipos[i],bioma,multB,multP,pe));
  return enemigos;
 }
}
function dropearLoot(enemigo,j){
 var tabla=(enemigo.tipo!=="normal")?(TABLA_LOOT_JEFES[enemigo.nombre]||[]):(TABLA_LOOT[enemigo.nombre]||[]);
 G.log.push("--- Saqueo: "+enemigo.nombre+" ---");
 if(!tabla.length){G.log.push("  No tenía nada...");return;}
 var got=0,caidos=[];
 var oro=tabla[0];
 if(rnd(1,100)<=oro[2]){var cant=Math.floor(rnd(oro[0],oro[1])*factorMaldicion(j,"oro")*(1+talMods(j).oro));j.oro+=cant;G.log.push("  +"+cant+" de oro");got++;}
 /* Jefe de bioma en Extremo: más probabilidad de items de mayor rareza */
 var jefeExt=(enemigo.tipo==="jefe"&&(j.ciclo||0)>0);
 for(var i=1;i<tabla.length;i++){var d=tabla[i],pr=jefeExt?Math.min(100,Math.round(d[1]*(1+0.3*d[2]))):d[1];pr=Math.min(100,Math.round(pr*(1+talMods(j).loot)));
  if(rnd(1,100)<=pr){agregarItem(j,d[0],1);G.log.push("  +1 "+d[0]+" ["+RARIDAD[d[2]]+"]");got++;caidos.push(d[0]);}
 }
 /* Modo Extremo: si cae loot, se suma un segundo item DISTINTO (nunca repetido) */
 if((j.ciclo||0)>0&&caidos.length>0){
  var otros=tabla.slice(1).filter(function(x){return caidos.indexOf(x[0])<0;});
  if(otros.length){
   var b;
   if(jefeExt){var tw=0,ws=otros.map(function(x){var w=(x[2]+1)*(x[2]+1);tw+=w;return w;}),r=Math.random()*tw,ix=0;while(ix<ws.length-1&&r>=ws[ix]){r-=ws[ix];ix++;}b=otros[ix];}
   else b=pick(otros);
   agregarItem(j,b[0],1);G.log.push("  ☠ Extremo: +1 "+b[0]+" ["+RARIDAD[b[2]]+"]");got++;}
 }
 if(got===0)G.log.push("  No obtuviste nada...");
}
function farmearBioma(biomaId,j,retornar){
 var bioma=LOOT_BIOMA[biomaId]; if(!bioma)return retornar?{}:null;
 var pos=[];
 for(var i=0;i<bioma.drops.length;i++){if(rnd(1,100)<=bioma.drops[i][1])pos.push(bioma.drops[i]);}
 if(!pos.length)return retornar?{}:null;
 var drops={};
 var d=pick(pos); agregarItem(j,d[0],1); drops[d[0]]=1;
 G.log.push("  +1 "+d[0]+" de "+bioma.nombre+" ["+RARIDAD[d[2]]+"]");
 /* Modo Extremo: segundo item distinto al primero */
 if((j.ciclo||0)>0){
  var alt=pos.filter(function(x){return x[0]!==d[0];});
  if(!alt.length)alt=bioma.drops.filter(function(x){return x[0]!==d[0];});
  if(alt.length){var d2=pick(alt);agregarItem(j,d2[0],1);drops[d2[0]]=1;G.log.push("  ☠ Extremo: +1 "+d2[0]+" de "+bioma.nombre+" ["+RARIDAD[d2[2]]+"]");}
 }
 return retornar?drops:null;
}
function maldicionPorMuerte(j){
 var disp=Object.keys(MALDICIONES).filter(function(n){return !j.maldiciones[n];});
 if(disp.length){var nm=pick(disp);j.maldiciones[nm]=MALDICIONES[nm];G.log.push("☠ La sombra de El Olvidado te marca: "+nm);}
}
/* Purga de maldiciones: sube por bioma (1-7) hasta PURGA_MAX en el bioma 7; en Extremo cuesta PURGA_EXTREMO en cualquier piso */
var PURGA_MAX=200,PURGA_EXTREMO=500;
function costoPurga(j){
 if((j.ciclo||0)>0)return PURGA_EXTREMO;
 var b=Math.min(7,Math.max(1,Math.floor(((j.piso||1)-1)/10)+1));
 return Math.round(PURGA_MAX*b/7/10)*10;
}
function usarPocion(j,nombre){
 if(PROF_CONS[nombre])return profUsar(j,nombre);
 var st=calcStats(j);var fCura=factorMaldicion(j,"cura");
 var p=POCIONES.find(function(x){return x.n===nombre;});
 if(!p){ // inferir tipo por nombre (robusto para saves antiguos / variantes)
  var tipo=/[ÉE]lfica|Antigua/i.test(nombre)?"full":/Recurso/i.test(nombre)?"recurso":"vida";
  var pct=/Superior/i.test(nombre)?.75:/Mayor/i.test(nombre)?.50:.25;
  p={n:nombre,tipo:tipo,pct:pct,desc:"Consumible"};
 }
 if(!j.inventario[nombre]||j.inventario[nombre]<=0)return false;
 if(p.tipo==="xp"){ganarXP(j,1000);G.log.push("Usaste "+nombre+". +1000 XP.");}
 else if(p.tipo==="almas"){talEst(j).almas+=100;G.log.push("Usaste "+nombre+". +100 almas.");}
 else if(p.tipo==="full"){j.vida=st.vidaMax;j.recurso=st.recursoMax;G.log.push("Usaste "+nombre+". ¡Stats restaurados!");}
 else if(p.tipo==="vida"){var c=Math.floor(st.vidaMax*p.pct*fCura);j.vida=Math.min(st.vidaMax,j.vida+c);G.log.push("Usaste "+nombre+". +"+c+" de vida.");}
 else{var r=Math.floor(st.recursoMax*p.pct*fCura);j.recurso=Math.min(st.recursoMax,j.recurso+r);G.log.push("Usaste "+nombre+". +"+r+" de "+j.recursoNombre+".");}
 j.inventario[nombre]--;if(j.inventario[nombre]<=0)delete j.inventario[nombre];
 return true;
}
