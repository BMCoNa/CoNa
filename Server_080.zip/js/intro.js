"use strict";
/* THE CHRONICLES OF NARADAK — Presentación de Wolf Studios
   Música épica + logo + desvanecido hacia el menú inicial.
   Archivos: assets/logo.png · assets/audio/intro.ogg / intro.mp3
   Toque en pantalla: omitir. */
(function(){
 if(window.top!==window)return;
 var DIR="assets/audio/",T={logo:600,flash:7000,salida:11400,fin:12600,quitar:13800};
 var EXT=(function(){try{var a=new Audio();return a.canPlayType('audio/ogg; codecs="vorbis"')?"ogg":"mp3";}catch(e){return "mp3";}})();
 var mudo=false;
 var css=document.createElement("style");
 css.textContent=
 "#wsIntro{position:fixed;inset:0;z-index:99999;background:radial-gradient(ellipse at 50% 45%,#1b130a 0%,#0a0704 55%,#000 100%);display:flex;align-items:center;justify-content:center;overflow:hidden;opacity:1;transition:opacity 1.2s ease;touch-action:manipulation;user-select:none;-webkit-user-select:none}"+
 "#wsIntro.fuera{opacity:0;pointer-events:none}"+
 "#wsGlow{position:absolute;left:50%;top:48%;width:min(120vw,900px);height:min(120vw,900px);transform:translate(-50%,-50%) scale(.7);border-radius:50%;background:radial-gradient(circle,rgba(232,170,60,.30) 0%,rgba(201,146,60,.12) 38%,transparent 68%);opacity:0;transition:opacity 2.4s ease,transform 6s ease-out}"+
 "#wsGlow.on{opacity:1;transform:translate(-50%,-50%) scale(1)}"+
 "#wsGlow.boom{animation:wsBoom 1.6s ease-out}"+
 "@keyframes wsBoom{0%{opacity:1;transform:translate(-50%,-50%) scale(1)}25%{opacity:1;transform:translate(-50%,-50%) scale(1.35);filter:brightness(2.2)}100%{opacity:.85;transform:translate(-50%,-50%) scale(1.05);filter:none}}"+
 "#wsLogoW{position:relative;opacity:0;transform:scale(1.07);transition:opacity 2.4s ease,transform 11s cubic-bezier(.2,.6,.3,1);max-width:80vw;max-height:76vh;display:flex}"+
 "#wsLogoW.on{opacity:1;transform:scale(1)}"+
 "#wsLogoW.sale{opacity:0;transition:opacity 1.1s ease;}"+
 "#wsLogo{display:block;max-width:80vw;max-height:76vh;width:auto;height:auto;filter:drop-shadow(0 0 22px rgba(232,170,60,.35))}"+
 "#wsShine{position:absolute;inset:0;-webkit-mask-image:url(assets/logo.png);mask-image:url(assets/logo.png);-webkit-mask-size:100% 100%;mask-size:100% 100%;-webkit-mask-repeat:no-repeat;mask-repeat:no-repeat;background:linear-gradient(105deg,transparent 38%,rgba(255,244,210,.9) 50%,transparent 62%);background-size:260% 100%;background-position:130% 0;background-repeat:no-repeat;opacity:0;pointer-events:none}"+
 "#wsShine.go{opacity:1;animation:wsShine 1.5s ease-in-out forwards}"+
 "@keyframes wsShine{from{background-position:130% 0}to{background-position:-30% 0}}"+
 "#wsFlash{position:absolute;inset:0;background:radial-gradient(circle at 50% 46%,rgba(255,236,190,.85),rgba(255,200,110,.25) 45%,transparent 75%);opacity:0;pointer-events:none}"+
 "#wsFlash.go{animation:wsFlash 1.1s ease-out}"+
 "@keyframes wsFlash{0%{opacity:0}12%{opacity:.75}100%{opacity:0}}"+
 "#wsTap{position:absolute;left:0;right:0;bottom:12%;text-align:center;font:600 15px Cinzel,serif;letter-spacing:.3em;color:#c9a463;text-transform:uppercase;animation:wsPulse 1.8s ease-in-out infinite}"+
 "@keyframes wsPulse{0%,100%{opacity:.35}50%{opacity:1}}"+
 "#wsSkip{position:absolute;right:14px;bottom:12px;font:500 11px Karla,sans-serif;letter-spacing:.15em;color:#8b7a5a;text-transform:uppercase;opacity:0;transition:opacity 1.5s ease}"+
 "#wsSkip.on{opacity:.6}"+
 ".wsEm{position:absolute;bottom:-12px;width:3px;height:3px;border-radius:50%;background:#ffcf7a;box-shadow:0 0 6px 2px rgba(255,170,60,.7);opacity:0;animation:wsRise linear infinite}"+
 "@keyframes wsRise{0%{transform:translate(0,0);opacity:0}12%{opacity:.9}100%{transform:translate(var(--dx),-105vh);opacity:0}}";
 document.head.appendChild(css);
 var ov=document.createElement("div");ov.id="wsIntro";
 ov.innerHTML='<div id="wsGlow"></div><div id="wsLogoW"><img id="wsLogo" src="assets/logo.png" alt="Wolf Studios" draggable="false"><div id="wsShine"></div></div><div id="wsFlash"></div><div id="wsTap" style="display:none">Toca para comenzar</div><div id="wsSkip">Toca para omitir</div>';
 for(var i=0;i<26;i++){
  var e=document.createElement("div");e.className="wsEm";
  e.style.left=(Math.random()*100)+"%";e.style.setProperty("--dx",((Math.random()-.5)*120)+"px");
  e.style.animationDuration=(6+Math.random()*7)+"s";e.style.animationDelay=(-Math.random()*9)+"s";
  e.style.transform="scale("+(.6+Math.random()*1.2)+")";ov.appendChild(e);
 }
 document.body.insertBefore(ov,document.body.firstChild);
 var $=function(id){return document.getElementById(id);};
 var audio=null,tms=[],iniciado=false,terminado=false;
 function T_(fn,ms){tms.push(setTimeout(fn,ms));}
 function sonar(){
  if(mudo)return Promise.resolve();
  try{audio=new Audio(DIR+"intro."+EXT);audio.volume=.9;audio.preload="auto";var p=audio.play();return Promise.race([p||Promise.resolve(),new Promise(function(res){setTimeout(res,1500);})]);}
  catch(e){return Promise.reject(e);}
 }
 function bajarAudio(ms){
  if(!audio)return;var a=audio,v0=a.volume,t0=Date.now();
  (function paso(){var k=Math.min(1,(Date.now()-t0)/ms);try{a.volume=Math.max(0,v0*(1-k));}catch(e){}if(k<1)setTimeout(paso,50);else{try{a.pause();}catch(e){}}})();
 }
 function quitar(){
  terminado=true;tms.forEach(clearTimeout);
  if(ov.parentNode)ov.parentNode.removeChild(ov);
  if(css.parentNode)css.parentNode.removeChild(css);
 }
 function terminar(rapido){
  if(terminado)return;terminado=true;tms.forEach(clearTimeout);
  var lw=$("wsLogoW");if(lw)lw.classList.add("sale");
  if(rapido){ov.style.transition="opacity .7s ease";bajarAudio(800);}
  setTimeout(function(){ov.classList.add("fuera");},rapido?150:0);
  setTimeout(quitar,rapido?1000:1300);
 }
 function empezar(){
  if(iniciado)return;iniciado=true;
  var tap=$("wsTap");if(tap)tap.style.display="none";
  T_(function(){$("wsGlow").classList.add("on");$("wsLogoW").classList.add("on");$("wsSkip").classList.add("on");},T.logo);
  T_(function(){
   $("wsFlash").classList.add("go");$("wsShine").classList.add("go");$("wsGlow").classList.add("boom");
  },T.flash);
  T_(function(){$("wsLogoW").classList.add("sale");},T.salida);
  T_(function(){ov.classList.add("fuera");},T.fin);
  T_(quitar,T.quitar);
 }
 function toque(){
  if(terminado)return;
  if(iniciado){terminar(true);return;}
  /* primer toque: permite el audio y arranca (sin depender de que el audio responda) */
  sonar().then(empezar,empezar);
 }
 var _tq=0;
 function toqueUnico(){var n=Date.now();if(n-_tq<300)return;_tq=n;toque();}
 ov.addEventListener("pointerdown",toqueUnico);
 ov.addEventListener("click",toqueUnico);
 ov.addEventListener("touchstart",toqueUnico,{passive:true});
 document.addEventListener("keydown",function(e){if(!terminado)toqueUnico();});
 /* seguro: pase lo que pase, la presentación desaparece a los 20 s */
 setTimeout(function(){if(!terminado){terminado=true;tms.forEach(clearTimeout);try{if(audio)audio.pause();}catch(e){}quitar();}},20000);
 /* intento automático; si el navegador bloquea el audio se pide un toque */
 var img=$("wsLogo"),listo=false;
 function intentar(){
  if(listo)return;listo=true;
  if(mudo){empezar();return;}
  sonar().then(empezar,function(){audio=null;var tap=$("wsTap");if(tap)tap.style.display="block";});
 }
 if(img.complete)intentar();else{img.onload=intentar;img.onerror=intentar;setTimeout(intentar,2500);}
})();
