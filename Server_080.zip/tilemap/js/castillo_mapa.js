"use strict";
/* THE CHRONICLES OF NARADAK — Interior del Castillo (2.5D isométrico, sala grande con cámara).
   Mensajes -> juego: {naradak:"ready"} · {naradak:"npc",id:"aventura"|"infinita"} · {naradak:"exit"} */
(function(){
var W=24,H=18,WH=150,TW=32,TH=16,SPD=3.8;
var cv=document.getElementById("cas"),cx=cv.getContext("2d"),$=function(i){return document.getElementById(i);};
var IM={},CI=[],DPR=1,Z=1,T=0,CAMX=0,CAMY=0;
var PC=(function(){try{var v=parseInt(localStorage.getItem("naradak_pc"),10);return v>=0&&v<CHARS.length&&CHARS_INFO[v].k==="humano"?v:4;}catch(e){return 4;}})();
var EMB=parent!==window;
function pj(x,y){return{x:(x-y)*TW,y:(x+y)*TH};}
function dirOf(dx,dy){var sx=dx-dy,sy=dx+dy;return Math.abs(sx)>Math.abs(sy)?(sx<0?1:2):(sy>0?0:3);}
/* ---------- NPC fijos: Generales de Guerra (sprites 48x72) ---------- */
var NP=[
 {id:"aventura",c:80,alt:72,x:5.8,y:6.9,n:"General Aldric",r:"Comandante de Guerra",verbo:"Modo Aventura",ico:"⚔",open:1},
 {id:"infinita",c:83,alt:77,x:11.5,y:15.6,n:"General Kaelen",r:"Señor de la Mazmorra Infinita",verbo:"Mazmorra Infinita",ico:"∞",open:1},
 {id:"valka",c:81,alt:73,x:17.4,y:7.6,n:"General Valka",r:"Vanguardia del Reino",verbo:"Hablar",ico:"🛡",lines:["Mis lanceros no descansan: cada piso despejado es una victoria.","Un buen general conoce el terreno antes de pisarlo.","Si quieres rejugar una campaña, habla con Aldric en la mesa de guerra."]},
 {id:"brom",c:82,alt:74,x:19.6,y:12.4,n:"General Brom",r:"Maestro de Asedio",verbo:"Hablar",ico:"🛡",lines:["Ni la muralla más gruesa resiste a un asedio bien planeado.","Guardo aquí las provisiones para la próxima campaña.","Los jefes de piso caen más rápido con el equipo adecuado."]},
 {id:"ysolde",c:85,alt:75,x:3.4,y:11.6,n:"Mariscal Ysolde",r:"Mariscal de Campo",verbo:"Hablar",ico:"🛡",lines:["La puerta del castillo nunca se cierra para quien porta el estandarte del Gremio.","Descansa, aventurero. La guerra espera al amanecer.","El mapa de Aldric muestra cada piso que ya conquistaste."]},
 {id:"rey",c:87,alt:76,x:12,y:2.0,n:"Rey Eadric",r:"Soberano de Naradak",verbo:"Hablar",ico:"👑",lift:16,lines:["Naradak resiste gracias a valientes como tú.","Mis generales te guiarán en las campañas que necesites.","Que la torre no te haga olvidar quién eres."]}
];
(function(){var used={};NP.forEach(function(p){used[p.c]=1;});
 NP.forEach(function(p){p.dir=0;p.cell=[Math.floor(p.x),Math.floor(p.y)];
  if(p.c===PC){var a=p.alt;for(var i=72;i<80;i++){if(i!==PC&&!used[i]){a=i;break;}}used[a]=1;p.c=a;}});})();
/* ---------- colisiones ---------- */
var blk=[];for(var y=0;y<H;y++){blk[y]=[];for(var x=0;x<W;x++)blk[y][x]=0;}
function bl(x0,y0,x1,y1){for(var y=y0;y<=y1;y++)for(var x=x0;x<=x1;x++)if(blk[y]&&x>=0&&x<W)blk[y][x]=1;}
bl(8,0,15,2);                    /* estrado del trono */
bl(2,0,3,0);bl(6,0,6,0);         /* chimenea, librero */
bl(18,0,23,1);bl(23,3,23,3);     /* camas, cofre */
bl(9,5,9,5);bl(9,9,9,9);bl(9,13,9,13);bl(14,5,14,5);bl(14,9,14,9);bl(14,13,14,13); /* pilares */
bl(4,8,7,9);                     /* mesa de guerra */
bl(19,5,21,5);bl(19,7,21,7);bl(19,8,21,8); /* comedor */
bl(2,3,4,3);bl(1,4,1,4);bl(5,3,5,3);       /* mesa norte */
bl(16,15,18,16);                 /* mostrador */
bl(21,13,22,13);bl(22,15,22,15);bl(21,16,21,16); /* armería */
bl(0,1,0,1);bl(0,5,0,6);bl(0,13,0,13);bl(0,16,0,16);
bl(8,3,8,3);bl(15,3,15,3);bl(16,4,16,4);
NP.forEach(function(p){blk[p.cell[1]][p.cell[0]]=1;});
function bfs(a,b){
 if(b.x<0||b.y<0||b.x>=W||b.y>=H||blk[b.y][b.x])return null;
 var q=[a],prev={},k=function(p){return p.x+","+p.y;};prev[k(a)]=null;
 while(q.length){var c=q.shift();if(c.x===b.x&&c.y===b.y)break;
  [[1,0],[-1,0],[0,1],[0,-1]].forEach(function(d){var n={x:c.x+d[0],y:c.y+d[1]};if(n.x<0||n.y<0||n.x>=W||n.y>=H||blk[n.y][n.x]||(k(n) in prev))return;prev[k(n)]=c;q.push(n);});}
 if(!(k(b) in prev))return null;var path=[],c=b;while(c){path.unshift(c);c=prev[k(c)];}path.shift();return path;
}
/* ---------- jugador ---------- */
var P={x:1.7,y:14.8,dir:0,mv:0,path:[],want:null},keys={},tgt=null,near=null;
function cell(){return{x:Math.max(0,Math.min(W-1,Math.floor(P.x))),y:Math.max(0,Math.min(H-1,Math.floor(P.y)))};}
function drawChar(c,x,y,dir,mv,t,lift){
 var im=CI[c];if(!im)return;var fw=CHARS_INFO[c].w,fh=CHARS_INFO[c].h,s=pj(x,y),f=mv?[1,0,1,2][Math.floor(t*8)%4]:1;
 cx.save();cx.translate(s.x,s.y+4);
 cx.fillStyle="rgba(0,0,0,.3)";cx.beginPath();cx.ellipse(0,-(lift||0),fw>40?13:10,4,0,0,7);cx.fill();
 cx.imageSmoothingEnabled=false;cx.drawImage(im,f*fw,dir*fh,fw,fh,-fw/2,-(fh-3)-(lift||0),fw,fh);cx.restore();
}
function mover(dt){
 var dx=0,dy=0;
 if(keys.w||keys.arrowup){dx--;dy--;}if(keys.s||keys.arrowdown){dx++;dy++;}if(keys.a||keys.arrowleft){dx--;dy++;}if(keys.d||keys.arrowright){dx++;dy--;}
 var manual=!!(dx||dy);
 if(manual){P.path=[];tgt=null;P.want=null;var l=Math.hypot(dx,dy);dx/=l;dy/=l;}
 else if(P.path.length){var n=P.path[0],tx=n.x+.5-P.x,ty=n.y+.5-P.y,d=Math.hypot(tx,ty);if(d<.08){P.path.shift();if(!P.path.length)tgt=null;}else{dx=tx/d;dy=ty/d;}}
 P.mv=!!(dx||dy);if(!P.mv)return;P.dir=dirOf(dx,dy);
 var st=SPD*dt,nx=P.x+dx*st,ny=P.y+dy*st;
 if(manual){
  var cxn=Math.floor(nx),cyo=Math.floor(P.y),cxo=Math.floor(P.x),cyn=Math.floor(ny);
  if(cxn>=0&&cxn<W&&cyo>=0&&cyo<H&&blk[cyo][cxn])nx=P.x;
  if(cxo>=0&&cxo<W&&cyn>=0&&cyn<H&&blk[cyn][Math.floor(nx)])ny=P.y;
 }
 P.x=Math.max(.3,Math.min(W-.3,nx));P.y=Math.max(.3,Math.min(H-.3,ny));
}
/* ---------- cámara ---------- */
function camara(dt,snap){
 var s=pj(P.x,P.y),tx=s.x,ty=s.y-34,vw=cv.width/DPR/Z,vh=cv.height/DPR/Z;
 var x0=-(H*TW),x1=W*TW,y0=-WH,y1=(W+H)*TH+14;
 tx=(x1-x0<=vw)?(x0+x1)/2:Math.max(x0+vw/2,Math.min(x1-vw/2,tx));
 ty=(y1-y0<=vh)?(y0+y1)/2:Math.max(y0+vh/2,Math.min(y1-vh/2,ty));
 var k=snap?1:Math.min(1,dt*6);CAMX+=(tx-CAMX)*k;CAMY+=(ty-CAMY)*k;
}
/* ---------- interacción ---------- */
var DIST=3.0;
function abrir(p){
 if(!p)return;keys={};P.path=[];tgt=null;P.want=null;
 if(p.open){if(EMB)parent.postMessage({naradak:"npc",id:p.id},"*");else toast("Abriría: "+p.verbo);return;}
 p.li=p.li||0;var l=p.lines[p.li%p.lines.length];p.li++;toast(p.n+": «"+l+"»",3800);
}
function salir(){keys={};if(EMB)parent.postMessage({naradak:"exit"},"*");else toast("Salida a la ciudad");}
var _tt=0;function toast(t,ms){var e=$("toast");e.textContent=t;e.style.display="block";clearTimeout(_tt);_tt=setTimeout(function(){e.style.display="none";},ms||1800);}
function cerca(){
 near=null;var m=DIST;NP.forEach(function(p){var d=Math.hypot(p.x-P.x,p.y-P.y);if(d<m){m=d;near=p;}});
 NP.forEach(function(p){if(Math.hypot(p.x-P.x,p.y-P.y)<DIST)p.dir=dirOf(P.x-p.x,P.y-p.y);});
 if(P.want&&Math.hypot(P.want.x-P.x,P.want.y-P.y)<DIST-.05){var w=P.want;P.want=null;abrir(w);return;}
 var b=$("bHab");b.style.display=near?"block":"none";if(near)b.textContent="E · "+near.n+" — "+near.verbo;
 if(P.x<.85&&P.y>13.9&&P.y<15.7){salir();P.x=1.7;P.y=14.8;P.path=[];}
}
function irA(p){
 if(Math.hypot(p.x-P.x,p.y-P.y)<DIST-.05){abrir(p);return;}
 var best=null,c0=cell();
 for(var yy=0;yy<H;yy++)for(var xx=0;xx<W;xx++){
  if(blk[yy][xx])continue;var d=Math.hypot(xx+.5-p.x,yy+.5-p.y);if(d>DIST-.05)continue;
  var pa=bfs(c0,{x:xx,y:yy});if(pa&&(!best||pa.length<best.pa.length))best={pa:pa,x:xx,y:yy};}
 if(best){P.path=best.pa;tgt={x:best.x,y:best.y};P.want=p;}
}
$("bHab").onclick=function(){abrir(near);};
addEventListener("keydown",function(e){var k=e.key.toLowerCase();if(k==="e"||k==="enter"){abrir(near);}else if(k==="escape"){salir();}else{keys[k]=1;if(k.indexOf("arrow")===0)e.preventDefault();}});
addEventListener("keyup",function(e){delete keys[e.key.toLowerCase()];});
addEventListener("blur",function(){keys={};});
cv.addEventListener("pointerdown",function(e){
 var r=cv.getBoundingClientRect(),wx=((e.clientX-r.left)-r.width/2)/Z+CAMX,wy=((e.clientY-r.top)-r.height/2)/Z+CAMY;
 var hit=null,bd=34;NP.forEach(function(p){var q=pj(p.x,p.y),hh=CHARS_INFO[p.c].h/2+(p.lift||0),d=Math.hypot(wx-q.x,wy-(q.y-hh));if(d<bd){bd=d;hit=p;}});
 if(hit){irA(hit);return;}
 var u=Math.floor((wy/TH+wx/TW)/2),v=Math.floor((wy/TH-wx/TW)/2);
 var pa=bfs(cell(),{x:u,y:v});if(pa){P.want=null;P.path=pa;tgt={x:u,y:v};}
});
/* ---------- capa estática ---------- */
var SX0=-(H*TW)-30,SY0=-WH-40,SW=(W+H)*TW+60,SH=(W+H)*TH+WH+80,STAT=null;
function seed(s){return function(){s|=0;s=s+0x6D2B79F5|0;var t=Math.imul(s^s>>>15,1|s);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296;};}
function banner(g,u0,w,y0,h,col){
 col=col||["#26468c","#17306a"];
 g.fillStyle="#2a170a";g.fillRect(u0-.1,y0-5,w+.2,4);
 g.fillStyle="#c9923c";g.fillRect(u0-.05,y0-3,w+.1,1.2);
 g.beginPath();g.moveTo(u0,y0);g.lineTo(u0+w,y0);g.lineTo(u0+w,y0+h);g.lineTo(u0+w/2,y0+h-12);g.lineTo(u0,y0+h);g.closePath();
 var gd=g.createLinearGradient(0,y0,0,y0+h);gd.addColorStop(0,col[0]);gd.addColorStop(1,col[1]);g.fillStyle=gd;g.fill();
 g.fillStyle="#c9923c";g.fillRect(u0,y0,.035,h-5);g.fillRect(u0+w-.035,y0,.035,h-5);
 g.fillStyle="#e8c46a";g.beginPath();g.ellipse(u0+w/2,y0+h*.36,.2,8,0,0,7);g.fill();
 g.fillStyle=col[1];g.beginPath();g.ellipse(u0+w/2,y0+h*.36,.13,5,0,0,7);g.fill();
 g.fillStyle="#e8c46a";g.fillRect(u0+w/2-.03,y0+h*.36-6,.06,12);g.fillRect(u0+w/2-.12,y0+h*.36-2,.24,1.6);
}
function tapiz(g,u0,w,y0,h){
 g.fillStyle="#2a170a";g.fillRect(u0-.12,y0-8,w+.24,7);g.fillStyle="#c9923c";g.fillRect(u0-.08,y0-5,w+.16,2);
 var gd=g.createLinearGradient(0,y0,0,y0+h);gd.addColorStop(0,"#7a1822");gd.addColorStop(1,"#4a0e16");g.fillStyle=gd;g.fillRect(u0,y0,w,h);
 g.strokeStyle="#c9923c";g.lineWidth=2;g.strokeRect(u0+.1,y0+6,w-.2,h-12);
 g.fillStyle="#c9923c";for(var i=0;i<12;i++){g.fillRect(u0+i*w/12,y0+h,.05,9);}
 var mx=u0+w/2,my=y0+h*.46;
 g.fillStyle="#e8c46a";g.beginPath();g.ellipse(mx,my,.55,22,0,0,7);g.fill();
 g.fillStyle="#7a1822";g.beginPath();g.ellipse(mx,my,.4,16,0,0,7);g.fill();
 g.fillStyle="#e8c46a";g.fillRect(mx-.05,my-26,.1,52);g.fillRect(mx-.34,my-4,.68,4);
 g.beginPath();g.moveTo(mx-.05,my-26);g.lineTo(mx,my-34);g.lineTo(mx+.05,my-26);g.fill();
 for(var s=-1;s<=1;s+=2){g.beginPath();g.moveTo(mx+s*.62,my-10);g.lineTo(mx+s*1.4,my-24);g.lineTo(mx+s*1.1,my+2);g.lineTo(mx+s*.62,my+6);g.fill();}
}
function ventana(g,u0,w,yt,h){
 var r=w/2,ry=r*TW,yb=yt+h;
 function arco(a,b,c,d){g.beginPath();g.moveTo(a,yb);g.lineTo(a,yt+ry);g.ellipse(a+(c-a)/2,yt+ry,(c-a)/2,ry+(b?0:0)+d,0,Math.PI,0);g.lineTo(c,yb);g.closePath();}
 arco(u0-.09,0,u0+w+.09,3);g.fillStyle="#9d978b";g.fill();
 arco(u0,0,u0+w,0);var gd=g.createLinearGradient(0,yt,0,yb);gd.addColorStop(0,"#2c4066");gd.addColorStop(1,"#141c30");g.fillStyle=gd;g.fill();
 g.save();arco(u0,0,u0+w,0);g.clip();
 g.fillStyle="rgba(150,180,235,.22)";g.fillRect(u0,yt,w,h*.35);
 g.fillStyle="#2a2620";g.fillRect(u0+r-.025,yt,.05,h);g.fillRect(u0,yt+h*.42,w,2.5);g.fillRect(u0,yt+h*.7,w,2.5);
 g.restore();
 g.fillStyle="#7d776c";g.fillRect(u0-.13,yb,w+.26,5);g.fillStyle="rgba(255,235,200,.25)";g.fillRect(u0-.13,yb,w+.26,1);
}
function box(g,x0,y0,x1,y1,z0,z1,cT,cL,cR){
 function P3(x,y,z){var p=pj(x,y);return[p.x,p.y-z];}
 function poly(a,col){g.beginPath();a.forEach(function(p,i){i?g.lineTo(p[0],p[1]):g.moveTo(p[0],p[1]);});g.closePath();g.fillStyle=col;g.fill();}
 poly([P3(x0,y1,z0),P3(x1,y1,z0),P3(x1,y1,z1),P3(x0,y1,z1)],cL);
 poly([P3(x1,y0,z0),P3(x1,y1,z0),P3(x1,y1,z1),P3(x1,y0,z1)],cR);
 poly([P3(x0,y0,z1),P3(x1,y0,z1),P3(x1,y1,z1),P3(x0,y1,z1)],cT);
 g.strokeStyle="rgba(255,225,170,.35)";g.lineWidth=1;g.beginPath();var a=P3(x0,y1,z1),b=P3(x1,y1,z1),c=P3(x1,y0,z1);g.moveTo(a[0],a[1]);g.lineTo(b[0],b[1]);g.lineTo(c[0],c[1]);g.stroke();
}
function construir(){
 var K=2,c=document.createElement("canvas");c.width=SW*K;c.height=SH*K;var g=c.getContext("2d");
 g.scale(K,K);g.translate(-SX0,-SY0);g.imageSmoothingEnabled=true;
 var R=seed(137);
 /* suelo de losas */
 g.save();g.transform(TW,TH,-TW,TH,0,0);
 var pal=["#6d675d","#78715f","#625d55","#706a64","#7a7467","#5f5a52","#74706a"];
 for(var y=0;y<H;y++)for(var x=0;x<W;x++){
  g.fillStyle=pal[Math.floor(R()*pal.length)];g.fillRect(x,y,1,1);
  if((x+y)%2===0){g.fillStyle="rgba(0,0,0,.07)";g.fillRect(x,y,1,1);}
  var cut=.3+R()*.4,hz=R()<.5;g.fillStyle="rgba(0,0,0,.30)";
  if(hz)g.fillRect(x,y+cut,1,.045);else g.fillRect(x+cut,y,.045,1);
  g.fillStyle="rgba(255,235,200,"+(.03+R()*.05)+")";g.fillRect(x+.05,y+.05,.9,.4);
  for(var n=0;n<3;n++){g.fillStyle="rgba(0,0,0,"+(.04+R()*.06)+")";g.fillRect(x+R(),y+R(),.06+R()*.12,.04);}
 }
 g.strokeStyle="rgba(10,8,6,.55)";g.lineWidth=.05;
 for(var i=0;i<=W;i++){g.beginPath();g.moveTo(i,0);g.lineTo(i,H);g.stroke();}
 for(var j=0;j<=H;j++){g.beginPath();g.moveTo(0,j);g.lineTo(W,j);g.stroke();}
 function alfombra(x0,y0,w,h,base,borde){
  g.fillStyle=base;g.fillRect(x0,y0,w,h);
  g.strokeStyle=borde;g.lineWidth=.08;g.strokeRect(x0+.15,y0+.15,w-.3,h-.3);
  g.strokeStyle="rgba(201,146,60,.55)";g.lineWidth=.03;g.strokeRect(x0+.35,y0+.35,w-.7,h-.7);
 }
 alfombra(10.5,3,3,H-3,"#7a1822","#c9923c");              /* pasillo real */
 alfombra(.15,14.15,10.4,1.3,"#7a1822","#c9923c");        /* felpudo a la puerta */
 g.fillStyle="#7a1822";g.fillRect(10.5,14.15,3,1.3);
 alfombra(3.1,6.3,5.8,4.3,"#1d3a78","#c9923c");           /* alfombra de guerra */
 alfombra(17.1,3.6,5.8,6.2,"#3d2a14","#c9923c");          /* comedor */
 g.fillStyle="rgba(201,146,60,.4)";
 for(var q=0;q<4;q++){g.beginPath();g.arc(12,5.2+q*3.3,.55,0,7);g.fill();}
 g.strokeStyle="rgba(201,146,60,.7)";g.lineWidth=.05;for(var q2=0;q2<4;q2++){g.beginPath();g.arc(12,5.2+q2*3.3,.38,0,7);g.stroke();}
 var gr=g.createLinearGradient(0,0,0,1.6);gr.addColorStop(0,"rgba(0,0,0,.5)");gr.addColorStop(1,"rgba(0,0,0,0)");g.fillStyle=gr;g.fillRect(0,0,W,1.6);
 var gl=g.createLinearGradient(0,0,1.6,0);gl.addColorStop(0,"rgba(0,0,0,.5)");gl.addColorStop(1,"rgba(0,0,0,0)");g.fillStyle=gl;g.fillRect(0,0,1.6,H);
 g.restore();
 /* paredes de piedra */
 function pared(len,shade){
  var gp=g.createLinearGradient(0,-WH,0,0);gp.addColorStop(0,"rgb("+Math.round(112*shade)+","+Math.round(108*shade)+","+Math.round(104*shade)+")");gp.addColorStop(1,"rgb("+Math.round(150*shade)+","+Math.round(144*shade)+","+Math.round(134*shade)+")");
  g.fillStyle=gp;g.fillRect(0,-WH,len,WH);
  var rows=Math.ceil(WH/13);
  for(var row=0;row<rows;row++){
   var yy=-WH+row*13,off=(row%2)*.5,u=-off;
   while(u<len){var bw=.7+R()*.5;
    g.fillStyle="rgba("+(R()<.5?"0,0,0":"255,240,210")+","+(.04+R()*.07)+")";g.fillRect(Math.max(0,u)+.02,yy+1,Math.min(bw,len-Math.max(0,u))-.04,11);
    g.fillStyle="rgba(20,16,12,.45)";g.fillRect(Math.max(0,u),yy,.035,13);
    u+=bw;}
   g.fillStyle="rgba(20,16,12,.45)";g.fillRect(0,yy,len,1);
  }
  g.fillStyle="rgba(15,12,10,"+(.30+(1-shade)*.4)+")";g.fillRect(0,-40,len,40);
  g.fillStyle="#2e1a0a";g.fillRect(0,-43,len,4);g.fillStyle="rgba(255,210,140,.25)";g.fillRect(0,-43,len,1);
  g.fillStyle="#2a170a";g.fillRect(0,-4,len,4);
  g.fillStyle="#3b2412";g.fillRect(0,-WH,len,10);g.fillStyle="rgba(255,210,140,.18)";g.fillRect(0,-WH,len,1.5);
  g.fillStyle="#2e1a0a";g.fillRect(0,-WH+10,len,3);
  for(var b=0;b<=len;b+=4){g.fillStyle="#3b2412";g.fillRect(b-.12,-WH,.24,WH);g.fillStyle="rgba(255,210,140,.14)";g.fillRect(b-.12,-WH,.04,WH);}
  g.fillStyle="#2e1a0a";g.fillRect(len-.24,-WH,.24,WH);
 }
 /* NE (y=0) */
 g.save();g.transform(TW,TH,0,1,0,0);pared(W,1);
 banner(g,.45,.85,-125,80);
 ventana(g,4.3,1.0,-130,80);
 banner(g,7.15,.8,-125,80);
 tapiz(g,9.4,5.2,-138,108);
 banner(g,16.4,.8,-125,80);
 ventana(g,18.4,1.0,-130,80);
 banner(g,20.0,.85,-125,80);
 ventana(g,21.8,1.0,-130,80);
 g.restore();
 /* NW (x=0) */
 g.save();g.transform(TW,-TH,0,1,0,0);g.save();g.translate(-H,0);pared(H,.80);g.restore();
 ventana(g,-2.6,1.0,-130,80);
 banner(g,-5.0,.85,-125,80);
 ventana(g,-8.7,1.0,-130,80);
 banner(g,-11.0,.85,-125,80);
 ventana(g,-12.9,1.0,-130,80);
 banner(g,-17.4,.85,-125,80);
 /* puerta del castillo (arco de piedra) */
 (function(){var u0=-15.6,w=1.6,h=104,r=w/2,ry=r*TW;
  function arco(a,c,hh,d){g.beginPath();g.moveTo(a,0);g.lineTo(a,-hh+ry);g.ellipse(a+(c-a)/2,-hh+ry,(c-a)/2,ry+d,0,Math.PI,0);g.lineTo(c,0);g.closePath();}
  arco(u0-.14,u0+w+.14,h+6,4);g.fillStyle="#9d978b";g.fill();
  arco(u0,u0+w,h,0);var gd=g.createLinearGradient(0,-h,0,0);gd.addColorStop(0,"#5a3818");gd.addColorStop(1,"#3a2410");g.fillStyle=gd;g.fill();
  g.save();arco(u0,u0+w,h,0);g.clip();
  g.fillStyle="rgba(0,0,0,.3)";for(var i=1;i<6;i++)g.fillRect(u0+i*w/6,-h,.03,h);
  g.fillStyle="#2a2a2e";g.fillRect(u0,-h*.62,w,4);g.fillRect(u0,-h*.28,w,4);g.fillRect(u0+w/2-.02,-h,.04,h);
  g.restore();
  g.fillStyle="#c9923c";g.beginPath();g.ellipse(u0+w*.78,-h*.4,.07,2.6,0,0,7);g.fill();
 })();
 g.restore();
 g.fillStyle="#2a170a";g.fillRect(-2,-WH,4,WH);
 /* estrado del trono */
 box(g,8,0,16,3.2,0,8,"#8a8478","#5e594f","#46423a");
 box(g,9,0,15,2.5,8,16,"#9a9488","#6a6559","#4f4a41");
 g.save();g.translate(0,-8);g.transform(TW,TH,-TW,TH,0,0);g.fillStyle="#7a1822";g.fillRect(11,2.5,2,.7);g.restore();
 g.save();g.translate(0,-16);g.transform(TW,TH,-TW,TH,0,0);g.fillStyle="#7a1822";g.fillRect(10.5,0,3,2.5);g.strokeStyle="#c9923c";g.lineWidth=.06;g.strokeRect(10.6,.1,2.8,2.3);g.restore();
 /* trono */
 box(g,11.1,.4,11.4,1.4,16,40,"#c9923c","#8a5a22","#5e3c14");
 box(g,12.6,.4,12.9,1.4,16,40,"#c9923c","#8a5a22","#5e3c14");
 box(g,11.1,.3,12.9,.7,16,66,"#e0b256","#9a2430","#6a1620");
 box(g,11.4,.7,12.6,1.5,16,26,"#b02a38","#8a1e2c","#5e1420");
 g.fillStyle="#e8c46a";(function(){var p=pj(12,.7);g.beginPath();g.arc(p.x,p.y-48,6,0,7);g.fill();g.fillStyle="#9a2430";g.beginPath();g.arc(p.x,p.y-48,3.5,0,7);g.fill();})();
 STAT=c;
}
/* ---------- objetos ordenados ---------- */
function spr(k,x,y,s,dy,mir){
 var im=IM[k],p=pj(x,y);cx.save();cx.translate(p.x,p.y+8+(dy||0));if(mir)cx.scale(-1,1);
 cx.drawImage(im,-im.width*s/2,-im.height*s,im.width*s,im.height*s);cx.restore();
}
function pilar(x,y){
 var a=x+.5,b=y+.5,C=["#8d877b","#6a6559","#4f4a41"],S=["#9b9588","#7a7467","#585246"];
 box(cx,a-.34,b-.34,a+.34,b+.34,0,9,C[0],C[1],C[2]);
 box(cx,a-.22,b-.22,a+.22,b+.22,9,98,S[0],S[1],S[2]);
 cx.strokeStyle="rgba(20,16,12,.35)";cx.lineWidth=1;
 for(var z=22;z<98;z+=14){var p1=pj(a-.22,b+.22),p2=pj(a+.22,b+.22),p3=pj(a+.22,b-.22);cx.beginPath();cx.moveTo(p1.x,p1.y-z);cx.lineTo(p2.x,p2.y-z);cx.lineTo(p3.x,p3.y-z);cx.stroke();}
 box(cx,a-.34,b-.34,a+.34,b+.34,98,108,C[0],C[1],C[2]);
}
function lista(){
 var L=[];
 function S(x,y,k,s,dy,m){L.push({k:x+y,f:function(){spr(k,x,y,s,dy,m);}});}
 S(3.0,.78,"chimenea",1.25);
 S(6.4,.62,"librero",1.5);
 S(8.2,.45,"antorcha",1.4,-62);S(15.8,.45,"antorcha",1.4,-62);
 S(.45,2.0,"antorcha",1.4,-62,1);S(.45,11.0,"antorcha",1.4,-62,1);S(.45,17.2,"antorcha",1.4,-62,1);
 [[9,5],[9,9],[9,13],[14,5],[14,9],[14,13]].forEach(function(p){L.push({k:p[0]+p[1]+1,f:function(){pilar(p[0],p[1]);}});});
 S(8.5,3.5,"brasero",1.5);S(15.5,3.5,"brasero",1.5);
 S(.9,13.5,"brasero",1.5);S(.9,16.5,"brasero",1.5);
 S(6.2,9.0,"mesa_guerra",.66);
 S(19.0,1.9,"cama",1.0);S(21.9,1.9,"cama",1.0);S(23.0,3.5,"cofre",.8);
 S(3.6,3.6,"mesa",1.2);S(1.7,4.8,"taburete",1.0);S(5.4,4.2,"taburete",1.0);
 S(20.1,5.7,"banco",.9);S(20.1,7.6,"mesa",1.4);S(20.1,8.8,"banco",.9);
 S(17.2,16.7,"mostrador",1.0);
 S(21.2,13.8,"barril",1.0);S(22.4,14.0,"barril",1.0);S(22.6,15.8,"caja",1.0);S(21.2,16.9,"cofre",.9);
 S(16.0,4.9,"jarron",1.0);S(7.8,4.0,"jarron",1.0);
 S(.8,1.9,"cofre",.8,0,1);
 S(.62,6.6,"tablon",1.35);
 NP.forEach(function(p){L.push({k:p.x+p.y,f:function(){drawChar(p.c,p.x,p.y,p.dir,0,T,p.lift);}});});
 L.push({k:0,pl:1});
 return L;
}
var OBJ=null;
/* ---------- dibujo ---------- */
function etiqueta(txt,x,y,hl){cx.save();cx.font="700 "+(hl?11:10)+"px Cinzel,serif";cx.textAlign="center";cx.lineWidth=3;cx.strokeStyle="rgba(20,12,4,.9)";cx.strokeText(txt,x,y);cx.fillStyle=hl?"#ffe9a8":"#f5e6c0";cx.fillText(txt,x,y);cx.restore();}
function marcadores(t){
 NP.forEach(function(p){
  var s=pj(p.x,p.y),bob=Math.sin(t*3+p.x)*2,hl=near===p,top=CHARS_INFO[p.c].h+(p.lift||0);
  cx.save();cx.translate(s.x,s.y);
  cx.font="16px serif";cx.textAlign="center";cx.fillText(p.ico,0,-top-8+bob);
  if(hl){etiqueta(p.n,0,-top-24);cx.font="10px Karla,sans-serif";cx.fillStyle="#d4c9b8";cx.lineWidth=3;cx.strokeStyle="rgba(20,12,4,.9)";cx.strokeText(p.r,0,-top-34);cx.fillText(p.r,0,-top-34);}
  cx.restore();
 });
 var d=pj(0,14.8);cx.save();cx.translate(d.x,d.y-122);etiqueta("Salida",0,0,P.x<2.2&&P.y>13.6);cx.restore();
}
function luces(t){
 cx.save();cx.setTransform(1,0,0,1,0,0);cx.fillStyle="rgba(10,14,30,.2)";cx.fillRect(0,0,cv.width,cv.height);cx.restore();
 cx.globalCompositeOperation="lighter";
 var fl=.85+.15*Math.sin(t*9)+.06*Math.sin(t*23);
 function glow(x,y,z,r,a,rgb){var s=pj(x,y),g=cx.createRadialGradient(s.x,s.y-z,2,s.x,s.y-z,r);g.addColorStop(0,"rgba("+rgb+","+(a*fl)+")");g.addColorStop(1,"rgba("+rgb+",0)");cx.fillStyle=g;cx.fillRect(s.x-r,s.y-z-r,r*2,r*2);}
 glow(3.0,1.2,30,190,.45,"255,150,50");
 glow(8.2,.8,60,120,.32,"255,180,80");glow(15.8,.8,60,120,.32,"255,180,80");
 glow(8.5,3.6,40,100,.3,"255,170,70");glow(15.5,3.6,40,100,.3,"255,170,70");
 glow(.9,13.6,40,100,.3,"255,170,70");glow(.9,16.6,40,100,.3,"255,170,70");
 glow(.5,2.0,60,100,.25,"255,180,80");glow(.5,11.0,60,100,.25,"255,180,80");glow(.5,17.2,60,100,.25,"255,180,80");
 glow(12,2.5,60,170,.18,"255,200,120");glow(6,8,50,160,.15,"255,200,120");glow(20,7,50,140,.14,"255,200,120");
 [[4.8,.5],[19.0,.5],[22.3,.5],[.5,2.1],[.5,8.2],[.5,12.4]].forEach(function(w){glow(w[0],w[1],95,90,.13,"140,170,230");});
 cx.globalCompositeOperation="source-over";
}
function draw(t){
 var w=cv.width,h=cv.height;cx.setTransform(1,0,0,1,0,0);cx.fillStyle="#12100c";cx.fillRect(0,0,w,h);
 cx.setTransform(Z*DPR,0,0,Z*DPR,w/2-CAMX*Z*DPR,h/2-CAMY*Z*DPR);
 cx.imageSmoothingEnabled=true;cx.drawImage(STAT,SX0,SY0,SW,SH);
 if(tgt){var s=pj(tgt.x+.5,tgt.y+.5);cx.strokeStyle="rgba(232,200,120,"+(.5+.4*Math.sin(t*6))+")";cx.lineWidth=2;cx.beginPath();cx.moveTo(s.x,s.y-8);cx.lineTo(s.x+16,s.y);cx.lineTo(s.x,s.y+8);cx.lineTo(s.x-16,s.y);cx.closePath();cx.stroke();}
 var L=OBJ.slice();L.forEach(function(o){if(o.pl)o.k=P.x+P.y;});L.sort(function(a,b){return a.k-b.k;});
 L.forEach(function(o){if(o.pl)drawChar(PC,P.x,P.y,P.dir,P.mv,T);else o.f();});
 luces(t);marcadores(t);
}
/* ---------- arranque ---------- */
function resize(){
 DPR=Math.min(2,devicePixelRatio||1);cv.width=innerWidth*DPR;cv.height=innerHeight*DPR;
 Z=Math.max(.75,Math.min(1.5,innerWidth/760));
}
addEventListener("resize",resize);resize();
var keysA=Object.keys(CASASSETS),pend=keysA.length+CHARS.length;
function ok(){if(--pend===0)iniciar();}
keysA.forEach(function(k){var im=new Image();im.onload=ok;im.src=CASASSETS[k];IM[k]=im;});
CHARS.forEach(function(d,i){var im=new Image();im.onload=ok;im.src=d;CI[i]=im;});
function iniciar(){
 construir();OBJ=lista();camara(0,true);
 if(EMB)parent.postMessage({naradak:"ready"},"*");
 var last=performance.now();
 (function loop(now){var dt=Math.min(.05,(now-last)/1000);last=now;T+=dt;
  mover(dt);cerca();camara(dt,false);draw(T);requestAnimationFrame(loop);})(last);
}
})();
