"use strict";
/* THE CHRONICLES OF NARADAK — Mundo Abierto 2.5D (292x292 celdas). Requiere assets.js y chars.js 
   · Sector central = Claro del Campamento (aparición de quienes salen a explorar con el General Varek).
   · Los CAMINOS terminan en PUERTAS DE PIEDRA que enlazan con otra parte del mapa (teletransporte entre sectores).
   · Generación determinista (semilla fija): todos los jugadores ven el mismo mundo.
   · Online: ?online=1 -> lugar "mundo" en el WebSocket /ws del servidor local. */
var Mundo={onExit:null};
(function(){
var GN=5,S=88,B=8,M=6,W=M*2+S*GN+B*(GN-1),H=W,N=W*H,TW=64,TH=32,SPD=4.4,MIN_S=5.6,IMG={},CIMG=[];
var cv=document.getElementById("mapa"),cx=cv.getContext("2d"),$=function(i){return document.getElementById(i);};
/* ---------- utilidades ---------- */
function rng(s){return function(){s|=0;s=s+0x6D2B79F5|0;var t=Math.imul(s^s>>>15,1|s);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296;};}
var R=rng(90210);function ri(n){return Math.floor(R()*n);}
var DX=[1,0,-1,0],DY=[0,1,0,-1];
function I(x,y){return y*W+x;}
function inb(x,y){return x>=0&&y>=0&&x<W&&y<H;}
function pj(x,y){return{x:(x-y)*TW/2,y:(x+y)*TH/2};}
function OX(k){return M+k*(S+B);}
function hash(x,y,s){var h=Math.imul(x,374761393)+Math.imul(y,668265263)+Math.imul(s,1274126177);h=Math.imul(h^(h>>>13),1274126177);return((h^(h>>>16))>>>0)/4294967296;}
function vn(x,y,sc,s){var gx=x/sc,gy=y/sc,x0=Math.floor(gx),y0=Math.floor(gy),fx=gx-x0,fy=gy-y0;fx=fx*fx*(3-2*fx);fy=fy*fy*(3-2*fy);
 var a=hash(x0,y0,s),b=hash(x0+1,y0,s),c=hash(x0,y0+1,s),d=hash(x0+1,y0+1,s);return a+(b-a)*fx+(c-a)*fy+(a-b-c+d)*fx*fy;}
function rgba(h,a){var n=parseInt(h.slice(1),16);return"rgba("+(n>>16)+","+((n>>8)&255)+","+(n&255)+","+a+")";}
/* ---------- sectores ---------- */
/* Plano del mundo abierto (cuadrícula 5x5, Home = campamento en la esquina superior izquierda):
     Home  2  3  9 10
       1   4  8 11 18
       5   7 12 17 19
       6  13 16 20 23
      14  15 21 22 24
   Para construir un sector nuevo: defSec(columna,fila,{...}) y listo; las puertas/caminos con sus vecinos se generan solas. */
var SECID=[[0,2,3,9,10],[1,4,8,11,18],[5,7,12,17,19],[6,13,16,20,23],[14,15,21,22,24]];
function SK(c,r){return r*GN+c;}
var TM={};
for(var r0=0;r0<GN;r0++)for(var c0=0;c0<GN;c0++)TM[SK(c0,r0)]={id:SECID[r0][c0],c:c0,r:r0,built:0,n:"sin explorar",col:"#8a8a8a"};
/* ---------- DIFICULTAD POR SECTOR (multiplicadores) ----------
   Cada sector construido lleva un objeto dif (opción "dif" de defSec). Se ve en el minimapa (color + cifras) y en el HUD.
     vida  = vida de los monstruos        dano = daño de los monstruos        def = defensa (se calcula de vida)
     cant  = cantidad de monstruos        rec  = XP y botín (oro) por muerte
     agro  = radio de detección           vel  = velocidad de movimiento
     pe    = "piso equivalente" base de las stats (1 = piso 1 del Bosque de Silverleaf)
   Si un sector nuevo no define "dif", se calcula con difAuto(id): cuanto mayor el número de sector, más difícil. */
function difAuto(id){var n=Math.max(0,id-1);return{vida:+(1.6+n*.25).toFixed(2),dano:+(1.4+n*.2).toFixed(2),cant:+Math.min(2,1+n*.05).toFixed(2),rec:+(1.5+n*.25).toFixed(2),agro:+Math.min(1.6,1+n*.03).toFixed(2),vel:+Math.min(1.25,1+n*.01).toFixed(2),pe:1+id*2};}
function difNorm(t){var d=t.dif||difAuto(t.id),a=difAuto(t.id);for(var k in a)if(d[k]==null)d[k]=a[k];t.dif=d;}
function defSec(c,r,o){var t=TM[SK(c,r)];for(var k in o)t[k]=o[k];t.built=1;difNorm(t);}
function nomSec(k){var t=TM[k];return t.id===0?t.n:"Sector "+t.id+" · "+t.n;}
var DIRS=[{n:"N",dx:0,dy:-1,o:"S"},{n:"E",dx:1,dy:0,o:"W"},{n:"S",dx:0,dy:1,o:"N"},{n:"W",dx:-1,dy:0,o:"E"}];
defSec(0,0,{n:"Claro del Campamento",dn:.21,dark:.08,core:"camp",ru:3,col:"#e8c9a0",tr:[0,1,2,4,5,7,8,3],
 dif:{vida:1,dano:1,cant:.5,rec:1,agro:.8,vel:1,pe:1}});            /* Home */
defSec(0,1,{n:"Bosque del Camino Viejo",dn:.27,dark:.35,core:"fortress_t",ru:5,col:"#7fbf6a",tr:[3,0,9,2,4,5,7,1],
 dif:{vida:2,dano:1.4,cant:1,rec:1.5,agro:1,vel:1.05,pe:3}});     /* Sector 1 */
defSec(1,0,{n:"Aldea Abandonada de los Vigías",dn:.23,dark:.3,core:"aldea",ru:7,col:"#6fb0a0",tr:[3,0,9,2,4,5,7,1],
 dif:{vida:1.85,dano:1.6,cant:1.3,rec:1.75,agro:1.05,vel:1.04,pe:5}});  /* Sector 2 */
defSec(2,0,{n:"Necrópolis de los Olvidados",dn:.2,dark:.6,core:"necropolis",ru:6,col:"#9a86c4",tr:[3,9,2,6,8,4],
 dif:{vida:4,dano:3,cant:1.5,rec:2,agro:1.1,vel:1.08,pe:7}});     /* Sector 3 */
defSec(1,1,{n:"Ciudadela Quebrada",dn:.22,dark:.42,core:"ciudadela",ru:7,col:"#d4965a",tr:[2,4,5,7,8,3,6],
 dif:{vida:6,dano:4,cant:1.7,rec:2.25,agro:1.15,vel:1.1,pe:9}});     /* Sector 4 */
defSec(0,2,{n:"Santuario de los Peregrinos Caídos",dn:.2,dark:.5,core:"santuario",ru:7,col:"#7fa3c9",tr:[6,4,2,8,5,7,3],
 dif:{vida:8,dano:5,cant:1.85,rec:2.5,agro:1.2,vel:1.12,pe:11}});     /* Sector 5 */
defSec(0,3,{n:"Cantera de los Gigantes Caídos",dn:.18,dark:.55,core:"cantera",ru:8,col:"#a89c8a",tr:[6,8,9,4,7],
 dif:{vida:10,dano:6,cant:1.95,rec:2.75,agro:1.25,vel:1.14,pe:13}});     /* Sector 6 */
defSec(1,2,{n:"Catedral Hundida",dn:.2,dark:.5,core:"catedral",ru:8,col:"#c9b5e0",tr:[3,6,9,2,5],
 dif:{vida:12,dano:7,cant:2.05,rec:3,agro:1.3,vel:1.16,pe:15}});     /* Sector 7 */
defSec(2,1,{n:"Bastión de los Reyes Olvidados",dn:.19,dark:.58,core:"bastion",ru:9,col:"#c46a5a",tr:[8,9,6,7,4],
 dif:{vida:14,dano:8,cant:2.15,rec:3.25,agro:1.35,vel:1.18,pe:17}});     /* Sector 8 */
/* ---------- datos del mundo ---------- */
var blk=new Uint8Array(N),road=new Uint8Array(N),keep=new Uint8Array(N),verge=new Uint8Array(N),sec=new Int8Array(N).fill(-1),tiles=new Array(N);
var OB=[],GATES=[],DECALS=[],NPC=[],POLY={},EXITS=[];
var CC={x:OX(0)+S/2,y:OX(0)+S/2};   /* centro del campamento (Home) */
for(var sy0=0;sy0<GN;sy0++)for(var sx0=0;sx0<GN;sx0++){var k0=SK(sx0,sy0),th=TM[k0];
 for(var y=OX(sy0);y<OX(sy0)+S;y++)for(var x=OX(sx0);x<OX(sx0)+S;x++){var i=I(x,y);
  if(th.built){sec[i]=k0;tiles[i]=R()<th.dark?"d"+ri(5):"g"+(R()<.55?ri(3):ri(16));}
  else{sec[i]=-2;tiles[i]=null;blk[i]=1;}}}      /* -2 = sector aún sin construir (vacío infranqueable) */
function cercaBuilt(x,y){for(var b=-9;b<=9;b+=3)for(var a=-9;a<=9;a+=3){var X=x+a,Y=y+b;if(inb(X,Y)&&sec[I(X,Y)]>=0)return true;}return false;}
/* Mapa abierto: el cinturón entre dos sectores construidos (y el cruce de cuatro si hay 3 o más) es terreno transitable y pasa a pertenecer al sector más cercano;
   el resto (borde del mundo y lado de sectores sin construir) sigue siendo bosque infranqueable. */
var BELT=[];
function bBuilt(c,r){return c>=0&&r>=0&&c<GN&&r<GN&&!!TM[SK(c,r)].built;}
function cinturonDe(x,y){
 var P=S+B,ux=x-M,uy=y-M;if(ux<0||uy<0)return -1;
 var c=Math.floor(ux/P),r=Math.floor(uy/P),fx=ux-c*P,fy=uy-r*P,cs=fx<S?[c]:[c,c+1],rs=fy<S?[r]:[r,r+1],L=[],bs=0,best=-1,bd=1e9;
 cs.forEach(function(a){rs.forEach(function(b){if(a>=0&&b>=0&&a<GN&&b<GN)L.push([a,b]);});});
 if(L.length<2)return -1;
 L.forEach(function(q){if(bBuilt(q[0],q[1])){bs++;var d=Math.hypot(x-(OX(q[0])+S/2),y-(OX(q[1])+S/2));if(d<bd){bd=d;best=SK(q[0],q[1]);}}});
 return (L.length===2?bs===2:bs>=3)?best:-1;}
for(var i=0;i<N;i++){if(sec[i]===-1){var ob=cinturonDe(i%W,(i/W)|0);
 if(ob>=0){var bx=i%W,by=(i/W)|0;sec[i]=ob;blk[i]=0;BELT.push(i);tiles[i]=hash(bx,by,77)<TM[ob].dark?"d"+Math.floor(hash(bx,by,78)*5):"g"+Math.floor(hash(bx,by,79)*16);}
 else{blk[i]=1;tiles[i]=cercaBuilt(i%W,(i/W)|0)?"g"+ri(16):null;}}}
function libre(x,y){if(!inb(x,y))return false;var i=I(x,y);return !blk[i]&&!road[i]&&sec[i]>=0;}
function libreN(x,y,w,h){for(var b=0;b<h;b++)for(var a=0;a<w;a++)if(!libre(x+a,y+b))return false;return true;}
function put(n,x,y,o){o=o||{};o.i=n;o.cx=x+.5;o.cy=y+.5;OB.push(o);if(inb(x,y)&&!o.nb)blk[I(x,y)]=1;return o;}
function putBig(n,x,y,w,h,o){o=o||{};o.i=n;o.cx=x+w/2;o.cy=y+h/2;o.fx=x;o.fy=y;o.fw=w;o.fh=h;OB.push(o);
 for(var b=0;b<h;b++)for(var a=0;a<w;a++)if(inb(x+a,y+b))blk[I(x+a,y+b)]=1;return o;}
function dec(n,x,y,o){o=o||{};o.i=n;o.cx=x+.2+R()*.6;o.cy=y+.2+R()*.6;o.nb=1;OB.push(o);return o;}
function suelo(x,y,t){if(inb(x,y)&&sec[I(x,y)]>=0)tiles[I(x,y)]=t;}
function piso(x0,y0,x1,y1,p){for(var y=y0;y<=y1;y++)for(var x=x0;x<=x1;x++)if(inb(x,y)&&sec[I(x,y)]>=0&&R()<p)tiles[I(x,y)]="p"+ri(8);}
function despeja(x,y,r,t){for(var b=-r;b<=r;b++)for(var a=-r;a<=r;a++){if(a*a+b*b>r*r+1)continue;var X=x+a,Y=y+b;if(!inb(X,Y)||sec[I(X,Y)]<0)continue;keep[I(X,Y)]=1;if(t&&!road[I(X,Y)]&&R()<.8)tiles[I(X,Y)]=t==="e"?"e"+ri(3):"p"+ri(8);}}
/* ---------- caminos ---------- */
function carve(a,b,wd,sk){
 var dx=b.x-a.x,dy=b.y-a.y,len=Math.max(1,Math.hypot(dx,dy)),n=Math.ceil(len*1.3),nx=-dy/len,ny=dx/len,A1=2+len*.045,A2=1.1,f1=1.5+R()*2.5,f2=5+R()*4,p1=R()*6.28,p2=R()*6.28,pts=[];
 var ox=OX(sk%GN),oy=OX((sk/GN)|0);
 for(var k=0;k<=n;k++){var t=k/n,off=(Math.sin(t*f1*Math.PI+p1)*A1+Math.sin(t*f2*Math.PI+p2)*A2)*Math.min(1,Math.min(t,1-t)*5);
  var px=a.x+dx*t+nx*off,py=a.y+dy*t+ny*off;px=Math.max(ox+4,Math.min(ox+S-5,px));py=Math.max(oy+4,Math.min(oy+S-5,py));pts.push({x:px,y:py});
  var X0=Math.floor(px-wd-2),X1=Math.ceil(px+wd+2),Y0=Math.floor(py-wd-2),Y1=Math.ceil(py+wd+2);
  for(var Y=Y0;Y<=Y1;Y++)for(var X=X0;X<=X1;X++){if(!inb(X,Y)||sec[I(X,Y)]!==sk)continue;var d=Math.hypot(X+.5-px,Y+.5-py),i=I(X,Y);
   if(d<wd){if(!road[i]){road[i]=1;tiles[i]="e"+ri(3);}blk[i]=0;}else if(d<wd+1.5)verge[i]=1;}}
 (POLY[sk]=POLY[sk]||[]).push(pts);return pts;}
function pavimenta(cx0,cy0,r,pr){for(var y=cy0-r;y<=cy0+r;y++)for(var x=cx0-r;x<=cx0+r;x++){if(!inb(x,y))continue;var i=I(x,y);if(road[i]&&Math.hypot(x-cx0,y-cy0)<r&&R()<pr)tiles[i]="p"+ri(8);}}
/* ---------- puertas de piedra ---------- */
function mkGate(id,gx,gy,label,col,to,pts,ex){
 var g={id:id,x:gx,y:gy,cx:gx+.5,cy:gy+.5,label:label,col:col,to:to,out:{x:gx,y:gy+2},sk:sec[I(gx,gy)]};
 if(ex)for(var q in ex)g[q]=ex[q];
 if(pts){for(var k=0;k<pts.length;k++){if(Math.hypot(pts[k].x-gx-.5,pts[k].y-gy-.5)>=3.6){g.out={x:Math.floor(pts[k].x),y:Math.floor(pts[k].y)};break;}}}
 GATES.push(g);return g;}
function colocaPuerta(g){
 despeja(g.x,g.y,3,"e");
 for(var b=-1;b<=1;b++)for(var a=-1;a<=1;a++){var i=I(g.x+a,g.y+b);blk[i]=0;if(!road[i]){tiles[i]="p"+ri(8);}}
 [[-1,-1],[1,-1],[-1,1],[1,1]].forEach(function(d){put("pg_"+g.col,g.x+d[0],g.y+d[1],{light:!g.cerrada,dy:0,gc:g.col});});
 if(g.cerrada){var v=g.dir==="N"||g.dir==="S";for(var k=-1;k<=1;k++){var X=g.x+(v?k:0),Y=g.y+(v?0:k);if(!blk[I(X,Y)])put("ru_muro2",X,Y,{});}return;}
 OB.push({i:"_portal",cx:g.cx,cy:g.cy,fn:"portal",g:g,light:1,nb:1});
 DECALS.push({x:g.x,y:g.y,fn:"runa",col:g.col});
 [[-1,0],[1,0],[0,-1],[0,1]].forEach(function(d){blk[I(g.x+d[0],g.y+d[1])]=0;});blk[I(g.x,g.y)]=0;}
/* ---------- constructores de ruinas ---------- */
function muro(x,y){if(!libre(x,y))return;var r=R();if(r<.14)put("ru_escombro"+ri(2),x,y,{});else put("ru_muro"+ri(3),x,y,{});}
function pilar(x,y,roto){if(!libre(x,y))return;put(roto?"ru_pilar_roto":"ru_pilar",x,y,{});}
function escombro(x,y){if(libre(x,y))put("ru_escombro"+ri(2),x,y,{});}
function tomba(x,y){if(libre(x,y))put("ru_lapida"+ri(3),x,y,{});}
function menhir(x,y){if(libre(x,y))put("ru_menhir"+ri(2),x,y,{});}
function altar(x,y){if(libre(x,y))put("ru_altar",x,y,{light:1});}
function estatua(x,y){if(libre(x,y))put("ru_estatua"+ri(2),x,y,{});}
function linea(x0,y0,x1,y1,br){var dx=Math.sign(x1-x0),dy=Math.sign(y1-y0),x=x0,y=y0;
 for(;;){if(R()>br)muro(x,y);else if(R()<.4)escombro(x,y);if(x===x1&&y===y1)break;x+=dx;y+=dy;}}
function fortress(cx0,cy0,w,h,torres){
 var x0=cx0-(w>>1),y0=cy0-(h>>1),x1=x0+w-1,y1=y0+h-1,x,y;
 piso(x0,y0,x1,y1,.85);
 for(x=x0;x<=x1;x++){if(Math.abs(x-cx0)<=1)continue;if(R()>.16)muro(x,y0);else escombro(x,y0);if(R()>.16)muro(x,y1);else escombro(x,y1);}
 for(y=y0;y<=y1;y++){if(Math.abs(y-cy0)<=1)continue;if(R()>.16)muro(x0,y);else escombro(x0,y);if(R()>.16)muro(x1,y);else escombro(x1,y);}
 [[x0,y0],[x1,y0],[x0,y1],[x1,y1]].forEach(function(p,k){
  if(torres&&k!==3&&libreN(p[0]-(p[0]<cx0?1:0),p[1]-(p[1]<cy0?1:0),2,2)){var tx=p[0]-(p[0]<cx0?1:0),ty=p[1]-(p[1]<cy0?1:0);putBig(k%2?"torre":"torre2",tx,ty,2,2,{});}
  else{pilar(p[0],p[1],R()<.35);}});
 var mx=cx0+((w/4)|0),my=cy0-((h/4)|0);
 linea(x0+3,my,cx0-3,my,.3);linea(mx,y0+2,mx,my-1,.35);linea(cx0+3,cy0+3,x1-3,cy0+3,.45);
 altar(cx0-3,cy0-3);estatua(cx0+4,cy0-2);estatua(cx0-5,cy0+4);
 for(var n=0;n<14;n++)escombro(x0+2+ri(w-4),y0+2+ri(h-4));
 for(n=0;n<5;n++)pilar(x0+3+ri(w-6),y0+3+ri(h-6),R()<.5);
 for(n=0;n<4;n++)tomba(x0+2+ri(w-4),y0+2+ri(h-4));
 despeja(cx0,cy0,Math.max(w,h)/2+3,null);}
function temple(cx0,cy0,w,h){
 var x0=cx0-(w>>1),y0=cy0-(h>>1),x1=x0+w-1,y1=y0+h-1,x;
 piso(x0-2,y0-2,x1+2,y1+2,.4);piso(x0,y0,x1,y1,.92);
 for(x=x0+1;x<=x1-3;x+=3){var a=R();if(a<.88)pilar(x,y0+2,a<.35);var b=R();if(b<.88)pilar(x,y1-2,b<.35);}
 for(var y=y0+2;y<=y1-2;y+=3){var c=R();if(c<.7)pilar(x1,y,c<.3);}
 altar(x1-3,cy0);estatua(x1-3,cy0-3);estatua(x1-3,cy0+3);
 for(x=x0;x<=x1;x++)if(R()<.5)muro(x,y0-1);
 for(var n=0;n<10;n++)escombro(x0-2+ri(w+4),y0-2+ri(h+4));
 for(n=0;n<3;n++)menhir(x0-3+ri(w+6),y0-3+ri(h+6));
 despeja(cx0,cy0,Math.max(w,h)/2+3,null);}
function circle(cx0,cy0,r,n){
 for(var b=-4;b<=4;b++)for(var a=-4;a<=4;a++)if(a*a+b*b<=16&&R()<.9)suelo(cx0+a,cy0+b,"p"+ri(8));
 for(var k=0;k<n;k++){var an=k/n*6.2832,x=Math.round(cx0+Math.cos(an)*r),y=Math.round(cy0+Math.sin(an)*r*.95);
  if(R()<.2)escombro(x,y);else menhir(x,y);}
 altar(cx0,cy0);pilar(cx0-2,cy0-2,R()<.4);pilar(cx0+2,cy0-2,R()<.4);pilar(cx0-2,cy0+2,R()<.4);pilar(cx0+2,cy0+2,R()<.4);
 for(k=0;k<8;k++)escombro(cx0-r+ri(r*2),cy0-r+ri(r*2));
 despeja(cx0,cy0,r+3,null);}
function graveyard(cx0,cy0,w,h){
 var x0=cx0-(w>>1),y0=cy0-(h>>1),x1=x0+w-1,y1=y0+h-1,x,y;
 for(x=x0;x<=x1;x++){if(Math.abs(x-cx0)>1){if(R()<.8&&libre(x,y0))put("fence",x,y0,{});if(R()<.8&&libre(x,y1))put("fence",x,y1,{});}}
 for(y=y0;y<=y1;y++){if(Math.abs(y-cy0)>1){if(R()<.8&&libre(x0,y))put("fence",x0,y,{});if(R()<.8&&libre(x1,y))put("fence",x1,y,{});}}
 for(y=y0+2;y<=y1-2;y+=2)for(x=x0+2;x<=x1-2;x+=2){if(Math.abs(x-cx0)<=3&&Math.abs(y-cy0)<=3)continue;if(Math.abs(x-cx0)<=1||Math.abs(y-cy0)<=1)continue;if(R()<.68)tomba(x,y);else if(R()<.2)escombro(x,y);}
 estatua(cx0+2,cy0);altar(cx0-2,cy0);
 for(var n=0;n<8;n++){var X=x0+1+ri(w-2),Y=y0+1+ri(h-2);if(libre(X,Y)&&R()<.5)put("t"+[3,9,2][ri(3)],X,Y,{});else dec("mush",X,Y,{});}
 despeja(cx0,cy0,Math.max(w,h)/2+3,null);}
function village(cx0,cy0){
 var casas=["cabana1","cabana2","dh_azul","dh_paja","dh_turq","dh_verde"],sl=[[-11,-9],[-4,-10],[4,-10],[11,-8],[-12,0],[12,1],[-9,8],[-2,9],[6,9],[13,9]];
 sl.forEach(function(s){var x=cx0+s[0],y=cy0+s[1];if(libreN(x,y,2,2)&&R()<.85){putBig(casas[ri(casas.length)],x,y,2,2,{k:"h"});
  for(var n=0;n<3;n++)escombro(x-1+ri(4),y-1+ri(4));if(R()<.5&&libre(x+2,y+1))put("fence",x+2,y+1,{});if(R()<.4&&libre(x-1,y))dec("stump",x-1,y,{});}});
 if(libreN(cx0-1,cy0-5,2,2))putBig("capilla",cx0-2,cy0-6,3,3,{k:"h"});
 if(libreN(cx0+13,cy0-3,3,3))putBig("molino",cx0+13,cy0-3,3,3,{k:"h"});
 for(var n=0;n<18;n++)escombro(cx0-12+ri(25),cy0-10+ri(21));
 for(n=0;n<8;n++){var X=cx0-12+ri(25),Y=cy0-10+ri(21);if(libre(X,Y))put(R()<.5?"stump":"log",X,Y,{});}
 for(n=0;n<5;n++)pilar(cx0-10+ri(21),cy0-8+ri(17),true);
 despeja(cx0,cy0,16,null);}
/* anillo de muralla en ruinas alrededor de un punto: huecos junto a los ejes (por donde pasan los caminos) y brechas al azar */
function muralla(cx0,cy0,r){
 var n=Math.round(6.2832*r*1.15),k,an,x,y,q;
 for(k=0;k<n;k++){an=k/n*6.2832;x=Math.round(cx0+Math.cos(an)*r);y=Math.round(cy0+Math.sin(an)*r);
  if(Math.min(Math.abs(Math.cos(an)),Math.abs(Math.sin(an)))<.13)continue;
  q=R();if(q<.16)continue;if(q<.28)escombro(x,y);else if(q<.34)pilar(x,y,R()<.5);else muro(x,y);}
 for(k=0;k<4;k++){var ax=cx0+(k===0?r:k===2?-r:0),ay=cy0+(k===1?r:k===3?-r:0),dx=k%2?4:0,dy=k%2?0:4;   /* pilares a los lados de cada hueco */
  pilar(ax+dx,ay+dy,R()<.3);pilar(ax-dx,ay-dy,R()<.3);}}
function minor(x,y,tipo){
 despeja(x,y,3,"e");
 if(tipo===0){linea(x-2,y-1,x+2,y-1,.25);linea(x+2,y-1,x+2,y+2,.35);escombro(x,y+1);escombro(x-1,y);tomba(x-1,y+2);}
 else if(tipo===1){pilar(x-2,y,0);pilar(x,y,1);pilar(x+2,y,R()<.5);escombro(x,y+2);escombro(x-1,y-2);}
 else if(tipo===2){estatua(x,y);escombro(x-1,y+1);escombro(x+1,y-1);menhir(x-2,y-1);}
 else if(tipo===3){tomba(x-1,y);tomba(x+1,y);tomba(x,y+2);if(libre(x,y-2))put("t"+[3,9][ri(2)],x,y-2,{});dec("mush",x+2,y,{});}
 else if(tipo===4){menhir(x-2,y);menhir(x+2,y);menhir(x,y-2);altar(x,y);}
 else{if(libre(x+1,y))put("log",x+1,y,{});if(libre(x-1,y+1))put("stump",x-1,y+1,{});DECALS.push({x:x,y:y,fn:"brasas"});dec("mush",x-2,y-1,{});escombro(x+2,y+2);}}
/* ---------- campamento ---------- */
var SPAWN={x:CC.x,y:CC.y+6};
function campamento(cx0,cy0){
 for(var b=-11;b<=11;b++)for(var a=-11;a<=11;a++){var d=Math.hypot(a,b),X=cx0+a,Y=cy0+b;if(!inb(X,Y))continue;var i=I(X,Y);
  if(d<=11)keep[i]=1;if(d<7.4&&!road[i]){tiles[i]=R()<.88?"e"+ri(3):"g"+ri(3);}else if(d<9.5&&!road[i]&&R()<.4)tiles[i]="e"+ri(3);}
 var f=put("fogata",cx0,cy0,{fn:"fuego",light:1,glow:1,k:"f"});DECALS.push({x:cx0,y:cy0,fn:"brasas"});
 [[-2,-1,"log"],[2,1,"log"],[-1,2,"stump"],[1,-2,"stump"],[3,-1,"stump"],[-3,1,"stump"]].forEach(function(p){if(libre(cx0+p[0],cy0+p[1]))put(p[2],cx0+p[0],cy0+p[1],{});});
 var tt=[[-7,-6,0],[4,-7,1],[-8,2,2],[6,2,0],[-2,-9,1]];
 tt.forEach(function(t){if(libreN(cx0+t[0],cy0+t[1],2,2))putBig("ru_carpa"+t[2],cx0+t[0],cy0+t[1],2,2,{k:"c"});});
 [[8,-2,"mu_cajas"],[9,-1,"mu_barril"],[8,0,"mu_barril"],[-9,-3,"mu_cajas"],[-9,-4,"mu_cajas"],[-8,-1,"mu_barril"]].forEach(function(p){if(libre(cx0+p[0],cy0+p[1]))put(p[2],cx0+p[0],cy0+p[1],{});});
 put("mesa",cx0+5,cy0-3,{});put("mesa",cx0-5,cy0+4,{});
 [[-5,-3],[5,-5],[6,5],[-6,6],[0,-6],[0,7],[-10,0],[10,1]].forEach(function(p){if(libre(cx0+p[0],cy0+p[1]))put("farol",cx0+p[0],cy0+p[1],{light:1});});
 if(libre(cx0+2,cy0+8))put("ru_estandarte",cx0+2,cy0+8,{sw:1});if(libre(cx0-3,cy0+8))put("ru_estandarte",cx0-3,cy0+8,{sw:1});
 if(libre(cx0,cy0+9)){var cr=put("ru_cartel",cx0,cy0+9,{lab:"Oakhaven",k:"x",light:0});EXITS.push({cx:cx0+.5,cy:cy0+9.5,label:"Volver a Oakhaven",o:cr});}
 var sol=[[4,0,50,"Soldado Brant",["El General Varek manda a todos los exploradores por este claro.","El camino del sur lleva al Sector 1. Cada camino termina en una puerta de piedra."]],
  [-4,1,48,"Arquera Ilse",["Los caminos son seguros cerca del fuego. Más allá… mantén el arco listo.","Al sur, el Bosque del Camino Viejo. Hay un puesto de vigilancia en ruinas en su centro."]],
  [-1,-4,52,"Cazador Rowan",["El camino del este lleva a la Aldea Abandonada de los Vigías y, más allá, a una necrópolis. Ve bien equipado.","No te salgas del camino: los bosques confunden a cualquiera."]],
  [2,4,26,"Vigía Edda",["Cuando quieras volver a Oakhaven, habla con el Mensajero Doran o usa el cartel del sur.","Cruza la puerta de piedra al final del camino: te llevará al Sector 1."]],
  [-3,6,53,"Mensajero Doran",["¿Quieres volver a Oakhaven? Háblame (E) y te llevo de vuelta.","Hago el camino a Oakhaven cada vez que alguien lo necesita."],1]];
 sol.forEach(function(s){var X=cx0+s[0],Y=cy0+s[1];if(inb(X,Y)){blk[I(X,Y)]=1;NPC.push({c:s[2],x:X+.5,y:Y+.5,dir:0,name:s[3],lines:s[4],ret:!!s[5]});}});
 despeja(cx0,cy0,11,null);}
/* ---------- generación del mundo ---------- */
function polyCerca(sk,x,y){var best=null,bd=1e9,L=POLY[sk]||[];for(var a=0;a<L.length;a++)for(var b=0;b<L[a].length;b+=3){var p=L[a][b],d=Math.hypot(p.x-x,p.y-y);if(d<bd){bd=d;best=p;}}return best;}
var TRE={};
/* Zona del jefe: claro de radio 6 lejos del centro y de las puertas, unido por un sendero al camino más cercano */
function zonaJefe(k){
 var T=TM[k],ox=OX(T.c),oy=OX(T.r),cxx=ox+S/2,cyy=oy+S/2,R0=6,best=null,bm=1e9,n=0;
 while(n++<600){
  var X=ox+14+ri(S-28),Y=oy+14+ri(S-28);
  if(Math.hypot(X-cxx,Y-cyy)<26)continue;
  if(GATES.some(function(g){return Math.hypot(g.x-X,g.y-Y)<18;}))continue;
  var bad=0;
  for(var b=-R0-2;b<=R0+2;b++)for(var a=-R0-2;a<=R0+2;a++){if(a*a+b*b>(R0+2)*(R0+2))continue;var q=I(X+a,Y+b);if(blk[q]||road[q]||keep[q]||sec[q]!==k)bad++;}
  if(bad<bm){bm=bad;best={x:X,y:Y};}
  if(bad===0)break;
 }
 if(!best)return;
 var X0=best.x,Y0=best.y;
 for(var b2=-R0;b2<=R0;b2++)for(var a2=-R0;a2<=R0;a2++){if(a2*a2+b2*b2>R0*R0)continue;var i2=I(X0+a2,Y0+b2);if(sec[i2]!==k)continue;keep[i2]=1;if(!road[i2])tiles[i2]=R()<.85?"p"+ri(8):"e"+ri(3);}
 var pc=polyCerca(k,X0,Y0);if(pc)carve({x:pc.x,y:pc.y},{x:X0+.5,y:Y0+.5},1,k);
 for(var m=0;m<8;m++){var an=m*Math.PI/4+.3,px=Math.round(X0+(R0-1)*Math.cos(an)),py=Math.round(Y0+(R0-1)*Math.sin(an));if(m%2)menhir(px,py);else pilar(px,py,m%4===0);}
 DECALS.push({x:X0,y:Y0,fn:"runa",col:"#d8483c"});
 T.boss={x:X0+.5,y:Y0+.5,r:R0};
}
/* Garantiza que el bosque no encierre zonas: quita los árboles que separan celdas libres alcanzables de las que no lo son */
function conectarBosque(){
 var q=new Int32Array(N),DXs=[1,-1,0,0],DYs=[0,0,1,-1],iter,ii,kk2;
 for(iter=0;iter<12;iter++){
  var vis=new Uint8Array(N),qh=0,qt=0;
  var seeds=[{x:Math.floor(CC.x),y:Math.floor(CC.y)}];GATES.forEach(function(g){seeds.push(g.out);});
  for(kk2=0;kk2<GN*GN;kk2++){var Tq=TM[kk2];if(Tq.built){seeds.push({x:OX(Tq.c)+(S>>1),y:OX(Tq.r)+(S>>1)});if(Tq.boss)seeds.push({x:Math.floor(Tq.boss.x),y:Math.floor(Tq.boss.y)});}}
  seeds.forEach(function(s){if(!inb(s.x,s.y))return;var c=I(s.x,s.y);if(!blk[c]&&!vis[c]&&sec[c]>=0){vis[c]=1;q[qt++]=c;}});
  while(qh<qt){var c0=q[qh++],x0=c0%W,y0=(c0/W)|0;for(var d=0;d<4;d++){var X=x0+DXs[d],Y=y0+DYs[d];if(!inb(X,Y))continue;var j=I(X,Y);if(blk[j]||vis[j]||sec[j]<0)continue;vis[j]=1;q[qt++]=j;}}
  var kill=[];
  for(ii in TRE){var i=+ii,o=TRE[ii];if(!o||o.del)continue;var x=i%W,y=(i/W)|0,a=0,b=0;
   for(var e=0;e<4;e++){var X1=x+DXs[e],Y1=y+DYs[e];if(!inb(X1,Y1))continue;var j1=I(X1,Y1);if(sec[j1]<0||blk[j1])continue;if(vis[j1])a=1;else b=1;}
   if(a&&b)kill.push(i);}
  if(!kill.length)break;
  kill.forEach(function(i){TRE[i].del=1;blk[i]=0;});
 }
 var w=0;for(var z=0;z<OB.length;z++)if(!OB[z].del)OB[w++]=OB[z];OB.length=w;
}
function generar(){
 var k,T;
 /* 1) caminos y puertas: cada sector construido tiene un camino hacia cada vecino de la cuadrícula.
       Vecino construido = puerta abierta (enlace); vecino sin construir = camino sellado por un muro. */
 for(k=0;k<GN*GN;k++){T=TM[k];if(!T.built)continue;
  var cx0=OX(T.c)+S/2,cy0=OX(T.r)+S/2,ring=T.core==="camp"?7:5;
  DIRS.forEach(function(d){var nc=T.c+d.dx,nr=T.r+d.dy;if(nc<0||nr<0||nc>=GN||nr>=GN)return;
   var nk=SK(nc,nr),NT=TM[nk],gx=Math.round(cx0+d.dx*38),gy=Math.round(cy0+d.dy*38),ab=!!NT.built,
       pts=carve({x:cx0+d.dx*ring+(d.dx?0:(R()-.5)*2),y:cy0+d.dy*ring+(d.dy?0:(R()-.5)*2)},{x:gx+.5,y:gy+.5},1.2,k);
   if(!ab)return;
   if(ab&&(d.n==="E"||d.n==="S")){   /* camino continuo a través del cinturón abierto */
    var ex0=d.dx?OX(T.c)+S-10:Math.round(cx0),ey0=d.dy?OX(T.r)+S-10:Math.round(cy0),ex1=d.dx?OX(NT.c)+10:ex0,ey1=d.dy?OX(NT.r)+10:ey0;
    for(var yy=ey0-(d.dx?1:0);yy<=ey1+(d.dx?1:0);yy++)for(var xx=ex0-(d.dy?1:0);xx<=ex1+(d.dy?1:0);xx++){if(!inb(xx,yy)||sec[I(xx,yy)]<0)continue;var ii=I(xx,yy);if(!road[ii]){road[ii]=1;tiles[ii]="e"+ri(3);}blk[ii]=0;}}});}
 /* 2) estructura central de cada sector */
 for(k=0;k<GN*GN;k++){T=TM[k];if(!T.built)continue;var cxx=OX(T.c)+S/2,cyy=OX(T.r)+S/2,c=T.core;
  if(c==="camp")campamento(cxx,cyy);
  else{pavimenta(cxx,cyy,12,.6);
   if(c==="fortress")fortress(cxx,cyy,26,20,false);else if(c==="fortress_t")fortress(cxx,cyy,22,18,true);
   else if(c==="temple")temple(cxx,cyy,24,16);else if(c==="temple_s")temple(cxx,cyy,16,12);
   else if(c==="graveyard")graveyard(cxx,cyy,22,18);else if(c==="village")village(cxx,cyy);
   else if(c==="aldea"){village(cxx,cyy);fortress(cxx-27,cyy+24,14,12,true);circle(cxx+27,cyy-24,6,10);graveyard(cxx+26,cyy+25,12,10);
    for(var aq=0;aq<8;aq++){var ax=cxx-38+ri(76),ay=cyy-38+ri(76);if(Math.hypot(ax-cxx,ay-cyy)>20){if(aq%2)escombro(ax,ay);else pilar(ax,ay,true);}}}
   else if(c==="necropolis"){graveyard(cxx,cyy,30,24);temple(cxx-24,cyy-20,16,12);circle(cxx+24,cyy+18,6,10);
    for(var nq=0;nq<6;nq++){var nx=cxx-38+ri(76),ny=cyy-38+ri(76);if(Math.hypot(nx-cxx,ny-cyy)>18)tomba(nx,ny);}}
   else if(c==="ciudadela"){fortress(cxx,cyy,32,26,true);muralla(cxx,cyy,29);temple(cxx-25,cyy-25,14,10);circle(cxx+26,cyy-25,5,8);graveyard(cxx+26,cyy+26,12,10);fortress(cxx-26,cyy+26,12,10,false);
    for(var cq=0;cq<10;cq++){var qx=cxx-38+ri(76),qy=cyy-38+ri(76);if(Math.hypot(qx-cxx,qy-cyy)>31){if(cq%3===0)menhir(qx,qy);else if(cq%3===1)pilar(qx,qy,true);else escombro(qx,qy);}}}
   else if(c==="santuario"){temple(cxx,cyy,28,20);circle(cxx+27,cyy-24,6,10);graveyard(cxx-26,cyy+25,14,12);fortress(cxx+26,cyy+26,12,10,false);circle(cxx-27,cyy-25,5,8);
    for(var sq=0;sq<10;sq++){var sx=cxx-38+ri(76),sy=cyy-38+ri(76);if(Math.hypot(sx-cxx,sy-cyy)>24){if(sq%3===0)menhir(sx,sy);else if(sq%3===1)tomba(sx,sy);else pilar(sx,sy,true);}}}
   else if(c==="cantera"){fortress(cxx,cyy,24,18,false);circle(cxx-26,cyy-24,8,12);circle(cxx+26,cyy+24,7,10);graveyard(cxx+27,cyy-25,12,10);fortress(cxx-26,cyy+26,12,10,false);
    for(var qq=0;qq<14;qq++){var qx2=cxx-38+ri(76),qy2=cyy-38+ri(76);if(Math.hypot(qx2-cxx,qy2-cyy)>22){if(qq%2)menhir(qx2,qy2);else escombro(qx2,qy2);}}}
   else if(c==="catedral"){temple(cxx,cyy,34,24);muralla(cxx,cyy,30);graveyard(cxx-27,cyy-24,14,12);circle(cxx+27,cyy+25,6,10);fortress(cxx+26,cyy-25,12,10,true);
    for(var ct=0;ct<10;ct++){var tx=cxx-38+ri(76),ty=cyy-38+ri(76);if(Math.hypot(tx-cxx,ty-cyy)>31){if(ct%3===0)tomba(tx,ty);else if(ct%3===1)pilar(tx,ty,true);else menhir(tx,ty);}}}
   else if(c==="bastion"){fortress(cxx,cyy,34,28,true);muralla(cxx,cyy,31);fortress(cxx-27,cyy-26,12,10,true);fortress(cxx+27,cyy+26,12,10,true);graveyard(cxx+26,cyy-26,12,10);circle(cxx-27,cyy+26,5,8);
    for(var bq=0;bq<10;bq++){var bx2=cxx-38+ri(76),by2=cyy-38+ri(76);if(Math.hypot(bx2-cxx,by2-cyy)>33){if(bq%3===0)menhir(bx2,by2);else if(bq%3===1)tomba(bx2,by2);else pilar(bx2,by2,true);}}}
   else if(c==="circle")circle(cxx,cyy,8,12);else if(c==="circle_big")circle(cxx,cyy,11,16);}}
 /* 3) puertas colocadas (después de los caminos y del núcleo) */
 GATES.forEach(colocaPuerta);
 /* 3b) zona del jefe de cada sector (arena pequeña despejada, con camino y círculo de pilares; el jefe aparecerá en su centro) */
 for(k=0;k<GN*GN;k++){T=TM[k];if(!T.built||T.id===0)continue;zonaJefe(k);}
 /* 4) senderos laterales con ruinas menores + 5) ruinas sueltas por el bosque */
 for(k=0;k<GN*GN;k++){T=TM[k];if(!T.built)continue;var ox=OX(T.c),oy=OX(T.r),cxx2=ox+S/2,cyy2=oy+S/2,sites=[],n=T.ru+2,tries=0;
  while(sites.length<n&&tries++<400){var X=ox+12+ri(S-24),Y=oy+12+ri(S-24);
   if(Math.hypot(X-cxx2,Y-cyy2)<19)continue;
   if(GATES.some(function(g){return Math.hypot(g.x-X,g.y-Y)<14;}))continue;
   if(T.boss&&Math.hypot(T.boss.x-X,T.boss.y-Y)<14)continue;
   if(sites.some(function(s){return Math.hypot(s.x-X,s.y-Y)<16;}))continue;
   sites.push({x:X,y:Y});}
  sites.forEach(function(s){var p=polyCerca(k,s.x,s.y);if(p)carve({x:p.x,y:p.y},{x:s.x+.5,y:s.y+.5},1,k);minor(s.x,s.y,ri(6));});
  var cnt=T.ru*14+16;
  for(var q=0;q<cnt;q++){var X2=ox+6+ri(S-12),Y2=oy+6+ri(S-12);if(!libre(X2,Y2)||verge[I(X2,Y2)]||keep[I(X2,Y2)])continue;
   var t=ri(5);if(t===0){muro(X2,Y2);muro(X2+1,Y2);escombro(X2+2,Y2);}else if(t===1){pilar(X2,Y2,R()<.5);escombro(X2+1,Y2+1);}else if(t===2){menhir(X2,Y2);}else if(t===3){tomba(X2,Y2);}else{escombro(X2,Y2);escombro(X2+1,Y2);muro(X2,Y2+1);}}}
 /* 6) bosque */
 for(k=0;k<GN*GN;k++){T=TM[k];if(!T.built)continue;var ox2=OX(T.c),oy2=OX(T.r),tr=T.tr;
  for(var y=oy2;y<oy2+S;y++)for(var x=ox2;x<ox2+S;x++){var i=I(x,y);if(road[i]||blk[i]||keep[i])continue;
   var nz=vn(x,y,9,k+3),nz2=vn(x,y,4,k+11),p=T.dn*(.14+.62*nz);if(nz2<.28)p*=.2;if(verge[i])p*=.3;   /* bosque ralo: árboles sueltos, todo el sector transitable */
   var ex=Math.min(bBuilt(T.c-1,T.r)?99:x-ox2,bBuilt(T.c+1,T.r)?99:ox2+S-1-x,bBuilt(T.c,T.r-1)?99:y-oy2,bBuilt(T.c,T.r+1)?99:oy2+S-1-y);if(ex<5)p=Math.max(p,.2-ex*.03);p=Math.min(p,.22);
   var r=R();
   if(r<p){TRE[i]=put("t"+tr[ri(tr.length)],x,y,{sw:1,k:"t"});}
   else if(r<p+.055){dec("b"+ri(5),x,y,{sw:1});}
   else if(r<p+.075){dec("f"+ri(2),x,y,{sw:1});}
   else if(r<p+.081){dec("mush",x,y,{});}
   else if(r<p+.087){put(R()<.5?"stump":"log",x,y,{});}
   else if(r<p+.095){put("r"+ri(4),x,y,{});}}}
 BELT.forEach(function(i){var x=i%W,y=(i/W)|0,T2=TM[sec[i]];if(road[i]||blk[i]||keep[i])return;
  var nz=vn(x,y,9,T2.id+3),p=Math.min(.22,T2.dn*(.14+.62*nz)*(hash(x,y,5)<.25?.2:1)),r=hash(x,y,6),tr=T2.tr;
  if(r<p){TRE[i]=put("t"+tr[Math.floor(hash(x,y,7)*tr.length)],x,y,{sw:1,k:"t"});}
  else if(r<p+.055)dec("b"+Math.floor(hash(x,y,8)*5),x,y,{sw:1});
  else if(r<p+.075)dec("f"+Math.floor(hash(x,y,9)*2),x,y,{sw:1});});
 conectarBosque();
 /* 7) cinturones infranqueables (solo junto a sectores construidos): bosque denso y roca */
 for(var y2=0;y2<H;y2++)for(var x2=0;x2<W;x2++){var i2=I(x2,y2);if(sec[i2]!==-1||!tiles[i2])continue;
  var a=R();if(a<.8)OB.push({i:"t"+ri(10),cx:x2+.5,cy:y2+.5,sw:1,k:"t"});else if(a<.9)OB.push({i:"r"+ri(4),cx:x2+.5,cy:y2+.5,k:"r"});else OB.push({i:"b"+ri(5),cx:x2+.5,cy:y2+.5,sw:1});}
}
generar();
/* Constantes de monstruos: las comparten el cliente y el servidor (server/mundo_sim.js carga este archivo hasta el marcador SIM_FIN) */
var MON_BASE=42,MON_SEGURA=12,MON_RESP=[22,38],MON_ALFA=.06,MON_MAX_SEC=110;
var MON_NOM=["Slime Verde","Goblin Explorador","Lobo Salvaje","Araña Gigante","Duende Tramposo","Ent Joven","Bandido del Bosque","Champiñón Venenoso"],
    MON_PES=[3,3,3,2,2,1,2,2];
/* ---------- JEFES DE SECTOR (los comparten el cliente y el servidor) ----------
   Un jefe es un héroe humano con aspecto de General y las 3 habilidades base de una clase (HABILIDADES[clase] de js/data/clases.js).
   f = multiplicadores sobre un monstruo normal de su sector (vida ×9, defensa ×5, daño ×0.8). Vive en una zona remota del sector (la elige
   el servidor), no ataca hasta ser atacado y no persigue fuera de su área (arena, en celdas): al salir vuelve y se cura del todo.
   Habilidad: k = id · cd = enfriamiento (s) · wind = telegrafía (s) · m = multiplicador de daño · stun = aturdimiento (s) · r = alcance extra (u) · arc = medio arco (× π)
   Botín (una tirada por muerte): leg/epi/rar = objeto de la forja avanzada de una clase al azar (Legendario/Épico/Raro) · oro = oroTotal repartido entre el equipo. */
/* Reaparición de los jefes de sector: JEFE_RESP_DIAS días del mundo (1 día = 1440 min de juego = 1440/MIN_S s reales; 7 días ≈ 30 min reales).
   Para una semana REAL pon JEFE_RESP=7*24*3600. */
var JEFE_RESP_DIAS=7,JEFE_RESP=Math.round(JEFE_RESP_DIAS*1440/MIN_S);
var JEFES=[
 {id:"j1",sec:1,n:"General Torvald",t:"Desertor del Camino Viejo",c:80,esc:1.5,clase:"Guerrero",
  f:{vida:15,def:10,dano:4},arena:15,resp:JEFE_RESP,xp:20,spd:3.1,
  nivel:20,ramas:{Berserker:false,Ejecutor:false},
  loot:{leg:.01,epi:.05,rar:.10,oro:.80,oroTotal:20000},
  habs:[
   {k:1,n:"Golpe Brutal",cd:7,wind:.9,m:1.5,stun:1.2,r:30,arc:.6,col:"#ff7a2a"},
   {k:2,n:"Postura de Acero",cd:20,wind:.6,dur:5,df:.2,col:"#8ab0d8"},
   {k:3,n:"Ejecutar",cd:10,wind:.75,m:1.2,robo:.5,r:64,arc:.3,col:"#c03080"}]},
 {id:"j2",sec:2,n:"Capitana Valka",t:"Centinela de los Vigías",c:81,esc:1.5,clase:"Paladin",
  f:{vida:20,def:15,dano:5},arena:15,resp:JEFE_RESP,xp:20,spd:2.9,
  nivel:30,ramas:{Inquisidor:false,Guardián:false},
  loot:{leg:.02,epi:.05,rar:.10,oro:.80,oroTotal:20000},
  habs:[
   {k:1,n:"Golpe Sagrado",cd:6,wind:.9,m:1.4,r:24,arc:1,col:"#ffe080"},
   {k:2,n:"Sentencia de Luz",cd:18,wind:.6,dur:5,df:.25,col:"#8ab0d8"},
   {k:3,n:"Bendición de Poderío",cd:35,wind:1,heal:.05,col:"#7ab88a"}]},
 {id:"j3",sec:3,n:"Archimago Morvek",t:"Custodio de la Necrópolis",c:82,esc:1.5,clase:"Mago",td:"magico",reach:5,
  f:{vida:20,def:15,dano:8},arena:15,resp:JEFE_RESP,xp:20,spd:2.9,
  nivel:40,ramas:{Ignis:false,Cryomante:false},
  loot:{leg:.02,epi:.05,rar:.10,oro:.80,oroTotal:20000},
  habs:[
   {k:1,n:"Bola de Fuego",cd:8,wind:1.1,m:2.5,r:130,arc:.12,col:"#ff7a30"},
   {k:2,n:"Congelar",cd:14,wind:1,m:.7,stun:1.5,r:40,arc:1,col:"#8fd0f0"},
   {k:3,n:"Barrera Arcana",cd:24,wind:.6,dur:6,shield:.05,col:"#b090ff"}]},
 {id:"j4",sec:4,n:"Capitán Sylas",t:"Arquero de la Ciudadela",c:83,esc:1.5,clase:"Arquero",reach:6,
  f:{vida:30,def:15,dano:10},arena:15,resp:JEFE_RESP,xp:20,spd:3.2,
  nivel:50,ramas:{Cazador:false,Francotirador:true},
  loot:{leg:.02,epi:.05,rar:.10,oro:.80,oroTotal:20000},
  habs:[
   {k:1,n:"Tiro Certero",cd:6,wind:.9,m:2,r:130,arc:.12,col:"#9ad060"},
   {k:2,n:"Lluvia de Flechas",cd:12,wind:1.1,m:1.4,r:90,arc:1,col:"#d8e8a0"},
   {k:3,n:"Paso Espectral",cd:18,wind:.6,dur:5,dm:.3,col:"#9ab89a"}]},
 {id:"j5",sec:5,n:"Prelada Ysmera",t:"Guardiana del Santuario",c:85,esc:1.5,clase:"Clérigo",td:"magico",reach:2.5,
  f:{vida:30,def:15,dano:10},arena:15,resp:JEFE_RESP,xp:20,spd:2.9,
  nivel:60,ramas:{Hierofante:false,"Heraldo Solar":true},
  loot:{leg:.03,epi:.07,rar:.15,oro:.80,oroTotal:20000},
  habs:[
   {k:1,n:"Pulso Vital",cd:7,wind:.9,m:1.1,robo:.6,r:80,arc:1,col:"#8ff0d0"},
   {k:2,n:"Égida Radiante",cd:24,wind:.6,dur:6,df:.25,shield:.05,col:"#8ff0d0"},
   {k:3,n:"Plegaria de Pureza",cd:22,wind:.8,dur:8,dm:.25,col:"#ffe9a0"}]},
 {id:"j6",sec:6,n:"Acechadora Nyssa",t:"Sombra de la Cantera",c:73,esc:1.5,clase:"Asesino",
  f:{vida:40,def:15,dano:15},arena:15,resp:JEFE_RESP,xp:20,spd:3.6,
  nivel:70,ramas:{Ninja:false,Sicario:true},
  loot:{leg:.03,epi:.07,rar:.15,oro:.80,oroTotal:20000},
  habs:[
   {k:1,n:"Golpe Espectral",cd:6,wind:.7,m:2.5,r:40,arc:.5,col:"#b070e0"},
   {k:2,n:"Bomba de Humo",cd:14,wind:.9,m:.5,stun:1.5,r:80,arc:1,col:"#8a8a96"},
   {k:3,n:"Asesinato Múltiple",cd:11,wind:.8,m:2.4,r:50,arc:.5,col:"#c070d0"}]},
 {id:"j7",sec:7,n:"Inquisidor Aurelian",t:"Guardián de la Catedral Hundida",c:74,esc:1.5,clase:"Paladin",
  f:{vida:60,def:25,dano:10},arena:15,resp:JEFE_RESP,xp:20,spd:2.9,
  nivel:80,ramas:{Inquisidor:false,"Guardián":true},
  loot:{leg:.03,epi:.07,rar:.15,oro:.80,oroTotal:20000},
  habs:[
   {k:1,n:"Golpe Sagrado",cd:6,wind:.9,m:1.5,r:28,arc:1,col:"#ffe080"},
   {k:2,n:"Sentencia de Luz",cd:20,wind:.6,dur:5,df:.25,col:"#8ab0d8"},
   {k:3,n:"Bendición de Poderío",cd:40,wind:1,heal:.05,col:"#7ab88a"}]},
 {id:"j8",sec:8,n:"Rey Caído Valdemar",t:"Soberano del Bastión Olvidado",c:72,esc:1.5,clase:"Guerrero",
  f:{vida:55,def:20,dano:15},arena:15,resp:JEFE_RESP,xp:20,spd:3.0,
  nivel:90,ramas:{Berserker:false,Ejecutor:true},
  loot:{leg:.03,epi:.07,rar:.15,oro:.80,oroTotal:20000},
  habs:[
   {k:1,n:"Golpe Brutal",cd:7,wind:.9,m:1.6,stun:1.2,r:30,arc:.6,col:"#ff7a2a"},
   {k:2,n:"Postura de Acero",cd:20,wind:.6,dur:5,df:.2,col:"#8ab0d8"},
   {k:3,n:"Ejecutar",cd:10,wind:.75,m:1.3,robo:.5,r:64,arc:.3,col:"#c03080"}]}
];
/* ---------- NIVEL Y RAMAS DE LOS JEFES ----------
   nivel (en cada jefe de JEFES): reemplaza al "piso equivalente" del sector para calcular sus stats (vida, daño, defensa) y su XP; valores por defecto = el piso
   equivalente de su sector (Sector 1 = 3, 2 = 5, 3 = 7), es decir, igual que antes. Súbelo o bájalo para ajustar al jefe con precisión.
   ramas (en cada jefe): las 2 ramas de su clase, todas en false. Pon true en UNA para que el jefe la use (solo si nivel >= 50; si hay más de una en true se usa la primera).
   Igual que los jugadores: Nv 50+ talentos pasivos de la rama · Nv 60 Habilidad 1 de la rama · Nv 80 Habilidad 2 · 65/75 potencia · 85-100 maestría.
   Pasivos que aplican a un jefe: dmg y aoe (+% daño) · defp (+% defensa) · dr (-% daño recibido) · h1p/h2p (+% poder de Hab.1/Hab.2) · bp0/bp1 (+% de su 1ª/2ª habilidad base).
   El resto de talentos de rama (robo de vida, crítico, oro...) no tienen efecto en jefes.
   RAMA_JEFE = las habilidades de rama ya traducidas al formato de jefe (mismos campos que "habs"; k 4 y 5) y sus nodos [nivel,{pasivos}]. Se pueden retocar. */
var NIV_RAMA_JEFE=50,NIV_HAB1_JEFE=60,NIV_HAB2_JEFE=80;
var RAMA_JEFE={
 "Berserker":{clase:"Guerrero",
  h1:{k:4,n:"Torbellino Aniquilador",cd:3,col:"#ff7a2a",m:2,wind:0.9,r:80,arc:1},
  h2:{k:5,n:"Sangre de Loco",cd:5,col:"#ff7a2a",wind:0.7,dur:10,dm:0.25},
  nodos:[[50,{dmg:0.15}],[65,{h1p:0.2}],[75,{h1p:0.2}],[100,{bp0:0.5}]]},
 "Ejecutor":{clase:"Guerrero",
  h1:{k:4,n:"Sentencia Final",cd:3,col:"#ff7a2a",m:3,wind:1,r:40,arc:0.5},
  h2:{k:5,n:"Marca del Condenado",cd:5,col:"#ff7a2a",m:1.2,wind:0.82,r:40,arc:0.5},
  nodos:[[65,{h1p:0.2}],[75,{h1p:0.2}],[100,{bp0:0.5}]]},
 "Inquisidor":{clase:"Paladin",
  h1:{k:4,n:"Juicio Divino",cd:3,col:"#ffe080",m:1.6,wind:0.86,r:80,arc:1},
  h2:{k:5,n:"Cruzada Fanática",cd:5,col:"#ffe080",wind:0.7,dur:12,dm:0.25},
  nodos:[[50,{aoe:0.2}],[65,{h1p:0.2}],[75,{h1p:0.2}],[85,{h1p:0.25}],[100,{bp0:0.5}]]},
 "Guardián":{clase:"Paladin",
  h1:{k:4,n:"Bastión Inquebrantable",cd:22,col:"#ffe080",wind:0.7,dur:5,df:0.3},
  h2:{k:5,n:"Luz Regeneradora",cd:30,col:"#ffe080",wind:0.7,dur:10,heal:0.06},
  nodos:[[50,{defp:0.15}],[58,{dr:0.05}],[65,{h1p:0.2}],[75,{h1p:0.2}],[90,{h2p:0.5}],[100,{bp1:0.5}]]},
 "Cazador":{clase:"Arquero",
  h1:{k:4,n:"Vínculo Alfa",cd:6,col:"#9ad060",wind:0.7,dur:10,dm:1},
  h2:{k:5,n:"Trampa Alfa",cd:5,col:"#9ad060",m:0.8,wind:0.78,stun:2.5,r:80,arc:1},
  nodos:[[50,{dmg:0.1}],[65,{h1p:0.2}],[75,{h1p:0.2}],[85,{dmg:0.15}],[100,{bp0:0.5}]]},
 "Francotirador":{clase:"Arquero",
  h1:{k:4,n:"Disparo de Largo Alcance",cd:6,col:"#9ad060",m:4,wind:1.1,r:130,arc:0.12},
  h2:{k:5,n:"Posición Elevada",cd:5,col:"#9ad060",wind:0.7,dur:4,dm:0.25},
  nodos:[[50,{dmg:0.1}],[65,{h1p:0.2}],[75,{h1p:0.2}],[100,{bp0:0.5}]]},
 "Ninja":{clase:"Asesino",
  h1:{k:4,n:"Corte Sombra x7",cd:5,col:"#b070e0",m:3.5,wind:1.05,r:40,arc:0.5},
  h2:{k:5,n:"Paso Espectral",cd:5,col:"#b070e0",wind:0.7,dur:4,dm:0.25},
  nodos:[[65,{h1p:0.2}],[75,{h1p:0.2}],[90,{h2p:0.3}],[100,{bp0:0.5}]]},
 "Sicario":{clase:"Asesino",
  h1:{k:4,n:"Lluvia de Cuchillas",cd:3,col:"#b070e0",m:1.6,wind:0.86,r:80,arc:1},
  h2:{k:5,n:"Contrato Marcado",cd:6,col:"#b070e0",m:1.2,wind:0.82,r:40,arc:0.5},
  nodos:[[54,{aoe:0.2}],[65,{h1p:0.2}],[75,{h1p:0.2}],[85,{h1p:0.6}],[100,{bp0:0.5}]]},
 "Ignis":{clase:"Mago",
  h1:{k:4,n:"Infierno",cd:4,col:"#b090ff",m:2.4,wind:0.94,r:80,arc:1},
  h2:{k:5,n:"Combustión",cd:5,col:"#b090ff",m:2.5,wind:0.95,stun:1.25,r:80,arc:1},
  nodos:[[54,{aoe:0.25}],[58,{dmg:0.1}],[65,{h1p:0.2}],[75,{h1p:0.2}],[100,{bp0:0.5}]]},
 "Cryomante":{clase:"Mago",
  h1:{k:4,n:"Prisión Glacial",cd:4,col:"#b090ff",m:0.8,wind:0.78,stun:2.5,r:80,arc:1},
  h2:{k:5,n:"Lanza de Hielo Absoluto",cd:5,col:"#b090ff",m:3.5,wind:1.05,stun:1.25,r:130,arc:0.12},
  nodos:[[65,{h1p:0.2}],[75,{h1p:0.2}],[100,{bp1:0.5}]]},
 "Hierofante":{clase:"Clérigo",
  h1:{k:4,n:"Santuario de Luz",cd:24,col:"#8ff0d0",wind:0.7,dur:6,df:0.25,shield:0.08,heal:0.06},
  h2:{k:5,n:"Resurgir Divino",cd:30,col:"#8ff0d0",wind:0.7,dur:8,df:0.2,heal:0.06,dm:0.2},
  nodos:[[50,{defp:0.12}],[65,{h1p:0.2}],[75,{h1p:0.2}],[85,{h1p:0.5}],[90,{h2p:0.3}],[100,{bp0:0.5}]]},
 "Heraldo Solar":{clase:"Clérigo",
  h1:{k:4,n:"Nova Solar",cd:3,col:"#8ff0d0",m:2,wind:0.9,r:80,arc:1},
  h2:{k:5,n:"Ascensión Radiante",cd:5,col:"#8ff0d0",wind:0.7,dur:12,dm:0.35},
  nodos:[[50,{dmg:0.15}],[54,{aoe:0.25}],[65,{h1p:0.2}],[75,{h1p:0.2}],[90,{h2p:0.3}],[100,{bp0:0.5}]]}
};
function escalarHabJ(h,f){["m","heal","shield","dm","df"].forEach(function(k){if(h[k])h[k]=+(h[k]*f).toFixed(3);});return h;}
function prepararJefes(){
 JEFES.forEach(function(d){
  if(!d._base){d._base=d.habs.map(function(h){return Object.assign({},h);});}
  d.nivel=Math.max(1,Math.floor(+d.nivel||1));d.avisos=[];d.rama=null;d.mod={dmg:0,defp:0,dr:0};
  d.habs=d._base.map(function(h){return Object.assign({},h);});
  var rs=d.ramas||{},act=Object.keys(rs).filter(function(n){return rs[n]===true;});
  if(!act.length)return;
  if(act.length>1)d.avisos.push("varias ramas en true ("+act.join(", ")+"): se usa "+act[0]);
  var rn=act[0],R=RAMA_JEFE[rn];
  if(!R||R.clase!==d.clase){d.avisos.push("la rama \""+rn+"\" no existe o no es de la clase "+d.clase);return;}
  if(d.nivel<NIV_RAMA_JEFE){d.avisos.push("rama \""+rn+"\" ignorada: el jefe es Nv "+d.nivel+" (necesita Nv "+NIV_RAMA_JEFE+")");return;}
  var mods={};R.nodos.forEach(function(n){if(n[0]<=d.nivel)for(var k in n[1])mods[k]=(mods[k]||0)+n[1][k];});
  if(mods.bp0&&d.habs[0])escalarHabJ(d.habs[0],1+mods.bp0);
  if(mods.bp1&&d.habs[1])escalarHabJ(d.habs[1],1+mods.bp1);
  if(d.nivel>=NIV_HAB1_JEFE)d.habs.push(escalarHabJ(Object.assign({},R.h1),1+(mods.h1p||0)));
  if(d.nivel>=NIV_HAB2_JEFE)d.habs.push(escalarHabJ(Object.assign({},R.h2),1+(mods.h2p||0)));
  d.rama=rn;d.mod={dmg:(mods.dmg||0)+(mods.aoe||0),defp:mods.defp||0,dr:Math.min(.8,mods.dr||0)};
 });}
prepararJefes();
/*@SIM_FIN*/
/* cubos de búsqueda por cubeta (8x8 celdas) */
var NB=Math.ceil(W/8),BK=new Array(NB*NB);
OB.forEach(function(o){var b=((o.cy|0)>>3)*NB+((o.cx|0)>>3);(BK[b]||(BK[b]=[])).push(o);});
/* ---------- camino (BFS) ---------- */
var _q=new Int32Array(N),_pv=new Int32Array(N);
function bfs(a,b){
 if(!inb(b.x,b.y)||blk[I(b.x,b.y)])return null;
 _pv.fill(-2);var qh=0,qt=0,s=I(a.x,a.y),e=I(b.x,b.y);_pv[s]=-1;_q[qt++]=s;
 while(qh<qt){var c=_q[qh++];if(c===e)break;var x=c%W,y=(c/W)|0;
  for(var k=0;k<4;k++){var X=x+DX[k],Y=y+DY[k];if(!inb(X,Y))continue;var j=I(X,Y);if(blk[j]||_pv[j]!==-2)continue;_pv[j]=c;_q[qt++]=j;}}
 if(_pv[e]===-2)return null;var path=[],c2=e;while(c2!==-1){path.push({x:c2%W,y:(c2/W)|0});c2=_pv[c2];}path.reverse();path.shift();return path;}
function celdaLibre(x,y){if(inb(x,y)&&!blk[I(x,y)])return{x:x,y:y};
 for(var r=1;r<=6;r++)for(var b=-r;b<=r;b++)for(var a=-r;a<=r;a++){if(Math.max(Math.abs(a),Math.abs(b))!==r)continue;if(inb(x+a,y+b)&&!blk[I(x+a,y+b)])return{x:x+a,y:y+b};}return null;}
/* ---------- sprites procedurales (ruinas, campamento, puertas) ---------- */
var SR=rng(1717);function sr(a,b){return a+SR()*(b-a);}
function mkc(w,h,gc,fn){var c=document.createElement("canvas");c.width=w;c.height=h;c.gc=gc;var g=c.getContext("2d");fn(g,w/2,gc);return c;}
function poly(g,p,fill,stroke){g.beginPath();g.moveTo(p[0],p[1]);for(var i=2;i<p.length;i+=2)g.lineTo(p[i],p[i+1]);g.closePath();if(fill){g.fillStyle=fill;g.fill();}if(stroke){g.strokeStyle=stroke;g.lineWidth=1;g.stroke();}}
function sombra(g,ox,oy,rx,ry){g.fillStyle="rgba(0,0,0,.28)";g.beginPath();g.ellipse(ox,oy+2,rx,ry,0,0,7);g.fill();}
function prism(g,ox,oy,hw,hh,h,cT,cL,cR){
 poly(g,[ox-hw,oy,ox,oy+hh,ox,oy+hh-h,ox-hw,oy-h],cL);poly(g,[ox,oy+hh,ox+hw,oy,ox+hw,oy-h,ox,oy+hh-h],cR);poly(g,[ox,oy-hh-h,ox+hw,oy-h,ox,oy+hh-h,ox-hw,oy-h],cT);}
function ladrillos(g,ox,oy,hw,hh,h){
 g.strokeStyle="rgba(28,24,18,.38)";g.lineWidth=1;
 for(var y=8;y<h;y+=8){g.beginPath();g.moveTo(ox-hw,oy-y);g.lineTo(ox,oy+hh-y);g.lineTo(ox+hw,oy-y);g.stroke();}
 var row=0;for(var y2=0;y2<h;y2+=8){var of=(row++%2)?.25:0;for(var j=.25+of;j<1;j+=.5){
  var xl=ox-hw+hw*j,yl=oy+hh*j;g.beginPath();g.moveTo(xl,yl-y2);g.lineTo(xl,yl-Math.min(h,y2+8));g.stroke();
  var xr=ox+hw*j,yr=oy+hh-hh*j;g.beginPath();g.moveTo(xr,yr-y2);g.lineTo(xr,yr-Math.min(h,y2+8));g.stroke();}}}
function musgo(g,ox,oy,hw,hh,h,n){g.fillStyle="rgba(86,128,58,.78)";for(var i=0;i<n;i++){var a=sr(-hw*.7,hw*.7),b=sr(-hh*.6,hh*.6);g.beginPath();g.ellipse(ox+a,oy-h+b,sr(3,8),sr(2,4),0,0,7);g.fill();}
 g.fillStyle="rgba(70,110,50,.6)";for(i=0;i<n;i++){g.beginPath();g.ellipse(ox+sr(-hw*.8,hw*.8),oy+sr(-2,hh*.6),sr(3,6),sr(2,3),0,0,7);g.fill();}}
function mella(g,ox,oy,hw,hh,h,n){g.globalCompositeOperation="destination-out";for(var i=0;i<n;i++){var x=ox+sr(-hw*.7,hw*.7),y=oy-h+sr(-hh*.5,hh*.5),s=sr(5,11);poly(g,[x-s,y-s*.6,x+s,y-s*.6,x+sr(-3,3),y+s*.5],"#000");}g.globalCompositeOperation="source-over";}
function spMuro(v){var h=[26,38,52][v];return mkc(76,h+54,h+34,function(g,ox,oy){sombra(g,ox,oy,30,12);
 prism(g,ox,oy,28,14,h,"#aaa699","#6b675c","#847f71");ladrillos(g,ox,oy,28,14,h);mella(g,ox,oy,28,14,h,2+v);musgo(g,ox,oy,28,14,h,4);});}
function spPilar(roto,col){var h=roto?30:74;return mkc(48,h+40,h+22,function(g,ox,oy){sombra(g,ox,oy,18,8);
 prism(g,ox,oy,13,6.5,8,"#aaa699","#6b675c","#847f71");
 var gr=g.createLinearGradient(ox-9,0,ox+9,0);gr.addColorStop(0,col?"#3a3a4a":"#6e6a5f");gr.addColorStop(.45,col?"#6a6a80":"#bab5a6");gr.addColorStop(1,col?"#2e2e3c":"#7c7768");
 g.fillStyle=gr;
 if(roto){g.beginPath();g.moveTo(ox-9,oy-8);g.lineTo(ox-9,oy-h+6);g.lineTo(ox-5,oy-h);g.lineTo(ox-1,oy-h+7);g.lineTo(ox+3,oy-h+1);g.lineTo(ox+9,oy-h+9);g.lineTo(ox+9,oy-8);g.closePath();g.fill();}
 else{g.fillRect(ox-9,oy-h+8,18,h-16);
  prism(g,ox,oy-h+8,12,6,7,"#b5b0a2","#6b675c","#847f71");}
 g.strokeStyle="rgba(0,0,0,.25)";for(var x=-5;x<=5;x+=5){g.beginPath();g.moveTo(ox+x,oy-h+(roto?10:14));g.lineTo(ox+x,oy-9);g.stroke();}
 if(col){var cg=g.createRadialGradient(ox,oy-h-2,1,ox,oy-h-2,13);cg.addColorStop(0,rgba(col,1));cg.addColorStop(1,rgba(col,0));g.fillStyle=cg;g.fillRect(ox-14,oy-h-16,28,28);
  g.fillStyle=col;poly(g,[ox,oy-h-12,ox+5,oy-h-3,ox,oy-h+4,ox-5,oy-h-3],col);
  g.strokeStyle=rgba(col,.8);g.lineWidth=1.5;for(var q=0;q<4;q++){g.beginPath();g.moveTo(ox-4,oy-18-q*13);g.lineTo(ox+4,oy-14-q*13);g.stroke();}}
 else musgo(g,ox,oy-(roto?h-6:6),9,5,0,3);
 if(roto){g.fillStyle="#7d786b";poly(g,[ox+10,oy+2,ox+17,oy-2,ox+19,oy+3,ox+12,oy+6],"#7d786b");}});}
function spEscombro(v){return mkc(64,40,26,function(g,ox,oy){sombra(g,ox,oy,22,9);
 for(var i=0;i<9+v*3;i++){var x=ox+sr(-17,17),y=oy+sr(-7,6),s=sr(4,10),c=Math.round(sr(112,170));
  poly(g,[x-s,y,x-s*.4,y-s*.9,x+s*.6,y-s*.7,x+s,y+s*.1,x+s*.2,y+s*.5],"rgb("+c+","+(c-4)+","+(c-14)+")","rgba(0,0,0,.3)");}
 musgo(g,ox,oy,16,6,2,3);});}
function spLapida(v){return mkc(44,64,50,function(g,ox,oy){sombra(g,ox,oy,13,6);
 g.fillStyle="#5d5a50";g.beginPath();g.ellipse(ox,oy-1,10,4,0,0,7);g.fill();
 if(v===2){g.fillStyle="#8e8a7e";g.fillRect(ox-3,oy-34,6,32);g.fillRect(ox-10,oy-26,20,6);g.fillStyle="#6a675c";g.fillRect(ox+1,oy-34,2,32);}
 else{g.fillStyle="#938f83";g.beginPath();g.moveTo(ox-9,oy-2);g.lineTo(ox-9,oy-24+v*2);g.quadraticCurveTo(ox,oy-36+v*2,ox+9,oy-24+v*2);g.lineTo(ox+9,oy-2);g.closePath();g.fill();
  g.fillStyle="#6a675c";g.fillRect(ox+4,oy-24,5,22);g.strokeStyle="rgba(0,0,0,.35)";g.beginPath();g.moveTo(ox-4,oy-20);g.lineTo(ox+2,oy-20);g.moveTo(ox-5,oy-15);g.lineTo(ox+3,oy-15);g.moveTo(ox-4,oy-10);g.lineTo(ox+1,oy-10);g.stroke();}
 musgo(g,ox,oy-4,8,3,0,2);});}
function spMenhir(v){return mkc(52,96,82,function(g,ox,oy){sombra(g,ox,oy,18,8);
 var gr=g.createLinearGradient(ox-14,0,ox+14,0);gr.addColorStop(0,"#5f5c52");gr.addColorStop(.5,"#9a968a");gr.addColorStop(1,"#6d695e");g.fillStyle=gr;
 g.beginPath();g.moveTo(ox-13,oy);g.lineTo(ox-10,oy-34);g.lineTo(ox-5,oy-58-v*6);g.lineTo(ox+2,oy-66-v*6);g.lineTo(ox+9,oy-44);g.lineTo(ox+13,oy-6);g.lineTo(ox+6,oy+3);g.lineTo(ox-8,oy+4);g.closePath();g.fill();
 g.strokeStyle="rgba(120,200,255,.55)";g.lineWidth=1.5;g.beginPath();g.moveTo(ox-3,oy-18);g.lineTo(ox+3,oy-26);g.lineTo(ox-2,oy-34);g.lineTo(ox+3,oy-42);g.stroke();
 musgo(g,ox,oy-4,10,4,0,4);});}
function spAltar(){return mkc(80,80,62,function(g,ox,oy){sombra(g,ox,oy,28,11);
 prism(g,ox,oy,24,12,12,"#9b978a","#5f5b51","#78736a");prism(g,ox,oy-12,19,9.5,9,"#aaa699","#6b675c","#847f71");ladrillos(g,ox,oy-12,19,9.5,9);
 g.strokeStyle="rgba(130,220,255,.9)";g.lineWidth=1.6;g.beginPath();g.ellipse(ox,oy-23,8,4,0,0,7);g.stroke();g.beginPath();g.moveTo(ox-5,oy-23);g.lineTo(ox+5,oy-23);g.moveTo(ox,oy-26);g.lineTo(ox,oy-20);g.stroke();
 musgo(g,ox,oy-21,15,7,0,3);});}
function spEstatua(v){return mkc(60,112,98,function(g,ox,oy){sombra(g,ox,oy,22,9);
 prism(g,ox,oy,16,8,16,"#a8a498","#69655a","#827d70");
 var gr=g.createLinearGradient(ox-12,0,ox+12,0);gr.addColorStop(0,"#6d6a5f");gr.addColorStop(.5,"#b2ad9f");gr.addColorStop(1,"#77736a");g.fillStyle=gr;
 g.beginPath();g.moveTo(ox-11,oy-14);g.lineTo(ox-8,oy-46);g.lineTo(ox+8,oy-46);g.lineTo(ox+11,oy-14);g.closePath();g.fill();
 g.beginPath();g.arc(ox,oy-54,7,0,7);g.fill();
 if(v===0){g.fillRect(ox+8,oy-46,10,5);g.fillRect(ox+16,oy-62,4,20);}else{g.fillRect(ox-18,oy-46,10,5);g.fillRect(ox-18,oy-58,4,14);}
 g.globalCompositeOperation="destination-out";poly(g,[ox+(v?-8:3),oy-62,ox+(v?-2:9),oy-58,ox+(v?-9:2),oy-52],"#000");g.globalCompositeOperation="source-over";
 musgo(g,ox,oy-14,12,5,0,3);});}
function spCarpa(v){var cols=[["#9a3b2e","#7a2c22","#c9a46a"],["#3f6b3c","#2f5430","#c9b87a"],["#a58a52","#85693a","#7a3b2e"]][v];
 return mkc(150,118,92,function(g,ox,oy){sombra(g,ox,oy,60,26);
  var hw=56,hh=28,ap=76;
  poly(g,[ox-hw,oy,ox,oy+hh,ox,oy-ap],cols[0],"rgba(0,0,0,.45)");poly(g,[ox,oy+hh,ox+hw,oy,ox,oy-ap],cols[1],"rgba(0,0,0,.45)");
  g.strokeStyle=cols[2];g.globalAlpha=.55;g.lineWidth=4;
  [.25,.55,.85].forEach(function(t){g.beginPath();g.moveTo(ox,oy-ap);g.lineTo(ox-hw+hw*t,oy+hh*t);g.stroke();g.beginPath();g.moveTo(ox,oy-ap);g.lineTo(ox+hw*t,oy+hh-hh*t);g.stroke();});
  g.globalAlpha=1;
  poly(g,[ox+hw*.2,oy+hh-hh*.2,ox+hw*.62,oy+hh-hh*.62,ox+hw*.38,oy-30],"#1d130d");
  g.strokeStyle="#4a3420";g.lineWidth=3;g.beginPath();g.moveTo(ox,oy-ap);g.lineTo(ox,oy-ap-12);g.stroke();
  g.fillStyle=cols[2];poly(g,[ox,oy-ap-12,ox+14,oy-ap-8,ox,oy-ap-3],cols[2]);});}
function spFogata(){return mkc(80,60,34,function(g,ox,oy){
 g.fillStyle="rgba(20,14,10,.55)";g.beginPath();g.ellipse(ox,oy+2,30,13,0,0,7);g.fill();
 for(var k=0;k<11;k++){var a=k/11*6.283,x=ox+Math.cos(a)*22,y=oy+Math.sin(a)*10;poly(g,[x-6,y,x-4,y-7,x+4,y-8,x+7,y-1,x+3,y+4],"rgb("+(120+(k*9)%40)+","+(116+(k*7)%36)+","+(104+(k*5)%30)+")","rgba(0,0,0,.4)");}
 g.strokeStyle="#4b2f18";g.lineCap="round";g.lineWidth=7;g.beginPath();g.moveTo(ox-15,oy+4);g.lineTo(ox+13,oy-6);g.moveTo(ox-14,oy-6);g.lineTo(ox+14,oy+5);g.stroke();
 g.strokeStyle="#6b4424";g.lineWidth=3;g.beginPath();g.moveTo(ox-15,oy+3);g.lineTo(ox+13,oy-7);g.moveTo(ox-14,oy-7);g.lineTo(ox+14,oy+4);g.stroke();});}
function spEstandarte(){return mkc(70,150,128,function(g,ox,oy){sombra(g,ox,oy,10,5);
 g.fillStyle="#4a3420";g.fillRect(ox-2,oy-110,4,112);g.fillStyle="#d9b24a";g.beginPath();g.arc(ox,oy-113,4,0,7);g.fill();
 g.fillStyle="#2f4f8a";g.beginPath();g.moveTo(ox+2,oy-106);g.quadraticCurveTo(ox+22,oy-100,ox+34,oy-106);g.lineTo(ox+34,oy-66);g.quadraticCurveTo(ox+22,oy-58,ox+2,oy-66);g.closePath();g.fill();
 g.fillStyle="#d9b24a";g.beginPath();g.moveTo(ox+18,oy-98);g.lineTo(ox+24,oy-84);g.lineTo(ox+18,oy-74);g.lineTo(ox+12,oy-84);g.closePath();g.fill();
 g.strokeStyle="#d9b24a";g.lineWidth=2;g.beginPath();g.moveTo(ox+2,oy-106);g.quadraticCurveTo(ox+22,oy-100,ox+34,oy-106);g.stroke();});}
function spCartel(){return mkc(110,120,100,function(g,ox,oy){sombra(g,ox,oy,16,7);
 g.fillStyle="#4a3420";g.fillRect(ox-3,oy-78,6,80);
 g.save();g.translate(ox,oy-66);g.fillStyle="#7a5a34";g.strokeStyle="#33220f";g.lineWidth=2;g.beginPath();g.moveTo(-42,-10);g.lineTo(34,-10);g.lineTo(46,0);g.lineTo(34,10);g.lineTo(-42,10);g.closePath();g.fill();g.stroke();
 g.fillStyle="#f1dfb0";g.font="700 11px serif";g.textAlign="center";g.fillText("OAKHAVEN",-2,4);g.restore();
 g.save();g.translate(ox,oy-44);g.fillStyle="#6a4c2b";g.strokeStyle="#33220f";g.lineWidth=2;g.beginPath();g.moveTo(40,-8);g.lineTo(-34,-8);g.lineTo(-46,2);g.lineTo(-34,10);g.lineTo(40,10);g.closePath();g.fill();g.stroke();
 g.fillStyle="#f1dfb0";g.font="700 9px serif";g.textAlign="center";g.fillText("Bosque Abierto",2,5);g.restore();});}
function hacerSprites(){
 for(var v=0;v<3;v++){IMG["ru_muro"+v]=spMuro(v);IMG["ru_carpa"+v]=spCarpa(v);}
 for(v=0;v<2;v++){IMG["ru_escombro"+v]=spEscombro(v);IMG["ru_menhir"+v]=spMenhir(v);IMG["ru_estatua"+v]=spEstatua(v);}
 for(v=0;v<3;v++)IMG["ru_lapida"+v]=spLapida(v);
 IMG.ru_pilar=spPilar(false);IMG.ru_pilar_roto=spPilar(true);IMG.ru_altar=spAltar();IMG.fogata=spFogata();IMG.ru_estandarte=spEstandarte();IMG.ru_cartel=spCartel();
 GATES.forEach(function(g){if(!IMG["pg_"+g.col])IMG["pg_"+g.col]=spPilar(false,g.col);});}
/* ---------- personajes ---------- */
var EMB=/[?&]embed=1/.test(location.search),ONLINE_Q=/[?&]online=1/.test(location.search);
var PC=(function(){try{var v=parseInt(localStorage.getItem("naradak_pc"),10);return v>=0&&v<CHARS.length&&CHARS_INFO[v].k==="humano"?v:4;}catch(e){return 4;}})();
function chImg(c){var im=CIMG[c];if(!im){im=new Image();im.src=CHARS[c];CIMG[c]=im;}return im;}
function dirOf(dx,dy){var sx=dx-dy,sy=dx+dy;return Math.abs(sx)>Math.abs(sy)?(sx<0?1:2):(sy>0?0:3);}
/* ---- Joystick táctil: lo activa/desactiva el servidor (JOYSTICK_ACTIVO en server/servidor.js) ---- */
var JOY={on:false,id:-1,u:0,v:0};
function joyMov(){return(JOY.on&&(JOY.u||JOY.v))?{dx:JOY.v+JOY.u,dy:JOY.v-JOY.u}:null;}   /* pantalla (u→, v↓) a ejes isométricos del mundo */
var P={x:SPAWN.x+.5,y:SPAWN.y+.5,dir:3,mv:0,path:[],bub:null},cam=pj(P.x,P.y),T=0,tmin=8*60,Z=innerWidth<600?1:1.2,near=null,keys={},tgt=null,DPR=1,curSec=0,cool=0,tp=null;
function burbuja(txt,s,y0){cx.save();cx.font="600 11px Karla,sans-serif";cx.textAlign="center";
 var L=[],w=txt.split(" "),ln="";w.forEach(function(p){if((ln+" "+p).length>24&&ln){L.push(ln);ln=p;}else ln=ln?ln+" "+p:p;});if(ln)L.push(ln);L=L.slice(0,4);
 var mw=0;L.forEach(function(l){mw=Math.max(mw,cx.measureText(l).width);});var bw=mw+14,bh=L.length*13+8,bx=s.x-bw/2,by=y0-bh;
 cx.fillStyle="rgba(245,236,210,.95)";cx.strokeStyle="#5a4a2a";cx.lineWidth=1.5;cx.beginPath();cx.rect(bx,by,bw,bh);cx.fill();cx.stroke();
 cx.beginPath();cx.moveTo(s.x-4,by+bh);cx.lineTo(s.x,by+bh+5);cx.lineTo(s.x+4,by+bh);cx.fill();
 cx.fillStyle="#2a1810";L.forEach(function(l,k){cx.fillText(l,s.x,by+13+k*13);});cx.restore();}
function drawChar(c,x,y,dir,mv,t,lab,bub,flash){
 var im=chImg(c);if(!im.complete||!im.naturalWidth)return;var fw=CHARS_INFO[c].w,fh=CHARS_INFO[c].h,s=pj(x,y),f=mv?[1,0,1,2][Math.floor(t*8)%4]:1;
 cx.save();cx.translate(s.x,s.y+4);
 cx.fillStyle="rgba(0,0,0,.3)";cx.beginPath();cx.ellipse(0,0,10,4,0,0,7);cx.fill();
 cx.imageSmoothingEnabled=false;if(flash&&"filter" in cx)cx.filter="brightness(2.4)";cx.drawImage(im,f*fw,dir*fh,fw,fh,-fw/2,-(fh-3),fw,fh);if("filter" in cx)cx.filter="none";
 if(lab){cx.font="700 10px Cinzel,serif";cx.textAlign="center";cx.lineWidth=3;cx.strokeStyle="rgba(20,12,4,.85)";cx.strokeText(lab,0,-fh-2);cx.fillStyle="#f5e6c0";cx.fillText(lab,0,-fh-2);}
 if(bub&&bub.hasta>T)burbuja(bub.txt,{x:0,y:0},-fh-(lab?14:4));
 cx.restore();}
/* ---------- niebla del minimapa ---------- */
var MM=document.createElement("canvas");MM.width=W;MM.height=H;
var FOG=document.createElement("canvas");FOG.width=W;FOG.height=H;var fg=FOG.getContext("2d");fg.fillStyle="#04070a";fg.fillRect(0,0,W,H);
var _rx=-99,_ry=-99;
function revela(x,y,r){var g=fg.createRadialGradient(x,y,r*.55,x,y,r);g.addColorStop(0,"rgba(0,0,0,1)");g.addColorStop(1,"rgba(0,0,0,0)");fg.globalCompositeOperation="destination-out";fg.fillStyle=g;fg.fillRect(x-r,y-r,r*2,r*2);fg.globalCompositeOperation="source-over";_rx=x;_ry=y;}
function hacerMM(){var g=MM.getContext("2d");
 for(var y=0;y<H;y++)for(var x=0;x<W;x++){var i=I(x,y),c;
  if(sec[i]<0)c=tiles[i]?"#16301a":"#05080a";else if(road[i])c=tiles[i].charAt(0)==="p"?"#cdbd8f":"#a58b5a";else if(tiles[i].charAt(0)==="p")c="#9d9684";else if(tiles[i].charAt(0)==="e")c="#8a7648";else c=tiles[i].charAt(0)==="d"?"#4b6a34":"#3f6d2e";
  g.fillStyle=c;g.fillRect(x,y,1,1);}
 OB.forEach(function(o){var n=o.i,x=o.cx|0,y=o.cy|0,c=null;
  if(o.k==="t"||/^t\d$/.test(n))c="#1e3d1c";else if(/^ru_|^torre|^pg_/.test(n))c="#bdb8a6";else if(o.k==="h")c="#a0663e";else if(o.k==="c")c="#c04a38";else if(n==="fogata")c="#ff9a30";else if(/^r\d$/.test(n))c="#777";
  if(c){g.fillStyle=c;g.fillRect(x,y,o.fw||1,o.fh||1);}});}
var mini=$("mini");mini.width=W;mini.height=H;var mx=mini.getContext("2d"),mwrap=$("mwrap"),mEst=0;
function drawMini(){mx.imageSmoothingEnabled=false;mx.clearRect(0,0,mini.width,mini.height);mx.drawImage(MM,0,0);
 GATES.forEach(function(g){mx.fillStyle=g.col;mx.fillRect(g.x-2,g.y-2,5,5);mx.strokeStyle="#000";mx.lineWidth=1;mx.strokeRect(g.x-2.5,g.y-2.5,6,6);});
 mx.fillStyle="#ff9a30";mx.fillRect(CC.x-2,CC.y-2,5,5);
 for(var kt=0;kt<GN*GN;kt++){var TD=TM[kt];if(!TD.built)continue;mx.fillStyle=difColor(TD.dif,.2);mx.fillRect(OX(TD.c),OX(TD.r),S,S);}
 mx.strokeStyle="rgba(120,230,140,.7)";mx.lineWidth=1.5;mx.setLineDash([4,3]);mx.beginPath();mx.arc(CC.x,CC.y,MON_SEGURA,0,7);mx.stroke();mx.setLineDash([]);
 for(var kz=0;kz<GN*GN;kz++){var BZ=TM[kz].boss;if(!BZ)continue;mx.strokeStyle="rgba(230,70,60,.95)";mx.lineWidth=2;mx.beginPath();mx.arc(BZ.x,BZ.y,BZ.r,0,7);mx.stroke();mx.fillStyle="rgba(230,70,60,.9)";mx.font="700 14px sans-serif";mx.textAlign="center";mx.textBaseline="middle";mx.fillText("☠",BZ.x,BZ.y);}
 dMonMini(mx);
 mx.drawImage(FOG,0,0);
 mx.textAlign="center";mx.textBaseline="middle";mx.font="700 30px serif";
 for(var kk=0;kk<GN*GN;kk++){var TS=TM[kk];mx.fillStyle=TS.built?"rgba(255,236,170,.8)":"rgba(255,236,170,.3)";mx.font="700 30px serif";mx.fillText(TS.id===0?"Home":String(TS.id),OX(TS.c)+S/2,OX(TS.r)+S/2);
  if(TS.built){var dq=TS.dif;mx.font="700 "+(mEst===1?12:15)+"px sans-serif";mx.lineWidth=3.5;mx.strokeStyle="rgba(0,0,0,.8)";var l1="♥×"+dq.vida+" ⚔×"+dq.dano,l2="👹×"+dq.cant+" 💰×"+dq.rec,cxm=OX(TS.c)+S/2,cym=OX(TS.r)+S/2;
   mx.strokeText(l1,cxm,cym+26);mx.fillStyle="#fff";mx.fillText(l1,cxm,cym+26);if(mEst===1){mx.strokeText(l2,cxm,cym+42);mx.fillText(l2,cxm,cym+42);}}}
 mx.fillStyle="#6ab0ff";for(var id in RP){var r=RP[id];if(r.lugar==="mundo")mx.fillRect(r.x-2,r.y-2,4,4);}
 mx.fillStyle="#fff";mx.strokeStyle="#c00";mx.lineWidth=1.5;mx.beginPath();mx.arc(P.x,P.y,3.5,0,7);mx.fill();mx.stroke();}
function setMini(e){mEst=e;document.body.classList.toggle("mmOff",e===2);mini.classList.toggle("off",e===2);mwrap.classList.toggle("big",e===1);}
/* ---------- online (servidor local) ---------- */
var ONL={ws:null,id:0,on:false},RP={},ME=(function(){var b=null;try{for(var i=1;i<=5;i++){var j=JSON.parse(localStorage.getItem("naradak_slot_"+i)||"null");if(j&&(!b||(j.savedAt||0)>(b.savedAt||0)))b=j;}}catch(e){}
 return{nombre:b&&b.nombre?String(b.nombre):"Aventurero",clase:b&&b.clase?String(b.clase):"",nivel:b&&b.nivel?b.nivel:1};})();
/* Embebido en el juego se usa la conexión persistente (window.parent.OnlineHub: grupos, raid, chat privado y comercio); standalone: WebSocket propio */
function hubOak(){try{return EMB&&parent&&parent!==window&&parent.OnlineHub?parent.OnlineHub:null;}catch(e){return null;}}
function envia(o){if(ONL.hub){try{ONL.hub.enviar(o);}catch(e){}return;}if(ONL.ws&&ONL.ws.readyState===1)ONL.ws.send(JSON.stringify(o));}
function enLinea(){return ONL.hub?ONL.hub.conectado():!!(ONL.ws&&ONL.ws.readyState===1);}
function avatarOk(a){a=a|0;return CHARS_INFO[a]&&CHARS_INFO[a].k==="humano"?a:4;}
function nRemotos(){var n=0;for(var id in RP)if(RP[id].lugar==="mundo")n++;return n;}
function hudOnline(txt){var h=$("hOnline");if(!h)return;h.textContent=txt||(ONL.on?(enLinea()?"🌐 "+(nRemotos()+1)+" en el mundo":"🌐 conectando…"):"");}
function chatLog(txt){var l=$("clog");if(!l)return;var d=document.createElement("div");d.textContent=txt;l.appendChild(d);while(l.children.length>6)l.removeChild(l.firstChild);setTimeout(function(){if(d.parentNode)d.parentNode.removeChild(d);},12000);}
function rpSet(p){var r=RP[p.id]||(RP[p.id]={id:p.id,x:+p.x||0,y:+p.y||0,tx:+p.x||0,ty:+p.y||0,dir:0,mv:0,bub:null});
 r.nombre=p.nombre||r.nombre||"Jugador";if(p.clase!=null)r.clase=p.clase;if(p.nivel!=null)r.nivel=p.nivel;r.c=avatarOk(p.avatar!=null?p.avatar:r.c);r.lugar=p.lugar||r.lugar||"pueblo";
 if(p.x!=null){r.tx=+p.x||0;r.ty=+p.y||0;if(Math.hypot(r.tx-r.x,r.ty-r.y)>8){r.x=r.tx;r.y=r.ty;}}
 var dm={s:0,w:3,n:3,a:1,d:2,e:2};if(p.dir!=null&&dm[p.dir]!=null)r.dir=dm[p.dir];}
function onMsg(m){
  if(m.t==="hub_cerrado"){RP={};simSrvOff();relojOff();hudOnline();return;}
  if(m.t==="mon_ini"){simSrvOn();return;}
  if(m.t==="mon_s"){monSnap(m);return;}
  if(m.t==="mon_muere"){monMuere(m);return;}
  if(m.t==="mon_atq"){monAtq(m);return;}
  if(m.t==="mon_mapa"){SIM.mm=m.m||[];return;}
  if(m.t==="jefe_aviso"){anunciar(m.msg);chatLog(m.msg);return;}
  if(m.t==="jefe_botin"){botinJefe(m);return;}
  if(m.t==="g_buff"){recibeBuff(m);return;}
  if(m.t==="reloj"){relojRecibe(m);return;}
  if(m.t==="bienvenido"){ONL.id=m.id;RP={};m.jugadores.forEach(rpSet);if(ONL.hub)envia({t:"lugar",lugar:"mundo",x:P.x,y:P.y});relojIniciar();}
  else if(m.t==="entra")rpSet(m.jugador);
  else if(m.t==="sale")delete RP[m.id];
  else if(m.t==="lugar"){var r=RP[m.id];if(r){r.lugar=m.lugar;if(m.x!=null){r.x=r.tx=+m.x;r.y=r.ty=+m.y;}}}
  else if(m.t==="mueve"){var q=RP[m.id];if(q){q.tx=+m.x;q.ty=+m.y;if(m.dir)rpSet({id:m.id,dir:m.dir});}}
  else if(m.t==="info"){var q2=RP[m.id];if(q2)q2.nivel=m.nivel;}
  else if(m.t==="chat"){chatLog(m.nombre+": "+m.texto);var b={txt:m.texto,hasta:T+6};if(m.id===ONL.id)P.bub=b;else if(RP[m.id])RP[m.id].bub=b;}
  else if(m.t==="error"){chatLog("⚠ "+m.msg);if(!ONL.hub)ONL.on=false;}
  hudOnline();
}
function conectar(){
 var H=hubOak();
 if(H){
  ONL.hub=H;
  try{if(ONL.unsub)ONL.unsub();}catch(e){}
  ONL.unsub=H.suscribir(onMsg);
  ["pointerdown","keydown"].forEach(function(ev){addEventListener(ev,function(){try{H.tocar();}catch(e){}},true);});
  addEventListener("pagehide",function(){try{ONL.unsub();}catch(e){}});
  if(H.conectado()){envia({t:"lugar",lugar:"mundo",x:P.x,y:P.y});relojIniciar();}
  hudOnline();return;
 }
 var ws=new WebSocket((location.protocol==="https:"?"wss://":"ws://")+location.host+"/ws");ONL.ws=ws;hudOnline();
 ws.onopen=function(){envia({t:"hola",tk:(window.nrdkCuenta&&window.nrdkCuenta.token)||"",nombre:ME.nombre,clase:ME.clase,nivel:ME.nivel,avatar:PC,lugar:"mundo",x:P.x,y:P.y});hudOnline();};
 ws.onmessage=function(e){var m;try{m=JSON.parse(e.data);}catch(x){return;}onMsg(m);};
 ws.onclose=function(){ONL.ws=null;RP={};hudOnline();if(ONL.on)setTimeout(conectar,3000);};}
/* Hablar con otro jugador: Invitar a grupo · Comerciar · Chat privado */
var JM=null,JMid=0,JMnpc=null;
function cerrarJM(){JMid=0;JMnpc=null;if(JM)JM.style.display="none";}
function abrirJugador(id){
 var r=RP[id],H=ONL.hub;if(!r)return;JMid=id;
 if(!JM){
  JM=document.createElement("div");
  JM.style.cssText="position:fixed;left:50%;bottom:90px;transform:translateX(-50%);z-index:95;min-width:230px;max-width:90vw;padding:12px;background:rgba(20,12,4,.94);color:#f5e6c0;border:2px solid #5a4a2a;border-radius:6px;font-family:Karla,sans-serif;text-align:center";
  JM.addEventListener("pointerdown",function(e){e.stopPropagation();});
  document.body.appendChild(JM);
 }
 JM.innerHTML="";
 var t=document.createElement("div");t.style.cssText="font-family:Cinzel,serif;font-size:16px;color:#e8c9a0";t.textContent=r.nombre;JM.appendChild(t);
 var st=document.createElement("div");st.style.cssText="font-size:12px;color:#b8a888;margin:2px 0 8px";st.textContent="Nv "+(r.nivel||"?")+(r.clase?" · "+r.clase:"");JM.appendChild(st);
 function btn(txt,fn,css){var b=document.createElement("button");b.textContent=txt;b.style.cssText="display:block;width:100%;margin-top:6px;padding:8px 10px;font-family:Cinzel,serif;font-size:13px;background:#8b6f47;color:#f5f1e8;border:2px solid #5a4a2a;border-radius:4px;cursor:pointer;"+(css||"");b.onclick=fn;JM.appendChild(b);}
 if(!H){var n=document.createElement("div");n.style.cssText="font-size:12px";n.textContent="Grupo, comercio y chat privado solo están disponibles al jugar desde el juego principal.";JM.appendChild(n);}
 else{
  var enG=H.esMiembro(id);
  btn(enG?"👥 Ya está en tu grupo":"👥 Invitar a grupo",function(){if(!enG)H.invitar(id);cerrarJM();});
  btn("🤝 Comerciar",function(){H.comerciar(id);cerrarJM();});
  btn("💬 Chat privado",function(){H.susurrar(id);cerrarJM();});
 }
 btn("Cerrar",cerrarJM,"background:#4a3a24");
 JM.style.display="block";
}
function irAJugador(id){var r=RP[id];if(!r)return;if(Math.hypot(r.x-P.x,r.y-P.y)<2.7){abrirJugador(id);return;}P.talkR=id;ir(Math.floor(r.x),Math.floor(r.y)+1);}
function onlineIniciar(){if(ONL.on)return;if(location.protocol.indexOf("http")!==0){chatLog("⚠ Abre el juego desde el servidor local (http://IP:8080).");return;}
 ONL.on=true;$("chat").style.display="block";conectar();setInterval(function(){if(enLinea())relojIniciar();},60000);}   /* re-mide el reloj cada minuto */
Mundo.online=onlineIniciar;
Mundo.live=function(){return {hp:PS.hp,max:PS.max,mp:PS.mp,mpMax:PS.mpMax};};   /* vida y recurso en directo (panel Personaje) */
/* ============================================================
   MONSTRUOS DEL MUNDO ABIERTO — generación por sector con multiplicadores
   · Cada sector construido (TM[k].dif) define sus multiplicadores: vida, daño, cantidad, recompensa, agresividad, velocidad.
   · Las stats base salen del juego (BIOMAS[1] + _normalEnemigo, igual que el Laberinto/Mazmorra) y se multiplican por el sector.
   · Zonas seguras: el campamento (radio MON_SEGURA) y las puertas de piedra. Solo aparecen en celdas alcanzables.
   · Reaparecen solos (MON_RESP) lejos del jugador; el 6 % son "Alfa" (más vida/daño y ×2,5 de botín).
   · Combate: ataque básico con la stats reales del personaje (calcStats). Clic en un monstruo = ir y atacarlo,
     Espacio / J = atacar al más cercano, botón ⚔ en pantalla táctil. Recompensa: XP + botín del juego (dropearLoot).
   · Standalone (sin el juego padre) usa stats por defecto y no guarda nada.
   ============================================================ */
var SPR_DUR=4,SPR_CD=12,SPR_MULT=1.6;   /* sprint: dura SPR_DUR s y luego enfría SPR_CD s */

var MON_SPR=[[/Slime/,104],[/Goblin|Duende/,114],[/Champi/,109],[/Lobo/,124],[/Ara[ñn]a/,149],[/Ent /,126],[/Bandido/,106]],
    MON_ESC={104:1.9,109:2.1,114:1.2},MON_TOP={114:20};
var MON=[],MONRESP=[],NOMON=new Uint8Array(N),REACH=new Uint8Array(N),FX=[],MUERTE=null,MONT=0,MONID=0;
var PS={hp:300,max:300,mp:100,mpMax:100,atkT:0,reg:0,comb:0,regW:0,sync:0,tg:null,rep:0,hold:false,kills:0,rst:0,sinDano:true,
 cd:[0,0,0,0,0],habs:[],habSig:"",potT:0,defB:0,defT:0,sh:0,shT:0,invT:0,stunT:0,silT:0,resStun:0,castT:0,castMax:.4,castCol:"#fff",swing:0,sw:false,face:Math.PI/4,hurt:0,
 dashT:0,dvx:0,dvy:0,dashB:0,dashHit:null,nx:null,sprint:false,sprT:0,sprCd:0,enC:false},SJ=null,_difTxt="";
function pw(){try{var p=EMB&&parent&&parent!==window?parent:null;return p&&p.G&&p.G.j&&p.calcStats&&p.danoMitigado?p:null;}catch(e){return null;}}
function mrnd(a,b){return a+Math.floor(Math.random()*(b-a+1));}
function monSprite(nb){for(var i=0;i<MON_SPR.length;i++)if(MON_SPR[i][0].test(nb))return MON_SPR[i][1];return 124;}
function monNombre(){var t=0,k;for(k=0;k<MON_PES.length;k++)t+=MON_PES[k];var r=Math.random()*t;for(k=0;k<MON_PES.length;k++){r-=MON_PES[k];if(r<0)return MON_NOM[k];}return MON_NOM[0];}
/* ---- stats del jugador (del juego padre si existe) ---- */
var M0=new Proxy({},{get:function(){return 0;}});
function armaHabs(j,Wp){
 var ra=Wp.ramaAct?Wp.ramaAct(j):null,sig=j.clase+"|"+j.nivel+"|"+(ra&&j.tal?ra.n+":"+(j.tal.act||[]).join(","):"");
 if(sig===PS.habSig)return;PS.habSig=sig;
 var M=Wp.talMods(j),hab=(Wp.HABILIDADES[j.clase]||[]).slice(0,3).map(function(h,i){return Object.assign({},h,{costo:Wp.costoHab(j,h.costo),desc:h.desc+Wp.baseBonoTxt(j,i)});});
 if(ra&&j.tal&&j.tal.act)[ra.h1,ra.h2].forEach(function(sk){if(j.tal.act.indexOf(ra.n+"_"+sk.s)>=0)hab.push({n:sk.n,costo:Wp.costoHab(j,sk.c),desc:sk.d+Wp.habBonoTxt(j,sk),efecto:"rama",cd:Math.max(1,sk.cd-M[sk.s+"cd"]),rama:sk});});
 PS.habs=hab;PS.cd=[0,0,0,0,0].map(function(v,i){return PS.cd[i]||0;});
}
function refrescaSJ(){
 var Wp=pw();
 if(Wp){try{var j=Wp.G.j,st=Wp.calcStats(j),cl=(Wp.CLASES&&Wp.CLASES[j.clase])||{};
  SJ={j:j,W:Wp,st:st,M:Wp.talMods(j),atkMin:st.atkMin,atkMax:st.atkMax,def:st.def,max:st.vidaMax,mpMax:st.recursoMax,probEsq:st.probEsq||0,redFis:st.redFis||0,redMag:st.redMag||0,crit:(cl.crit||5)+(st.critB||0),cm:st.critMult||1.5,clase:j.clase,col:cl.color||"#e8c9a0",vel:(Wp.velJugador?Wp.velJugador(j):1)||1};
  armaHabs(j,Wp);}catch(e){Wp=null;}}
 if(!Wp)SJ={j:null,W:null,st:{atkMin:22,atkMax:32,def:12,vidaMax:300,recursoMax:100,critB:0,critMult:1.5,potencia:1,probEsq:0,redFis:0,redMag:0},M:M0,atkMin:22,atkMax:32,def:12,max:300,mpMax:100,probEsq:0,redFis:0,redMag:0,crit:10,cm:1.5,clase:"",col:"#e8c9a0",vel:1};
 PS.max=Math.max(1,SJ.max);PS.mpMax=Math.max(1,SJ.mpMax);if(PS.hp>PS.max)PS.hp=PS.max;if(PS.mp>PS.mpMax)PS.mp=PS.mpMax;}
var MELEE={Guerrero:1,Paladin:1,Asesino:1};
function sprintOn(){if(PS.sprT>0){PS.sprT=0;PS.sprCd=SPR_CD*.6;return;}if(PS.sprCd>0)return;PS.sprT=SPR_DUR;PS.sprCd=0;}   /* pulsar de nuevo cancela y deja un enfriamiento menor */
function esMelee(){return !!(SJ&&MELEE[SJ.clase]);}
function reachJ(){var c=SJ?SJ.clase:"";return c==="Mago"||c==="Arquero"?6:c==="Clérigo"?4:2.6;}   /* alcance del ataque básico, en celdas */
function enCampo(){return Math.hypot(P.x-CC.x,P.y-CC.y)<MON_SEGURA-.5;}
/* ---- zonas prohibidas para monstruos y celdas alcanzables ---- */
function monMapa(){
 var x,y,i;
 for(y=Math.floor(CC.y-MON_SEGURA-1);y<=CC.y+MON_SEGURA+1;y++)for(x=Math.floor(CC.x-MON_SEGURA-1);x<=CC.x+MON_SEGURA+1;x++)if(inb(x,y)&&Math.hypot(x+.5-CC.x,y+.5-CC.y)<MON_SEGURA)NOMON[I(x,y)]=1;
 GATES.forEach(function(g){for(var b=-5;b<=5;b++)for(var a=-5;a<=5;a++){var X=g.x+a,Y=g.y+b;if(inb(X,Y)&&a*a+b*b<=25)NOMON[I(X,Y)]=1;}});
 for(var kb in TM){var bz=TM[kb].boss;if(!bz)continue;for(var b=-bz.r-2;b<=bz.r+2;b++)for(var a=-bz.r-2;a<=bz.r+2;a++){var X=Math.floor(bz.x)+a,Y=Math.floor(bz.y)+b;if(inb(X,Y)&&a*a+b*b<=(bz.r+2)*(bz.r+2))NOMON[I(X,Y)]=1;}}
 var q=new Int32Array(N),qh=0,qt=0,seeds=[{x:Math.floor(SPAWN.x),y:Math.floor(SPAWN.y)}];
 GATES.forEach(function(g){seeds.push(g.out);});
 seeds.forEach(function(s){if(!inb(s.x,s.y))return;var c=I(s.x,s.y);if(!blk[c]&&!REACH[c]){REACH[c]=1;q[qt++]=c;}});
 while(qh<qt){var c0=q[qh++],cx0=c0%W,cy0=(c0/W)|0;for(var k=0;k<4;k++){var X2=cx0+DX[k],Y2=cy0+DY[k];if(!inb(X2,Y2))continue;var j=I(X2,Y2);if(blk[j]||REACH[j])continue;REACH[j]=1;q[qt++]=j;}}}
function celdaSpawn(sk,minD){
 var T0=TM[sk],ox=OX(T0.c),oy=OX(T0.r);
 for(var n=0;n<120;n++){var x=ox+4+Math.floor(Math.random()*(S-8)),y=oy+4+Math.floor(Math.random()*(S-8)),i=I(x,y);
  if(blk[i]||!REACH[i]||NOMON[i]||sec[i]!==sk)continue;
  if(road[i]&&Math.random()<.6)continue;
  if(minD&&Math.hypot(x+.5-P.x,y+.5-P.y)<minD)continue;
  return{x:x+.5,y:y+.5};}
 return null;}
/* ---- creación de un monstruo con los multiplicadores de su sector ---- */
function crearMon(sk,x,y,nb,pack,spec){
 var d=TM[sk].dif,Wp=pw(),alfa=spec?!!spec.alfa:Math.random()<MON_ALFA,en,pe=d.pe;nb=nb||monNombre();
 if(Wp&&Wp._normalEnemigo&&Wp.BIOMAS&&Wp.BIOMAS[1]){en=Wp._normalEnemigo(nb,Wp.BIOMAS[1],1.2,Math.min(9,pe),pe);en.vida=Math.floor(en.vida*(Wp.ENEM_VIDA_F||1.75));}
 else{en={nombre:nb,tipo:"normal",vida:Math.floor((80+Math.min(9,pe)*2+pe*1.2)*1.44*1.75),atkMin:Math.floor((15+Math.min(9,pe)+pe*.28)*1.44*.9),atkMax:Math.floor((15+Math.min(9,pe)+pe*.28)*1.44*1.1),def:Math.floor((15+Math.min(9,pe)+pe*.45)*1.38),xp:15+pe*2,oro:8+pe*2};}
 var fv=d.vida*(alfa?2:1),fd=d.dano*(alfa?1.4:1);
 en.vida=Math.max(1,Math.floor(en.vida*fv));en.vidaMax=en.vida;
 en.atkMin=Math.max(1,Math.floor(en.atkMin*fd));en.atkMax=Math.max(en.atkMin,Math.floor(en.atkMax*fd));
 en.def=Math.floor(en.def*(1+(d.vida-1)*.5)*(alfa?1.25:1));en.bid=1;
 if(Wp&&Wp.armarEnemigo){try{Wp.armarEnemigo(en);}catch(e){}}
 var c=monSprite(nb),inf=CHARS_INFO[c]||{w:48,h:52};
 en.id=spec?spec.id:++MONID;en.sk=sk;en.x=x;en.y=y;en.hx=x;en.hy=y;en.c=c;en.alfa=alfa;en.pack=pack||0;
 en.esc=42*(MON_ESC[c]||1)*(alfa?1.3:1)/inf.h;
 en.rec=d.rec*(alfa?2.5:1);en.spd=(2.9+(c===124?.9:0)+(c===104?-.6:0))*d.vel*(alfa?1.1:1);
 en.agro=6.5*d.agro;
 if(spec){en.vida=en.vidaMax=spec.vm;en.atkMin=spec.a0;en.atkMax=spec.a1;en.def=spec.df;en.xp=spec.xp;en.oro=spec.oro;en.rec=spec.rec;en.spd=spec.spd;en.agro=spec.agro;en.hx=spec.hx;en.hy=spec.hy;}
 en.tx=x;en.ty=y;
 en.reach=1.1;en.st="idle";en.cd=.6+Math.random();en.wt=Math.random()*3;en.wx=x;en.wy=y;en.dir=Math.floor(Math.random()*4);en.mv=0;en.ph=Math.random()*5;
 if(IAM)IAM.initMon(en,nb);
 en.flash=0;en.muerto=false;en.mt=0;en.bias=Math.random()<.5?1:-1;en.stunT=0;en.kx=0;en.ky=0;en.wind=0;en.windMax=.42;en.windA=0;en.ux=x*U;en.uy=y*U;
 en.r=Math.max(10,Math.min(26,inf.w*en.esc*.3));en.alt=Math.max(30,(inf.h-(MON_TOP[c]||inf.h*.12))*en.esc);en.col=alfa?"#ff7a2a":"#a65a3c";
 if(spec&&spec.jf){var ij=CHARS_INFO[spec.c]||{w:48,h:72},jd=jefeDef(spec.jid);
  en.jefe=1;en.tipo="jefe";en.nombre=spec.nb+(jd?" · Nv "+jd.nivel:"");en.c=spec.c;en.esc=spec.esc;en.r=spec.r;en.alt=ij.h*spec.esc*.9;en.col="#ffd24a";en.tipoDano=jd&&jd.td||"fisico";
  en.pEsq=0;en.pAbs=0;en.pBloq=0;en.pCrit=6;en.critMult=1.5;en.jd=jd;en.windK=0;en.buffT=0;}
 MON.push(en);return en;}
function jefeDef(id){for(var i=0;i<JEFES.length;i++)if(JEFES[i].id===id)return JEFES[i];return null;}
function habJ(e,k){var d=e&&e.jd;if(!d)return null;for(var i=0;i<d.habs.length;i++)if(d.habs[i].k===k)return d.habs[i];return null;}
function monVivos(sk){var n=0;for(var i=0;i<MON.length;i++)if(MON[i].sk===sk&&!MON[i].muerto)n++;return n;}
function monObjetivo(sk){return Math.min(MON_MAX_SEC,Math.round(MON_BASE*TM[sk].dif.cant));}
function spawnManada(sk,tope){
 var c=celdaSpawn(sk,0);if(!c)return 0;
 var n=Math.min(tope||3,1+(Math.random()<.5?1:0)+(Math.random()<.2?1:0)),nb=Math.random()<.7?monNombre():null,pk=++MONID,k=0;
 for(var a=0;a<n*6&&k<n;a++){var x=Math.floor(c.x+(Math.random()-.5)*5),y=Math.floor(c.y+(Math.random()-.5)*5);
  if(!inb(x,y)||blk[I(x,y)]||!REACH[I(x,y)]||NOMON[I(x,y)]||sec[I(x,y)]!==sk)continue;
  crearMon(sk,x+.5,y+.5,nb,pk);k++;}
 return k;}
function monIniciar(){
 monMapa();refrescaSJ();
 var Wp=SJ.W;PS.hp=Wp?Math.max(1,Math.min(PS.max,Math.floor(SJ.j.vida)||PS.max)):PS.max;
 monPoblar();}
function monPoblar(){
 for(var k=0;k<GN*GN;k++){if(!TM[k].built)continue;var obj=monObjetivo(k),g=0;while(monVivos(k)<obj&&g++<80)spawnManada(k,obj-monVivos(k));}}
/* ============================================================
   SIMULACIÓN EN EL SERVIDOR (modo online)
   · El servidor (server/mundo_sim.js) es el anfitrión: crea, mueve, hace atacar y reaparecer a los monstruos y reparte
     su estado (mon_s, 10 Hz) a todos los jugadores del mundo. Este cliente solo interpola ("títeres") y envía sus golpes
     (mon_hit), aturdimientos y efectos (mon_fx). Los golpes de un monstruo llegan en mon_atq con la lista de jugadores
     alcanzados; cada cliente aplica su propia mitigación (defensa, esquiva, escudos) con golpeMon().
   · Si el servidor no tiene la simulación o se cae la conexión, el cliente vuelve a simular los monstruos en local.
   ============================================================ */
var SIM={on:false,mm:[]};
function byId(id){for(var i=0;i<MON.length;i++)if(MON[i].id===id)return MON[i];return null;}
function simSrvOn(){SIM.on=true;MON.length=0;MONRESP.length=0;SIM.mm=[];PS.tg=null;envia({t:"mon_est",mu:MUERTE?1:0});}
function simSrvOff(){if(!SIM.on)return;SIM.on=false;MON.length=0;MONRESP.length=0;SIM.mm=[];PS.tg=null;monPoblar();}
var ST_N=["idle","chase","back"];
function monSnap(m){
 if(!SIM.on)return;
 (m.d||[]).forEach(function(id){var q=byId(id);if(q&&!q.muerto){if(PS.tg===q)PS.tg=null;MON.splice(MON.indexOf(q),1);}});
 (m.a||[]).forEach(function(s){if(byId(s.id))return;crearMon(s.sk,s.x,s.y,s.nb,s.pack,s);});
 (m.m||[]).forEach(function(r){
  var e=byId(r[0]);if(!e||e.muerto)return;
  e.claim=0;e.tx=r[1];e.ty=r[2];e.vida=r[3];
  if(r[4]===1&&e.st!=="chase"){ftxt(e.x,e.y,"!","#ff6a4a",16,46);if(Math.hypot(e.x-P.x,e.y-P.y)<14){PS.comb=Math.max(PS.comb,4);PS.regW=REGEN_ESPERA;}}
  e.st=ST_N[r[4]]||"idle";
  if(r[5]>0&&!(e.wind>0))e.windMax=(!e.jefe&&r.length>9&&r[9]>0)?r[9]:.42*(e.alfa?.9:1);
  e.wind=r[5];e.windA=r[6];e.stunT=r[7];e.def=r[8];
  if(e.jefe&&r.length>9){e.windK=r[9]|0;if(r[5]>0)e.windMax=r[10]||e.windMax;e.buffT=r[11]||0;}});
}
/* ---- botín del jefe: llega del servidor (una tirada por muerte) · objeto = solo para el líder del equipo, que lo reparte por comercio ---- */
function botinJefe(m){
 var Wp=SJ&&SJ.W,j=SJ&&SJ.j,tx=[];
 if(!Wp||!j){chatLog("☠ "+m.jefe+" ha caído.");return;}
 try{
  var n0=j.nivel,lg=Wp.G.log,it=null;Wp.G.log=[];
  if(m.xp>0)Wp.ganarXP(j,m.xp);
  Wp.G.log=lg;
  if(m.oro>0)j.oro=(j.oro||0)+m.oro;
  if(m.item&&m.para===ONL.id){var r=(Wp.RECETAS_FORJA||[]).filter(function(a){return a[0]===m.item;})[0];if(r){it=Wp.copiaItem(Wp.recetaObj(r));Wp.equipoBolsa(j).push(it);}}
  Wp.guardar();
  if(j.nivel>n0){refrescaSJ();PS.hp=PS.max;PS.mp=PS.mpMax;ftxt(P.x,P.y,"★ Nivel "+j.nivel,"#ffe080",18,80);}
  tx.push("☠ "+m.jefe+" derrotado · +"+m.xp+" XP");
  if(m.oro>0)tx.push("💰 +"+m.oro+" oro (botín del equipo)");
  if(m.item)tx.push("🏆 "+m.rareza+": "+m.item+" ("+m.clase+") → "+(m.para===ONL.id?"tú (reparte el botín por comercio)":m.paraNombre));
  if(m.oro>0)ftxt(P.x,P.y,"+"+m.oro+" oro","#f0c040",14,70);
  if(m.item)anunciar("🏆 "+m.rareza+": "+m.item);else anunciar("☠ "+m.jefe+" derrotado");
  tx.forEach(chatLog);
 }catch(e){}}
var JB=null;
function hudJefe(){
 var b=null,bd=1e9,i;
 for(i=0;i<MON.length;i++){var q=MON[i];if(!q.jefe||q.muerto)continue;var d=Math.hypot(q.x-P.x,q.y-P.y);if(d<bd){bd=d;b=q;}}
 if(!JB){JB=document.createElement("div");JB.style.cssText="position:fixed;top:76px;left:50%;transform:translateX(-50%);z-index:56;pointer-events:none;width:min(440px,78vw);font-family:Cinzel,serif;text-align:center;display:none;text-shadow:1px 1px 2px #000";
  JB.innerHTML='<div class="jN" style="color:#ffd24a;font-size:14px;font-weight:700"></div><div style="height:14px;background:rgba(0,0,0,.7);border:2px solid #6a4a1a;border-radius:7px;overflow:hidden;margin-top:2px"><div class="jH" style="height:100%;width:100%;background:linear-gradient(#e0a030,#a06010)"></div></div><div class="jT" style="color:#f5e6c0;font-size:11px;font-family:Karla,sans-serif;font-weight:700;margin-top:1px"></div>';
  document.body.appendChild(JB);}
 if(!b||bd>34||(b.vida>=b.vidaMax&&b.st!=="chase"&&bd>14)){JB.style.display="none";return;}
 var hb=b.windK?habJ(b,b.windK):null,tt="♥ "+Math.max(0,Math.ceil(b.vida))+" / "+b.vidaMax+(b.buffT>0?"  ·  🛡 "+((b.jd.habs.filter(function(h){return h.df||h.shield;})[0]||{}).n||"Defensa"):"")+(hb&&b.wind>0?"  ·  ⚠ "+hb.n:"")+(b.stunT>0?"  ·  💫":"");
 JB.style.display="block";JB.querySelector(".jN").textContent="♛ "+b.nombre+(b.jd?" · "+b.jd.t:"");
 JB.querySelector(".jH").style.width=pc(b.vida,b.vidaMax)+"%";JB.querySelector(".jT").textContent=tt;}
function monMuere(m){
 var e=byId(m.id);if(!e||e.muerto)return;
 e.x=e.tx=m.x;e.y=e.ty=m.y;e.ux=e.x*U;e.uy=e.y*U;e.vida=0;
 matarLocal(e,m.by===ONL.id||(m.eq&&m.eq.indexOf(ONL.id)>=0));}
function monAtq(m){
 var e=byId(m.id);if(!e||e.muerto)return;
 var CD=(SJ&&SJ.W&&SJ.W.COLOR_DANO)||{fisico:"#e05050",magico:"#b070e0"},hb=e.jefe&&m.k?habJ(e,m.k):null,rad=e.r+14+34+(hb&&hb.r||0),ex=e.x*U,ey=e.y*U;
 e.wind=0;e.windA=m.a;e.windK=0;
 if(hb&&!hb.m){fx({k:"rune",x:ex,y:ey,r:70,col:hb.col,life:.8,low:true});motas(ex,ey,10,hb.col,e.r*1.2,60,.9);ftxt(e.x,e.y,(hb.heal&&!hb.df&&!hb.shield?"✚ ":hb.dm&&!hb.df&&!hb.shield&&!hb.heal?"⚔ ":"🛡 ")+hb.n,hb.col,13,76);if(hb.heal&&m.hl>0)ftxt(e.x,e.y,"+"+m.hl,"#7ab88a",13,62);return;}
 fx({k:"slash",x:ex,y:ey,a:m.a,r:rad,arc:hb?hb.arc*Math.PI*2:Math.PI*1.1,w:hb?12:8,col:hb?hb.col:CD[e.tipoDano||"fisico"],flip:Math.random()<.5,life:hb?.3:.22});
 if(hb){boom(ex+Math.cos(m.a)*rad*.7,ey+Math.sin(m.a)*rad*.7,hb.k===1?46:30,hb.col);SHK=Math.max(SHK,hb.k===1?6:3);ftxt(e.x,e.y,hb.n,hb.col,13,76);
  if(hb.robo&&m.hl>0)ftxt(e.x,e.y,"+"+m.hl,"#7ab88a",12,62);}
 if(!MUERTE&&m.h&&m.h.indexOf(ONL.id)>=0)golpeMon(e,(hb?hb.m:1)*(m.dm||1),hb?hb.stun:0);}
function monStepSrv(dt){
 for(var i=MON.length-1;i>=0;i--){var m=MON[i];
  if(m.muerto){m.mt+=dt;if(m.mt>.9){if(PS.tg===m)PS.tg=null;MON.splice(i,1);}continue;}
  if(m.flash>0)m.flash-=dt;if(m.wind>0)m.wind=Math.max(0,m.wind-dt);if(m.stunT>0)m.stunT-=dt;
  var dx=m.tx-m.x,dy=m.ty-m.y,d=Math.hypot(dx,dy);
  if(d>6){m.x=m.tx;m.y=m.ty;m.mv=0;}
  else if(d>.01){var f=Math.min(1,dt*14);m.x+=dx*f;m.y+=dy*f;m.mv=d>.05?1:0;if(m.mv)m.dir=dirOf(dx,dy);}
  else m.mv=0;
  if(m.wind>0){m.mv=0;m.dir=dirOf(Math.cos(m.windA),Math.sin(m.windA));}
  m.ux=m.x*U;m.uy=m.y*U;}}
/* ---- reloj del mundo online: la hora la marca el servidor y es la misma para todos ---- */
var CLK={n:0,env:0,best:null,off:0,ok:false};
function relojPadre(on){try{parent.postMessage({naradak:"reloj_online",on:!!on},"*");}catch(e){}}
function relojPedir(){CLK.env=performance.now();envia({t:"reloj",c:CLK.env});}
function relojIniciar(){CLK.n=0;CLK.best=null;relojPedir();}
function relojRecibe(m){
 var rec=performance.now(),rtt=rec-(+m.c),ah=+m.ahora,ini=+m.inicio;
 if(!(rtt>=0)||!isFinite(ah)||!isFinite(ini))return;
 var off=ah+rtt/2-ini-rec;
 if(!CLK.best||rtt<CLK.best.rtt)CLK.best={rtt:rtt,off:off};
 CLK.off=CLK.best.off;if(!CLK.ok){CLK.ok=true;relojPadre(true);}
 if(++CLK.n<5)setTimeout(relojPedir,90);}
function relojSrv(){return 8*60+((performance.now()+CLK.off)/1000)*MIN_S;}
function relojOff(){if(CLK.ok){CLK.ok=false;relojPadre(false);}}
setInterval(function(){if(CLK.ok)relojPadre(true);},4000);   /* latido: el juego principal oculta su reloj mientras llega */
addEventListener("pagehide",function(){relojOff();});
/* ---- IA ---- */
function monLibre(x,y){var X=Math.floor(x),Y=Math.floor(y);if(!inb(X,Y))return false;var i=I(X,Y);return !blk[i]&&!NOMON[i]&&sec[i]>=0;}
/* IA de comportamientos (tilemap/js/mundo_ia.js): navegación sin atascos y tácticas. Si no está cargada, se usa la IA básica de abajo. */
var IAM=(typeof MundoIA!=="undefined"&&MundoIA)||null,NAVC=null;
function navMon(){return NAVC||(IAM?(NAVC=IAM.crearNav(W,H,monLibre)):null);}
function monPaso(m,tx,ty,sp,dt){
 var nv=navMon();if(nv){var ox=m.x,oy=m.y;nv.paso(m,tx,ty,sp,dt);if(m.x!==ox||m.y!==oy)m.dir=dirOf(m.x-ox,m.y-oy);return;}
 var dx=tx-m.x,dy=ty-m.y,d=Math.hypot(dx,dy);if(d<.05){m.mv=0;return;}
 var a0=Math.atan2(dy,dx),st=Math.min(d,sp*dt),angs=m.bias>0?[0,.7,-.7,1.4,-1.4]:[0,-.7,.7,-1.4,1.4];
 for(var k=0;k<5;k++){var a=a0+angs[k],nx=m.x+Math.cos(a)*st,ny=m.y+Math.sin(a)*st;
  if(monLibre(nx,ny)){m.x=nx;m.y=ny;m.dir=dirOf(Math.cos(a),Math.sin(a));m.mv=1;if(k)m.bias=angs[k]>0?1:-1;return;}}
 m.mv=0;}
/* ============================================================
   COMBATE DE ACCIÓN — habilidades, arma y efectos iguales a los del combate en tiempo real del juego (combate_demo.js)
   · Unidades de combate: 1 celda = U (32) unidades = 32 px de pantalla en isométrico (pjU = pj en unidades).
   · Los monstruos guardan x,y en celdas y su espejo ux,uy en unidades (se actualiza cada fotograma).
   ============================================================ */
var U=32,FXL=[],TXL=[],TML=[],PRL=[],FLS=null,SHK=0,MAXM=230,MAXT=320;
function pjU(x,y){return{x:x-y,y:(x+y)*.5};}
function clamp(v,a,b){return v<a?a:v>b?b:v;}
function rf(a,b){return a+Math.random()*(b-a);}
function angd(a,b){var d=a-b;while(d>Math.PI)d-=2*Math.PI;while(d<-Math.PI)d+=2*Math.PI;return d;}
function hexA(h,a){var m=/^#([0-9a-f]{6})$/i.exec(h||"");if(!m)return "rgba(255,255,255,"+a+")";var n=parseInt(m[1],16);return "rgba("+(n>>16)+","+((n>>8)&255)+","+(n&255)+","+a+")";}
function fx(o){if(FXL.length>420)return o;if(o.t===undefined)o.t=0;FXL.push(o);return o;}
function destello(col,a){FLS={col:col,a:a};}
function txt(x,y,t,col,sz,lift){var p=pjU(x,y);TXL.push({x:p.x,y:p.y-14-(lift===undefined?24:lift)*1.2,t:t,col:col,sz:sz||14,a:0,life:.9,vx:rf(-14,14)});}
function ftxt(x,y,t,col,sz,lift){txt(x*U,y*U,t,col,sz,lift===undefined?24:lift*.8);}   /* x,y en celdas */
function PX(){return P.x*U;}function PY(){return P.y*U;}
function chispas(x,y,n,col,v,life,z){for(var i=0;i<n;i++){var a=Math.random()*6.283,s=rf(.4,1)*v;fx({k:"pt2",sh:"line",x:x,y:y,z:z===undefined?18:z,vx:Math.cos(a)*s,vy:Math.sin(a)*s,vz:rf(40,130),g:260,life:rf(.5,1)*life,col:col,sz:rf(1.5,3)});}}
function motas(x,y,n,col,rad,vz,life){for(var i=0;i<n;i++){var a=Math.random()*6.283,r=Math.random()*rad;fx({k:"pt2",sh:"glow",x:x+Math.cos(a)*r,y:y+Math.sin(a)*r,z:rf(0,16),vx:0,vy:0,vz:vz*rf(.6,1.2),g:-10,t:-Math.random()*.25,life:life*rf(.7,1.1),col:col,sz:rf(2,4.2)});}}
function humo(x,y,n,col,rad,life,r1){for(var i=0;i<n;i++){var a=Math.random()*6.283,r=Math.random()*rad;fx({k:"puff",x:x+Math.cos(a)*r,y:y+Math.sin(a)*r,z:rf(2,14),vx:Math.cos(a)*rf(10,50),vy:Math.sin(a)*rf(10,50),vz:rf(8,28),g:0,t:-Math.random()*.12,life:life*rf(.75,1.15),col:col,r0:rf(6,10),r1:r1*rf(.7,1.2),al:.55});}}
function hielo(x,y,n,rad){for(var i=0;i<n;i++){var a=i/n*6.283+rf(-.2,.2),s=rad*rf(1.4,2.4);fx({k:"pt2",sh:"shard",x:x,y:y,z:8,vx:Math.cos(a)*s,vy:Math.sin(a)*s,vz:rf(60,150),g:300,rot:Math.random()*6,sp:rf(-6,6),sz:rf(2.5,4.5),life:rf(.45,.8),col:i%2?"#e8f6ff":"#8fd0f0"});}}
function lluvia(cx0,cy0,rad,n,col,tv,w,len){for(var i=0;i<n;i++){var a=Math.random()*6.283,r=Math.sqrt(Math.random())*rad,x=cx0+Math.cos(a)*r,y=cy0+Math.sin(a)*r,lf=.2,dl=Math.max(0,tv-lf)+Math.random()*.07;
 (function(x,y){fx({k:"drop",x:x,y:y,H:rf(240,300),dx:rf(-40,-20),col:col,w:w||2.6,len:len||26,t:-dl,life:lf,fin:function(){fx({k:"flare",x:x,y:y,z:4,col:col,s:9,life:.2});humo(x,y,1,"#b8a888",6,.4,16);}});})(x,y);}}
function boom(x,y,r,col){fx({k:"boom",x:x,y:y,r:r*.9,col:col,life:.38});fx({k:"shock",x:x,y:y,r1:r,col:col,life:.4,low:true,rays:0,a0:0});chispas(x,y,Math.min(22,10+((r/8)|0)),col,r*3.2,.7,16);motas(x,y,8,col,r*.5,70,.8);humo(x,y,5,"#3a2a22",r*.4,.9,r*.45);}
function impacto(e,col,crit){var z=Math.max(12,(e.alt||40)*.5);chispas(e.ux,e.uy,crit?12:6,col,crit?260:170,.45,z);fx({k:"flare",x:e.ux,y:e.uy,z:z,col:col,s:crit?26:14,life:crit?.28:.2});}
function lanzando(col){PS.castT=PS.castMax=.4;PS.castCol=col;PS.swing=Math.max(PS.swing,.22);fx({k:"rune",x:PX(),y:PY(),r:44,col:col,life:.5,low:true,follow:true});}
function trailPr(p){
 if(p.sty==="fuego"){fx({k:"pt2",sh:"glow",x:p.x+rf(-5,5),y:p.y+rf(-5,5),z:16+rf(-4,4),vx:-p.vx*.04,vy:-p.vy*.04,vz:rf(10,50),g:0,life:rf(.3,.5),col:"#ff9a3a",sz:rf(3,6)});
  if(Math.random()<.35)fx({k:"puff",x:p.x,y:p.y,z:16,vx:0,vy:0,vz:12,g:0,life:.5,col:"#40302a",r0:5,r1:12,al:.35});}
 else fx({k:"pt2",sh:"glow",x:p.x,y:p.y,z:16,vx:0,vy:0,vz:0,g:0,life:.22,col:p.sty==="flecha"?"#cfe8a0":p.col,sz:p.sty==="tiro"?3:2.2});}
function elip(c,x,y,r,fill,stroke){var p=pjU(x,y);c.beginPath();c.ellipse(p.x,p.y,r*1.4142,r*.7071,0,0,7);if(fill)c.fill();if(stroke)c.stroke();}
function sector2(c,x,y,r,a0,a1,cerrar){var n=Math.max(6,Math.ceil(Math.abs(a1-a0)*8)),p;c.beginPath();if(cerrar){p=pjU(x,y);c.moveTo(p.x,p.y);}
 for(var i=0;i<=n;i++){var a=a0+(a1-a0)*i/n;p=pjU(x+Math.cos(a)*r,y+Math.sin(a)*r);if(i===0&&!cerrar)c.moveTo(p.x,p.y);else c.lineTo(p.x,p.y);}if(cerrar)c.closePath();}
/* dibujo de cada tipo de efecto (el lienzo ya está en coordenadas del mundo isométrico) */
var FXD={
 slash:function(c,f,u){
  var a0=f.a-f.arc/2,lead=Math.min(1,u*2.2),n=16,rr=f.r*(.75+.25*Math.min(1,u*2)),fade=Math.max(0,1-Math.max(0,u-.25)/.75),w=f.w||9,p0,p1,i,lx=0,ly=0;
  c.translate(0,-(f.h===undefined?14:f.h));c.lineCap="round";
  for(i=0;i<n;i++){var s0=i/n*lead,s1=(i+1)/n*lead,q0=f.flip?1-s0:s0,q1=f.flip?1-s1:s1,k=(i+1)/n;
   p0=pjU(f.x+Math.cos(a0+f.arc*q0)*rr,f.y+Math.sin(a0+f.arc*q0)*rr);p1=pjU(f.x+Math.cos(a0+f.arc*q1)*rr,f.y+Math.sin(a0+f.arc*q1)*rr);
   c.globalAlpha=Math.pow(k,1.6)*fade;c.strokeStyle=f.col;c.lineWidth=w*(.25+.75*k)*(1-u*.4);
   c.beginPath();c.moveTo(p0.x,p0.y);c.lineTo(p1.x,p1.y);c.stroke();
   c.strokeStyle="#fff";c.lineWidth=w*.28*k*(1-u*.4);c.stroke();lx=p1.x;ly=p1.y;}
  c.globalAlpha=fade;c.fillStyle="#fff";c.shadowColor=f.col;c.shadowBlur=10;c.beginPath();c.arc(lx,ly,w*.28,0,7);c.fill();c.shadowBlur=0;c.lineCap="butt";},
 shock:function(c,f,u){
  var e=1-Math.pow(1-u,2.2),r=f.r1*(.15+.85*e),al=1-u,p=pjU(f.x,f.y);
  c.translate(p.x,p.y);c.scale(1.4142,.7071);
  var g=c.createRadialGradient(0,0,r*.5,0,0,r);g.addColorStop(0,hexA(f.col,0));g.addColorStop(1,hexA(f.col,.5*al));
  c.fillStyle=g;c.beginPath();c.arc(0,0,r,0,7);c.fill();
  c.strokeStyle=f.col;c.globalAlpha=al;c.lineWidth=4*(1-u)+1;c.beginPath();c.arc(0,0,r,0,7);c.stroke();
  c.strokeStyle="#fff";c.globalAlpha=al*.7;c.lineWidth=1.5;c.beginPath();c.arc(0,0,r*.96,0,7);c.stroke();
  if(f.rays){c.strokeStyle=f.col;c.globalAlpha=al*.55;c.lineWidth=2;for(var i=0;i<f.rays;i++){var a=i/f.rays*6.2832+(f.a0||0);c.beginPath();c.moveTo(Math.cos(a)*r*.35,Math.sin(a)*r*.35);c.lineTo(Math.cos(a)*r,Math.sin(a)*r);c.stroke();}}},
 rune:function(c,f,u){
  var al=Math.max(0,u<.2?u/.2:1-(u-.2)/.8),r=f.r*(.7+.3*Math.min(1,u*3)),cx0=f.follow?PX():f.x,cy0=f.follow?PY():f.y,rot=f.t*(f.rot||2.4),i,p,t;
  c.strokeStyle=f.col;c.fillStyle=f.col;c.globalAlpha=al*.9;c.lineWidth=2;
  elip(c,cx0,cy0,r,false,true);elip(c,cx0,cy0,r*.82,false,true);
  for(t=0;t<2;t++){c.beginPath();for(i=0;i<3;i++){p=pjU(cx0+Math.cos(rot+t*1.0472+i*2.0944)*r*.82,cy0+Math.sin(rot+t*1.0472+i*2.0944)*r*.82);if(i)c.lineTo(p.x,p.y);else c.moveTo(p.x,p.y);}c.closePath();c.stroke();}
  for(i=0;i<12;i++){var a=-rot*.6+i*.5236,q1=pjU(cx0+Math.cos(a)*r*.82,cy0+Math.sin(a)*r*.82),q2=pjU(cx0+Math.cos(a)*r*.95,cy0+Math.sin(a)*r*.95);c.beginPath();c.moveTo(q1.x,q1.y);c.lineTo(q2.x,q2.y);c.stroke();}
  c.globalAlpha=al*.12;elip(c,cx0,cy0,r,true,false);},
 beam:function(c,f,u){
  var p1=pjU(f.x1,f.y1),p2=pjU(f.x2,f.y2),h=f.h===undefined?18:f.h,al=1-u*u,w=(f.w||10)*(1-u*.7),pts=[{x:p1.x,y:p1.y-h}],i;
  if(f.zig){var R2=rng((f.sd|0)+Math.floor(f.t*40)),dx=p2.x-p1.x,dy=p2.y-p1.y,l=Math.hypot(dx,dy)||1,nx=-dy/l,ny=dx/l,n=8;
   for(i=1;i<n;i++){var o=(R2()-.5)*f.zig*(1-u);pts.push({x:p1.x+dx*i/n+nx*o,y:p1.y-h+dy*i/n+ny*o});}}
  pts.push({x:p2.x,y:p2.y-h});
  c.globalCompositeOperation="lighter";c.lineCap="round";c.lineJoin="round";
  [[w*2.4,.25,f.col],[w,.7,f.col],[w*.4,1,"#fff"]].forEach(function(L){c.globalAlpha=L[1]*al;c.strokeStyle=L[2];c.lineWidth=L[0];c.beginPath();pts.forEach(function(q,j){if(j)c.lineTo(q.x,q.y);else c.moveTo(q.x,q.y);});c.stroke();});
  c.globalAlpha=al;c.fillStyle="#fff";c.beginPath();c.arc(p2.x,p2.y-h,w*.7+2,0,7);c.fill();},
 xslash:function(c,f,u){
  var p=pjU(f.x,f.y),s=f.s||26,al=1-Math.max(0,u-.35)/.65;
  c.translate(p.x,p.y-(f.h||24));c.rotate(f.ro||0);c.lineCap="round";
  [[-1,-.7,1,.7,Math.min(1,u*4)],[1,-.7,-1,.7,Math.max(0,Math.min(1,(u-.12)*4))]].forEach(function(q){
   if(q[4]<=0)return;var x1=q[0]*s,y1=q[1]*s,x2=x1+(q[2]*s-x1)*q[4],y2=y1+(q[3]*s-y1)*q[4];
   c.globalAlpha=al;c.strokeStyle=f.col;c.lineWidth=7*(1-u*.6);c.beginPath();c.moveTo(x1,y1);c.lineTo(x2,y2);c.stroke();
   c.strokeStyle="#fff";c.lineWidth=2.4*(1-u*.5);c.stroke();});},
 pillar:function(c,f,u){
  var p=pjU(f.x,f.y),al=u<.15?u/.15:1-(u-.15)/.85,w=(f.w||34)*(u<.15?.4+u/.15*.6:1-(u-.15)*.35),h=f.h||230;
  c.globalCompositeOperation="lighter";
  var g=c.createLinearGradient(0,p.y-h,0,p.y);g.addColorStop(0,hexA(f.col,0));g.addColorStop(.6,hexA(f.col,.45*al));g.addColorStop(1,hexA(f.col,.8*al));
  c.fillStyle=g;c.beginPath();c.moveTo(p.x-w/2,p.y);c.lineTo(p.x-w*.3,p.y-h);c.lineTo(p.x+w*.3,p.y-h);c.lineTo(p.x+w/2,p.y);c.closePath();c.fill();
  var g2=c.createLinearGradient(0,p.y-h,0,p.y);g2.addColorStop(0,"rgba(255,255,255,0)");g2.addColorStop(1,"rgba(255,255,255,"+(.85*al)+")");
  c.fillStyle=g2;c.beginPath();c.moveTo(p.x-w*.18,p.y);c.lineTo(p.x-w*.1,p.y-h);c.lineTo(p.x+w*.1,p.y-h);c.lineTo(p.x+w*.18,p.y);c.closePath();c.fill();},
 dome:function(c,f,u){
  var p=pjU(PX(),PY()),al=u<.2?u/.2:1-(u-.2)/.8,r=f.r*(.6+.4*Math.min(1,u*3));
  var g=c.createRadialGradient(p.x,p.y-26,r*.2,p.x,p.y-26,r*1.1);g.addColorStop(0,hexA(f.col,0));g.addColorStop(.75,hexA(f.col,.22*al));g.addColorStop(1,hexA(f.col,.6*al));
  c.fillStyle=g;c.beginPath();c.ellipse(p.x,p.y-26,r,r*1.25,0,0,7);c.fill();
  c.strokeStyle="#fff";c.globalAlpha=.5*al;c.lineWidth=1.5;c.beginPath();c.ellipse(p.x,p.y-26,r,r*1.25,0,3.46,4.87);c.stroke();},
 flare:function(c,f,u){
  var p=pjU(f.x,f.y),s=(f.s||16)*(1-u*.6);
  c.globalCompositeOperation="lighter";c.translate(p.x,p.y-(f.z||18));c.globalAlpha=1-u;
  var g=c.createRadialGradient(0,0,0,0,0,s);g.addColorStop(0,"rgba(255,255,255,1)");g.addColorStop(.35,hexA(f.col,.8));g.addColorStop(1,hexA(f.col,0));
  c.fillStyle=g;c.beginPath();c.arc(0,0,s,0,7);c.fill();
  c.strokeStyle="#fff";c.lineWidth=2*(1-u);c.beginPath();c.moveTo(-s*1.6,0);c.lineTo(s*1.6,0);c.moveTo(0,-s*1.6);c.lineTo(0,s*1.6);c.stroke();},
 boom:function(c,f,u){
  var p=pjU(f.x,f.y),r=f.r*(.3+.7*(1-Math.pow(1-u,2.4))),al=1-u;
  c.globalCompositeOperation="lighter";
  var g=c.createRadialGradient(p.x,p.y-12,0,p.x,p.y-12,r*1.3);g.addColorStop(0,"rgba(255,255,255,"+al+")");g.addColorStop(.25,hexA(f.col,.85*al));g.addColorStop(1,hexA(f.col,0));
  c.fillStyle=g;c.beginPath();c.arc(p.x,p.y-12,r*1.3,0,7);c.fill();},
 pt2:function(c,f,u){
  var q=pjU(f.x,f.y);c.globalAlpha=Math.max(0,1-u);
  if(f.sh==="line"){var sx=f.vx-f.vy,sy=(f.vx+f.vy)*.5-f.vz,l=Math.hypot(sx,sy)||1,L=3+f.sz*2.5;
   c.strokeStyle=f.col;c.lineWidth=f.sz*.8;c.lineCap="round";c.beginPath();c.moveTo(q.x,q.y-f.z);c.lineTo(q.x-sx/l*L,q.y-f.z-sy/l*L);c.stroke();}
  else if(f.sh==="shard"){c.translate(q.x,q.y-f.z);c.rotate((f.rot||0)+f.t*(f.sp||0));c.fillStyle=f.col;
   c.beginPath();c.moveTo(0,-f.sz*2);c.lineTo(f.sz*.8,0);c.lineTo(0,f.sz*2);c.lineTo(-f.sz*.8,0);c.closePath();c.fill();}
  else{c.globalCompositeOperation="lighter";c.fillStyle=f.col;c.beginPath();c.arc(q.x,q.y-f.z,f.sz*(1-u*.5),0,7);c.fill();}},
 puff:function(c,f,u){
  var q=pjU(f.x,f.y),r=f.r0+(f.r1-f.r0)*(1-Math.pow(1-u,2)),al=f.al*(1-u)*(u<.1?u/.1:1);
  var g=c.createRadialGradient(q.x,q.y-f.z,r*.15,q.x,q.y-f.z,r);g.addColorStop(0,hexA(f.col,al));g.addColorStop(1,hexA(f.col,0));
  c.fillStyle=g;c.beginPath();c.arc(q.x,q.y-f.z,r,0,7);c.fill();},
 drop:function(c,f,u){
  var e=u*u*.4+u*.6,h=f.H*(1-e),q=pjU(f.x,f.y),x=q.x+f.dx*(1-e),y=q.y-h,L=f.len||22,vl=Math.hypot(f.dx,f.H)||1;
  c.globalAlpha=Math.min(1,u*6);c.lineCap="round";c.strokeStyle=f.col;c.lineWidth=f.w||2.5;
  c.beginPath();c.moveTo(x,y);c.lineTo(x+f.dx/vl*L,y-f.H/vl*L);c.stroke();
  c.strokeStyle="#fff";c.lineWidth=(f.w||2.5)*.4;c.stroke();},
 drain:function(c,f,u){
  var a=pjU(f.x1,f.y1),b=pjU(PX(),PY()),i;
  c.globalCompositeOperation="lighter";c.fillStyle=f.col;
  for(i=0;i<f.n;i++){var s=Math.max(0,Math.min(1,u*1.3-i/f.n*.3)),e=s*s*(3-2*s),sn=Math.sin(e*3.1416);
   if(s<=0||s>=1)continue;
   c.globalAlpha=1-u*.5;c.beginPath();c.arc(a.x+(b.x-a.x)*e+sn*f.cv*(i%2?1:-1),a.y-16+(b.y-24-a.y+16)*e-sn*24,3-e*1.5,0,7);c.fill();}}
};
/* proyectiles: flecha · tiro (estela perforante) · fuego · orbe */
function dibujarProy(c,p){
 var q=pjU(p.x,p.y),sx=p.vx-p.vy,sy=(p.vx+p.vy)*.5,l=Math.hypot(sx,sy)||1,ux=sx/l,uy=sy/l,y=q.y-16,t=T,s=p.sty||"orbe";
 c.fillStyle="rgba(0,0,0,.3)";c.beginPath();c.ellipse(q.x,q.y,p.r*1.3,p.r*.65,0,0,7);c.fill();
 c.save();
 if(s==="flecha"){var tx=q.x-ux*22,ty=y-uy*22,hx=q.x+ux*12,hy=y+uy*12;
  c.lineCap="round";c.strokeStyle="#cdb98a";c.lineWidth=2;c.beginPath();c.moveTo(tx,ty);c.lineTo(hx,hy);c.stroke();
  c.fillStyle="#eef0f6";c.beginPath();c.moveTo(hx+ux*7,hy+uy*7);c.lineTo(hx-uy*3.5,hy+ux*3.5);c.lineTo(hx+uy*3.5,hy-ux*3.5);c.closePath();c.fill();
  c.strokeStyle=p.col;c.lineWidth=1.8;c.beginPath();
  c.moveTo(tx,ty);c.lineTo(tx-ux*3-uy*4,ty-uy*3+ux*4);c.moveTo(tx,ty);c.lineTo(tx-ux*3+uy*4,ty-uy*3-ux*4);
  c.moveTo(tx+ux*5,ty+uy*5);c.lineTo(tx+ux*2-uy*4,ty+uy*2+ux*4);c.moveTo(tx+ux*5,ty+uy*5);c.lineTo(tx+ux*2+uy*4,ty+uy*2-ux*4);c.stroke();
 }else if(s==="tiro"){
  c.globalCompositeOperation="lighter";c.lineCap="round";
  [[9,.25],[5,.6],[2,1]].forEach(function(w){c.globalAlpha=w[1];c.strokeStyle=w[1]===1?"#fff":p.col;c.lineWidth=w[0];c.beginPath();c.moveTo(q.x-ux*64,y-uy*64);c.lineTo(q.x+ux*6,y+uy*6);c.stroke();});
 }else if(s==="fuego"){
  c.globalCompositeOperation="lighter";
  var r=p.r*(1.5+.18*Math.sin(t*38)),g=c.createRadialGradient(q.x,y,1,q.x,y,r*2),w2=4*Math.sin(t*50);
  g.addColorStop(0,"rgba(255,255,255,1)");g.addColorStop(.3,"rgba(255,190,80,.95)");g.addColorStop(.7,"rgba(255,90,20,.45)");g.addColorStop(1,"rgba(255,60,10,0)");
  c.fillStyle=g;c.beginPath();c.arc(q.x,y,r*2,0,7);c.fill();
  c.strokeStyle="rgba(255,150,50,.8)";c.lineWidth=3;c.lineCap="round";c.beginPath();c.moveTo(q.x,y);c.lineTo(q.x-ux*30-uy*w2,y-uy*30+ux*w2);c.stroke();
 }else{
  c.globalCompositeOperation="lighter";
  var r2=p.r*(1+.15*Math.sin(t*20+p.x)),g2=c.createRadialGradient(q.x,y,1,q.x,y,r2*2.2);
  g2.addColorStop(0,"rgba(255,255,255,.95)");g2.addColorStop(.35,hexA(p.col,.8));g2.addColorStop(1,hexA(p.col,0));
  c.fillStyle=g2;c.beginPath();c.arc(q.x,y,r2*2.2,0,7);c.fill();
 }
 c.restore();}
/* ---- utilidades de combate ---- */
function EN(){return MON.filter(function(m){return !m.muerto;});}
function vivo(e){return !!e&&!e.muerto&&MON.indexOf(e)>=0;}
function syncU(){for(var i=0;i<MON.length;i++){MON[i].ux=MON[i].x*U;MON[i].uy=MON[i].y*U;}}
function dEP(e){return Math.hypot(e.ux-PX(),e.uy-PY());}
function angA(e){return Math.atan2(e.uy-PY(),e.ux-PX());}
function masCercanoU(maxd){var b=null,bd=1e9;EN().forEach(function(e){var d=dEP(e);if(d<bd&&(!maxd||d<=maxd)){bd=d;b=e;}});return b;}
/* objetivo vigente: el fijado con un toque; si no hay, el más cercano */
function blancoW(maxd){var t=PS.tg;if(vivo(t)&&(!maxd||dEP(t)<=maxd))return t;return masCercanoU(maxd||420);}
function asistirAng(a){var tg=null,bd=1e9,ca=Math.cos(a),sa=Math.sin(a);
 EN().forEach(function(e){var dx=e.ux-PX(),dy=e.uy-PY(),t=dx*ca+dy*sa;if(t<20||t>700)return;var perp=Math.abs(-dx*sa+dy*ca);if(perp<e.r+24&&perp<bd){bd=perp;tg=e;}});
 return tg?Math.atan2(tg.uy-PY(),tg.ux-PX()):a;}
function cono(x,y,ang,rango,arc,fn){EN().forEach(function(e){var dx=e.ux-x,dy=e.uy-y,d=Math.hypot(dx,dy);if(d>rango+e.r)return;if(Math.abs(angd(Math.atan2(dy,dx),ang))<=arc/2+Math.atan2(e.r,Math.max(d,1)))fn(e);});}
function circ(x,y,rad,fn){EN().forEach(function(e){if(Math.hypot(e.ux-x,e.uy-y)<=rad+e.r)fn(e);});}
function TS(){return(SJ&&SJ.W&&SJ.W.TURNO_S)||2;}
function libreP(x,y){var X=Math.floor(x),Y=Math.floor(y);return inb(X,Y)&&!blk[I(X,Y)]&&sec[I(X,Y)]>=0;}
function objMelee(maxd){var t=PS.tg;if(vivo(t))return t;return masCercanoU(maxd||(SJ&&SJ.clase==="Asesino"?MAXT:MAXM));}
function enAlcance(Tg,maxd){return dEP(Tg)<=(maxd||(SJ&&SJ.clase==="Asesino"?MAXT:MAXM))+Tg.r;}
function sinObjMelee(Tg){txt(PX(),PY(),Tg?"Fuera de alcance":"Sin objetivo","#aaa",12,30);}
function carasA(ang){PS.face=ang;P.dir=dirOf(Math.cos(ang),Math.sin(ang));}
/* acercarse al objetivo (Guerrero/Paladín) o teletransportarse a su espalda (Asesino) */
function irA(Tg,tele,n){
 var x0=PX(),y0=PY(),a=Math.atan2(Tg.uy-y0,Tg.ux-x0),off=Tg.r+14+(tele?4:10),d=Math.hypot(Tg.ux-x0,Tg.uy-y0),q,nx,ny;
 if(!tele&&d<=off+24)return;
 humo(x0,y0,tele?6:3,tele?"#3a2a4a":"#b8a888",12,.5,26);
 for(q=1;q<=4;q++)fx({k:"ghost",x:x0+(Tg.ux-x0)*q/5,y:y0+(Tg.uy-y0)*q/5,d:dirOf(Math.cos(a),Math.sin(a)),life:.28});
 if(tele){var a2=a+(n||0)*2.4;fx({k:"beam",x1:x0,y1:y0,x2:Tg.ux,y2:Tg.uy,col:"#b070e0",w:7,life:.22});nx=Tg.ux+Math.cos(a2)*off;ny=Tg.uy+Math.sin(a2)*off;}
 else{nx=Tg.ux-Math.cos(a)*off;ny=Tg.uy-Math.sin(a)*off;}
 var ok=libreP(nx/U,ny/U);
 if(!ok)for(q=1;q<=6&&!ok;q++){nx=Tg.ux-Math.cos(a)*(off+q*10);ny=Tg.uy-Math.sin(a)*(off+q*10);ok=libreP(nx/U,ny/U);}
 if(!ok)return;
 P.x=nx/U;P.y=ny/U;P.path=[];tgt=null;
 if(!tele)chispas(PX(),PY(),6,"#ffd9a0",160,.4,18);
 carasA(Math.atan2(Tg.uy-PY(),Tg.ux-PX()));}
function dashW(a,dist,t,dmg){PS.dashT=t;PS.dvx=Math.cos(a)*dist/t/U;PS.dvy=Math.sin(a)*dist/t/U;PS.dashB=dmg;PS.dashHit=[];P.path=[];tgt=null;}
/* talentos de rama en tiempo real */
function mejora(e){var M=SJ.M,m=1;
 if(M.exth&&e.vida<e.vidaMax*M.exth)m*=1+M.exv;
 if(M.elite&&e.tipo!=="normal")m*=1+M.elite;
 if(e.mk)m*=1+e.mk.dm;
 return m;}
function rebotar(e0,raw,n){
 EN().filter(function(e){return e!==e0&&Math.hypot(e.ux-e0.ux,e.uy-e0.uy)<=260;}).sort(function(a,b){return Math.hypot(a.ux-e0.ux,a.uy-e0.uy)-Math.hypot(b.ux-e0.ux,b.uy-e0.uy);}).slice(0,n).forEach(function(e){
  fx({k:"beam",x1:e0.ux,y1:e0.uy,x2:e.ux,y2:e.uy,col:"#f0e0a0",w:5,zig:16,sd:Math.floor(Math.random()*9999),life:.22});herir(e,raw,{crit:true,fc:true,kb:40,col:"#f0e0a0"});});}
function purgarControl(){var q=PS.stunT>0||PS.silT>0||PS.venT>T;PS.stunT=0;PS.silT=0;PS.venT=0;PS.resStun=0;if(q)txt(PX(),PY(),"✨ Control purgado","#ffe9a0",13,48);return q;}
/* ---- daño a monstruos ---- */
function herir(e,raw,o){
 o=o||{};if(!vivo(e)||!SJ)return 0;
 var st=SJ.st,j=SJ.j,Wp=SJ.W,M=SJ.M,crit=false;raw*=mejora(e);
 if(o.crit){var solo=EN().filter(function(m){return dEP(m)<420;}).length===1,cp=Math.min(60,SJ.crit)+(solo?M.critU*100:0);if(o.fc||Math.random()*100<cp){raw*=st.critMult;crit=true;}}
 var dfn=Math.floor(e.def*(1-M.ig)),d=Wp?Wp.danoMitigado(Math.floor(raw),dfn,crit):Math.max(1,Math.floor(raw*100/(100+dfn)));
 var df=Wp&&Wp.defensaEnemigo?Wp.defensaEnemigo(e,d):{d:d,ev:null,cura:0};d=df.d;
 if(df.ev==="esq"){txt(e.ux+rf(-8,8),e.uy,"Esquiva","#8ab0d8",13,e.r+8);return 0;}
 if(df.ev==="abs"){e.vida=Math.min(e.vidaMax,e.vida+df.cura);if(SIM.on)envia({t:"mon_fx",id:e.id,heal:df.cura});txt(e.ux+rf(-8,8),e.uy,"Absorbe +"+df.cura,"#b070e0",13,e.r+8);return 0;}
 if(df.ev==="bloq")txt(e.ux+rf(-8,8),e.uy-12,"Bloqueo","#9aa8b8",11,e.r+8);
 e.vida-=d;e.flash=.14;PS.comb=6;PS.regW=REGEN_ESPERA;
 var tb0=j&&j.tb,lsv=M.ls+(tb0?(tb0.vl||0)+(tb0.rb||0):0);if(tb0)tb0.acc+=d;if(lsv)PS.hp=Math.min(PS.max,PS.hp+Math.floor(d*lsv));
 var jf=(e.tipo==="jefe"?.2:e.tipo==="mini_jefe"?.5:1);
 var hkx=0,hky=0,hst=0;
 if(o.kb){var a=Math.atan2(e.uy-PY(),e.ux-PX());hkx=Math.cos(a)*o.kb*jf*4/U;hky=Math.sin(a)*o.kb*jf*4/U;if(!SIM.on){e.kx+=hkx;e.ky+=hky;}}
 if(o.stun){hst=o.stun*jf2(e);e.stunT=Math.max(e.stunT,hst);}
 if(SIM.on)envia({t:"mon_hit",id:e.id,d:d,kx:+hkx.toFixed(3),ky:+hky.toFixed(3),stun:+hst.toFixed(2)});
 txt(e.ux+rf(-8,8),e.uy,String(d),crit?"#ffd24a":"#f0f0f0",crit?20:14,e.r+8);
 impacto(e,crit?"#ffd24a":(o.col||"#ffe9b0"),crit);
 if(o.heal){var h=Math.floor(d*o.heal);PS.hp=Math.min(PS.max,PS.hp+h);txt(PX(),PY(),"+"+h,"#7ab88a",13,24);fx({k:"drain",x1:e.ux,y1:e.uy,col:"#e05050",n:6,cv:16,life:.5});}
 if(!SIM.on&&e.st!=="chase")monAlerta(e);
 if(SIM.on){if(e.vida<0)e.vida=0;}else if(e.vida<=0)matar(e);
 return d;}
function jf2(e){return e.tipo==="jefe"?.5:e.tipo==="mini_jefe"?.7:1;}
function aturde(e,s){e.stunT=Math.max(e.stunT,s);if(SIM.on)envia({t:"mon_fx",id:e.id,stun:+s.toFixed(2)});}
/* Online: matar() solo pide la muerte al servidor (ejecuciones); la muerte real llega con mon_muere */
function matar(e){
 if(SIM.on){if(e.muerto||e.claim)return;e.claim=1;envia({t:"mon_hit",id:e.id,d:0,ex:1});return;}
 matarLocal(e,true);}
function matarLocal(e,cobra){
 if(e.muerto)return;e.muerto=true;e.mt=0;e.mv=0;e.st="idle";e.wind=0;if(PS.tg===e)PS.tg=null;if(cobra)PS.kills++;
 if(cobra&&e.mk){var Wp=SJ&&SJ.W;if(e.mk.bf&&SJ.j)SJ.j.tb={n:"Contrato",t:20,dm:e.mk.bf.dm,acc:0};if(e.mk.cof)txt(e.ux,e.uy,"📦 Cofre x"+e.mk.cof,"#e0c060",14,40);}
 for(var n=0;n<14;n++)FXL.push({k:"part",x:e.ux,y:e.uy,vx:rf(-140,140),vy:rf(-140,140),t:0,life:rf(.3,.6),col:e.col});
 fx({k:"shock",x:e.ux,y:e.uy,r1:e.r*2.4,col:e.col,life:.3,low:true,rays:0});humo(e.ux,e.uy,3,"#6a5a4a",e.r*.5,.6,e.r*1.1);motas(e.ux,e.uy,5,"#d8d0ff",e.r*.4,60,.8);
 if(cobra)recompensa(e);
 if(!SIM.on)MONRESP.push({sk:e.sk,t:T+MON_RESP[0]+Math.random()*(MON_RESP[1]-MON_RESP[0])*(e.alfa?1.5:1)});}
/* ============ ESTILOS DE LAS HABILIDADES DE RAMA (por nombre) ============ */
var RAMA_FX={
 "Torbellino Aniquilador":{c:"#e05030",t:"giro"},"Sentencia Final":{c:"#ffd24a",t:"ejecucion"},"Juicio Divino":{c:"#ffe080",t:"santo"},
 "Disparo de Largo Alcance":{c:"#fff0c0",t:"riel"},"Corte Sombra x7":{c:"#c070d0",t:"cortes"},"Lluvia de Cuchillas":{c:"#dcdce8",t:"cuchillas"},
 "Infierno":{c:"#ff7a30",t:"infierno"},"Combustión":{c:"#ffb040",t:"combustion"},"Prisión Glacial":{c:"#8fd0f0",t:"hielo"},
 "Lanza de Hielo Absoluto":{c:"#bfe6ff",t:"lanza"},"Trampa Alfa":{c:"#9ad060",t:"trampa"},"Sangre de Loco":{c:"#e03030",t:"furia"},
 "Cruzada Fanática":{c:"#ffe080",t:"cruzada"},"Bastión Inquebrantable":{c:"#8ab0d8",t:"bastion"},"Luz Regeneradora":{c:"#7ab88a",t:"luz"},
 "Vínculo Alfa":{c:"#9ad060",t:"vinculo"},"Posición Elevada":{c:"#f0e0a0",t:"elevada"},"Paso Espectral":{c:"#b070e0",t:"sombra"},
 "Santuario de Luz":{c:"#8ff0d0",t:"santuario"},"Resurgir Divino":{c:"#fff0a0",t:"resurgir"},"Nova Solar":{c:"#ffd060",t:"nova"},"Ascensión Radiante":{c:"#ffe8a0",t:"ascension"},
 "Marca del Condenado":{c:"#ff5030",t:"marca"},"Contrato Marcado":{c:"#e0c060",t:"marca"}
};
function rfx(sk,col){return RAMA_FX[sk.n]||{c:col,t:""};}
function fxRamaArea(sk,mCls,cen,rad,col){
 var r=rfx(sk,col),c0=r.c,x=cen.x,y=cen.y;
 if(r.t==="giro"){fx({k:"shock",x:x,y:y,r1:rad,col:c0,life:.5,low:true,rays:12,a0:0});humo(x,y,10,"#b8a080",rad*.7,.6,40);}
 else if(r.t==="santo"){fx({k:"shock",x:x,y:y,r1:rad,col:c0,life:.5,low:true,rays:16,a0:0});fx({k:"pillar",x:x,y:y,col:c0,w:70,h:300,life:.6});motas(x,y,12,c0,rad*.6,80,.9);destello("#fff2c0",.2);}
 else if(r.t==="infierno"){fx({k:"rune",x:x,y:y,r:rad,col:c0,life:1.3,low:true,rot:1.5});}
 else if(r.t==="combustion"){boom(x,y,rad,c0);fx({k:"rune",x:x,y:y,r:rad,col:c0,life:.6,low:true,rot:3});destello("#ffd890",.25);}
 else if(r.t==="hielo"){fx({k:"rune",x:x,y:y,r:rad,col:c0,life:.8,low:true});hielo(x,y,14,rad);humo(x,y,8,"#bfe6ff",rad*.6,.9,45);fx({k:"shock",x:x,y:y,r1:rad,col:c0,life:.5,low:true,rays:10,a0:0});}
 else if(r.t==="cuchillas"){fx({k:"rune",x:x,y:y,r:rad,col:c0,life:.9,low:true});}
 else if(r.t==="nova"){fx({k:"rune",x:x,y:y,r:rad,col:c0,life:.9,low:true,rot:2});fx({k:"pillar",x:x,y:y,col:c0,w:64,h:300,life:.5});motas(x,y,14,"#fff0b0",rad*.6,90,.9);destello("#fff2c0",.18);}
 else if(r.t==="trampa"){fx({k:"rune",x:x,y:y,r:rad,col:c0,life:1,low:true,rot:-1.8});fx({k:"shock",x:x,y:y,r1:rad,col:c0,life:.5,low:true,rays:0});motas(x,y,16,c0,rad*.7,60,1);}
 else fx({k:"shock",x:x,y:y,r1:rad,col:c0,life:.45,low:true,rays:8,a0:0});
 if(!mCls)FXL.push({k:"mark",x:x,y:y,r:rad,t:0,life:.5,col:c0});}
function fxRamaUno(sk,px,py,t,col){
 var r=rfx(sk,col),c0=r.c;
 if(r.t==="ejecucion"){fx({k:"pillar",x:t.ux,y:t.uy,col:c0,w:50,h:280,life:.45});fx({k:"xslash",x:t.ux,y:t.uy,col:c0,s:44,life:.4});fx({k:"shock",x:t.ux,y:t.uy,r1:90,col:c0,life:.4,low:true,rays:10,a0:0});destello("#ffe9a0",.15);}
 else if(r.t==="riel"){fx({k:"beam",x1:px,y1:py,x2:t.ux,y2:t.uy,col:c0,w:16,life:.3});fx({k:"flare",x:px,y:py,z:24,col:c0,s:26,life:.25});fx({k:"flare",x:t.ux,y:t.uy,z:20,col:c0,s:34,life:.3});SHK=Math.max(SHK,4);}
 else if(r.t==="lanza"){fx({k:"beam",x1:px,y1:py,x2:t.ux,y2:t.uy,col:c0,w:12,life:.28});hielo(t.ux,t.uy,10,40);fx({k:"shock",x:t.ux,y:t.uy,r1:80,col:c0,life:.4,low:true,rays:8,a0:0});}
 else if(r.t==="cortes"){fx({k:"rune",x:t.ux,y:t.uy,r:t.r+30,col:c0,life:1,low:true,rot:4});}
 else fx({k:"beam",x1:px,y1:py,x2:t.ux,y2:t.uy,col:c0,w:9,life:.22});}
function fxRamaGolpe(sk,n,h,tg,cen,rad,col,mCls){
 var r=rfx(sk,col),c0=r.c,t=tg&&tg[0];
 if(r.t==="giro"&&cen){
  fx({k:"slash",x:cen.x,y:cen.y,a:n*Math.PI,r:rad,arc:6.2,w:16,col:c0,flip:n%2===1,life:.3,h:16});
  fx({k:"slash",x:cen.x,y:cen.y,a:n*Math.PI+1,r:rad*.7,arc:6.2,w:9,col:"#ffe0a0",flip:n%2===0,life:.25,h:10});
 }else if(r.t==="infierno"&&cen){boom(cen.x,cen.y,rad*(.55+.18*n),c0);}
 else if(r.t==="cuchillas"&&cen){lluvia(cen.x,cen.y,rad*.95,10,"#dcdce8",.2,2.2,22);}
 else if(r.t==="cortes"&&t){
  fx({k:"xslash",x:t.ux+rf(-8,8),y:t.uy+rf(-8,8),col:c0,s:26+n*2,ro:n*.8,life:.25});
  fx({k:"beam",x1:PX(),y1:PY(),x2:t.ux,y2:t.uy,col:c0,w:5,life:.1});
  if(n===h-1){fx({k:"shock",x:t.ux,y:t.uy,r1:80,col:c0,life:.4,low:true,rays:10,a0:0});destello("#e0b0f0",.15);}
 }else if(r.t==="lanza"&&t&&n>0){hielo(t.ux,t.uy,6,30);}}
function fxRamaBuff(sk,col){
 var r=rfx(sk,col),c0=r.c,x=PX(),y=PY(),g0;
 fx({k:"shock",x:x,y:y,r1:90,col:c0,life:.5,low:true,rays:0});
 if(r.t==="furia"){fx({k:"shock",x:x,y:y,r1:150,col:"#ff7040",life:.6,low:true,rays:16,a0:0});chispas(x,y,18,"#ff6040",300,.6,26);motas(x,y,16,c0,26,110,.9);destello("#ff5030",.16);SHK=Math.max(SHK,5);}
 else if(r.t==="cruzada"){fx({k:"pillar",x:x,y:y,col:c0,w:56,h:270,life:.8});motas(x,y,16,c0,30,90,1);destello("#fff2c0",.16);}
 else if(r.t==="bastion"){fx({k:"dome",r:40,col:c0,life:1});motas(x,y,10,c0,26,50,.8);}
 else if(r.t==="santuario"){fx({k:"dome",r:44,col:c0,life:1.2});fx({k:"rune",x:x,y:y,r:120,col:c0,life:1.2,low:true,rot:1});motas(x,y,18,"#c8ffe8",34,80,1.1);}
 else if(r.t==="resurgir"){fx({k:"pillar",x:x,y:y,col:c0,w:70,h:320,life:1});fx({k:"shock",x:x,y:y,r1:170,col:c0,life:.6,low:true,rays:16,a0:0});motas(x,y,26,"#fff8d0",40,110,1.2);destello("#fff8d0",.22);}
 else if(r.t==="ascension"){fx({k:"pillar",x:x,y:y,col:c0,w:56,h:280,life:.9});fx({k:"dome",r:40,col:c0,life:1});motas(x,y,18,"#fff2c0",30,100,1);destello("#fff2c0",.16);}
 else if(r.t==="luz"){fx({k:"pillar",x:x,y:y,col:c0,w:60,h:300,life:.9});motas(x,y,22,"#c8ffd8",34,100,1.1);}
 else if(r.t==="vinculo"){motas(x,y,18,c0,40,70,1);}
 else if(r.t==="elevada"){motas(x,y,14,c0,24,90,.9);fx({k:"dome",r:34,col:c0,life:.8});}
 else if(r.t==="sombra"){humo(x,y,10,"#3a2a4a",18,.7,34);for(g0=0;g0<3;g0++)fx({k:"ghost",x:x+rf(-14,14),y:y+rf(-14,14),d:P.dir,life:.35});}
 else motas(x,y,14,c0,26,80,.9);
 FXL.push({k:"ring",x:x,y:y,r0:20,r1:70,t:0,life:.55,col:c0,fill:false,follow:true});}
function fxRamaMarca(sk,px,py,t,col){
 var r=rfx(sk,col),c0=r.c;
 fx({k:"beam",x1:px,y1:py,x2:t.ux,y2:t.uy,col:c0,w:5,life:.22});
 fx({k:"rune",x:t.ux,y:t.uy,r:t.r+36,col:c0,life:1.1,low:true,rot:3});
 fx({k:"pillar",x:t.ux,y:t.uy,col:c0,w:26,h:150,life:.5});}
/* ---- refuerzos de Paladín y Clérigo sobre los aliados del grupo ----
   El lanzador calcula el efecto con sus stats y lo manda al servidor (g_buff); el servidor lo reenvía a los miembros de su grupo que estén en el mundo
   y cerca (r celdas). Cada aliado lo aplica a su propio personaje. Campos: hp (fracción de su vida máx) · df (fracción de su DEF) · dfl (DEF fija) · dfT (s) ·
   sh (escudo, fracción de su vida máx) · shT · pur (purga aturdimiento/silencio) · inv (s de inmunidad) · tb (refuerzo temporal: t, dm, red, reg, cc = inmune a control). */
var BUFF_R=175;   /* área de los refuerzos (unidades) = la del Pulso Vital; solo los aliados del grupo dentro de ella los reciben */
function buffAliados(fx,r){if(!ONL.on||!ONL.hub||!hubG())return;fx2({k:"rune",x:PX(),y:PY(),r:BUFF_R,col:fx.col||"#ffe9a0",life:.9,low:true,rot:1.1});envia({t:"g_buff",r:r||(BUFF_R/U+1),fx:fx});}
function fx2(o){fx(o);}
function recibeBuff(m){
 var f=m.fx;if(!f||MUERTE||!SJ||!SJ.j)return;
 var j=SJ.j,px=PX(),py=PY(),col=f.col||"#ffe9a0",bo,h,es;
 if(f.hp>0){h=Math.floor(PS.max*f.hp);if(h>0){PS.hp=Math.min(PS.max,PS.hp+h);txt(px,py,"+"+h,"#7ab88a",18,30);}}
 if(f.df>0||f.dfl>0){bo=Math.floor((f.dfl||0)+SJ.st.def*(f.df||0));if(bo>0&&(PS.defT<=0||bo>=PS.defB)){PS.defB=bo;PS.defT=f.dfT>0?f.dfT:6;}}
 if(f.sh>0){es=Math.floor(PS.max*f.sh);if(es>PS.sh){PS.sh=es;PS.shT=Math.max(8,f.shT||0);}}
 if(f.pur)purgarControl();
 if(f.inv>0)PS.invT=Math.max(PS.invT,f.inv);
 if(f.tb&&f.tb.t>0){var o=j.tb;if(!o||!(o.t>0)||(o.dm||0)<=(f.tb.dm||0))j.tb={n:f.tb.n,t:f.tb.t,dm:f.tb.dm||0,red:f.tb.red||0,reg:f.tb.reg||0,cc:f.tb.cc||0,acc:0};}
 if(f.hp>0||f.pur||f.tb){fx({k:"pillar",x:px,y:py,col:col,w:46,h:230,life:.8});motas(px,py,14,col,26,80,.9);}
 if(f.df>0||f.dfl>0||f.sh>0||f.inv>0||(f.tb&&f.tb.red>0))fx({k:"dome",r:38,col:col,life:.9});
 txt(px,py,(f.n||"Refuerzo")+" · "+(m.nombre||"aliado"),col,12,52);
 chatLog("✨ "+(m.nombre||"Un aliado")+" te refuerza: "+(f.n||"refuerzo"));}
/* Hab. 1 / Hab. 2 de la rama (sk = definición en RAMAS). Daño (d), buff (b) o marca (m) */
function lanzarRama(sk,i){
 var j=SJ.j,st=SJ.st,M=SJ.M,Wp=SJ.W,k=sk.s,pw0=1+M[k+"p"],px=PX(),py=PY(),mCls=(j.clase==="Guerrero"||j.clase==="Paladin"),col=SJ.col,fcol=rfx(sk,col).c;
 function base(){return mrnd(st.atkMin,Math.max(st.atkMin,st.atkMax))*Wp.gmGlob(j,i);}
 function cur(maxd){var bt=blancoW(),mx,my;if(bt){mx=bt.ux;my=bt.uy;}else{mx=px+Math.cos(PS.face)*maxd*.7;my=py+Math.sin(PS.face)*maxd*.7;}var dx=mx-px,dy=my-py,d=Math.hypot(dx,dy)||1,q=Math.min(1,maxd/d);return{x:px+dx*q,y:py+dy*q};}
 function cercanoCursor(){return blancoW(620);}
 if(sk.k==="d"){
  var h=(sk.h||1)+M[k+"h"],tg,cen,rad;
  if(sk.a){
   if(mCls){
    var Tm=objMelee();
    if(Tm){
     if(!enAlcance(Tm)){sinObjMelee(Tm);return false;}
     if(j.clase==="Guerrero"){irA(Tm);px=PX();py=PY();cen={x:px,y:py};}else cen={x:Tm.ux,y:Tm.uy};
    }else cen={x:px,y:py};
    rad=175;
   }else{cen=cur(380);rad=140;}
   tg=EN().filter(function(e){return Math.hypot(e.ux-cen.x,e.uy-cen.y)<=rad+e.r;});
   fxRamaArea(sk,mCls,cen,rad,col);
  }else{
   var t0=(mCls||j.clase==="Asesino")?objMelee():cercanoCursor();
   if(!t0||!enAlcance(t0,(mCls||j.clase==="Asesino")?0:620)){sinObjMelee(t0);return false;}
   if(mCls||j.clase==="Asesino")irA(t0,j.clase==="Asesino",0);
   px=PX();py=PY();tg=[t0];fxRamaUno(sk,px,py,t0,col);
  }
  var esc=1+(sk.esc||0)*tg.length,sg=1+(sk.sg||0)+M[k+"sg"]+M.sg,ig=Math.min(1,(sk.ig||0)+M[k+"ig"]+M.ig);
  var stn=sk.st?(sk.st+M[k+"st"]+M.stb)*1.25:0,cp=Math.min(60,SJ.crit);
  if(sk.sdf){PS.defB=-Math.floor(st.def*sk.sdf);PS.defT=4;}
  for(var n=0;n<h;n++)(function(n){TML.push({t:n*.14,fn:function(){
   tg.forEach(function(e){
    if(!vivo(e))return;
    if(j.clase==="Asesino"&&!sk.a&&n>0)irA(e,true,n);
    var cr=1;
    if(sk.cr||(sk.fx&&e.stunT>0)||(sk.ci&&Math.random()*100<cp+sk.ci*100*n))cr=st.critMult*(e.stunT>0?1+M.fz:1);
    var m=sk.m*((sk.fm&&n===h-1)?sk.fm:1)*((sk.und&&/No-Muerto|Espectro|Momia|Lich|Alma|Sombra/.test(e.nombre))?2:1);
    var dd=e.def;e.def=Math.floor(dd*(1-ig));
    herir(e,base()*m*pw0*esc*cr*sg,{kb:30,col:fcol});e.def=dd;});
   fxRamaGolpe(sk,n,h,tg,cen,rad,col,mCls);
  }});})(n);
  TML.push({t:h*.14+.03,fn:function(){
   tg.forEach(function(e){
    if(!vivo(e))return;
    if(stn)aturde(e,stn*jf2(e));
    if(sk.dd){e.def=Math.floor(e.def*(1-sk.dd));if(SIM.on)envia({t:"mon_fx",id:e.id,dd:sk.dd});}});
   if(sk.lh&&tg.length){var chl=Math.floor(PS.max*sk.lh*Math.min(6,tg.length)*Wp.curaMult(j));PS.hp=Math.min(PS.max,PS.hp+chl);txt(PX(),PY(),"+"+chl,"#7ab88a",15,34);}
   var xe=M[k+"ex"];
   if(xe)EN().forEach(function(e){if(e.tipo==="normal"&&e.vida>0&&e.vida<e.vidaMax*xe&&dEP(e)<420){e.vida=0;txt(e.ux,e.uy,"Ejecutado","#ffd24a",14,40);matar(e);}});
   if(sk.rs&&tg.length&&!vivo(tg[0])){PS.cd[i]=0;PS.mp=Math.min(PS.mpMax,PS.mp+sk.rs);txt(PX(),PY(),"↺ "+sk.n,"#e0c060",13,50);}
  }});
  SHK=Math.max(SHK,3);
 }else if(sk.k==="b"){
  if(sk.t)j.tb={n:sk.n,t:sk.t,dm:(sk.dm||0)*pw0,rb:sk.rb||0,vl:sk.vl||0,vl2:sk.vl2||0,dpl:sk.dpl||0,cc:sk.cc||0,red:Math.min(.9,(sk.red||0)*pw0),reg:(sk.reg||0)*pw0,ref:(sk.ref||0)+M[k+"ref"],hp:M[k+"hp"],acc:0};
  if(sk.inv)PS.invT=Math.max(PS.invT,sk.inv*1.5);
  var sh=((sk.sh||0)+M[k+"sh"])*(sk.sh?pw0:1)*(1+M.cura);if(sh){PS.sh=Math.floor(PS.max*sh);PS.shT=8;}
  if(sk.hl){var hl=Math.floor(PS.max*sk.hl*pw0*Wp.curaMult(j));PS.hp=Math.min(PS.max,PS.hp+hl);txt(px,py,"+"+hl,"#7ab88a",18,30);}
  if(sk.df){PS.defB=Math.floor(st.def*sk.df*pw0);PS.defT=sk.t;}
  if(sk.pur)purgarControl();
  if(sk.nx)PS.nx={dm:sk.nx.dm*pw0,bn:sk.nx.bn||0,h:1+M[k+"nx"]};
  fxRamaBuff(sk,col);txt(px,py,sk.n,"#e0c060",13,52);
  if(j.clase==="Paladin"||j.clase==="Clérigo"){
   var fa={n:sk.n,col:fcol};
   if(sk.hl)fa.hp=sk.hl*pw0*Wp.curaMult(j);
   if(sk.df){fa.df=sk.df*pw0;fa.dfT=sk.t;}
   if(sh){fa.sh=sh;fa.shT=8;}
   if(sk.pur)fa.pur=1;
   if(sk.inv)fa.inv=sk.inv*1.5;
   if(sk.t)fa.tb={n:sk.n,t:sk.t,dm:(sk.dm||0)*pw0,red:Math.min(.9,(sk.red||0)*pw0),reg:(sk.reg||0)*pw0,cc:sk.cc||0};
   buffAliados(fa);}
 }else{
  var t1=cercanoCursor();if(!t1){txt(px,py,"Sin objetivo","#aaa",12,30);return false;}
  t1.mk={dm:sk.dm,cof:(sk.cof||0)+M[k+"cof"],orp:(sk.orp||0)+M[k+"oro"],bf:sk.bf||null};
  fxRamaMarca(sk,px,py,t1,col);txt(t1.ux,t1.uy,"🎯 Marcado","#e0c060",13,50);
 }
 return true;}
/* ---- habilidades de clase (las 3 base + las 2 de la rama) ---- */
function lanzarH(i){
 var h=PS.habs[i];if(!h||!SJ||!SJ.W||MUERTE||tp||PS.stunT>0||PS.dashT>0)return;
 var j=SJ.j,st=SJ.st,M=SJ.M,Wp=SJ.W,ef=h.efecto,ok=true,px=PX(),py=PY();
 if(PS.silT>0){txt(px,py,"🔇 Silenciado","#b070e0",13,30);return;}
 if(PS.cd[i]>0)return;
 if(PS.mp<h.costo){txt(px,py,"Sin "+(j.recursoNombre||"recurso"),"#6a9ae8",12,30);return;}
 var bt=blancoW(),ang=bt?angA(bt):asistirAng(PS.face),cl=SJ.col;
 function B(){return mrnd(st.atkMin,Math.max(st.atkMin,st.atkMax))*Wp.gmGlob(j,i);}
 function cursor(maxd){var mx,my;if(bt){mx=bt.ux;my=bt.uy;}else{mx=px+Math.cos(ang)*maxd*.7;my=py+Math.sin(ang)*maxd*.7;}var dx=mx-px,dy=my-py,d=Math.hypot(dx,dy)||1,k=Math.min(1,maxd/d);return{x:px+dx*k,y:py+dy*k};}
 function tm(fn,t){TML.push({t:t,fn:fn});}
 if(ef==="dano_150_stun"){
  var Tg=objMelee();
  if(!Tg||!enAlcance(Tg)){ok=false;sinObjMelee(Tg);}
  else{
   irA(Tg);px=PX();py=PY();ang=angA(Tg);
   fx({k:"slash",x:px,y:py,a:ang,r:118,arc:2.4,w:15,col:"#ffb060",life:.3});
   fx({k:"slash",x:px,y:py,a:ang,r:105,arc:2.2,w:10,col:"#ffe0a0",flip:true,t:-.1,life:.26});
   fx({k:"shock",x:px+Math.cos(ang)*70,y:py+Math.sin(ang)*70,r1:70,col:"#ffb060",t:-.05,life:.4,low:true,rays:8,a0:ang});
   humo(px+Math.cos(ang)*60,py+Math.sin(ang)*60,4,"#b8a080",30,.5,26);
   herir(Tg,B()*1.5,{stun:1.5,kb:150,col:"#ffb060"});
   cono(px,py,ang,115,2.4,function(e){if(e!==Tg)herir(e,B()*1.5,{stun:1.5,kb:150,col:"#ffb060"});});SHK=4;}
 }else if(ef==="def_30_2t"||ef==="def_50_3t"){
  var sac=ef.indexOf("50")>=0,cd=sac?"#ffe080":"#8ab0d8";
  var bo=Math.floor(((sac)?50:Math.floor(st.def*.3))*st.potencia*(1+M["bp"+i]));
  PS.defB=bo;PS.defT=((ef.indexOf("3t")>=0?3:2)+M.durx)*TS();
  fx({k:"shock",x:px,y:py,r1:80,col:cd,life:.5,low:true,rays:0});
  fx({k:"dome",r:36,col:cd,life:.8});motas(px,py,14,cd,24,70,.9);
  if(sac){fx({k:"pillar",x:px,y:py,col:cd,w:44,h:260,life:.7});destello("#ffe9a0",.18);}
  txt(px,py,"+"+bo+" DEF",cd,14,30);
  if(sac)buffAliados({n:"Sentencia de Luz",col:cd,dfl:bo,dfT:PS.defT});
 }else if(ef==="robo_vida_50"){
  var Te=objMelee();
  if(!Te||!enAlcance(Te)){ok=false;sinObjMelee(Te);}
  else{
   irA(Te);ang=angA(Te);px=PX();py=PY();
   fx({k:"slash",x:px,y:py,a:ang,r:122,arc:1.7,w:15,col:"#c04040",life:.3});
   fx({k:"slash",x:px,y:py,a:ang,r:100,arc:1.5,w:9,col:"#ff9080",flip:true,t:-.08,life:.24});
   chispas(px+Math.cos(ang)*60,py+Math.sin(ang)*60,8,"#c04040",200,.5,24);
   herir(Te,B(),{heal:.5,kb:100,col:"#c04040"});
   cono(px,py,ang,100,1.6,function(e){if(e!==Te)herir(e,B(),{heal:.5,kb:100,col:"#c04040"});});}
 }else if(ef==="escudo_vida"){
  PS.sh=Math.floor(PS.max*.4*st.potencia);PS.shT=8;
  fx({k:"dome",r:40,col:"#8ab0d8",life:.9});
  fx({k:"shock",x:px,y:py,r1:70,col:"#8ab0d8",life:.5,low:true,rays:12,a0:0});motas(px,py,16,"#bcd8f8",26,80,1);
  txt(px,py,"Escudo "+PS.sh,"#8ab0d8",14,30);
 }else if(ef==="dano_200"){
  PRL.push({e:false,x:px,y:py,vx:Math.cos(ang)*950,vy:Math.sin(ang)*950,r:7,life:.6,raw:function(){return B()*2;},pierce:true,hit:[],col:"#f0e0a0",kb:130,sty:"tiro",hom:bt||null});
  fx({k:"beam",x1:px,y1:py,x2:px+Math.cos(ang)*260,y2:py+Math.sin(ang)*260,col:"#f0e0a0",w:5,life:.14});
  fx({k:"flare",x:px+Math.cos(ang)*20,y:py+Math.sin(ang)*20,z:24,col:"#f0e0a0",s:22,life:.2});
 }else if(ef==="aoe_75"){
  var cu0=cursor(380),mult=.45*(1+M.aoe);
  FXL.push({k:"mark",x:cu0.x,y:cu0.y,r:120,t:0,life:1.2,col:"#9ad060"});
  fx({k:"rune",x:cu0.x,y:cu0.y,r:120,col:"#9ad060",life:1.2,low:true,rot:1.2});
  [.35,.7,1.05].forEach(function(t){
   lluvia(cu0.x,cu0.y,115,9,"#d8e8a0",t,2.6,26);
   tm(function(){fx({k:"shock",x:cu0.x,y:cu0.y,r1:120,col:"#9ad060",life:.3,low:true,rays:0});circ(cu0.x,cu0.y,120,function(e){herir(e,B()*mult,{kb:40,col:"#d8e8a0"});});},t);});
 }else if(ef==="aoe_140"){
  var Ta=objMelee();
  if(!Ta||!enAlcance(Ta)){ok=false;sinObjMelee(Ta);}
  else{
   var ax=Ta.ux,ay=Ta.uy;ang=angA(Ta);
   fx({k:"shock",x:ax,y:ay,r1:158,col:"#ffe080",life:.45,low:true,rays:14,a0:0});
   fx({k:"pillar",x:ax,y:ay,col:"#ffe080",w:60,h:280,life:.5});
   chispas(ax,ay,16,"#fff0b0",330,.6,22);motas(ax,ay,10,"#ffe080",60,80,.8);destello("#fff2c0",.2);
   circ(ax,ay,155,function(e){herir(e,B()*1.4*(1+M.aoe),{kb:120,col:"#ffe080"});});SHK=5;}
 }else if(ef==="vida_max_75"){
  var cu=Math.floor(PS.max*.75);PS.hp=Math.min(PS.max,PS.hp+cu);
  fx({k:"pillar",x:px,y:py,col:"#7ab88a",w:56,h:290,life:.9});
  fx({k:"shock",x:px,y:py,r1:110,col:"#7ab88a",life:.6,low:true,rays:0});
  motas(px,py,24,"#c8ffd8",36,100,1.1);destello("#d0ffd8",.14);
  FXL.push({k:"ring",x:px,y:py,r0:60,r1:10,t:0,life:.5,col:"#7ab88a",fill:false,follow:true});txt(px,py,"+"+cu,"#7ab88a",18,30);
  buffAliados({n:"Bendición de Poderío",col:"#7ab88a",hp:.75});
 }else if(ef==="fuego_250"){
  PRL.push({e:false,x:px,y:py,vx:Math.cos(ang)*520,vy:Math.sin(ang)*520,r:12,life:1.2,raw:function(){return B()*2.5;},explode:{r:95,f:.5,raw:function(){return B()*2.5;}},col:"#ff7a30",sty:"fuego",hom:bt||null});
  fx({k:"flare",x:px+Math.cos(ang)*18,y:py+Math.sin(ang)*18,z:26,col:"#ff9a3a",s:24,life:.25});
 }else if(ef==="stun_aoe"){
  fx({k:"shock",x:px,y:py,r1:188,col:"#7ab8d8",life:.5,low:true,rays:12,a0:0});
  hielo(px,py,18,188);humo(px,py,10,"#bfe6ff",60,.9,50);destello("#cfeaff",.2);
  circ(px,py,185,function(e){herir(e,B()*.7*(1+M.aoe),{stun:2,kb:60,col:"#bfe6ff"});});SHK=4;
 }else if(ef==="punalada"){
  var t=objMelee();
  if(!t||!enAlcance(t)){ok=false;sinObjMelee(t);}
  else{
   irA(t,true,0);ang=angA(t);
   herir(t,B()*2.5,{kb:40,col:"#b070e0"});
   fx({k:"xslash",x:t.ux,y:t.uy,col:"#b070e0",s:34,life:.32});
   fx({k:"shock",x:t.ux,y:t.uy,r1:60,col:"#b070e0",life:.3,low:true,rays:0});}
 }else if(ef==="stun_2"){
  humo(px,py,26,"#8a8a96",120,1.1,70);humo(px,py,10,"#2a2a34",90,1.2,60);
  fx({k:"shock",x:px,y:py,r1:168,col:"#aaaab8",life:.5,low:true,rays:0});chispas(px,py,10,"#ffd080",260,.5,20);
  circ(px,py,165,function(e){aturde(e,3.5*jf2(e));});
  PS.invT=Math.max(PS.invT,2);txt(px,py,"Inmune","#7ab88a",13,30);
 }else if(ef==="atk_mult"){
  var bt2=objMelee(),ls=EN().filter(function(e){return e!==bt2&&dEP(e)<=MAXT;}).sort(function(a,b){return a.vida-b.vida;});
  if(bt2)ls=[bt2].concat(ls);
  ls=ls.slice(0,3);
  if(!ls.length||!enAlcance(ls[0])){ok=false;sinObjMelee(ls[0]);}
  else{ang=angA(ls[0]);for(var q=0;q<3;q++)(function(q){var t=ls[q%ls.length];tm(function(){
   if(!vivo(t))return;
   irA(t,true,Math.floor(q/ls.length));
   fx({k:"xslash",x:t.ux,y:t.uy,col:"#c070d0",s:28,ro:q*.6,life:.28});
   herir(t,B(),{kb:30,col:"#c070d0"});
  },q*.18);})(q);}
 }else if(ef==="inmunidad_60"){
  var dx0=0,dy0=0;if(keys.w||keys.arrowup){dx0--;dy0--;}if(keys.s||keys.arrowdown){dx0++;dy0++;}if(keys.a||keys.arrowleft){dx0--;dy0++;}if(keys.d||keys.arrowright){dx0++;dy0--;}
  var jm0=joyMov();if(!dx0&&!dy0&&jm0){dx0=jm0.dx;dy0=jm0.dy;}
  humo(px,py,5,"#9ab89a",12,.45,22);fx({k:"shock",x:px,y:py,r1:55,col:"#9ad060",life:.3,low:true,rays:0});
  dashW((dx0||dy0)?Math.atan2(dy0,dx0):(bt?angA(bt)+Math.PI:ang+Math.PI),240,.22,B()*.6);PS.invT=Math.max(PS.invT,2);
 }else if(ef==="pulso_vital"){
  var cv=Math.floor(PS.max*.25*Wp.curaMult(j)*(1+M.bp0)),cvr=175;
  PS.hp=Math.min(PS.max,PS.hp+cv);
  fx({k:"rune",x:px,y:py,r:cvr,col:"#8ff0d0",life:.9,low:true,rot:1.4});
  fx({k:"shock",x:px,y:py,r1:cvr,col:"#ffe9a0",life:.5,low:true,rays:12,a0:0});
  fx({k:"pillar",x:px,y:py,col:"#9ff0d8",w:56,h:260,life:.7});
  motas(px,py,22,"#c8ffe8",40,100,1.1);destello("#d8fff0",.14);
  FXL.push({k:"ring",x:px,y:py,r0:20,r1:cvr*.6,t:0,life:.5,col:"#8ff0d0",fill:false,follow:true});
  txt(px,py,"+"+cv,"#7ab88a",18,30);
  buffAliados({n:"Pulso Vital",col:"#8ff0d0",hp:.25*Wp.curaMult(j)*(1+M.bp0)},cvr/U+1);
  circ(px,py,cvr,function(e){herir(e,B()*1.1*(1+M.aoe),{kb:70,col:"#ffe9a0"});});SHK=3;
 }else if(ef==="egida_rad"){
  var bo2=Math.floor(st.def*.4*st.potencia*(1+M.bp1)),es2=Math.floor(PS.max*.2*st.potencia*(1+M.cura));
  PS.defB=bo2;PS.defT=(3+M.durx)*TS();PS.sh=es2;PS.shT=Math.max(8,PS.defT);
  fx({k:"dome",r:42,col:"#8ff0d0",life:1});fx({k:"shock",x:px,y:py,r1:90,col:"#8ff0d0",life:.5,low:true,rays:12,a0:0});
  motas(px,py,16,"#c8ffe8",26,80,1);
  txt(px,py,"+"+bo2+" DEF · Escudo "+es2,"#8ff0d0",13,30);
  buffAliados({n:"Égida Radiante",col:"#8ff0d0",df:.4*st.potencia*(1+M.bp1),dfT:PS.defT,sh:.2*st.potencia*(1+M.cura),shT:PS.shT});
 }else if(ef==="pureza"){
  purgarControl();
  j.tb={n:"Pureza",t:(3+M.durx)*TS(),dm:.25*Wp.potBuff(st)*(1+M.bp2),cc:1,acc:0};
  fx({k:"pillar",x:px,y:py,col:"#ffe9a0",w:50,h:260,life:.8});fx({k:"dome",r:38,col:"#ffe9a0",life:.9});
  motas(px,py,18,"#fff2c0",30,90,1);destello("#fff2c0",.14);
  txt(px,py,"✨ Purga · +"+Math.round(j.tb.dm*100)+"% daño","#ffe9a0",13,30);
  buffAliados({n:"Plegaria de Pureza",col:"#ffe9a0",pur:1,tb:{n:"Pureza",t:j.tb.t,dm:j.tb.dm,cc:1}});
 }else if(ef==="rama"){ok=lanzarRama(h.rama,i);}else ok=false;
 if(ok){PS.mp-=h.costo;PS.cd[i]=h.cd*TS();lanzando(cl);carasA(ang);PS.comb=6;}
}
/* ---- ataque básico (arma, tajos y proyectiles como en el combate en tiempo real) ---- */
function bfRapido(){var tb=SJ&&SJ.j&&SJ.j.tb;return tb&&tb.vl2&&PS.hp<PS.max*.2?1.3:1;}
function intAtaque(){return TS()/(SJ.vel*bfRapido())*.35;}
var MELEE_R={Guerrero:[84,2.0],Paladin:[80,2.1],Asesino:[66,1.55]};
function alcanceB(Tg){return esMelee()?MELEE_R[SJ.clase][0]*.8+Tg.r:reachJ()*U;}   /* unidades */
function atacar(Tg){
 if(MUERTE||!Tg||!vivo(Tg)||PS.atkT>0||!SJ||PS.stunT>0||PS.dashT>0)return false;
 if(dEP(Tg)>alcanceB(Tg)+8)return false;
 var st=SJ.st,j=SJ.j,M=SJ.M,Wp=SJ.W,cl=SJ.col,ang=angA(Tg),px=PX(),py=PY(),nx=PS.nx,R=MELEE_R[SJ.clase];
 PS.atkT=intAtaque();PS.swing=.16;PS.comb=6;PS.regW=REGEN_ESPERA;carasA(ang);
 if(M.dbl&&Math.random()<M.dbl)PS.atkT*=.35;
 if(M.rec)PS.mp=Math.min(PS.mpMax,PS.mp+M.rec);
 if(nx){nx.h--;if(nx.h<=0)PS.nx=null;}
 var f=(Wp&&Wp.gmGlob?Wp.gmGlob(j,-1):1)*(1+M.clone);
 function B0(){return mrnd(SJ.atkMin,Math.max(SJ.atkMin,SJ.atkMax));}
 if(esMelee()){
  var ase=SJ.clase==="Asesino";PS.sw=!PS.sw;
  fx({k:"slash",x:px,y:py,a:ang,r:R[0],arc:R[1],w:ase?6:10,col:cl,flip:PS.sw,life:.2});
  if(ase)fx({k:"slash",x:px,y:py,a:ang,r:R[0]*.9,arc:R[1]*.9,w:5,col:"#dcdce8",flip:!PS.sw,t:-.05,life:.18});
  var hit=false,first=null;
  if(ase){var cand=[];cono(px,py,ang,R[0],R[1],function(e){cand.push(e);});
   var one=(cand.indexOf(Tg)>=0)?Tg:cand.sort(function(a,b){return dEP(a)-dEP(b);})[0];
   if(one){hit=true;first=one;herir(one,B0()*f*(nx?1+nx.dm:1),{crit:true,fc:!!nx,kb:90,col:cl});}
  }else cono(px,py,ang,R[0],R[1],function(e){hit=true;if(!first)first=e;herir(e,B0()*f*(nx?1+nx.dm:1),{crit:true,fc:!!nx,kb:90,col:cl});});
  if(nx&&nx.bn&&first)rebotar(first,B0()*f*(1+nx.dm),nx.bn);
  if(hit)PS.mp=Math.min(PS.mpMax,PS.mp+PS.mpMax*HIT_GAIN);
 }else{
  var cler=SJ.clase==="Clérigo",mago=SJ.clase==="Mago"||cler,cOrb=cler?"#ffe9a0":"#b09aff",x0=px+Math.cos(ang)*18,y0=py+Math.sin(ang)*18;
  PRL.push({e:false,x:x0,y:y0,x00:x0,y00:y0,vx:Math.cos(ang)*(mago?560:700),vy:Math.sin(ang)*(mago?560:700),r:mago?9:5,life:.85,mult:1,basic:true,f:f,nxd:nx?{dm:nx.dm,bn:nx.bn}:null,col:mago?cOrb:"#cfe8a0",sty:mago?"orbe":"flecha",hom:Tg});
  fx({k:"flare",x:x0,y:y0,z:22,col:mago?cOrb:"#cfe8a0",s:mago?16:11,life:.14});
 }
 return true;}
var REGEN_ESPERA=10,REGEN_MP=.02,HIT_GAIN=.015,POT_CD=4;   /* REGEN_ESPERA: segundos en combate (sin regenerar vida ni recurso) tras el último evento de combate */
function enCombate(){return PS.regW>0;}
/* perseguido: algún monstruo vivo en persecución cerca del jugador (fuera de la zona segura) */
function perseguido(){if(enCampo())return false;for(var i=0;i<MON.length;i++){var m=MON[i];if(!m.muerto&&m.st==="chase"&&Math.hypot(m.x-P.x,m.y-P.y)<16)return true;}return false;}
/* ---- proyectiles del jugador ---- */
function prStep(dt){
 for(var k=PRL.length-1;k>=0;k--){
  var p2=PRL[k];
  if(p2.hom&&vivo(p2.hom)&&!(p2.hit&&p2.hit.indexOf(p2.hom)>=0)){var sp0=Math.hypot(p2.vx,p2.vy),ca=Math.atan2(p2.vy,p2.vx),da=clamp(angd(Math.atan2(p2.hom.uy-p2.y,p2.hom.ux-p2.x),ca),-9*dt,9*dt);ca+=da;p2.vx=Math.cos(ca)*sp0;p2.vy=Math.sin(ca)*sp0;}
  p2.x+=p2.vx*dt;p2.y+=p2.vy*dt;p2.life-=dt;
  if(p2.sty&&FXL.length<300){p2.te=(p2.te||0)+dt;var iv=p2.sty==="fuego"?.016:.03;while(p2.te>iv){p2.te-=iv;trailPr(p2);}}
  var fin=p2.life<=0;
  var bx=Math.floor(p2.x/U),by=Math.floor(p2.y/U);
  if(!fin&&(!inb(bx,by)||(blk[I(bx,by)]&&Math.hypot(p2.x-(p2.x00===undefined?p2.x:p2.x00),p2.y-(p2.y00===undefined?p2.y:p2.y00))>48))){fin=true;if(p2.explode)boom(p2.x,p2.y,p2.explode.r,"#ff7a30");p2.explode=null;FXL.push({k:"part",x:p2.x,y:p2.y,vx:rf(-60,60),vy:rf(-60,60),t:0,life:.25,col:"#aaa"});}
  if(!fin){
   var arr=EN();
   for(var m=0;m<arr.length;m++){
    var e=arr[m];
    if(Math.hypot(e.ux-p2.x,e.uy-p2.y)<e.r+p2.r){
     if(p2.pierce){if(p2.hit.indexOf(e)>=0)continue;p2.hit.push(e);herir(e,p2.raw(),{kb:p2.kb});continue;}
     if(p2.basic){var rb=mrnd(SJ.atkMin,Math.max(SJ.atkMin,SJ.atkMax))*p2.f*(p2.nxd?1+p2.nxd.dm:1);herir(e,rb,{crit:true,fc:!!p2.nxd,kb:70});if(p2.nxd&&p2.nxd.bn)rebotar(e,rb,p2.nxd.bn);PS.mp=Math.min(PS.mpMax,PS.mp+PS.mpMax*HIT_GAIN);}
     else herir(e,p2.raw(),{kb:90});
     if(p2.explode){var ex=p2.explode;boom(p2.x,p2.y,ex.r,"#ff7a30");destello("#ffb060",.12);circ(p2.x,p2.y,ex.r,function(o){if(o!==e)herir(o,ex.raw()*ex.f,{kb:80});});SHK=5;}
     fin=true;break;}}}
  if(fin){if(p2.explode&&p2.life<=0)boom(p2.x,p2.y,p2.explode.r,"#ff7a30");PRL.splice(k,1);}}}
/* ---- daño al jugador ---- */
function golpeMon(m,mx,stn){
 if(MUERTE||!SJ)return;
 var tipo=m.tipoDano||"fisico",Wp=SJ.W,M=SJ.M,j=SJ.j,CD=(Wp&&Wp.COLOR_DANO)||{fisico:"#e05050",magico:"#b070e0"},px=PX(),py=PY();
 if(PS.invT>0){txt(px,py,"Inmune","#7ab88a",12,24);return;}
 if(tipo==="fisico"&&Math.random()*100<SJ.probEsq){txt(px,py,"Esquiva","#8ab0d8",13,24);return;}
 var base=Math.floor(mrnd(m.atkMin,m.atkMax)*(mx||1)),critE=Math.random()*100<(m.pCrit||0);if(critE)base=Math.floor(base*(m.critMult||1.5));
 var def=SJ.def+PS.defB+(tipo==="magico"?SJ.redMag:SJ.redFis),pd=(Wp&&Wp.PISO_DANO)||.3,
     d=Wp?Wp.danoMitigado(base,def,critE):Math.max(1,Math.floor(base*100/(100+Math.max(0,def)))),
     dr=Math.min(.9,M.dr+(j&&j.tb&&j.tb.red||0));
 d=Math.max(Math.floor(d*(1-dr)),Math.max(1,Math.floor(base*pd)));
 if(PS.sh>0){if(d<=PS.sh){PS.sh-=d;d=0;}else{d-=PS.sh;PS.sh=0;}}
 PS.hp-=d;PS.hurt=.25;PS.comb=6;PS.regW=REGEN_ESPERA;PS.sinDano=false;
 if(stn>0&&d>0&&!(PS.resStun>0)){PS.stunT=Math.max(PS.stunT,stn);PS.resStun=stn+2.5;txt(px,py,"💫 Aturdido","#ffe680",13,40);}
 if(j&&j.tb&&j.tb.ref&&d>0)herir(m,d*j.tb.ref,{});
 SHK=Math.max(SHK,4);
 txt(px,py,d>0?(critE?"💥"+d:String(d)):"Bloqueado",CD[tipo],d>0?(critE?20:16):12,24);
 if(!(PS.hp>0)){PS.hp=0;morir();}}
function morir(){
 if(MUERTE)return;MUERTE={t:0,hecho:false};PS.tg=null;P.path=[];tgt=null;P.mv=0;PS.dashT=0;PRL.length=0;TML.length=0;
 anunciar("☠ Has caído…");if(SIM.on)envia({t:"mon_est",mu:1});
 MON.forEach(function(m){if(!m.muerto){if(m.st==="chase")m.st="back";m.wind=0;}});}
function muerteStep(dt){
 if(!MUERTE)return;MUERTE.t+=dt;
 if(!MUERTE.hecho&&MUERTE.t>=.9){MUERTE.hecho=true;
  var ok=false;for(var n=0;n<60&&!ok;n++){var X=Math.floor(CC.x)+Math.floor(Math.random()*7)-3,Y=Math.floor(CC.y)+3+Math.floor(Math.random()*4);if(!blk[I(X,Y)]){P.x=X+.5;P.y=Y+.5;ok=true;}}
  cam=pj(P.x,P.y);P.dir=0;PS.hp=Math.max(1,Math.floor(PS.max*.5));PS.comb=0;PS.regW=0;PS.sh=0;PS.shT=0;PS.defB=0;PS.defT=0;PS.invT=0;PS.stunT=0;PS.silT=0;PS.nx=null;if(SJ&&SJ.j)SJ.j.tb=null;
  curSec=0;revela(Math.floor(P.x),Math.floor(P.y),18);
  anunciar("Los soldados te llevan de vuelta al campamento");if(SIM.on)envia({t:"mon_est",mu:0});}
 if(MUERTE.t>=1.8)MUERTE=null;}
function recompensa(m){
 var Wp=SJ&&SJ.W,j=SJ&&SJ.j,xp=Math.max(1,Math.floor(m.xp*m.rec));
 if(!Wp||!j){ftxt(m.x,m.y,"+"+xp+" XP","#ffe080",13,60);return;}
 try{
  var n0=j.nivel,oro0=j.oro,lg=Wp.G.log,fama0=j.fama||0,tit0=Wp.tituloJ?Wp.tituloJ(j):"";Wp.G.log=[];
  Wp.ganarXP(j,xp);
  Wp.dropearLoot(m,j);
  var dO=j.oro-oro0;if(m.rec>1&&dO>0)j.oro+=Math.floor(dO*(m.rec-1));
  try{if(Wp.cosechar)Wp.cosechar(j,m);}catch(e){}
  try{if(m.mk&&Wp.marcaMuerta)Wp.marcaMuerta(j,m);}catch(e){}
  try{if(Wp.registrarBaja)Wp.registrarBaja(j,m.nombre,PS.sinDano,0);}catch(e){}
  var items=[];Wp.G.log.forEach(function(l){var q=/^\s+\+(\d+) de oro/.exec(l);if(q)return;var w=/^\s+(?:☠ Extremo: )?\+1 (.+?) \[/.exec(l);if(w)items.push(w[1]);});
  Wp.G.log=lg;
  if(n0>=100)ftxt(m.x,m.y,"+"+((j.fama||0)-fama0)+" fama","#d8a0ff",13,60);else ftxt(m.x,m.y,"+"+xp+" XP","#ffe080",13,60);
  if(Wp.tituloJ&&Wp.tituloJ(j)!==tit0){anunciar("🏅 ¡Nuevo título: "+Wp.tituloJ(j)+"!");ftxt(P.x,P.y,"🏅 "+Wp.tituloJ(j),"#ffe080",18,80);}
  var go=j.oro-oro0;if(go>0)ftxt(m.x,m.y,"+"+go+" oro","#f0c040",12,74);
  items.slice(0,3).forEach(function(it,k){ftxt(m.x,m.y,"+1 "+it,"#9fe8a0",11,88+k*13);});
  if(j.nivel>n0){refrescaSJ();PS.hp=PS.max;PS.mp=PS.mpMax;ftxt(P.x,P.y,"★ Nivel "+j.nivel,"#ffe080",18,80);destello("#ffe080",.25);anunciar("★ ¡Nivel "+j.nivel+"!");}
  PS.rst=1;
 }catch(e){ftxt(m.x,m.y,"+"+xp+" XP","#ffe080",13,60);}}
function guardaVida(){var Wp=SJ&&SJ.W;if(!Wp||!SJ.j)return;try{var j=SJ.j,tb=j.tb;j.vida=Math.max(1,Math.round(PS.hp));j.recurso=Math.max(0,Math.round(PS.mp));if(PS.rst){PS.rst=0;j.tb=null;Wp.guardar();j.tb=tb;}}catch(e){}}
addEventListener("pagehide",function(){guardaVida();try{if(SJ&&SJ.j){SJ.j.tb=null;SJ.j.nx=null;}}catch(e){}});
/* ---- pociones del cinturón ---- */
function potCuenta(tipo){var Wp=SJ&&SJ.W,j=SJ&&SJ.j,n=0;if(!Wp||!j)return 0;Wp.POCIONES.forEach(function(p){if(p.tipo===tipo||p.tipo==="full")n+=j.inventario[p.n]||0;});return n;}
function usaPocion(nombre,auto){
 var Wp=SJ&&SJ.W,j=SJ&&SJ.j,px=PX(),py=PY();if(!Wp||!j||MUERTE||tp)return;
 if(PS.potT>0)return;
 var p=null,f=Wp.factorMaldicion(j,"cura");
 if(auto){var tipo=auto==="v"?"vida":"recurso",cand=Wp.POCIONES.filter(function(q){return q.tipo===tipo&&(j.inventario[q.n]||0)>0;}).sort(function(a,b){return a.pct-b.pct;});
  if(!cand.length)cand=Wp.POCIONES.filter(function(q){return q.tipo==="full"&&(j.inventario[q.n]||0)>0;});
  if(!cand.length){txt(px,py,"Sin pociones","#aaa",12,30);return;}
  var mx=auto==="v"?PS.max:PS.mpMax,cur=auto==="v"?PS.hp:PS.mp,falta=mx-cur;
  p=cand.filter(function(q){return Math.floor(mx*q.pct*f)>=falta;})[0]||cand[cand.length-1];
 }else p=Wp.POCIONES.filter(function(q){return q.n===nombre;})[0];
 if(!p||(j.inventario[p.n]||0)<=0){txt(px,py,"Sin pociones","#aaa",12,30);return;}
 j.inventario[p.n]--;if(j.inventario[p.n]<=0)delete j.inventario[p.n];
 if(p.tipo==="full"){PS.hp=PS.max;PS.mp=PS.mpMax;txt(px,py,"¡Restaurado!","#e0c060",15,24);fx({k:"pillar",x:px,y:py,col:"#e0c060",w:40,h:200,life:.6});}
 else if(p.tipo==="vida"){var c=Math.floor(PS.max*p.pct*f);PS.hp=Math.min(PS.max,PS.hp+c);txt(px,py,"+"+c,"#7ab88a",15,24);motas(px,py,8,"#c8ffd8",20,70,.8);}
 else{var r=Math.floor(PS.mpMax*p.pct*f);PS.mp=Math.min(PS.mpMax,PS.mp+r);txt(px,py,"+"+r,"#6a9ae8",15,24);motas(px,py,8,"#bcd8ff",20,70,.8);}
 PS.potT=POT_CD;PS.rst=1;try{var tb=j.tb;j.tb=null;Wp.guardar();j.tb=tb;}catch(e){}}
function monAlerta(m){
 if(m.st==="chase")return;m.st="chase";ftxt(m.x,m.y,"!","#ff6a4a",16,46);m.cd=Math.max(m.cd,.45);
 if(Math.hypot(m.x-P.x,m.y-P.y)<14){PS.comb=Math.max(PS.comb,4);PS.regW=REGEN_ESPERA;}
 if(m.pack){var gr=[m];for(var i=0;i<MON.length;i++){var o=MON[i];if(o.pack===m.pack&&!o.muerto&&o.st!=="chase"&&Math.hypot(o.x-m.x,o.y-m.y)<8){o.st="chase";o.cd=Math.max(o.cd,.45+Math.random()*.4);gr.push(o);}}if(IAM)IAM.slots(gr);}}
function empezarGolpe(m,dx,dy){m.windMax=m.wind=IAM?IAM.ventana(m):.42*(m.alfa?.9:1);m.windA=Math.atan2(dy,dx);}
function resolverMon(m){
 var A=m.windA,rad=m.r+14+34,CD=(SJ&&SJ.W&&SJ.W.COLOR_DANO)||{fisico:"#e05050",magico:"#b070e0"};
 m.cd=IAM?IAM.trasGolpe(m):(.62*(.85+Math.random()*.35))/(m.spd>3.6?1.15:1);
 fx({k:"slash",x:m.x*U,y:m.y*U,a:A,r:rad,arc:Math.PI*1.1,w:8,col:CD[m.tipoDano||"fisico"],flip:Math.random()<.5,life:.22});
 if(MUERTE)return;
 var dd=Math.hypot(P.x-m.x,P.y-m.y)*U,a2=Math.atan2(P.y-m.y,P.x-m.x);
 if(dd<=rad&&Math.abs(angd(a2,A))<=Math.PI*.55)golpeMon(m);}
function monStep(dt){
 if(NAVC)NAVC.tick();
 var seg=enCampo(),noc=noche(),i,m,slow=1-Math.min(.6,(SJ&&SJ.M&&SJ.M.slow)||0);
 for(i=0;i<MON.length;i++){m=MON[i];
  if(m.muerto){m.mt+=dt;continue;}
  if(m.flash>0)m.flash-=dt;m.cd-=dt;
  if(m.kx||m.ky){if(Math.hypot(m.kx,m.ky)>.04){var kx2=m.x+m.kx*dt,ky2=m.y+m.ky*dt;if(monLibre(kx2,ky2)){m.x=kx2;m.y=ky2;}else{m.kx=0;m.ky=0;}var kf=Math.max(0,1-dt*9);m.kx*=kf;m.ky*=kf;}else{m.kx=0;m.ky=0;}}
  if(m.stunT>0){m.stunT-=dt;m.wind=0;m.mv=0;continue;}
  var dx=P.x-m.x,dy=P.y-m.y,d=Math.hypot(dx,dy),dh=Math.hypot(m.x-m.hx,m.y-m.hy),spd=m.spd*slow;
  if(m.wind>0){m.wind-=dt;m.mv=0;m.dir=dirOf(dx,dy);if(m.wind<=0){m.wind=0;resolverMon(m);}continue;}
  if(m.st==="idle"){
   m.wt-=dt;
   if(m.wt<=0){m.wt=2+Math.random()*4;if(Math.random()<.6){var a=Math.random()*6.283,r=Math.random()*4.5;m.wx=m.hx+Math.cos(a)*r;m.wy=m.hy+Math.sin(a)*r;}else{m.wx=m.x;m.wy=m.y;}}
   if(Math.hypot(m.wx-m.x,m.wy-m.y)>.2)monPaso(m,m.wx,m.wy,spd*.35,dt);else m.mv=0;
   if(!seg&&d<m.agro*(1+.25*noc))monAlerta(m);
  }else if(m.st==="chase"){
   if(seg||d>m.agro*2.4||dh>24||MUERTE){m.st="back";if(IAM)IAM.olvida(m);}
   else if(IAM){var ox=m.x,oy=m.y,go=IAM.chase(navMon(),m,P,d,dt,spd);
    if(m.mv&&(m.x!==ox||m.y!==oy))m.dir=dirOf(m.x-ox,m.y-oy);else m.dir=dirOf(dx,dy);
    if(go)empezarGolpe(m,dx,dy);
    if(IAM.sinCamino(m)){m.st="back";IAM.olvida(m);}}
   else if(d>m.reach){monPaso(m,P.x,P.y,spd,dt);}
   else{m.mv=0;m.dir=dirOf(dx,dy);if(m.cd<=0)empezarGolpe(m,dx,dy);}
  }else{
   m.vida=Math.min(m.vidaMax,m.vida+m.vidaMax*.12*dt);
   if(Math.hypot(m.hx-m.x,m.hy-m.y)<.6){m.st="idle";m.mv=0;}else monPaso(m,m.hx,m.hy,spd*1.1,dt);
   if(!seg&&d<m.agro*.7&&m.vida>m.vidaMax*.5)monAlerta(m);
  }
 }
 for(i=0;i<MON.length;i++){var a1=MON[i];if(a1.muerto)continue;for(var j=i+1;j<MON.length;j++){var b1=MON[j];if(b1.muerto)continue;var ddx=b1.x-a1.x,ddy=b1.y-a1.y,dd=ddx*ddx+ddy*ddy;
  if(dd<.36&&dd>1e-6){var l=Math.sqrt(dd),p=(.6-l)*.5;if(monLibre(a1.x-ddx/l*p,a1.y-ddy/l*p)){a1.x-=ddx/l*p;a1.y-=ddy/l*p;}if(monLibre(b1.x+ddx/l*p,b1.y+ddy/l*p)){b1.x+=ddx/l*p;b1.y+=ddy/l*p;}}}}
 for(i=MON.length-1;i>=0;i--)if(MON[i].muerto&&MON[i].mt>.9){if(PS.tg===MON[i])PS.tg=null;MON.splice(i,1);}
 for(i=MONRESP.length-1;i>=0;i--){var rs=MONRESP[i];if(T<rs.t)continue;
  if(monVivos(rs.sk)>=monObjetivo(rs.sk)){MONRESP.splice(i,1);continue;}
  var c=celdaSpawn(rs.sk,24);if(c){crearMon(rs.sk,c.x,c.y);MONRESP.splice(i,1);}else rs.t=T+3;}
}
/* ---- bucle de combate del jugador ---- */
function fxStep(dt){
 var i;
 for(i=TML.length-1;i>=0;i--){TML[i].t-=dt;if(TML[i].t<=0){var f=TML[i].fn;TML.splice(i,1);f();}}
 for(i=FXL.length-1;i>=0;i--){var x=FXL[i];x.t+=dt;
  if(x.t>0){if(x.vx!==undefined){x.x+=x.vx*dt;x.y+=x.vy*dt;}if(x.vz!==undefined){x.z+=x.vz*dt;x.vz-=(x.g||0)*dt;if(x.z<0){x.z=0;x.vz=Math.abs(x.vz)*.2;}}}
  if(x.t>=x.life){if(x.fin)x.fin(x);FXL.splice(i,1);}}
 for(i=TXL.length-1;i>=0;i--){var t=TXL[i];t.a+=dt;t.y-=28*dt;t.x+=(t.vx||0)*dt;if(t.a>=t.life)TXL.splice(i,1);}
 SHK=Math.max(0,SHK-dt*20);if(FLS){FLS.a-=dt*2.4;if(FLS.a<=0)FLS=null;}}
function combateStep(dt){
 if(!SJ||MUERTE)return;
 var j=SJ.j,M=SJ.M,tb=j&&j.tb,i;
 syncU();
 ["atkT","invT","stunT","silT","potT","resStun","hurt","swing","castT"].forEach(function(n){if(PS[n]>0)PS[n]=Math.max(0,PS[n]-dt);});
 for(i=0;i<5;i++)if(PS.cd[i]>0)PS.cd[i]=Math.max(0,PS.cd[i]-dt);
 if(PS.sprT>0){PS.sprT-=dt;if(PS.sprT<=0){PS.sprT=0;PS.sprCd=SPR_CD;}}else if(PS.sprCd>0)PS.sprCd=Math.max(0,PS.sprCd-dt);
 if(PS.defT>0){PS.defT-=dt;if(PS.defT<=0)PS.defB=0;}
 if(PS.shT>0){PS.shT-=dt;if(PS.shT<=0)PS.sh=0;}
 PS.rep-=dt;
 if(PS.comb>0)PS.comb-=dt;
 /* ESTADO "EN COMBATE": te atacan, te persiguen o atacas a un enemigo -> se detiene la regeneración natural de vida y recurso.
    Pasados REGEN_ESPERA (10) s sin ninguno de esos factores, se reanuda. */
 if(perseguido())PS.regW=REGEN_ESPERA;
 else if(PS.regW>0)PS.regW=Math.max(0,PS.regW-dt);
 if(PS.regW<=0){
  PS.mp=Math.min(PS.mpMax,PS.mp+PS.mpMax*REGEN_MP*dt);
  if(PS.hp<PS.max){var rate=enCampo()?.06:.012;PS.hp=Math.min(PS.max,PS.hp+PS.max*rate*dt);}}
 if(tb&&tb.t>0&&Math.random()<dt*16)motas(PX(),PY(),1,SJ.col,16,55,.7);
 if(PS.nx&&Math.random()<dt*10)motas(PX(),PY(),1,"#ffe080",14,70,.6);
 if(M.regT)PS.hp=Math.min(PS.max,PS.hp+PS.max*M.regT*dt/TS());
 if(tb){tb.t-=dt;if(tb.reg)PS.hp=Math.min(PS.max,PS.hp+PS.max*tb.reg*dt/TS());
  if(tb.t<=0){if(tb.hp&&tb.acc){var hh=Math.floor(tb.acc*tb.hp);PS.hp=Math.min(PS.max,PS.hp+hh);txt(PX(),PY(),"+"+hh,"#7ab88a",15,30);}j.tb=null;}}
 if((PS.sync-=dt)<=0){PS.sync=1.5;guardaVida();}
 /* impulso (esquiva de habilidades) */
 if(PS.dashT>0){PS.dashT-=dt;P.mv=true;var nx=P.x+PS.dvx*dt,ny=P.y+PS.dvy*dt;if(libreP(nx,P.y))P.x=nx;if(libreP(P.x,ny))P.y=ny;
  if(PS.dashB>0)EN().forEach(function(e){if(PS.dashHit.indexOf(e)>=0||Math.hypot(e.ux-PX(),e.uy-PY())>e.r+22)return;PS.dashHit.push(e);herir(e,PS.dashB,{kb:120});});
  if(Math.random()<.8)FXL.push({k:"ghost",x:PX(),y:PY(),d:P.dir,t:0,life:.25});
 }
 var mv=keys.w||keys.a||keys.s||keys.d||keys.arrowup||keys.arrowdown||keys.arrowleft||keys.arrowright||!!joyMov(),tg=PS.tg;
 if(tg&&!vivo(tg))tg=PS.tg=null;
 if(mv)tg=PS.tg=null;
 if(PS.stunT>0||PS.dashT>0)return;
 if(tg){
  var al=alcanceB(tg);
  if(dEP(tg)>al){if(PS.rep<=0||!P.path.length){PS.rep=.5;ir(Math.floor(tg.x),Math.floor(tg.y));}}
  else{P.path=[];tgt=null;P.mv=0;atacar(tg);}
 }else if(keys.j||keys[" "]||PS.hold){var c=masCercanoU(alcanceB({r:14})+14);if(c)atacar(c);}
 if(!mv&&!P.path.length&&!PS.dashT){}
}
function simMundo(dt){
 fxStep(dt);prStep(dt);
 muerteStep(dt);
 if(!SJ||tp||(mEst===1&&!ONL.on))return;
 if((PS.reg2=(PS.reg2||0)-dt)<=0){PS.reg2=.5;refrescaSJ();}
 if(SIM.on)monStepSrv(dt);else monStep(dt);
 combateStep(dt);
 PS.enC=PS.comb>0;}
/* ---- dibujo ---- */
function dMon(m,t){
 var im=chImg(m.c);if(!im.complete||!im.naturalWidth)return;
 var inf=CHARS_INFO[m.c],fw=inf.w,fh=inf.h,s=pj(m.x,m.y),esc=m.esc,f=m.mv?[1,0,1,2][Math.floor(t*7+m.ph)%4]:1,al=m.muerto?Math.max(0,1-m.mt/.85):1;
 cx.save();cx.translate(s.x,s.y+4);cx.globalAlpha=al;
 if(m.alfa){var gr=cx.createRadialGradient(0,0,2,0,0,24);gr.addColorStop(0,"rgba(255,70,40,.55)");gr.addColorStop(1,"rgba(255,70,40,0)");cx.fillStyle=gr;cx.save();cx.scale(1,.5);cx.beginPath();cx.arc(0,0,26,0,7);cx.fill();cx.restore();}
 if(m.jefe){var gj=cx.createRadialGradient(0,0,2,0,0,40),cj=m.buffT>0?"138,176,216":"255,200,70";gj.addColorStop(0,"rgba("+cj+",.5)");gj.addColorStop(1,"rgba("+cj+",0)");cx.fillStyle=gj;cx.save();cx.scale(1,.5);cx.beginPath();cx.arc(0,0,44,0,7);cx.fill();cx.restore();}
 cx.fillStyle="rgba(0,0,0,.3)";cx.beginPath();cx.ellipse(0,0,Math.max(8,fw*esc*.28),4,0,0,7);cx.fill();
 cx.imageSmoothingEnabled=false;if(m.flash>0&&"filter" in cx)cx.filter="brightness(2.3)";
 if(m.muerto)cx.rotate(Math.min(1.2,m.mt*2.2)*(m.dir%2?1:-1)*.5);
 cx.drawImage(im,f*fw,m.dir*fh,fw,fh,-fw*esc/2,-(fh-3)*esc,fw*esc,fh*esc);
 if("filter" in cx)cx.filter="none";
 cx.restore();
 if(m.muerto)return;
 var top=(fh-(MON_TOP[m.c]||fh*.12))*esc+8,dd=Math.hypot(P.x-m.x,P.y-m.y);
 if(m.vida<m.vidaMax||m.st==="chase"||dd<7||m.jefe){
  cx.save();cx.translate(s.x,s.y+4-top);var w=m.jefe?72:Math.max(34,fw*esc*.6),p=Math.max(0,m.vida/m.vidaMax);
  cx.fillStyle="rgba(0,0,0,.65)";cx.fillRect(-w/2,0,w,5);cx.fillStyle=m.jefe?"#d4a017":m.alfa?"#ff7a2a":"#c8382e";cx.fillRect(-w/2,0,w*p,5);
  cx.strokeStyle=m.alfa||m.jefe?"#ffd24a":"rgba(0,0,0,.7)";cx.lineWidth=1;cx.strokeRect(-w/2-.5,-.5,w+1,6);
  if(dd<9||m.st==="chase"||m.jefe){cx.font="700 10px Cinzel,serif";cx.textAlign="center";cx.lineWidth=3;cx.strokeStyle="rgba(20,12,4,.85)";var lb=(m.jefe?"♛ ":m.alfa?"Alfa · ":"")+m.nombre;cx.strokeText(lb,0,-4);cx.fillStyle=m.jefe?"#ffd24a":m.alfa?"#ffb060":"#f5e6c0";cx.fillText(lb,0,-4);}
  cx.restore();}
 if(PS.tg===m){var ts=pj(m.x,m.y),by=ts.y+4-top-26-Math.abs(Math.sin(t*5))*3;cx.fillStyle="#ffd24a";cx.strokeStyle="rgba(0,0,0,.8)";cx.lineWidth=2;cx.beginPath();cx.moveTo(ts.x-6,by-8);cx.lineTo(ts.x+6,by-8);cx.lineTo(ts.x,by+3);cx.closePath();cx.stroke();cx.fill();}}
/* ---- dibujo del combate ---- */
function dSuelo(t){
 cx.save();
 FXL.forEach(function(f){if(f.k==="mark"){cx.strokeStyle=f.col;cx.globalAlpha=.4+.3*Math.sin(f.t*18);cx.lineWidth=2;elip(cx,f.x,f.y,f.r,false,true);cx.globalAlpha=1;}});
 FXL.forEach(function(f){if(f.low&&f.t>=0&&FXD[f.k]){cx.save();FXD[f.k](cx,f,f.t/f.life);cx.restore();}});
 var mt=vivo(PS.tg)?PS.tg:null;
 if(mt){var rr=mt.r+11+2*Math.sin(t*6);cx.save();cx.strokeStyle="#ffd24a";cx.lineWidth=2.5;cx.setLineDash([10,7]);cx.lineDashOffset=-t*30;elip(cx,mt.ux,mt.uy,rr,false,true);cx.setLineDash([]);cx.globalAlpha=.16;cx.fillStyle="#ffd24a";elip(cx,mt.ux,mt.uy,rr,true,false);cx.restore();}
 var CD=(SJ&&SJ.W&&SJ.W.COLOR_DANO)||{fisico:"#e05050",magico:"#b070e0"};
 for(var i=0;i<MON.length;i++){var m=MON[i];if(m.muerto||!(m.wind>0))continue;
  var hb=m.jefe&&m.windK?habJ(m,m.windK):null,pr=1-m.wind/m.windMax,rad=m.r+48+(hb&&hb.r||0),ar=hb&&hb.arc?hb.arc*Math.PI:Math.PI*.55,col=hb?hb.col:CD[m.tipoDano||"fisico"];
  cx.save();cx.globalAlpha=.18+.22*pr;cx.fillStyle=col;cx.strokeStyle=col;cx.lineWidth=2;
  if(hb&&!hb.m){elip(cx,m.x*U,m.y*U,m.r+10+50*pr,true,false);}
  else{sector2(cx,m.x*U,m.y*U,rad,m.windA-ar,m.windA+ar,true);cx.fill();if(hb){cx.globalAlpha=.55+.3*pr;cx.stroke();}}
  cx.restore();}
 cx.restore();}
function dMonX(m,t){
 if(m.muerto||!(m.stunT>0||m.mk))return;
 var s=pj(m.x,m.y),inf=CHARS_INFO[m.c],top=(inf.h-(MON_TOP[m.c]||inf.h*.12))*m.esc+8;
 cx.save();cx.translate(s.x,s.y+4-top-22);cx.textAlign="center";
 if(m.stunT>0){cx.font="bold 13px sans-serif";cx.fillStyle="#ffe680";for(var k=0;k<3;k++){var a=t*5+k*2.094;cx.fillText("✦",Math.cos(a)*14,Math.sin(a)*4);}}
 if(m.mk){cx.font="14px sans-serif";cx.fillText("🎯",18,-4);}
 cx.restore();}
function dPlayer(t){
 var ux=PX(),uy=PY(),en=PS.enC||PS.swing>0||PS.castT>0,cs=Math.cos(PS.face),sn=Math.sin(PS.face),cl=SJ?SJ.col:"#e8c9a0",clase=SJ?SJ.clase:"",ws=.85,
     ox=PS.swing>0?cs*5/U:0,oy=PS.swing>0?sn*5/U:0,s=pj(P.x,P.y);
 cx.save();
 if(PS.castT>0){var cu2=PS.castT/(PS.castMax||.4),g0=cx.createRadialGradient(s.x,s.y-26,4,s.x,s.y-26,50);cx.globalCompositeOperation="lighter";g0.addColorStop(0,hexA(PS.castCol,.6*cu2));g0.addColorStop(1,hexA(PS.castCol,0));cx.fillStyle=g0;cx.beginPath();cx.arc(s.x,s.y-26,50,0,7);cx.fill();cx.globalCompositeOperation="source-over";}
 if(en){var tp0=pjU(ux+cs*40,uy+sn*40),b1=pjU(ux+Math.cos(PS.face+.3)*27,uy+Math.sin(PS.face+.3)*27),b2=pjU(ux+Math.cos(PS.face-.3)*27,uy+Math.sin(PS.face-.3)*27);
  cx.globalAlpha=.8;cx.fillStyle=cl;cx.beginPath();cx.moveTo(tp0.x,tp0.y);cx.lineTo(b1.x,b1.y);cx.lineTo(b2.x,b2.y);cx.closePath();cx.fill();cx.globalAlpha=1;}
 if(PS.sh>0){cx.strokeStyle="#8ab0d8";cx.globalAlpha=.7;cx.lineWidth=3;elip(cx,ux,uy,22,false,true);cx.globalAlpha=1;}
 if(PS.invT>0){cx.strokeStyle="#7ab88a";cx.globalAlpha=.6+.3*Math.sin(t*30);cx.lineWidth=2;elip(cx,ux,uy,27,false,true);cx.globalAlpha=1;}
 function pt(d,hh){var q=pjU(ux+cs*d*ws,uy+sn*d*ws);return{x:q.x,y:q.y-hh*ws};}
 function arma(){
  cx.lineCap="round";var a,b;
  if(clase==="Mago"){a=pt(10,2);b=pt(10,56);cx.strokeStyle="#7a5a30";cx.lineWidth=3;cx.beginPath();cx.moveTo(a.x,a.y);cx.lineTo(b.x,b.y);cx.stroke();cx.fillStyle="#b09aff";cx.shadowColor="#b09aff";cx.shadowBlur=10;cx.beginPath();cx.arc(b.x,b.y-3,4,0,7);cx.fill();cx.shadowBlur=0;}
  else if(clase==="Clérigo"){a=pt(10,2);b=pt(10,52);cx.strokeStyle="#c9b27a";cx.lineWidth=3;cx.beginPath();cx.moveTo(a.x,a.y);cx.lineTo(b.x,b.y);cx.stroke();cx.fillStyle="#ffe9a0";cx.shadowColor="#ffe9a0";cx.shadowBlur=12;cx.beginPath();cx.arc(b.x,b.y-4,5,0,7);cx.fill();cx.shadowBlur=0;cx.strokeStyle="#ffe9a0";cx.lineWidth=2;cx.beginPath();cx.moveTo(b.x-6,b.y-4);cx.lineTo(b.x+6,b.y-4);cx.moveTo(b.x,b.y-10);cx.lineTo(b.x,b.y+2);cx.stroke();}
  else if(clase==="Arquero"){var t0=pt(12,40),m0=pt(26,26),u0=pt(12,12);cx.strokeStyle="#8a5a2a";cx.lineWidth=3;cx.beginPath();cx.moveTo(t0.x,t0.y);cx.quadraticCurveTo(m0.x,m0.y,u0.x,u0.y);cx.stroke();cx.strokeStyle="rgba(240,230,200,.8)";cx.lineWidth=1;cx.beginPath();cx.moveTo(t0.x,t0.y);cx.lineTo(u0.x,u0.y);cx.stroke();}
  else if(clase==="Asesino"){[.5,-.5].forEach(function(o){var q=pjU(ux+Math.cos(PS.face+o)*10*ws,uy+Math.sin(PS.face+o)*10*ws),r=pjU(ux+Math.cos(PS.face+o*.6)*28*ws,uy+Math.sin(PS.face+o*.6)*28*ws);cx.strokeStyle="#dcdce8";cx.lineWidth=2.5;cx.beginPath();cx.moveTo(q.x,q.y-20*ws);cx.lineTo(r.x,r.y-24*ws);cx.stroke();});}
  else{a=pt(8,20);b=pt(32,26);var m1=pt(14,21);cx.strokeStyle="#8b6a3a";cx.lineWidth=4;cx.beginPath();cx.moveTo(a.x,a.y);cx.lineTo(m1.x,m1.y);cx.stroke();cx.strokeStyle="#e8e8f0";cx.lineWidth=3;cx.beginPath();cx.moveTo(m1.x,m1.y);cx.lineTo(b.x,b.y);cx.stroke();}
  cx.lineCap="butt";}
 var delante=P.dir!==3;
 if(en&&!delante)arma();
 drawChar(PC,P.x+ox,P.y+oy,P.dir,P.mv,t,ME.nombre,P.bub,PS.hurt>0);
 if(en&&delante)arma();
 if(PS.sh>0){var shm=.5+.5*Math.sin(t*5),g3=cx.createRadialGradient(s.x,s.y-26,8,s.x,s.y-26,40);g3.addColorStop(0,"rgba(138,176,216,0)");g3.addColorStop(.8,"rgba(138,176,216,"+(.12+.1*shm)+")");g3.addColorStop(1,"rgba(190,220,255,"+(.45+.2*shm)+")");cx.fillStyle=g3;cx.beginPath();cx.ellipse(s.x,s.y-26,34,44,0,0,7);cx.fill();}
 if(PS.defT>0){cx.fillStyle="#8ab0d8";for(var oi=0;oi<4;oi++){var oa=t*2.6+oi*1.5708,oq=pjU(ux+Math.cos(oa)*26,uy+Math.sin(oa)*26);cx.globalAlpha=.9;cx.beginPath();cx.moveTo(oq.x,oq.y-34);cx.lineTo(oq.x+4,oq.y-28);cx.lineTo(oq.x,oq.y-22);cx.lineTo(oq.x-4,oq.y-28);cx.closePath();cx.fill();}cx.globalAlpha=1;}
 if(PS.stunT>0){cx.font="16px sans-serif";cx.textAlign="center";cx.fillText("💫",s.x,s.y-58);}
 cx.restore();}
function dFXH(t){
 var i,f,u;
 PRL.forEach(function(p){dibujarProy(cx,p);});
 for(i=0;i<FXL.length;i++){f=FXL[i];if(f.t<0||f.low)continue;u=f.t/f.life;cx.save();
  if(f.k==="ring"){var r=f.r0+(f.r1-f.r0)*u,cx0=f.follow?PX():f.x,cy0=f.follow?PY():f.y;cx.globalAlpha=(f.fill?.35:.8)*(1-u);cx.strokeStyle=f.col;cx.fillStyle=f.col;cx.lineWidth=3;elip(cx,cx0,cy0,r,f.fill,true);}
  else if(f.k==="part"){var q=pjU(f.x,f.y);cx.globalAlpha=1-u;cx.fillStyle=f.col;cx.fillRect(q.x-2,q.y-10-u*8,4,4);}
  else if(f.k==="ghost"){var q2=pjU(f.x,f.y),im=chImg(PC),inf=CHARS_INFO[PC];if(im.complete&&im.naturalWidth){cx.globalAlpha=.35*(1-u);cx.imageSmoothingEnabled=false;cx.drawImage(im,inf.w,(f.d||0)*inf.h,inf.w,inf.h,q2.x-inf.w/2,q2.y+4-(inf.h-3),inf.w,inf.h);}}
  else if(FXD[f.k])FXD[f.k](cx,f,u);
  cx.restore();}
 cx.textAlign="center";
 TXL.forEach(function(tx){cx.globalAlpha=1-Math.pow(tx.a/tx.life,2);cx.font="bold "+Math.round(tx.sz*(1+Math.max(0,1-tx.a/.12)*.7))+"px Karla,sans-serif";cx.lineWidth=3;cx.strokeStyle="rgba(0,0,0,.8)";cx.strokeText(tx.t,tx.x,tx.y);cx.fillStyle=tx.col;cx.fillText(tx.t,tx.x,tx.y);});
 cx.globalAlpha=1;
 if(FLS){cx.save();cx.setTransform(1,0,0,1,0,0);cx.globalCompositeOperation="lighter";cx.globalAlpha=Math.min(.4,FLS.a);cx.fillStyle=FLS.col;cx.fillRect(0,0,cv.width,cv.height);cx.restore();}}
function dMonMini(g){
 if(SIM.on){for(var q=0;q<SIM.mm.length;q++){var r=SIM.mm[q];if(r[2]===2){g.fillStyle="#ffd24a";g.strokeStyle="#000";g.lineWidth=1;g.beginPath();g.arc(r[0],r[1],5,0,7);g.fill();g.stroke();g.fillStyle="#000";g.font="700 8px sans-serif";g.textAlign="center";g.textBaseline="middle";g.fillText("♛",r[0],r[1]+.5);continue;}g.fillStyle=r[2]?"#ffb020":"#ff3b2a";g.fillRect(r[0]-2,r[1]-2,4,4);}return;}
 for(var i=0;i<MON.length;i++){var m=MON[i];if(m.muerto)continue;g.fillStyle=m.alfa?"#ffb020":"#ff3b2a";g.fillRect(m.x-2,m.y-2,4,4);}}
/* color de peligro de un sector (verde → rojo) según sus multiplicadores */
function difColor(d,a){var sc=(d.vida+d.dano)/2,h=Math.max(0,Math.min(120,120-(sc-1)*100));return"hsla("+Math.round(h)+",75%,52%,"+a+")";}
function difTxt(k){var d=TM[k].dif;return"♥×"+d.vida+"  ⚔×"+d.dano;}
function hudCombate(dt){
 if(!SJ)return;
 var cs=curSec,dd=$("hDif");
 if(dd){var T0=TM[cs];if(T0&&T0.dif){var d=T0.dif,t2=(enCampo()?"🔥 Zona segura · ":"")+"⚔ Peligro ♥×"+d.vida+" ✦×"+d.dano+" 👹×"+d.cant+" 💰×"+d.rec;if(t2!==_difTxt){_difTxt=t2;dd.textContent=t2;dd.style.borderColor=difColor(d,.9);}}}
 uiStep(dt);}
/* ============================================================
   INTERFAZ DE COMBATE (módulos): 1 tus stats · 2 grupo · 3 atacar/habilidades/sprint · 4 cinturón de pociones · 5 chat
   ============================================================ */
function escH(t){return String(t==null?"":t).replace(/[&<>"']/g,function(c){return{"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c];});}
function pc(v,m){return m>0?Math.max(0,Math.min(100,v/m*100)):0;}
var UIc={m1:"",cb:-1,m2:"",sk:"",belt:"",t:0,cdv:[],potv:""};
function hubG(){var H=ONL.hub;try{return H&&H.grupo?H.grupo():null;}catch(e){return null;}}
function menuJM(titulo,sub,items){
 if(!JM){JM=document.createElement("div");
  JM.style.cssText="position:fixed;left:50%;bottom:90px;transform:translateX(-50%);z-index:95;min-width:230px;max-width:90vw;padding:12px;background:rgba(20,12,4,.94);color:#f5e6c0;border:2px solid #5a4a2a;border-radius:6px;font-family:Karla,sans-serif;text-align:center";
  JM.addEventListener("pointerdown",function(e){e.stopPropagation();});document.body.appendChild(JM);}
 JMid=0;JM.innerHTML="";
 var t=document.createElement("div");t.style.cssText="font-family:Cinzel,serif;font-size:16px;color:#e8c9a0";t.textContent=titulo;JM.appendChild(t);
 var st=document.createElement("div");st.style.cssText="font-size:12px;color:#b8a888;margin:2px 0 8px";st.textContent=sub||"";JM.appendChild(st);
 items.forEach(function(it){var b=document.createElement("button");b.textContent=it[0];b.style.cssText="display:block;width:100%;margin-top:6px;padding:8px 10px;font-family:Cinzel,serif;font-size:13px;background:#8b6f47;color:#f5f1e8;border:2px solid #5a4a2a;border-radius:4px;cursor:pointer;"+(it[2]||"");b.onclick=function(){cerrarJM();if(it[1])it[1]();};JM.appendChild(b);});
 JM.style.display="block";}
function menuMiembro(id){
 var H=ONL.hub,g=hubG();if(!H||!g)return;
 var q=g.miembros.filter(function(m){return m.id===id;})[0],yo=H.id()===id;if(!q)return;
 var lider=g.lider===H.id(),it=[];
 if(yo){if(lider)it.push([g.raid?"Volver a grupo":"Convertir en raid",function(){H.enviar({t:"g_raid",on:!g.raid});}]);it.push(["Abandonar el "+(g.raid?"raid":"grupo"),function(){H.enviar({t:"g_salir"});},"background:#8b3a2a"]);}
 else{it.push(["💬 Chat privado",function(){H.susurrar(id);}]);it.push(["🤝 Comerciar",function(){H.comerciar(id);}]);
  if(lider){it.push(["♛ Dar liderazgo",function(){H.enviar({t:"g_lider",id:id});}]);it.push(["✖ Expulsar",function(){H.enviar({t:"g_expulsar",id:id});},"background:#8b3a2a"]);}}
 it.push(["Cerrar",null,"background:#4a3a24"]);
 menuJM(q.nombre,"Nv "+(q.nivel||"?")+(q.clase?" · "+q.clase:""),it);}
function joyIniciar(){
 var el=$("joy"),kn=$("joyK");if(!el||!kn)return;
 var pm=(location.search.match(/[?&]joystick=(\d)/)||[])[1];
 function poner(on){JOY.on=!!on;el.style.display=JOY.on?"block":"none";if(!JOY.on){JOY.u=JOY.v=0;JOY.id=-1;kn.style.transform="translate(-50%,-50%)";}}
 function leer(e){
  var r=el.getBoundingClientRect(),R=r.width/2,mx=R*.5,x=e.clientX-(r.left+R),y=e.clientY-(r.top+R),d=Math.hypot(x,y)||1,k=Math.min(d,mx);
  kn.style.transform="translate(calc(-50% + "+(x/d*k)+"px),calc(-50% + "+(y/d*k)+"px))";
  if(d<mx*.3){JOY.u=JOY.v=0;}else{JOY.u=x/d;JOY.v=y/d;}}
 function suelta(e){if(e.pointerId!==JOY.id)return;JOY.id=-1;JOY.u=JOY.v=0;kn.style.transform="translate(-50%,-50%)";el.classList.remove("on");}
 el.addEventListener("pointerdown",function(e){if(JOY.id>=0)return;e.preventDefault();e.stopPropagation();JOY.id=e.pointerId;try{el.setPointerCapture(e.pointerId);}catch(x){}el.classList.add("on");leer(e);});
 el.addEventListener("pointermove",function(e){if(e.pointerId!==JOY.id)return;e.preventDefault();leer(e);});
 el.addEventListener("pointerup",suelta);el.addEventListener("pointercancel",suelta);el.addEventListener("lostpointercapture",suelta);
 el.addEventListener("contextmenu",function(e){e.preventDefault();});
 if(pm==="1"||pm==="0"){poner(pm==="1");return;}   /* ?joystick=1 / ?joystick=0: forzar (pruebas) */
 poner(false);
 try{fetch("/api/estado",{cache:"no-store"}).then(function(r){return r.json();}).then(function(e){poner(e&&e.joystick);}).catch(function(){});}catch(e){}
}
function uiInit(){
 joyIniciar();
 var m3=$("m3s"),bs=$("bSpr"),ba=$("bAtk"),m2=$("m2"),m4=$("m4"),m1=$("m1");
 function stop(e){e.preventDefault();e.stopPropagation();}
 m3.addEventListener("pointerdown",function(e){var b=e.target.closest(".sk");if(!b)return;stop(e);lanzarH(+b.getAttribute("data-i"));});
 ba.addEventListener("pointerdown",function(e){stop(e);PS.hold=true;if(!vivo(PS.tg)){var c=masCercanoU(320);if(c){PS.tg=c;PS.rep=0;}}});
 ["pointerup","pointerleave","pointercancel"].forEach(function(ev){ba.addEventListener(ev,function(){PS.hold=false;});});
 bs.innerHTML='»<i class="cd"></i><b class="ct"></b>';bs.addEventListener("pointerdown",function(e){stop(e);sprintOn();});
 m4.addEventListener("pointerdown",function(e){var b=e.target.closest(".pt");if(!b)return;stop(e);var n=b.getAttribute("data-n");if(n)usaPocion(n);else usaPocion(null,b.getAttribute("data-a"));});
 m2.addEventListener("pointerdown",function(e){var b=e.target.closest(".mem");if(!b)return;stop(e);menuMiembro(+b.getAttribute("data-id"));});
 m1.addEventListener("pointerdown",function(e){stop(e);var H=ONL.hub;if(H&&hubG())menuMiembro(H.id());});
 m1.style.display="block";
 try{if(ONL.hub||hubOak()){var Hh=hubOak();if(Hh&&Hh.ocultarPanel){Hh.ocultarPanel(true);addEventListener("pagehide",function(){try{Hh.ocultarPanel(false);}catch(e){}});}}}catch(e){}
}
function uiStep(dt){
 UIc.t-=dt;if(UIc.t>0)return;UIc.t=.1;if(!SJ)return;
 hudJefe();
 var j=SJ.j||ME,nm=j.nombre||ME.nombre,lv=j.nivel||1;
 /* módulo 1 */
 var hpp=pc(PS.hp,PS.max),k1=nm+"|"+lv+"|"+Math.ceil(PS.hp)+"|"+PS.max+"|"+Math.floor(PS.mp)+"|"+PS.mpMax+"|"+Math.ceil(PS.sh);
 if(k1!==UIc.m1){UIc.m1=k1;
  var tt=SJ.W&&SJ.W.tituloJ?SJ.W.tituloJ(j):"";$("m1n").textContent=nm+(tt?" · "+tt:"");$("m1l").textContent="Nv "+lv;
  var h=$("m1h");h.style.width=hpp+"%";h.style.background=hpp<30?"#c0392b":"#4f9a46";$("m1ht").textContent="♥ "+Math.max(0,Math.ceil(PS.hp))+" / "+PS.max+(PS.sh>0?" 🛡"+Math.ceil(PS.sh):"");
  $("m1m").style.width=pc(PS.mp,PS.mpMax)+"%";$("m1mt").textContent=((j.recursoNombre||"Recurso"))+" "+Math.floor(PS.mp)+" / "+PS.mpMax;}
 /* estado "En combate" (módulo 1) */
 var cbk=enCombate()?Math.ceil(PS.regW):0;
 if(cbk!==UIc.cb){UIc.cb=cbk;var ce=$("m1c"),m1e=$("m1");
  if(ce){ce.style.display=cbk?"block":"none";ce.textContent=cbk?"⚔ En combate · "+cbk+"s":"";}
  if(m1e)m1e.classList.toggle("cmb",!!cbk);}
 /* módulo 2: grupo */
 var g=hubG(),H=ONL.hub,html="";
 if(g&&H){var me=H.id(),otros=g.miembros.filter(function(q){return q.id!==me;});
  otros.slice(0,4).forEach(function(q){
   var hp=pc(q.hp||0,q.hpMax||0);
   html+='<div class="mod mem'+(q.act?'':' ina')+'" data-id="'+q.id+'"><div class="nm"><b>'+(q.id===g.lider?'♛ ':'')+escH(q.nombre)+'</b><span>Nv '+(q.nivel||1)+'</span></div>'
    +'<div class="br hp"><i style="width:'+hp+'%;background:'+(hp<30?'#c0392b':'#4f9a46')+'"></i><u>♥ '+Math.round(q.hp||0)+'/'+Math.round(q.hpMax||0)+'</u></div>'
    +'<div class="br mp"><i style="width:'+pc(q.mp||0,q.mpMax||0)+'%"></i><u>'+escH(q.rn||"Recurso")+' '+Math.round(q.mp||0)+'/'+Math.round(q.mpMax||0)+'</u></div></div>';});
  if(otros.length>4)html+='<div class="more">+'+(otros.length-4)+' más</div>';}
 if(html!==UIc.m2){UIc.m2=html;$("m2").innerHTML=html;}
 /* módulo 3: habilidades */
 var sig=PS.habSig+"|"+PS.habs.length,mk=$("m3s");
 if(sig!==UIc.sk){UIc.sk=sig;UIc.cdv=[];var hh="";
  PS.habs.forEach(function(hb,i){var ic=hIcon(hb);hh+='<button class="sk" data-i="'+i+'" title="'+escH(hb.n+" — "+hb.desc)+'"><span class="ic">'+ic+'</span><em>'+(i+1)+'</em><s>'+hb.costo+'</s><i class="cd"></i><b class="ct"></b></button>';});
  mk.innerHTML=hh;}
 var bts=mk.children;
 for(var i=0;i<bts.length;i++){var hb=PS.habs[i];if(!hb)continue;var cdv=PS.cd[i],tot=hb.cd*TS(),kk=(cdv>0?Math.ceil(cdv*10):0)+"|"+(PS.mp<hb.costo||PS.silT>0?1:0);
  if(kk!==UIc.cdv[i]){UIc.cdv[i]=kk;bts[i].querySelector(".cd").style.height=(cdv>0?cdv/tot*100:0)+"%";bts[i].querySelector(".ct").textContent=cdv>0?(cdv>=1?Math.ceil(cdv):cdv.toFixed(1)):"";bts[i].classList.toggle("off",cdv>0||PS.mp<hb.costo||PS.silT>0);}}
 /* sprint: activo (azul, barra de tiempo) / enfriamiento (barra oscura + segundos) */
 var sb=$("bSpr"),sk2=(PS.sprT>0?"a"+Math.ceil(PS.sprT*10):"c"+Math.ceil(PS.sprCd*10));
 if(sk2!==UIc.spr){UIc.spr=sk2;var sc=sb.querySelector(".cd"),st2=sb.querySelector(".ct");sb.classList.toggle("on",PS.sprT>0);sb.classList.toggle("off",PS.sprCd>0&&PS.sprT<=0);
  if(PS.sprT>0){sc.style.height=(100-PS.sprT/SPR_DUR*100)+"%";st2.textContent=Math.ceil(PS.sprT);}
  else{sc.style.height=(PS.sprCd>0?PS.sprCd/SPR_CD*100:0)+"%";st2.textContent=PS.sprCd>0?Math.ceil(PS.sprCd):"";}}
 /* módulo 4: cinturón */
 beltStep();
}
function hIcon(h){var Wp=SJ&&SJ.W,k=(h.n==="Paso Espectral"&&SJ.clase==="Asesino")?"Paso Espectral Ninja":h.n,f=Wp&&Wp.HAB_ICONO&&Wp.HAB_ICONO[k];return f?'<img src="../assets/hab/'+f+'.png" alt="">':'<b>'+escH(h.n.charAt(0))+'</b>';}
function pIcon(n){var Wp=SJ&&SJ.W;try{if(Wp&&Wp.itemIcono)return '<img src="../assets/items/'+Wp.itemIcono(n)+'.png" alt="">';}catch(e){}return "🧪";}
function beltStep(){
 var Wp=SJ&&SJ.W,j=SJ&&SJ.j,b=$("m4");if(!b)return;
 var list=[];
 if(Wp&&j){var ord={vida:0,recurso:1,full:2};list=Wp.POCIONES.filter(function(p){return ord[p.tipo]!==undefined&&(j.inventario[p.n]||0)>0;}).sort(function(a,c){return ord[a.tipo]-ord[c.tipo]||a.pct-c.pct;}).slice(0,6);}
 var sig=list.map(function(p){return p.n+":"+j.inventario[p.n];}).join(",")+"|"+(Wp?1:0);
 if(sig!==UIc.belt){UIc.belt=sig;var h="";
  if(!list.length)h='<button class="pt dim" data-a="v"><span class="ic">❤</span><em>Q</em><s>0</s></button><button class="pt dim" data-a="r"><span class="ic">✦</span><em>R</em><s>0</s></button>';
  else list.forEach(function(p){h+='<button class="pt" data-n="'+escH(p.n)+'" title="'+escH(p.n+" — "+p.desc)+'"><span class="ic">'+pIcon(p.n)+'</span><s>'+j.inventario[p.n]+'</s><i class="cd"></i></button>';});
  b.innerHTML=h;UIc.potv="";}
 var pv=PS.potT>0?Math.round(PS.potT/POT_CD*100):0;
 if(String(pv)!==UIc.potv){UIc.potv=String(pv);var cs=b.querySelectorAll(".cd");for(var i=0;i<cs.length;i++)cs[i].style.height=pv+"%";}
}
/* ---------- render ---------- */
function noche(){var h=(tmin/60)%24;return h<5||h>=21?1:h<7?(7-h)/2:h>=19?(h-19)/2:0;}
var GLOW=document.createElement("canvas");GLOW.width=GLOW.height=160;
(function(){var g=GLOW.getContext("2d"),q=g.createRadialGradient(80,80,2,80,80,78);q.addColorStop(0,"rgba(255,170,60,.55)");q.addColorStop(1,"rgba(255,170,60,0)");g.fillStyle=q;g.fillRect(0,0,160,160);})();
function dFuego(o,t){var s=pj(o.cx,o.cy);cx.save();cx.translate(s.x,s.y+4);
 var f=Math.sin(t*9)*.5+Math.sin(t*14.3+1)*.5,sw=Math.sin(t*5)*3;
 function llama(h,w,c){cx.fillStyle=c;cx.beginPath();cx.moveTo(-w,0);cx.quadraticCurveTo(-w*1.1,-h*.5,sw*.6,-h+f*3);cx.quadraticCurveTo(w*1.1,-h*.5,w,0);cx.closePath();cx.fill();}
 var gl=cx.createRadialGradient(0,-10,2,0,-10,52);gl.addColorStop(0,"rgba(255,160,50,.35)");gl.addColorStop(1,"rgba(255,160,50,0)");cx.fillStyle=gl;cx.fillRect(-52,-62,104,104);
 llama(40+f*5,11,"#d9421a");llama(30+f*4,8,"#ff8e22");llama(20+f*3,5,"#ffe27a");
 for(var k=0;k<6;k++){var ph=(t*.55+k/6)%1;cx.globalAlpha=1-ph;cx.fillStyle="#ffcf6a";cx.fillRect(Math.sin(k*7+t*2)*8+sw*ph,-ph*62-10,2,2);}
 cx.restore();}
function dPortal(o,t){var s=pj(o.cx,o.cy),c=o.g.col;cx.save();cx.translate(s.x,s.y);cx.globalCompositeOperation="lighter";
 var p=.75+.25*Math.sin(t*2.4+o.cx),gr=cx.createRadialGradient(0,-44,2,0,-44,60);gr.addColorStop(0,rgba(c,.95*p));gr.addColorStop(.55,rgba(c,.4*p));gr.addColorStop(1,rgba(c,0));
 cx.fillStyle=gr;cx.beginPath();cx.ellipse(0,-44,34,60,0,0,7);cx.fill();
 cx.lineWidth=2;for(var k=0;k<3;k++){cx.strokeStyle=rgba("#ffffff",.5-k*.12);cx.beginPath();cx.ellipse(0,-44,28-k*6,52-k*11,t*(1.2+k*.4)+k,0,Math.PI*1.35);cx.stroke();}
 cx.restore();}
function dRuna(d,t){var s=pj(d.x+.5,d.y+.5);cx.save();cx.translate(s.x,s.y+2);cx.scale(1,.5);
 cx.globalAlpha=.5+.25*Math.sin(t*2);cx.strokeStyle=d.col;cx.lineWidth=3;
 [44,36,22].forEach(function(r){cx.beginPath();cx.arc(0,0,r,0,7);cx.stroke();});
 cx.lineWidth=2;for(var k=0;k<8;k++){var a=k/8*6.283+t*.35;cx.beginPath();cx.moveTo(Math.cos(a)*26,Math.sin(a)*26);cx.lineTo(Math.cos(a)*34,Math.sin(a)*34);cx.stroke();}
 cx.restore();}
function dBrasas(d,t){var s=pj(d.x+.5,d.y+.5);cx.save();cx.translate(s.x,s.y+2);cx.scale(1,.5);cx.fillStyle="rgba(24,16,10,.5)";cx.beginPath();cx.arc(0,0,26,0,7);cx.fill();
 for(var k=0;k<10;k++){cx.fillStyle="rgba(60,50,44,.6)";cx.fillRect(Math.cos(k*2.3)*20,Math.sin(k*3.1)*18,3,3);}cx.restore();}
function sprite(o,t){
 if(o.fn==="portal"){dPortal(o,t);return;}
 var im=IMG[o.i];
 if(im){var s=pj(o.cx,o.cy);cx.save();cx.translate(s.x,s.y+8);
  if(o.sw)cx.transform(1,0,Math.sin(t*1.6+o.cx*.7)*.035,1,0,0);
  if(im.gc!=null)cx.drawImage(im,-im.width/2,-im.gc-4);else cx.drawImage(im,-im.width/2,-im.height);
  cx.restore();}
 if(o.fn==="fuego")dFuego(o,t);}
var SHX=0,SHY=0;
function draw(t){
 var w=cv.width,h=cv.height;SHX=SHK>0?rf(-SHK,SHK):0;SHY=SHK>0?rf(-SHK,SHK):0;cx.setTransform(1,0,0,1,0,0);cx.fillStyle="#0c140a";cx.fillRect(0,0,w,h);
 var c=pj(P.x,P.y);cam.x+=(c.x-cam.x)*.12;cam.y+=(c.y-cam.y)*.12;
 cx.setTransform(Z*DPR,0,0,Z*DPR,w/2-cam.x*Z*DPR+SHX*DPR,h/2-cam.y*Z*DPR+SHY*DPR);
 var hw=w/DPR/Z/2,hh=h/DPR/Z/2,fr=Math.floor(t*1.5);
 var sxl=cam.x-hw-70,sxr=cam.x+hw+70,syt=cam.y-hh-50,syb=cam.y+hh+260;
 function gxy(sx,sy){return{x:(sy/16+sx/32)/2,y:(sy/16-sx/32)/2};}
 var q=[gxy(sxl,syt),gxy(sxr,syt),gxy(sxl,syb),gxy(sxr,syb)],gx0=Math.max(0,Math.floor(Math.min(q[0].x,q[1].x,q[2].x,q[3].x))-1),gx1=Math.min(W-1,Math.ceil(Math.max(q[0].x,q[1].x,q[2].x,q[3].x))+1),
     gy0=Math.max(0,Math.floor(Math.min(q[0].y,q[1].y,q[2].y,q[3].y))-1),gy1=Math.min(H-1,Math.ceil(Math.max(q[0].y,q[1].y,q[2].y,q[3].y))+1);
 for(var y=gy0;y<=gy1;y++)for(var x=gx0;x<=gx1;x++){var sx=(x-y)*32,sy=(x+y)*16+16;if(sx<sxl||sx>sxr||sy<syt-20||sy>cam.y+hh+70)continue;
  var k=tiles[y*W+x],im=IMG[k];if(!im)continue;var c0=k.charAt(0);
  if(c0==="g"||c0==="d")cx.drawImage(im,sx-im.width/2,sy-16);else cx.drawImage(im,sx-33,sy-13);}
 for(var di=0;di<DECALS.length;di++){var d=DECALS[di],ds=pj(d.x+.5,d.y+.5);if(Math.abs(ds.x-cam.x)>hw+80||Math.abs(ds.y-cam.y)>hh+60)continue;(d.fn==="runa"?dRuna:dBrasas)(d,t);}
 if(tgt){var s=pj(tgt.x+.5,tgt.y+.5);cx.strokeStyle="rgba(232,200,120,"+(.5+.4*Math.sin(t*6))+")";cx.lineWidth=2;cx.beginPath();cx.moveTo(s.x,s.y-15);cx.lineTo(s.x+30,s.y);cx.lineTo(s.x,s.y+15);cx.lineTo(s.x-30,s.y);cx.closePath();cx.stroke();}
 dSuelo(t);
 var L=[],bx0=Math.max(0,(gx0>>3)-1),bx1=Math.min(NB-1,(gx1>>3)+1),by0=Math.max(0,(gy0>>3)-1),by1=Math.min(NB-1,(gy1>>3)+1),i2;
 for(var by=by0;by<=by1;by++)for(var bx=bx0;bx<=bx1;bx++){var bl=BK[by*NB+bx];if(!bl)continue;
  for(i2=0;i2<bl.length;i2++){var o=bl[i2],sx2=(o.cx-o.cy)*32;if(sx2<sxl||sx2>sxr)continue;var sy2=(o.cx+o.cy)*16;if(sy2<syt-30||sy2>syb)continue;L.push(o);}}
 NPC.forEach(function(n){L.push({npc:1,o:n,cx:n.x,cy:n.y});});
 MON.forEach(function(m){if(Math.abs(m.x-P.x)+Math.abs(m.y-P.y)<64)L.push({mon:1,o:m,cx:m.x,cy:m.y});});
 for(var id in RP){var r=RP[id];if(r.lugar==="mundo")L.push({rp:1,o:r,cx:r.x,cy:r.y});}
 L.push({pl:1,cx:P.x,cy:P.y});
 L.sort(function(a,b){return(a.cx+a.cy)-(b.cx+b.cy);});
 L.forEach(function(o){
  if(o.pl)dPlayer(t);
  else if(o.npc){var n=o.o,dd=Math.hypot(P.x-n.x,P.y-n.y),dr=dd<7?dirOf(P.x-n.x,P.y-n.y):n.dir;drawChar(n.c,n.x,n.y,dr,0,t,n.name,dd<3.4?{txt:n.lines[Math.floor(t/6)%n.lines.length],hasta:T+1}:null);}
  else if(o.mon){dMon(o.o,t);dMonX(o.o,t);}
  else if(o.rp)drawChar(o.o.c,o.o.x,o.o.y,o.o.dir,o.o.mv,t+o.o.c,o.o.nombre,o.o.bub);
  else sprite(o,t);});
 var nn=noche();
 if(nn>0){cx.save();cx.setTransform(1,0,0,1,0,0);cx.fillStyle="rgba(6,12,40,"+(.58*nn)+")";cx.fillRect(0,0,w,h);cx.restore();
  cx.setTransform(Z*DPR,0,0,Z*DPR,w/2-cam.x*Z*DPR+SHX*DPR,h/2-cam.y*Z*DPR+SHY*DPR);cx.globalCompositeOperation="lighter";cx.globalAlpha=nn;
  L.forEach(function(o){if(!(o.light||o.glow))return;var s=pj(o.cx,o.cy),r=o.glow?110:o.fn==="portal"?70:o.i&&o.i.indexOf("pg_")===0?36:60;
   cx.drawImage(GLOW,s.x-r,s.y-20-r,r*2,r*2);});
  cx.globalAlpha=1;cx.globalCompositeOperation="source-over";}
 cx.setTransform(Z*DPR,0,0,Z*DPR,w/2-cam.x*Z*DPR+SHX*DPR,h/2-cam.y*Z*DPR+SHY*DPR);dFXH(T);
 /* bruma suave del bosque */
 cx.setTransform(1,0,0,1,0,0);var vg=cx.createRadialGradient(w/2,h/2,Math.min(w,h)*.35,w/2,h/2,Math.max(w,h)*.75);vg.addColorStop(0,"rgba(4,10,6,0)");vg.addColorStop(1,"rgba(4,10,6,.45)");cx.fillStyle=vg;cx.fillRect(0,0,w,h);
 if(SJ&&PS.hp/PS.max<.3&&!MUERTE){var lw=.18+.12*Math.sin(t*5);cx.setTransform(1,0,0,1,0,0);var rg=cx.createRadialGradient(w/2,h/2,Math.min(w,h)*.3,w/2,h/2,Math.max(w,h)*.7);rg.addColorStop(0,"rgba(160,0,0,0)");rg.addColorStop(1,"rgba(160,0,0,"+lw+")");cx.fillStyle=rg;cx.fillRect(0,0,w,h);}
 if(MUERTE){cx.setTransform(1,0,0,1,0,0);var ma=MUERTE.t<.9?MUERTE.t/.9:Math.max(0,1-(MUERTE.t-.9)/.9);cx.fillStyle="rgba(70,0,0,"+Math.min(1,ma)+")";cx.fillRect(0,0,w,h);}
 if(tp){var fa=tp.t<.35?tp.t/.35:Math.max(0,1-(tp.t-.35)/.35);cx.fillStyle="rgba(0,0,0,"+Math.min(1,fa)+")";cx.fillRect(0,0,w,h);}
}
/* ---------- lógica ---------- */
function cell(){return{x:Math.floor(P.x),y:Math.floor(P.y)};}
function ir(x,y){P.path=[];var d=celdaLibre(x,y);if(!d)return;var p=bfs(cell(),d);if(p){P.path=p;tgt=d;}else{chatLog("No hay camino hasta ahí: cruza una puerta de piedra.");}}
function mover(dt){
 if(tp||MUERTE||PS.stunT>0||PS.dashT>0)return;
 var dx=0,dy=0;
 if(keys.w||keys.arrowup){dx--;dy--;}if(keys.s||keys.arrowdown){dx++;dy++;}if(keys.a||keys.arrowleft){dx--;dy++;}if(keys.d||keys.arrowright){dx++;dy--;}
 var jm=joyMov();if(!dx&&!dy&&jm){dx=jm.dx;dy=jm.dy;}
 if(dx||dy){P.path=[];tgt=null;P.talkR=0;var l=Math.hypot(dx,dy);dx/=l;dy/=l;}
 else if(P.path.length){var n=P.path[0],tx=n.x+.5-P.x,ty=n.y+.5-P.y,d=Math.hypot(tx,ty);if(d<.1){P.path.shift();if(!P.path.length)tgt=null;}else{dx=tx/d;dy=ty/d;}}
 P.mv=!!(dx||dy);if(!P.mv)return;P.dir=dirOf(dx,dy);PS.face=Math.atan2(dy,dx);
 var st=SPD*(PS.sprT>0?SPR_MULT:1)*dt,nx=P.x+dx*st,ny=P.y+dy*st;
 if(!P.path.length){if(blk[I(Math.floor(nx),Math.floor(P.y))])nx=P.x;if(blk[I(Math.floor(nx),Math.floor(ny))])ny=P.y;}
 P.x=Math.max(2.3,Math.min(W-2.3,nx));P.y=Math.max(2.3,Math.min(H-2.3,ny));}
function cruzar(g){
 if(g.cerrada){chatLog("🔒 "+g.label+".");return;}
 if(tp||cool>0)return;var d=null;for(var i=0;i<GATES.length;i++)if(GATES[i].id===g.to){d=GATES[i];break;}if(!d)return;
 tp={t:0,g:g,d:d,hecho:false};P.path=[];tgt=null;P.mv=0;}
function teleStep(dt){
 if(!tp)return;tp.t+=dt;
 if(!tp.hecho&&tp.t>=.35){tp.hecho=true;var o=tp.d.out;P.x=o.x+.5;P.y=o.y+.5;cam=pj(P.x,P.y);P.dir=dirOf(P.x-tp.d.cx,P.y-tp.d.cy);cool=2.5;
  revela(Math.floor(P.x),Math.floor(P.y),18);anunciar(nomSec(tp.d.sk));}
 if(tp.t>=.7)tp=null;}
function cerca(){
 near=null;var m=2.7;
 GATES.forEach(function(g){var d=Math.hypot(g.cx-P.x,g.cy-P.y);if(d<m){m=d;near={t:"g",g:g,label:g.label};}});
 EXITS.forEach(function(e){var d=Math.hypot(e.cx-P.x,e.cy-P.y);if(d<m){m=d;near={t:"x",label:e.label};}});
 NPC.forEach(function(n){if(!n.ret)return;var d=Math.hypot(n.x-P.x,n.y-P.y);if(d<m){m=d;near={t:"r",npc:n,label:"Hablar con "+n.name+" · volver a Oakhaven"};}});
 if(JMnpc&&(!near||near.t!=="r"||near.npc!==JMnpc)){var dn=Math.hypot(JMnpc.x-P.x,JMnpc.y-P.y);if(dn>4)cerrarJM();}
 if(!(near&&near.t==="g"&&m<1.2))for(var rid in RP){var rr=RP[rid];if(rr.lugar!=="mundo")continue;var dr=Math.hypot(rr.x-P.x,rr.y-P.y);if(dr<m){m=dr;near={t:"p",id:+rid,label:"Hablar con "+rr.nombre};}}
 if(P.talkR){var rt=RP[P.talkR];if(!rt)P.talkR=0;else if(Math.hypot(rt.x-P.x,rt.y-P.y)<2.7){var id2=P.talkR;P.talkR=0;P.path=[];tgt=null;abrirJugador(id2);}}
 if(JMid){var rj=RP[JMid];if(!rj||Math.hypot(rj.x-P.x,rj.y-P.y)>4)cerrarJM();}
 if(near&&near.t==="g"&&!near.g.cerrada&&!tp&&cool<=0&&Math.hypot(near.g.cx-P.x,near.g.cy-P.y)<.85)cruzar(near.g);
 var bt=$("bEntrar");bt.style.display=near?"block":"none";bt.textContent=near?(near.t==="g"?(near.g.cerrada?"E · Examinar: "+near.label:"E · Cruzar: "+near.label):"E · "+near.label):"";}
function volverOak(){if(Mundo.onExit)Mundo.onExit();else chatLog("(Modo independiente) Aquí volverías a Oakhaven.");}
function hablarRetorno(n){menuJM(n.name,"¿Quieres volver a Oakhaven?",[["Volver a Oakhaven",volverOak],["Quedarme aquí",null,"background:#4a3a24"]]);JMnpc=n;}
function interactuar(){if(!near||tp)return;if(near.t==="g")cruzar(near.g);else if(near.t==="p")abrirJugador(near.id);else if(near.t==="r")hablarRetorno(near.npc);else{if(Mundo.onExit)Mundo.onExit();else chatLog("(Modo independiente) Aquí volverías a Oakhaven.");}}
$("bEntrar").onclick=interactuar;
var _dtm=0;function anunciar(t){var e=$("dTit");if(!e||!t)return;e.textContent=t;e.style.opacity=1;clearTimeout(_dtm);_dtm=setTimeout(function(){e.style.opacity=0;},2800);}
var chat=$("chat");
addEventListener("keydown",function(e){
 if(e.target===chat){if(e.key==="Enter"){var tx=chat.value.trim();if(tx&&ONL.on)envia({t:"chat",texto:tx});chat.value="";chat.blur();}else if(e.key==="Escape")chat.blur();e.stopPropagation();return;}
 var k=e.key.toLowerCase();
 if(k===" ")e.preventDefault();
 if(k==="enter"&&ONL.on){chat.focus();e.preventDefault();return;}
 if(k==="e")interactuar();else if(k==="m")setMini((mEst+1)%3);else if(k==="tab"||k==="n"){e.preventDefault();setMini(mEst===1?0:1);}
 else if(k==="escape"&&JMid)cerrarJM();else if(k==="escape"&&mEst===1)setMini(0);
 else if(k==="+"||k==="=")zoom(1.15);else if(k==="-"||k==="_")zoom(1/1.15);else if(k.length===1&&k>="1"&&k<="5")lanzarH(+k-1);else if(k==="shift"){if(!e.repeat)sprintOn();}else if(k==="q")usaPocion(null,"v");else if(k==="r")usaPocion(null,"r");else keys[k]=1;});
addEventListener("keyup",function(e){delete keys[e.key.toLowerCase()];});
addEventListener("blur",function(){keys={};JOY.u=JOY.v=0;JOY.id=-1;});
function zoom(f){Z=Math.max(.5,Math.min(2.2,Z*f));}
cv.addEventListener("wheel",function(e){e.preventDefault();zoom(e.deltaY<0?1.1:1/1.1);},{passive:false});
$("bZp").onclick=function(){zoom(1.2);};$("bZm").onclick=function(){zoom(1/1.2);};$("bMini").onclick=function(){setMini((mEst+1)%3);};
mini.addEventListener("pointerdown",function(e){var r=mini.getBoundingClientRect();ir(Math.floor((e.clientX-r.left)/r.width*W),Math.floor((e.clientY-r.top)/r.height*H));if(mEst===1)setMini(0);e.stopPropagation();});
cv.addEventListener("pointerdown",function(e){
 var r=cv.getBoundingClientRect(),sx=((e.clientX-r.left)-r.width/2)/Z+cam.x,sy=((e.clientY-r.top)-r.height/2)/Z+cam.y;
 for(var rid in RP){var rr=RP[rid];if(rr.lugar!=="mundo")continue;var rq=pj(rr.x,rr.y);if(Math.abs(sx-rq.x)<20&&sy<rq.y+6&&sy>rq.y-60){irAJugador(+rid);return;}}
 for(var mi=0;mi<MON.length;mi++){var mo=MON[mi];if(mo.muerto)continue;var mq=pj(mo.x,mo.y),mf=CHARS_INFO[mo.c],mw=Math.max(18,mf.w*mo.esc*.5),mh=mf.h*mo.esc;
  if(Math.abs(sx-mq.x)<mw&&sy<mq.y+8&&sy>mq.y-mh){PS.tg=mo;PS.rep=0;return;}}
 for(var i=0;i<GATES.length;i++){var g=GATES[i],q=pj(g.cx,g.cy);if(Math.abs(sx-q.x)<34&&sy<q.y+10&&sy>q.y-96){ir(g.x,g.y+1);return;}}
 ir(Math.floor((sy/16+sx/32)/2),Math.floor((sy/16-sx/32)/2));});
function resize(){DPR=Math.min(2,devicePixelRatio||1);cv.width=innerWidth*DPR;cv.height=innerHeight*DPR;cx.imageSmoothingEnabled=true;}
addEventListener("resize",resize);resize();
/* ---------- arranque ---------- */
function limpiaBorde(im){
 var w=im.width,h=im.height,c=document.createElement("canvas");c.width=w;c.height=h;
 var g=c.getContext("2d");g.drawImage(im,0,0);var d=g.getImageData(0,0,w,h),p=d.data,i,n;
 function blanco(i){var r=p[i],gg=p[i+1],b=p[i+2],mx=Math.max(r,gg,b),mn=Math.min(r,gg,b);return (r+gg+b)/3>130&&mx-mn<45;}
 function borde(x,y){var j=[[1,0],[-1,0],[0,1],[0,-1]];for(var k=0;k<4;k++){var X=x+j[k][0],Y=y+j[k][1];if(X<0||Y<0||X>=w||Y>=h||p[(Y*w+X)*4+3]<=40)return true;}return false;}
 for(n=0;n<40;n++){var kill=[];
  for(var y=0;y<h;y++)for(var x=0;x<w;x++){i=(y*w+x)*4;if(p[i+3]>0&&borde(x,y)&&blanco(i))kill.push(i);}
  if(!kill.length)break;kill.forEach(function(i){p[i+3]=0;});}
 for(i=3;i<p.length;i+=4)if(p[i]<90)p[i]=0;
 g.putImageData(d,0,0);return c;}
function limpiaSuelo(im){
 var w=im.width,h=im.height,c=document.createElement("canvas");c.width=w;c.height=h;
 var g=c.getContext("2d");g.drawImage(im,0,0);var d=g.getImageData(0,0,w,h),p=d.data,i,n,x,y;
 for(i=3;i<p.length;i+=4)if(p[i]<90)p[i]=0;
 var bad=[],good=[];
 for(i=0;i<w*h;i++){var o=i*4,r=p[o],gg=p[o+1],b=p[o+2],mx=Math.max(r,gg,b),mn=Math.min(r,gg,b);
  if(p[o+3]>0){if((r+gg+b)/3>120&&mx-mn<50)bad[i]=1;else good[i]=1;}}
 for(n=0;n<6;n++){var nw=[];
  for(y=0;y<h;y++)for(x=0;x<w;x++){i=y*w+x;if(!bad[i])continue;var sr2=0,sg=0,sb=0,k=0;
   for(var dy=-1;dy<=1;dy++)for(var dx=-1;dx<=1;dx++){var X=x+dx,Y=y+dy;if(X<0||Y<0||X>=w||Y>=h)continue;var j=Y*w+X;if(good[j]){sr2+=p[j*4];sg+=p[j*4+1];sb+=p[j*4+2];k++;}}
   if(k)nw.push([i,sr2/k,sg/k,sb/k]);}
  if(!nw.length)break;
  nw.forEach(function(q){var o=q[0]*4;p[o]=q[1];p[o+1]=q[2];p[o+2]=q[3];p[o+3]=255;bad[q[0]]=0;good[q[0]]=1;});}
 for(i=0;i<w*h;i++)if(bad[i])p[i*4+3]=0;
 g.putImageData(d,0,0);return c;}
var NEED=/^(g\d+|d\d|e\d|p\d|t\d|b\d|f\d|r\d|stump|log|mush|fence|cabana1|cabana2|dh_azul|dh_paja|dh_turq|dh_verde|capilla|molino|torre|torre2|farol|mesa|mu_cajas|mu_barril)$/;
var cargar=Object.keys(ASSETS).filter(function(k){return NEED.test(k);}),pend=cargar.length;
cargar.forEach(function(k){var im=new Image();im.onload=function(){
 if(/^(t\d|b\d|r\d|f\d|stump|log|mush|fence)$/.test(k)){try{IMG[k]=limpiaBorde(im);}catch(e){}}else if(/^[gd]\d+$/.test(k)){try{IMG[k]=limpiaSuelo(im);}catch(e){}}
 if(--pend===0)iniciar();};im.src=ASSETS[k][2];IMG[k]=im;});
function iniciar(){
 hacerSprites();hacerMM();chImg(PC);NPC.forEach(function(n){chImg(n.c);});
 $("cargando").style.display="none";
 /* aparición en el campamento: celda libre al azar cerca del fuego, hacia el sur */
 var ok=false;for(var n=0;n<40&&!ok;n++){var X=Math.floor(CC.x)+Math.floor(Math.random()*7)-3,Y=Math.floor(CC.y)+3+Math.floor(Math.random()*4);if(!blk[I(X,Y)]){P.x=X+.5;P.y=Y+.5;ok=true;}}
 cam=pj(P.x,P.y);revela(Math.floor(CC.x),Math.floor(CC.y),26);curSec=0;anunciar(nomSec(0));
 monIniciar();
 uiInit();
 addEventListener("message",function(e){var d=e.data;if(d&&d.naradak==="t"){if(!CLK.ok)tmin=(d.dia-1)*1440+d.min;}else if(d&&d.naradak==="online")onlineIniciar();});
 if(ONLINE_Q)onlineIniciar();
 var last=performance.now(),acc=0,ms=0;
 (function loop(now){var dt=Math.max(0,Math.min(.05,(now-last)/1000));last=now;T+=dt;if(CLK.ok&&ONL.on)tmin=relojSrv();else tmin+=dt*MIN_S;if(cool>0)cool-=dt;
  mover(dt);teleStep(dt);simMundo(dt);hudCombate(dt);
  for(var id in RP){var r=RP[id],f=Math.min(1,dt*9),px=r.x,py=r.y;r.x+=(r.tx-r.x)*f;r.y+=(r.ty-r.y)*f;r.mv=Math.hypot(r.x-px,r.y-py)>.002?1:0;if(r.mv&&Math.hypot(r.tx-r.x,r.ty-r.y)>.05)r.dir=dirOf(r.tx-r.x,r.ty-r.y);}
  acc+=dt;if(ONL.on&&acc>=.1){acc=0;if(Math.abs(P.x-(ONL._x||0))>.03||Math.abs(P.y-(ONL._y||0))>.03){ONL._x=P.x;ONL._y=P.y;envia({t:"mover",x:+P.x.toFixed(2),y:+P.y.toFixed(2),dir:["s","a","d","w"][P.dir]});}}
  if(Math.hypot(P.x-_rx,P.y-_ry)>3)revela(Math.floor(P.x),Math.floor(P.y),18);
  cerca();
  var ci=I(Math.floor(P.x),Math.floor(P.y)),sk=sec[ci];if(sk>=0&&sk!==curSec){curSec=sk;anunciar(nomSec(sk));}
  var m=Math.floor(tmin%1440);$("hHora").textContent=(CLK.ok?"🌐 ":"")+"Día "+(1+Math.floor(tmin/1440))+" · "+String(Math.floor(m/60)).padStart(2,"0")+":"+String(m%60).padStart(2,"0")+(noche()>.5?" 🌙":" ☀");
  $("hDist").textContent="📍 "+nomSec(curSec);
  draw(T);if(mEst!==2&&(ms+=dt)>.08){ms=0;drawMini();}requestAnimationFrame(loop);})(last);
}
Mundo.irA=function(x,y){P.x=x+.5;P.y=y+.5;cam=pj(P.x,P.y);P.path=[];tgt=null;revela(x,y,18);};
Mundo.mon=function(){return{MON:MON,PS:PS,SJ:SJ,TM:TM};};
Mundo.combate={habilidad:function(i){lanzarH(i);},atacar:function(){var c=masCercanoU(400);if(c){PS.tg=c;return atacar(c);}return false;},pocion:function(n){usaPocion(null,n);},fx:function(){return FXL.length;}};
Mundo.pos=function(){return{x:P.x,y:P.y,sec:curSec,tp:!!tp};};
Mundo.debug=function(){return{W:W,H:H,blk:blk,road:road,sec:sec,GATES:GATES,OB:OB,CC:CC,TM:TM,tiles:tiles,bfs:bfs};};
})();
