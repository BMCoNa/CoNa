"use strict";
/* THE CHRONICLES OF NARADAK — Oakhaven: ciudad enorme 2.5D (144x104 celdas). Requiere assets.js y chars.js.
   Generación determinista (misma ciudad para todos los jugadores). Online: ?online=1 -> WebSocket /ws del servidor local. */
var Oakhaven={onEnter:null};
(function(){
var W=144,H=104,N=W*H,TW=64,TH=32,SPD=4.2,MIN_S=5.6,NPCS=800,IMG={},CIMG=[];
var cv=document.getElementById("mapa"),cx=cv.getContext("2d"),$=function(i){return document.getElementById(i);};
var SERV={
 tienda:["Tienda","Armas, armaduras y pociones para tu clase.",["⚔ Armas","🛡 Armaduras","🧪 Pociones"]],
 gremio:["Gremio de Aventureros","Campana de misiones, rangos y recompensas.",["📜 Misiones","🏅 Rangos del gremio","🔔 Campana"]],
 herreria:["Herrería","Forja armas y armaduras con recetas Raras a Legendarias.",["🔨 Forjar arma","🛠 Forjar armadura","📖 Recetas"]],
 alquimista:["Alquimista","Pociones y elixires con ingredientes recolectados.",["⚗ Pociones","🌿 Ingredientes","📖 Recetas"]],
 hospital:["Hospital","Recupera vida y cura maldiciones.",["❤ Curación","☠ Quitar maldición"]],
 castillo:["Castillo","Modo Aventura y Mazmorra Infinita.",["⚔ Modo Aventura","∞ Mazmorra Infinita"]],
 muelle:["Muelle","Embarcadero del lago: pescadores, estibadores y marineros.",["🎣 Pescadores","⚓ Maestre del puerto"]],
 entrenamiento:["Área de Entrenamiento","Zona de Combate y Zona de Arquería.",["⚔ Combate","🏹 Arquería"]],
 taberna:["Taberna","Escuadrón, rumores, tablón de encargos y expediciones.",["🍺 Escuadrón","🗣 Rumores","📌 Tablón","🧭 Expediciones"]]};
var DIST=["Calles de Oakhaven","Plaza Mayor","Ciudadela Real","Barrio Noble","Distrito Comercial","Distrito de las Forjas","Distrito de los Alquimistas","Distrito Residencial","Jardines de Oakhaven","Puerto de Oakhaven","Distrito de las Tabernas","Distrito Sanitario","Distrito del Gremio"];
var DCOL=["","#e8c9a0","#b0b0d0","#9a6ad0","#e0a830","#e0642a","#30b890","#9a8a64","#50c850","#3a8ad0","#c8603a","#e0608a","#5a80e0"];
/* ---------- utilidades ---------- */
function rng(s){return function(){s|=0;s=s+0x6D2B79F5|0;var t=Math.imul(s^s>>>15,1|s);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296;};}
var R=rng(4242);function ri(n){return Math.floor(R()*n);}
var DX=[1,0,-1,0],DY=[0,1,0,-1];
function I(x,y){return y*W+x;}
function inb(x,y){return x>=0&&y>=0&&x<W&&y<H;}
function pj(x,y){return{x:(x-y)*TW/2,y:(x+y)*TH/2};}
/* ---------- ciudad ---------- */
var blk=new Uint8Array(N),road=new Uint8Array(N),zone=new Uint8Array(N),dep=new Uint8Array(N),shore=new Uint8Array(N),pav=new Uint8Array(N),dist=new Uint8Array(N),pier=new Uint8Array(N);
var tiles=new Array(N),objs=[],blds=[],SX=new Float32Array(N),SY=new Float32Array(N);
/* zone: 0 ciudad · 1 bosque (borde) · 2 agua */
var LY=[],ly=93;for(var x=0;x<W;x++){ly+=ri(3)-1;ly=Math.max(92,Math.min(95,ly));LY[x]=ly;}
for(var y=0;y<H;y++)for(var x=0;x<W;x++){var i=I(x,y);SX[i]=(x-y)*TW/2;SY[i]=(x+y)*TH/2;
 if(x>=26&&x<=118&&y>=LY[x]){zone[i]=2;blk[i]=1;}
 else if(Math.min(x,y,W-1-x)<2||(y>=86&&(x<26||x>118))){zone[i]=1;blk[i]=1;}}
function RD(x0,y0,x1,y1,p){for(var y=y0;y<=y1;y++)for(var x=x0;x<=x1;x++){if(!inb(x,y))continue;var i=I(x,y);if(zone[i]!==0)continue;road[i]=1;if(p)pav[i]=1;}}
var VX=[[12,2],[28,2],[44,2],[58,2],[70,3],[84,2],[98,2],[114,2],[130,2]],HY=[[14,2],[26,2],[36,2],[44,3],[54,2],[64,2],[74,2],[84,2]];
VX.forEach(function(v){var b=v[0]===70;RD(v[0],b?9:2,v[0]+v[1]-1,b?LY[71]-1:90,b||v[0]===58||v[0]===84);});
HY.forEach(function(h){RD(2,h[0],W-3,h[0]+h[1]-1,h[0]===44||h[0]===36||h[0]===54);});
RD(60,38,83,53,true);RD(60,4,83,13,true);   /* plaza mayor y patio del castillo */
function setDist(x0,y0,x1,y1,d){for(var y=y0;y<=y1;y++)for(var x=x0;x<=x1;x++)if(inb(x,y)&&zone[I(x,y)]===0&&!road[I(x,y)])dist[I(x,y)]=d;}
function setDistAll(x0,y0,x1,y1,d){for(var y=y0;y<=y1;y++)for(var x=x0;x<=x1;x++)if(inb(x,y)&&zone[I(x,y)]===0)dist[I(x,y)]=d;}
setDistAll(60,38,83,53,1);setDistAll(60,4,83,13,2);
/* profundidad del agua y orilla */
(function(){var q=new Int32Array(N),d=new Uint8Array(N),qh=0,qt=0;
 for(var i=0;i<N;i++){if(zone[i]===2)d[i]=99;else{d[i]=0;q[qt++]=i;}}
 while(qh<qt){var c=q[qh++],x=c%W,y=(c/W)|0;for(var k=0;k<4;k++){var X=x+DX[k],Y=y+DY[k];if(!inb(X,Y))continue;var j=I(X,Y);if(d[j]>d[c]+1){d[j]=d[c]+1;q[qt++]=j;}}}
 for(var i=0;i<N;i++)dep[i]=d[i];})();
function aw(x,y){return inb(x,y)&&zone[I(x,y)]===2;}
var SHN={SE:4,SW:4,S:4,E:1,W:1,NE:1,NW:1,dE:2,dW:2};
function orilla(x,y){var ne=aw(x,y-1),se=aw(x+1,y),sw=aw(x,y+1),nw=aw(x-1,y),k=null;
 if(se&&sw)k="S";else if(ne&&se)k="E";else if(nw&&sw)k="W";else if(se)k="SE";else if(sw)k="SW";else if(ne)k="NE";else if(nw)k="NW";
 else if(aw(x+1,y-1))k="dE";else if(aw(x-1,y+1))k="dW";
 if(!k)return null;return "sh_"+k+((x*7+y*13)%SHN[k]);}
for(var y=0;y<H;y++)for(var x=0;x<W;x++){var i=I(x,y),z=zone[i];
 if(z===2){tiles[i]=dep[i]<=2?"wa":"wb";continue;}
 if(road[i]){tiles[i]=pav[i]?(R()<.25?"p"+(5+ri(3)):"p"+ri(5)):"e"+ri(3);}
 else{tiles[i]="g"+(R()<.55?ri(3):ri(16));var o=orilla(x,y);if(o){tiles[i]=o;shore[i]=1;}}}
/* ---------- objetos ---------- */
function free(x,y,w,h){for(var b=0;b<h;b++)for(var a=0;a<w;a++){var X=x+a,Y=y+b;if(!inb(X,Y))return false;var i=I(X,Y);if(blk[i]||road[i]||zone[i]!==0||shore[i])return false;}return true;}
function put(n,x,y,w,h,o){o=o||{};o.i=n;o.cx=x+w/2;o.cy=y+h/2;o.fx=x;o.fy=y;o.fw=w;o.fh=h;objs.push(o);
 for(var b=0;b<h;b++)for(var a=0;a<w;a++)if(inb(x+a,y+b))blk[I(x+a,y+b)]=1;return o;}
function svc(id,x,y,sec){var o=put(id,x,y,2,2,{lab:SERV[id][0],id:id,w:2,h:2,k:"s",sec:sec?1:0});blds.push(o);return o;}
function dec(n,x,y,w,h,o){o=o||{};o.i=n;o.cx=x+w/2;o.cy=y+h/2;objs.push(o);return o;}
var CASAS=["dh_azul","dh_paja","dh_turq","dh_verde","cabana1","cabana2"],NOBLES=["dh_azul","dh_turq","dh_verde","dh_paja"];
function casa(x,y,lista){if(!free(x,y,2,2))return false;put(lista[ri(lista.length)],x,y,2,2,{k:"h",win:R()<.45?1:0});return true;}
function puesto(x,y){if(!free(x,y,1,1))return false;put("puesto"+(1+ri(3)),x,y,1,1,{k:"p"});return true;}
function flor(x,y){if(free(x,y,1,1)&&R()<.5)dec("f"+ri(2),x,y,1,1,{sw:1});}
function arbusto(x,y){if(free(x,y,1,1))put("b"+ri(5),x,y,1,1,{sw:1,k:"v"});}
function arbol(x,y){if(free(x,y,1,1))put("t"+ri(10),x,y,1,1,{sw:1,k:"v"});}
/* ciudadela: castillo, entrenamiento y torres */
var _c=put("castillo",69,6,4,3,{lab:"Castillo",id:"castillo",w:4,h:3,k:"c"});blds.push(_c);
var _e=put("entrenamiento",76,5,3,3,{lab:"Entrenar",id:"entrenamiento",w:3,h:3,k:"c",glow:1});blds.push(_e);
put("torre",61,5,2,2,{k:"c"});put("torre",81,5,2,2,{k:"c"});put("torre2",61,10,2,2,{k:"c"});put("torre2",81,10,2,2,{k:"c"});
[[68,10],[74,10],[68,13],[74,13],[64,7],[79,10]].forEach(function(p){put("farol",p[0],p[1],1,1,{light:1,k:"v"});});
/* plaza mayor: servicios principales */
svc("gremio",62,39);svc("hospital",66,39);svc("tienda",74,39);svc("taberna",78,39);svc("herreria",62,49);svc("alquimista",66,49);
[[75,49],[78,50],[81,49],[76,52],[80,52],[62,52],[65,52],[68,52]].forEach(function(p){put("puesto"+(1+ri(3)),p[0],p[1],1,1,{k:"p"});});
put("mesa",74,51,1,1,{k:"p"});put("forja",82,51,1,1,{k:"p"});put("mesa",70,41,1,1,{k:"p"});put("mesa",72,49,1,1,{k:"p"});
[[60,38],[83,38],[60,53],[83,53],[69,38],[73,38],[69,53],[73,53],[60,45],[83,45],[64,44],[78,46]].forEach(function(p){put("farol",p[0],p[1],1,1,{light:1,k:"v"});});
/* rellenado de manzanas */
function alleys(x0,y0,x1,y1){for(var y=y0;y<=y1;y++)for(var x=x0;x<=x1;x++){if(((x-x0)%3===2||(y-y0)%3===2)&&inb(x,y)){var i=I(x,y);if(zone[i]===0&&!road[i]&&!blk[i]&&!shore[i]&&R()<.85)tiles[i]="e"+ri(3);}}}
var DK={r:7,n:3,k:4,m:4,f:5,a:6,t:10,s:11,g:12,p:8,h:9};
var SVCK={k:["tienda",.40],f:["herreria",.36],a:["alquimista",.36],t:["taberna",.40],s:["hospital",.22],g:["gremio",.16]};
function cajon(x,y){if(free(x,y,1,1))put(R()<.5?"mu_cajas":"mu_barril",x,y,1,1,{k:"v"});}
function fillBlock(x0,y0,x1,y1,kind){
 var d=DK[kind];setDist(x0,y0,x1,y1,d);
 var x,y;
 if(kind==="m"){
  for(y=y0;y<=y1;y++)for(x=x0;x<=x1;x++){var i=I(x,y);if(zone[i]===0&&!road[i]&&!shore[i])tiles[i]="e"+ri(3);}
  for(y=y0+1;y<=y1-1;y+=3)for(x=x0+1;x<=x1-1;x+=3){var r=R();
   if(r<.8)puesto(x,y);else if(r<.88&&free(x,y,1,1))put("mesa",x,y,1,1,{k:"p"});else if(r<.93&&free(x,y,1,1))put("forja",x,y,1,1,{k:"p"});
   if(R()<.3)cajon(x+1,y+1);}
  return;}
 if(kind==="p"){
  var mx=Math.floor((x0+x1)/2),my=Math.floor((y0+y1)/2);
  for(y=y0;y<=y1;y++)for(x=x0;x<=x1;x++){var j=I(x,y);if(zone[j]!==0||road[j]||shore[j])continue;
   if(Math.abs(x-mx)<=0||Math.abs(y-my)<=0){tiles[j]="e"+ri(3);continue;}
   var r=R();if(r<.05)arbol(x,y);else if(r<.18)arbusto(x,y);else if(r<.34)flor(x,y);else if(r<.37&&free(x,y,1,1))put("r"+ri(4),x,y,1,1,{k:"v"});else if(r<.39&&free(x,y,1,1))put("mesa",x,y,1,1,{k:"p"});else if(r<.40&&free(x,y,1,1))put("stump",x,y,1,1,{k:"v"});}
  return;}
 if(kind==="h"){
  for(y=y0;y<=y1;y+=3)for(x=x0;x<=x1;x+=3){var r=R();
   if(r<.55)casa(x,y,["cabana1","cabana2"]);else if(r<.7&&free(x,y,1,1))put("forja",x,y,1,1,{k:"p"});
   else if(r<.9){cajon(x,y);cajon(x+1,y+1);}}
  return;}
 if(kind==="f"){for(y=y0;y<=y1;y++)for(x=x0;x<=x1;x++){var i2=I(x,y);if(zone[i2]===0&&!road[i2]&&!shore[i2])tiles[i2]="e"+ri(3);}}
 for(y=y0;y<=y1-1;y+=3)for(x=x0;x<=x1-1;x+=3){var r=R(),sv=SVCK[kind];
  if(sv){
   if(r<sv[1]){if(free(x,y,2,2))svc(sv[0],x,y,true);}
   else if(kind==="k"){if(r<.68){puesto(x,y);puesto(x+1,y+1);}else if(r<.9)casa(x,y,CASAS);else arbusto(x,y);}
   else if(kind==="f"){if(r<.62){if(free(x,y,1,1))put(R()<.6?"forja":"mesa",x,y,1,1,{k:"p"});cajon(x+1,y+1);}else if(r<.8)casa(x,y,["cabana1","cabana2"]);else cajon(x,y);}
   else if(kind==="a"){if(r<.62){arbusto(x,y);flor(x+1,y);arbusto(x+1,y+1);}else if(r<.8&&free(x,y,1,1))put("mesa",x,y,1,1,{k:"p"});else casa(x,y,CASAS);}
   else if(kind==="t"){if(r<.62){puesto(x,y);cajon(x+1,y+1);}else if(r<.9)casa(x,y,CASAS);else arbusto(x,y);}
   else{if(r<.72)casa(x,y,CASAS);else if(r<.9){arbusto(x,y);flor(x+1,y);}else flor(x,y);}}
  else if(kind==="n"){
   if(r<.82){if(casa(x,y,NOBLES)&&R()<.5)arbusto(x+2,y);}else if(r<.92)arbusto(x,y);
   if(R()<.05)arbol(x+2,y+2);}
  else{
   if(r<.78)casa(x,y,CASAS);else if(r<.9){arbusto(x,y);flor(x+1,y);}else flor(x,y);}
  if(R()<.35)flor(x+2,y+1);}
 alleys(x0,y0,x1,y1);}
var CXs=[[2,11],[14,27],[30,43],[46,57],[60,69],[73,83],[86,97],[100,113],[116,129],[132,141]],
 RYs=[[2,13],[16,25],[28,35],[38,43],[47,53],[56,63],[66,73],[76,83],[86,95]],
 KS=["nnnnxxnnnn","rnnnppnnnr","rrrmkkmrrr","rfffxxaaar","rfffxxaaar","rrkmmmmkrr","rrrtpptrrr","rrssttggrr","hhhhhhhhhh"];
for(var ry=0;ry<RYs.length;ry++)for(var cx2=0;cx2<CXs.length;cx2++){var kk=KS[ry].charAt(cx2);if(kk==="x")continue;
 var bx0=CXs[cx2][0],bx1=CXs[cx2][1];fillBlock(bx0,RYs[ry][0],bx1,RYs[ry][1],kk);}
/* muelle en el lago (al final de la avenida) */
var PS=Math.min(LY[70],LY[71]);
for(var y=PS-2;y<=PS+3;y++)for(var x=70;x<=71;x++){var i=I(x,y);pier[i]=1;tiles[i]="pier";blk[i]=0;road[i]=1;}
var _mu=put("muelle",69,PS+4,4,3,{lab:"Muelle",id:"muelle",w:4,h:3,dy:22,k:"c"});blds.push(_mu);
[PS+.55,PS+2.55].forEach(function(yy){objs.push({i:"mu_poste",cx:70.12,cy:yy,dy:-6});objs.push({i:"mu_poste",cx:71.88,cy:yy,dy:-6});});
objs.push({i:"mu_farolpez",cx:69.5,cy:PS+.9,light:1});
put("mu_bote",73,PS+2,1,1,{dy:6});
(function(){var q=new Int32Array(N),dd=new Uint8Array(N),qh=0,qt=0;
 for(var i=0;i<N;i++){if(zone[i]===0&&dist[i]>0){q[qt++]=i;}}
 while(qh<qt){var c=q[qh++],x=c%W,y=(c/W)|0;if(dd[c]>=5)continue;
  for(var k=0;k<4;k++){var X=x+DX[k],Y=y+DY[k];if(!inb(X,Y))continue;var j=I(X,Y);if(zone[j]!==0||dist[j]>0||!road[j])continue;dist[j]=dist[c];dd[j]=dd[c]+1;q[qt++]=j;}}})();
setDistAll(2,86,W-3,H-1,9);for(var i=0;i<N;i++)if(pier[i])dist[i]=9;
/* faroles junto a las calles y juncos */
for(var y=2;y<H-2;y++)for(var x=2;x<W-2;x++){var i=I(x,y);
 if((x+y)%9===0&&free(x,y,1,1)&&(road[i-1]||road[i+1]||road[i-W]||road[i+W])&&R()<.8)put("farol",x,y,1,1,{light:1,k:"v"});
 if(zone[i]===2&&dep[i]===1&&!pier[i]&&R()<.2)objs.push({i:"junco",cx:x+.5,cy:y+.5,sw:1});}
/* borde de bosque: pocos árboles, solo para ocultar el vacío */
for(var y=0;y<H;y++)for(var x=0;x<W;x++){var i=I(x,y);if(zone[i]!==1||tiles[i].charAt(0)==="s")continue;
 var p=R();if(p<.62)put("t"+ri(10),x,y,1,1,{sw:1});else if(p<.82)put("b"+ri(5),x,y,1,1,{sw:1});else if(p<.88)put("r"+ri(4),x,y,1,1,{});}
/* General de la plaza (NPC fijo, sprite grande 48x72 = hoja de Generales; c debe ser k="humano" en chars.js para que Oakhaven lo cargue). Ofrece: Salir a explorar / Entrar en las Mazmorras del Reino de Artaros */
var GEN={c:80,x:74.5,y:44.5,cell:[74,44],dir:1,name:"General Varek",rol:"Comandante de la Plaza"};
blk[I(GEN.cell[0],GEN.cell[1])]=1;
/* accesibilidad (celdas alcanzables desde la avenida) */
var reach=new Uint8Array(N),SPAWN={x:71,y:47};
(function(){var q=new Int32Array(N),qh=0,qt=0,s=I(SPAWN.x,SPAWN.y);reach[s]=1;q[qt++]=s;
 while(qh<qt){var c=q[qh++],x=c%W,y=(c/W)|0;for(var k=0;k<4;k++){var X=x+DX[k],Y=y+DY[k];if(!inb(X,Y))continue;var j=I(X,Y);if(blk[j]||reach[j])continue;reach[j]=1;q[qt++]=j;}}})();
/* ---------- camino (BFS) ---------- */
var _q=new Int32Array(N),_pv=new Int32Array(N);
function bfs(a,b){
 if(!inb(b.x,b.y)||blk[I(b.x,b.y)])return null;
 _pv.fill(-2);var qh=0,qt=0,s=I(a.x,a.y),e=I(b.x,b.y);_pv[s]=-1;_q[qt++]=s;
 while(qh<qt){var c=_q[qh++];if(c===e)break;var x=c%W,y=(c/W)|0;
  for(var k=0;k<4;k++){var X=x+DX[k],Y=y+DY[k];if(!inb(X,Y))continue;var j=I(X,Y);if(blk[j]||_pv[j]!==-2)continue;_pv[j]=c;_q[qt++]=j;}}
 if(_pv[e]===-2)return null;var path=[],c=e;while(c!==-1){path.push({x:c%W,y:(c/W)|0});c=_pv[c];}path.reverse();path.shift();return path;}
function celdaLibre(x,y){if(inb(x,y)&&!blk[I(x,y)])return{x:x,y:y};
 for(var r=1;r<=4;r++)for(var b=-r;b<=r;b++)for(var a=-r;a<=r;a++){if(Math.max(Math.abs(a),Math.abs(b))!==r)continue;if(inb(x+a,y+b)&&!blk[I(x+a,y+b)]&&reach[I(x+a,y+b)])return{x:x+a,y:y+b};}return null;}
/* ---------- personajes (hojas RPG Maker; filas: 0 abajo,1 izq,2 der,3 arriba) ---------- */
var EMB=/[?&]embed=1/.test(location.search),ONLINE_Q=/[?&]online=1/.test(location.search);
var PC=(function(){try{var v=parseInt(localStorage.getItem("naradak_pc"),10);return v>=0&&v<CHARS.length&&CHARS_INFO[v].k==="humano"?v:4;}catch(e){return 4;}})();
var P={x:SPAWN.x+.5,y:SPAWN.y+.5,dir:0,mv:0,path:[],want:null,enterB:null,bub:null},cam=pj(P.x,P.y),T=0,tmin=8*60,Z=innerWidth<600?1:1.2,near=null,nearV=null,vPref=false,keys={},talk=null,tgt=null,DPR=1,curDist=1;
try{var _sp=JSON.parse(localStorage.getItem("naradak_oak_pos")||"null");if(_sp&&inb(_sp.x|0,_sp.y|0)&&reach[I(_sp.x|0,_sp.y|0)]){P.x=+_sp.x;P.y=+_sp.y;cam=pj(P.x,P.y);}}catch(e){}
var NOM=["Aldric","Berta","Tomás","Lina","Rurik","Mira","Dani","Selka","Hugo","Elsa","Bruno","Nora","Gael","Irene","Otto","Vera","Lucas","Alma","Fabio","Zoe","Marco","Clara","Iván","Petra","Edda","Cedric","Maya","Bran"];
var APE=["Hale","Robledo","Alder","Voss","Fenn","Marsh","Thorne","Pardo","Oakley","Brook","Stein","Varga"];
var ROLES=[["Mercader","¡Los mejores precios de Oakhaven! Solo por hoy.","Se dice que la Herrería de la plaza forja armas legendarias."],["Panadera","El pan recién horneado se acaba rápido; llega temprano.","El Mercado Sur tiene la harina más fina del reino."],["Guardia","Oakhaven es segura mientras el castillo vigile el camino.","Circula, aventurero: la plaza se llena al mediodía."],["Aldeano","Vivo aquí desde hace treinta años y nunca vi tanta gente.","El Gremio paga bien por limpiar las cuevas del norte."],["Pescador","El lago está lleno de peces, pero el puerto cobra tasas.","Pásate por el Muelle al atardecer, hay buen ambiente."],["Herrero","Si necesitas una espada, ve a la Herrería de la plaza.","El hierro de las minas del norte es el mejor."],["Alquimista","Cuidado con mis pociones: no son para beber... aún.","Las hierbas del bosque valen su peso en oro."],["Bardo","Ven a la Taberna esta noche, tengo canciones nuevas.","Dicen que bajo el castillo hay una cripta olvidada."],["Niño","¡Mira cuánta gente! ¡Nunca vas a conocerlos a todos!","Mi mamá dice que no hable con aventureros."],["Cocinero","El estofado de la Taberna es famoso hasta en la capital.","Faltan manos: la ciudad crece cada semana."],["Noble","Los Jardines Reales son el orgullo de Oakhaven.","Un aventurero con rango alto siempre es bien recibido."],["Viajero","Vengo de lejos: Oakhaven es la ciudad más grande que he visto.","Perdí el rumbo: ¿dónde queda el Gremio?"]];
var humanos=[];for(var i=0;i<CHARS_INFO.length;i++)if(CHARS_INFO[i].k==="humano"&&CHARS_INFO[i].w===32&&CHARS_INFO[i].h===48)humanos.push(i);
function dirOf(dx,dy){var sx=dx-dy,sy=dx+dy;return Math.abs(sx)>Math.abs(sy)?(sx<0?1:2):(sy>0?0:3);}
function burbuja(txt,s,y0){cx.save();cx.font="600 11px Karla,sans-serif";cx.textAlign="center";
 var L=[],w=txt.split(" "),ln="";w.forEach(function(p){if((ln+" "+p).length>24&&ln){L.push(ln);ln=p;}else ln=ln?ln+" "+p:p;});if(ln)L.push(ln);L=L.slice(0,3);
 var mw=0;L.forEach(function(l){mw=Math.max(mw,cx.measureText(l).width);});var bw=mw+14,bh=L.length*13+8,bx=s.x-bw/2,by=y0-bh;
 cx.fillStyle="rgba(245,236,210,.95)";cx.strokeStyle="#5a4a2a";cx.lineWidth=1.5;cx.beginPath();cx.rect(bx,by,bw,bh);cx.fill();cx.stroke();
 cx.beginPath();cx.moveTo(s.x-4,by+bh);cx.lineTo(s.x,by+bh+5);cx.lineTo(s.x+4,by+bh);cx.fill();
 cx.fillStyle="#2a1810";L.forEach(function(l,k){cx.fillText(l,s.x,by+13+k*13);});cx.restore();}
function drawChar(c,x,y,dir,mv,t,lab,bub){
 var im=CIMG[c];if(!im)return;var fw=CHARS_INFO[c].w,fh=CHARS_INFO[c].h,s=pj(x,y),f=mv?[1,0,1,2][Math.floor(t*8)%4]:1;
 cx.save();cx.translate(s.x,s.y+4);
 cx.fillStyle="rgba(0,0,0,.3)";cx.beginPath();cx.ellipse(0,0,10,4,0,0,7);cx.fill();
 cx.imageSmoothingEnabled=false;cx.drawImage(im,f*fw,dir*fh,fw,fh,-fw/2,-(fh-3),fw,fh);
 if(lab){cx.font="700 10px Cinzel,serif";cx.textAlign="center";cx.lineWidth=3;cx.strokeStyle="rgba(20,12,4,.85)";cx.strokeText(lab,0,-fh-2);cx.fillStyle="#f5e6c0";cx.fillText(lab,0,-fh-2);}
 if(bub&&bub.hasta>T)burbuja(bub.txt,{x:0,y:0},-fh-(lab?14:4));
 cx.restore();}
/* ---------- población ---------- */
var V=[],GU=[],cand=[],GSPR=[50,48,52,26];
(function(){for(var i=0;i<N;i++)if(reach[i]&&!blk[i])cand.push(i);})();
function hyp(a,b){return Math.sqrt(a*a+b*b);}   /* Math.hypot puede variar en el último bit entre navegadores; sqrt es exacto (necesario para que la simulación sea idéntica) */
function cercaGen(x,y){return hyp(x+.5-GEN.x,y+.5-GEN.y)<2.4;}   /* claro alrededor del General: los aldeanos no lo tapan */
function spawnV(){V=[];GU=[];if(!humanos.length)return;var core=[],S=rng(710031);var civ=humanos.filter(function(h){return GSPR.indexOf(h)<0;});if(!civ.length)civ=humanos;   /* S: semilla fija -> los mismos aldeanos en todos los navegadores */
 cand.forEach(function(i){var x=i%W,y=(i/W)|0;if(x>=58&&x<=85&&y>=36&&y<=55||(y>=44&&y<=46)||(x>=70&&x<=72))core.push(i);});
 for(var n=0;n<NPCS;n++){var pool=(S()<.3&&core.length)?core:cand,i=pool[Math.floor(S()*pool.length)],x=i%W,y=(i/W)|0,c=civ[Math.floor(S()*civ.length)];
  if(cercaGen(x,y)){n--;continue;}
  var ro=ROLES[Math.floor(S()*ROLES.length)],k=V.length;
  V.push({c:c,x:x+.5,y:y+.5,t:null,d:Math.floor(S()*4),back:-1,wait:S()*3,mv:0,dir:0,sp:.9+S()*.7,name:NOM[Math.floor(S()*NOM.length)]+" "+APE[Math.floor(S()*APE.length)],rol:ro[0],lines:[ro[1],ro[2]],li:0,r:rng(880001+k*7919)});}}
/* guardias de ronda: recorren las avenidas y los distritos */
var GRUTAS=[
 [[61,39],[82,39],[82,52],[61,52]],[[82,52],[61,52],[61,39],[82,39]],
 [[62,12],[81,12],[81,8],[62,8]],
 [[71,14],[71,43]],[[71,47],[71,84]],
 [[13,45],[58,45]],[[85,45],[130,45]],
 [[45,16],[45,84]],[[99,16],[99,84]],
 [[13,15],[130,15]],[[13,16],[13,83]],[[131,16],[131,83]],
 [[13,37],[44,37],[44,54],[13,54]],[[85,37],[130,37],[130,54],[85,54]],
 [[45,27],[98,27],[98,37],[45,37]],
 [[60,85],[82,85],[71,PS-1],[71,PS+2]]];
function crearGuardias(){GU=[];   /* aleatoriedad con semilla fija por guardia */
 GRUTAS.forEach(function(ru,k){var pts=[];ru.forEach(function(q){var c=celdaLibre(q[0],q[1]);if(c)pts.push(c);});
  if(pts.length<2)return;var gr=rng(990011+k*104729),a=Math.floor(gr()*pts.length);
  GU.push({c:GSPR[k%GSPR.length],x:pts[a].x+.5,y:pts[a].y+.5,route:pts,ri:(a+1)%pts.length,path:[],wait:gr()*2,mv:0,dir:0,sp:1.15+gr()*.2,r:gr});});}
function moverG(g,dt){
 if(g.wait>0){g.wait-=dt;g.mv=0;return;}
 if(!g.path.length){var p=bfs({x:Math.floor(g.x),y:Math.floor(g.y)},g.route[g.ri]);
  if(!p||!p.length){g.ri=(g.ri+1)%g.route.length;g.wait=.6;g.mv=0;return;}g.path=p;}
 var n=g.path[0],ex=n.x+.5-g.x,ey=n.y+.5-g.y,dd=hyp(ex,ey);
 if(dd<.06){g.x=n.x+.5;g.y=n.y+.5;g.path.shift();if(!g.path.length){g.ri=(g.ri+1)%g.route.length;g.wait=.8+g.r()*1.6;g.mv=0;}return;}
 var st=Math.min(dd,g.sp*dt);g.x+=ex/dd*st;g.y+=ey/dd*st;g.mv=1;g.dir=dirOf(ex,ey);}
function moverV(v,dt){
 if(v.wait>0){v.wait-=dt;v.mv=0;return;}
 if(!v.t){var cx0=Math.floor(v.x),cy0=Math.floor(v.y),o=[],k;
  for(k=0;k<4;k++){var X=cx0+DX[k],Y=cy0+DY[k];if(inb(X,Y)&&reach[I(X,Y)]&&k!==v.back&&!cercaGen(X,Y))o.push(k);}
  if(!o.length){for(k=0;k<4;k++){var X2=cx0+DX[k],Y2=cy0+DY[k];if(inb(X2,Y2)&&reach[I(X2,Y2)])o.push(k);}if(!o.length){v.wait=2;return;}}
  var d=(o.indexOf(v.d)>=0&&v.r()<.8)?v.d:o[Math.floor(v.r()*o.length)];
  v.d=d;v.back=(d+2)%4;v.t={x:cx0+DX[d]+.5,y:cy0+DY[d]+.5};if(v.r()<.07)v.wait=.6+v.r()*3.5;}
 var ex=v.t.x-v.x,ey=v.t.y-v.y,dd=hyp(ex,ey);
 if(dd<.05){v.x=v.t.x;v.y=v.t.y;v.t=null;return;}
 var st=Math.min(dd,v.sp*dt);v.x+=ex/dd*st;v.y+=ey/dd*st;v.mv=1;v.dir=dirOf(ex,ey);}
/* ---------- simulación determinista y sincronizada ----------
   Todos los navegadores calculan la MISMA población: semilla fija, pasos de tiempo fijos (SIM_STEP) y un reloj de mundo común.
   Online, el reloj de mundo es el tiempo del servidor (ver "reloj" en servidor.js); sin servidor, el tiempo local.
   Cada SIM_CICLO segundos (solo online) la población vuelve a su estado inicial en todos los navegadores a la vez: así
   quien entra tarde recalcula como mucho SIM_CICLO/SIM_STEP pasos. Mientras se espera al reloj del servidor no se muestran aldeanos. */
var SIM_STEP=.1,SIM_CICLO=900,simN=0,simCyc=0,simAlpha=1,mundoOff=0,relojOk=false,cicloOn=false,simBloq=ONLINE_Q;
function simReiniciar(){spawnV();crearGuardias();var i,e;for(i=0;i<GU.length;i++){e=GU[i];e.px=e.rx=e.x;e.py=e.ry=e.y;}for(i=0;i<V.length;i++){e=V[i];e.px=e.rx=e.x;e.py=e.ry=e.y;}}
function simPaso(){var i,e;
 for(i=0;i<GU.length;i++){e=GU[i];e.px=e.x;e.py=e.y;moverG(e,SIM_STEP);}
 for(i=0;i<V.length;i++){e=V[i];e.px=e.x;e.py=e.y;moverV(e,SIM_STEP);}}
function simTick(){
 if(simBloq){if(relojOk||T>4)simBloq=false;else return;}   /* sin respuesta del servidor en 4 s: reloj local */
 var raw=(performance.now()+mundoOff)/1000,cyc=cicloOn?Math.floor(raw/SIM_CICLO):0,mt=cicloOn?raw-cyc*SIM_CICLO:raw;
 if(cyc!==simCyc||simN*SIM_STEP-mt>1){simCyc=cyc;simN=0;simReiniciar();}
 while((simN+1)*SIM_STEP<=mt){simPaso();simN++;}
 simAlpha=Math.max(0,Math.min(1,(mt-simN*SIM_STEP)/SIM_STEP));
 var i,e;
 for(i=0;i<GU.length;i++){e=GU[i];e.rx=e.px+(e.x-e.px)*simAlpha;e.ry=e.py+(e.y-e.py)*simAlpha;}
 for(i=0;i<V.length;i++){e=V[i];e.rx=e.px+(e.x-e.px)*simAlpha;e.ry=e.py+(e.y-e.py)*simAlpha;}}
/* ---------- General de la plaza: dialogo con dos opciones ---------- */
var GOPS=[
 {id:"explorar",ico:"🧭",txt:"Salir a explorar",
  resp:"Las puertas al Mundo Abierto se cruzan desde el juego principal: entra a Oakhaven desde el Muelle o el campamento y vuelve a hablar conmigo."},
 {id:"mazmorras",ico:"🕳",txt:"Entrar en las Mazmorras del Reino de Artaros",
  resp:"Las puertas de las Mazmorras del Reino de Artaros se abren desde el juego principal: entra a Oakhaven desde el Muelle o el campamento y vuelve a hablar conmigo."}],panelGen=false;
function pOpciones(lista){var b=$("pBtns");b.innerHTML="";b.style.display="flex";
 lista.forEach(function(o){var bt=document.createElement("button");bt.className="pOp";bt.textContent=o.txt;bt.onclick=o.fn;b.appendChild(bt);});}
function abrirGeneral(){
 $("pTit").textContent=GEN.name;
 $("pTxt").textContent="Mis soldados vigilan el camino a las tierras salvajes y la entrada a las Mazmorras del Reino de Artaros. ¿Qué camino tomarás, aventurero?";
 $("pLst").style.display="none";
 pOpciones(GOPS.map(function(o,k){return{txt:(k+1)+" · "+o.ico+" "+o.txt,fn:function(){elegirGeneral(o);}};}));
 panelGen=true;$("panel").style.display="flex";}
function elegirGeneral(o){
 var ok=false;try{ok=!!Oakhaven.onGeneral&&Oakhaven.onGeneral(o.id)===true;}catch(e){}
 if(ok){cerrar();return;}
 /* mientras el mapa de destino no exista: respuesta del General + volver a elegir */
 $("pTxt").textContent=o.resp+"\n\n🚧 Próximamente";
 pOpciones([{txt:"← Elegir otro camino",fn:abrirGeneral}]);}
function hablar(v){if(v&&v.rpid){abrirJugador(v.rpid);return;}if(v!==GEN)return;talk=GEN;abrirGeneral();}
/* Hablar con otro jugador: Invitar a grupo · Comerciar · Chat privado (el panel del grupo y los avisos viven en el juego principal) */
function abrirJugador(id){
 var r=RP[id],H=ONL.hub;if(!r)return;
 talk={rpid:id,x:r.x,y:r.y,name:r.nombre};panelGen=false;
 $("pTit").textContent=r.nombre;
 $("pTxt").textContent="Nv "+(r.nivel||"?")+(r.clase?" · "+r.clase:"");
 $("pLst").style.display="none";
 if(!H){$("pTxt").textContent+="\nGrupo, comercio y chat privado solo están disponibles al jugar desde el juego principal.";$("pBtns").style.display="none";}
 else{
  var enG=H.esMiembro(id);
  pOpciones([
   {txt:enG?"👥 Ya está en tu grupo":"👥 Invitar a grupo",fn:function(){if(!enG)H.invitar(id);cerrar();}},
   {txt:"🤝 Comerciar",fn:function(){H.comerciar(id);cerrar();}},
   {txt:"💬 Chat privado",fn:function(){H.susurrar(id);cerrar();}}]);
 }
 $("panel").style.display="flex";}
function irAJugador(id){
 var r=RP[id];if(!r)return;talk=null;
 if(Math.hypot(r.x-P.x,r.y-P.y)<2.6){hablar({rpid:id,name:r.nombre});return;}
 var best=null,gx=Math.floor(r.x),gy=Math.floor(r.y);
 for(var yy=gy-1;yy<=gy+1;yy++)for(var xx=gx-1;xx<=gx+1;xx++){
  if(xx===gx&&yy===gy)continue;if(!inb(xx,yy)||blk[I(xx,yy)])continue;
  var p=bfs(cell(),{x:xx,y:yy});if(p&&(!best||p.length<best.p.length))best={p:p,x:xx,y:yy};}
 if(best){P.want=null;P.enterB=null;P.talkG=false;P.talkR=id;P.path=best.p;tgt={x:best.x,y:best.y};}}
function irAGeneral(){
 talk=null;if(Math.hypot(GEN.x-P.x,GEN.y-P.y)<2.6){hablar(GEN);return;}
 var best=null,gx=GEN.cell[0],gy=GEN.cell[1];
 for(var yy=gy-1;yy<=gy+1;yy++)for(var xx=gx-1;xx<=gx+1;xx++){
  if(xx===gx&&yy===gy)continue;if(!inb(xx,yy)||blk[I(xx,yy)])continue;
  var p=bfs(cell(),{x:xx,y:yy});if(p&&(!best||p.length<best.p.length))best={p:p,x:xx,y:yy};}
 if(best){P.want=null;P.enterB=null;P.talkG=true;P.path=best.p;tgt={x:best.x,y:best.y};}}
function drawGeneral(t){
 var dd=Math.hypot(P.x-GEN.x,P.y-GEN.y),dir=dd<9?dirOf(P.x-GEN.x,P.y-GEN.y):GEN.dir;
 drawChar(GEN.c,GEN.x,GEN.y,dir,0,t,GEN.name);
 if(!panelGen||$("panel").style.display!=="flex"){var s=pj(GEN.x,GEN.y);cx.save();cx.translate(s.x,s.y+4);
  cx.font="900 20px Cinzel,serif";cx.textAlign="center";cx.lineWidth=4;cx.strokeStyle="rgba(20,12,4,.9)";
  var by=-92+Math.sin(t*3)*3;cx.strokeText("!",0,by);cx.fillStyle="#ffd25a";cx.fillText("!",0,by);cx.restore();}}
var _dtm=0;function anunciar(t){var e=$("dTit");if(!e||!t)return;e.textContent=t;e.style.opacity=1;clearTimeout(_dtm);_dtm=setTimeout(function(){e.style.opacity=0;},2800);}
function guardaPos(){try{localStorage.setItem("naradak_oak_pos",JSON.stringify({x:+P.x.toFixed(2),y:+P.y.toFixed(2)}));}catch(e){}}
function cerrar(){talk=null;panelGen=false;$("panel").style.display="none";}
/* ---------- minimapa ---------- */
var MM=document.createElement("canvas");MM.width=W*2;MM.height=H*2;
(function(){var g=MM.getContext("2d");
 for(var y=0;y<H;y++)for(var x=0;x<W;x++){var i=I(x,y),c;
  if(zone[i]===2)c="#2d5f8a";else if(zone[i]===1)c="#1f3d1b";else if(pier[i])c="#936230";else if(road[i])c=pav[i]?"#cdbd8f":"#a58b5a";else if(tiles[i].charAt(0)==="e")c="#8a7648";else c="#3f6d2e";
  g.fillStyle=c;g.fillRect(x*2,y*2,2,2);
  if(zone[i]===0&&dist[i]&&!pier[i]){g.globalAlpha=.42;g.fillStyle=DCOL[dist[i]];g.fillRect(x*2,y*2,2,2);g.globalAlpha=1;}}
 objs.forEach(function(o){if(o.fw==null||o.k==="v")return;var c=o.k==="s"?"#ffd25a":o.k==="c"?"#f0e0b0":o.k==="p"?"#d2692e":"#8a5a38";
  g.fillStyle=c;g.fillRect(o.fx*2,o.fy*2,o.fw*2,o.fh*2);});})();
var mini=$("mini"),mx=mini.getContext("2d");
function drawMini(){mx.clearRect(0,0,mini.width,mini.height);mx.drawImage(MM,0,0);
 mx.fillStyle="rgba(255,235,170,.7)";if(!simBloq)V.forEach(function(v){mx.fillRect(Math.floor(v.x)*2,Math.floor(v.y)*2,1,1);});
 mx.fillStyle="#ffd25a";mx.fillRect(GEN.x*2-2,GEN.y*2-2,4,4);mx.fillStyle="#ff5a4a";if(!simBloq)GU.forEach(function(g){mx.fillRect(Math.floor(g.x)*2-1,Math.floor(g.y)*2-1,3,3);});
 mx.fillStyle="#6ab0ff";for(var id in RP){var r=RP[id];if(r.lugar==="oakhaven")mx.fillRect(r.x*2-2,r.y*2-2,4,4);}
 mx.fillStyle="#fff";mx.strokeStyle="#c00";mx.lineWidth=1.5;mx.beginPath();mx.arc(P.x*2,P.y*2,4,0,7);mx.fill();mx.stroke();}
/* ---------- online (servidor local) ---------- */
var ONL={ws:null,id:0,on:false},RP={},ME=(function(){var b=null;try{for(var i=1;i<=5;i++){var j=JSON.parse(localStorage.getItem("naradak_slot_"+i)||"null");if(j&&(!b||(j.savedAt||0)>(b.savedAt||0)))b=j;}}catch(e){}
 return{nombre:b&&b.nombre?String(b.nombre):"Aventurero",clase:b&&b.clase?String(b.clase):"",nivel:b&&b.nivel?b.nivel:1};})();
/* Embebido en el juego: se usa la conexión persistente del juego principal (window.parent.OnlineHub); standalone: WebSocket propio */
function hubOak(){try{return EMB&&parent&&parent!==window&&parent.OnlineHub?parent.OnlineHub:null;}catch(e){return null;}}
function envia(o){if(ONL.hub){try{ONL.hub.enviar(o);}catch(e){}return;}if(ONL.ws&&ONL.ws.readyState===1)ONL.ws.send(JSON.stringify(o));}
function enLinea(){return ONL.hub?ONL.hub.conectado():!!(ONL.ws&&ONL.ws.readyState===1);}
function avatarOk(a){a=a|0;return CHARS_INFO[a]&&CHARS_INFO[a].k==="humano"&&CIMG[a]?a:4;}
function nRemotos(){var n=0;for(var id in RP)if(RP[id].lugar==="oakhaven")n++;return n;}
function hudOnline(txt){var h=$("hOnline");if(!h)return;h.textContent=txt||(ONL.on?(enLinea()?"🌐 "+(nRemotos()+1)+" en Oakhaven":"🌐 conectando…"):"");}
function chatLog(txt){var l=$("clog");if(!l)return;var d=document.createElement("div");d.textContent=txt;l.appendChild(d);while(l.children.length>6)l.removeChild(l.firstChild);setTimeout(function(){if(d.parentNode)d.parentNode.removeChild(d);},12000);}
function rpSet(p){var r=RP[p.id]||(RP[p.id]={id:p.id,x:+p.x||0,y:+p.y||0,tx:+p.x||0,ty:+p.y||0,dir:0,mv:0,bub:null});
 r.nombre=p.nombre||r.nombre||"Jugador";if(p.clase!=null)r.clase=p.clase;if(p.nivel!=null)r.nivel=p.nivel;r.c=avatarOk(p.avatar!=null?p.avatar:r.c);r.lugar=p.lugar||r.lugar||"pueblo";
 if(p.x!=null){r.tx=+p.x||0;r.ty=+p.y||0;if(Math.hypot(r.tx-r.x,r.ty-r.y)>8){r.x=r.tx;r.y=r.ty;}}
 if(p.dir!=null)r.dir={s:0,w:3,n:3,a:1,d:2,e:2}[p.dir]!=null?{s:0,w:3,n:3,a:1,d:2,e:2}[p.dir]:r.dir;}
/* reloj de mundo compartido: se mide contra el reloj del servidor (la muestra de menor latencia es la más fiable) */
var RELOJ={n:0,env:0,best:null};
function relojPadre(on){try{parent.postMessage({naradak:"reloj_online",on:!!on},"*");}catch(e){}}
setInterval(function(){if(relojOk)relojPadre(true);},4000);   /* latido: el juego principal oculta su reloj flotante mientras llega */
addEventListener("pagehide",function(){if(relojOk)relojPadre(false);});
function relojSrv(){return 8*60+((performance.now()+mundoOff)/1000)*MIN_S;}
function relojPedir(){RELOJ.env=performance.now();envia({t:"reloj",c:RELOJ.env});}
function relojIniciar(){RELOJ.n=0;RELOJ.best=null;relojPedir();}
function relojRecibe(m){
 var rec=performance.now(),rtt=rec-(+m.c),ah=+m.ahora,ini=+m.inicio;
 if(!(rtt>=0)||!isFinite(ah)||!isFinite(ini))return;
 var off=ah+rtt/2-ini-rec;
 if(!RELOJ.best||rtt<RELOJ.best.rtt)RELOJ.best={rtt:rtt,off:off};
 mundoOff=RELOJ.best.off;cicloOn=true;if(!relojOk){relojOk=true;relojPadre(true);}
 if(++RELOJ.n<5)setTimeout(relojPedir,90);}
function onMsg(m){
  if(m.t==="hub_cerrado"){RP={};if(relojOk){relojOk=false;relojPadre(false);}hudOnline();return;}
  if(m.t==="reloj"){relojRecibe(m);return;}   /* respuesta del servidor: hora de mundo compartida con el Mundo Abierto */
  if(m.t==="bienvenido"){ONL.id=m.id;RP={};m.jugadores.forEach(rpSet);if(ONL.hub)envia({t:"lugar",lugar:"oakhaven",x:P.x,y:P.y});relojIniciar();}
  else if(m.t==="entra")rpSet(m.jugador);
  else if(m.t==="sale")delete RP[m.id];
  else if(m.t==="lugar"){var r=RP[m.id];if(r){r.lugar=m.lugar;if(m.x!=null){r.x=r.tx=+m.x;r.y=r.ty=+m.y;}}}
  else if(m.t==="mueve"){var q=RP[m.id];if(q){q.tx=+m.x;q.ty=+m.y;if(m.dir)rpSet({id:m.id,dir:m.dir});}}
  else if(m.t==="info"){var q2=RP[m.id];if(q2)q2.nivel=m.nivel;}
  else if(m.t==="chat"){chatLog(m.nombre+": "+m.texto);var b={txt:m.texto,hasta:T+6};if(m.id===ONL.id)P.bub=b;else if(RP[m.id])RP[m.id].bub=b;}
  else if(m.t==="error"){chatLog("⚠ "+m.msg);if(!ONL.hub)ONL.on=false;}
  hudOnline();
}
function conectar(){
 var H=hubOak();
 if(H){
  ONL.hub=H;
  try{if(ONL.unsub)ONL.unsub();}catch(e){}
  ONL.unsub=H.suscribir(onMsg);
  ["pointerdown","keydown"].forEach(function(ev){addEventListener(ev,function(){try{H.tocar();}catch(e){}},true);});
  addEventListener("pagehide",function(){try{ONL.unsub();}catch(e){}});
  if(H.conectado()){envia({t:"lugar",lugar:"oakhaven",x:P.x,y:P.y});relojIniciar();}
  hudOnline();return;
 }
 var ws=new WebSocket((location.protocol==="https:"?"wss://":"ws://")+location.host+"/ws");ONL.ws=ws;hudOnline();
 ws.onopen=function(){envia({t:"hola",tk:(window.nrdkCuenta&&window.nrdkCuenta.token)||"",nombre:ME.nombre,clase:ME.clase,nivel:ME.nivel,avatar:PC,lugar:"oakhaven",x:P.x,y:P.y});hudOnline();};
 ws.onmessage=function(e){var m;try{m=JSON.parse(e.data);}catch(x){return;}onMsg(m);};
 ws.onclose=function(){ONL.ws=null;RP={};hudOnline();if(ONL.on)setTimeout(conectar,3000);};}
function onlineIniciar(){if(ONL.on)return;if(location.protocol.indexOf("http")!==0){chatLog("⚠ Abre el juego desde el servidor local (http://IP:8080).");return;}
 ONL.on=true;$("chat").style.display="block";conectar();setInterval(function(){if(ONL.ws&&ONL.ws.readyState===1)relojIniciar();},60000);}   /* re-mide el reloj cada minuto */
Oakhaven.online=onlineIniciar;
/* ---------- render ---------- */
function noche(){var h=(tmin/60)%24;return h<5||h>=21?1:h<7?(7-h)/2:h>=19?(h-19)/2:0;}
var GLOW=document.createElement("canvas");GLOW.width=GLOW.height=160;
(function(){var g=GLOW.getContext("2d"),q=g.createRadialGradient(80,80,2,80,80,78);q.addColorStop(0,"rgba(255,170,60,.55)");q.addColorStop(1,"rgba(255,170,60,0)");g.fillStyle=q;g.fillRect(0,0,160,160);})();
function sprite(o,t){
 var im=IMG[o.i];if(!im)return;var s=pj(o.cx,o.cy);cx.save();cx.translate(s.x,s.y+8+(o.dy||0));
 if(o.sw)cx.transform(1,0,Math.sin(t*1.6+o.cx*.7)*.035,1,0,0);
 cx.drawImage(im,-im.width/2,-im.height);cx.restore();
 if(o.lab&&(!o.sec||near===o||Math.hypot(o.cx-P.x,o.cy-P.y)<8)){var b=IMG.banner,d=near===o,w=96,h=42;cx.save();cx.globalAlpha=d?1:.82;
  cx.drawImage(b,s.x-w/2,s.y+8-im.height-h+8-(d?3:0),w,h);cx.fillStyle="#3a2410";cx.font="700 "+(d?11:10)+"px Cinzel,serif";cx.textAlign="center";cx.fillText(o.lab.split(" ")[0],s.x,s.y+8-im.height-h/2+13-(d?3:0));cx.restore();}
}
function draw(t){
 var w=cv.width,h=cv.height;cx.setTransform(1,0,0,1,0,0);cx.fillStyle="#101a0c";cx.fillRect(0,0,w,h);
 var c=pj(P.x,P.y);cam.x+=(c.x-cam.x)*.12;cam.y+=(c.y-cam.y)*.12;
 cx.setTransform(Z*DPR,0,0,Z*DPR,w/2-cam.x*Z*DPR,h/2-cam.y*Z*DPR);
 var vw=w/DPR/Z/2+80,vh=h/DPR/Z/2+80,fr=Math.floor(t*1.5);
 for(var y=0;y<H;y++)for(var x=0;x<W;x++){var i=y*W+x,sx=SX[i]+0,sy=SY[i]+16;if(Math.abs(sx-cam.x)>vw||Math.abs(sy-cam.y)>vh)continue;var k=tiles[i],c0=k.charAt(0),im;
  if(k==="pier"){var wi=IMG["wa"+((fr+x+y)%3)];if(wi)cx.drawImage(wi,sx-35,sy-14);
   cx.fillStyle="#2e1b0d";cx.beginPath();cx.moveTo(sx-32,sy-4);cx.lineTo(sx,sy+12);cx.lineTo(sx+32,sy-4);cx.lineTo(sx+32,sy+2);cx.lineTo(sx,sy+18);cx.lineTo(sx-32,sy+2);cx.closePath();cx.fill();
   cx.fillStyle="#936230";cx.beginPath();cx.moveTo(sx,sy-20);cx.lineTo(sx+32,sy-4);cx.lineTo(sx,sy+12);cx.lineTo(sx-32,sy-4);cx.closePath();cx.fill();
   for(var q=0;q<4;q++){var f0=q/4,f1=(q+1)/4;cx.fillStyle=q%2?"rgba(60,30,8,.16)":"rgba(255,210,150,.08)";
    cx.beginPath();cx.moveTo(sx-32*f0,sy-20+16*f0);cx.lineTo(sx+32-32*f0,sy-4+16*f0);cx.lineTo(sx+32-32*f1,sy-4+16*f1);cx.lineTo(sx-32*f1,sy-20+16*f1);cx.closePath();cx.fill();
    cx.strokeStyle="rgba(35,18,6,.55)";cx.lineWidth=1.2;cx.beginPath();cx.moveTo(sx-32*f1,sy-20+16*f1);cx.lineTo(sx+32-32*f1,sy-4+16*f1);cx.stroke();}
   continue;}
  if(c0==="w"){im=IMG[k+((fr+x*2+y)%3)];if(im)cx.drawImage(im,sx-35,sy-14);continue;}
  im=IMG[k];if(!im)continue;
  if(c0==="g"||c0==="d"){cx.drawImage(im,sx-im.width/2,sy-16);continue;}
  if(c0==="s"&&k.charAt(1)==="h"){cx.drawImage(im,sx-34,sy+4-39);continue;}
  cx.drawImage(im,sx-33,sy-13);}
 if(tgt){var s=pj(tgt.x+.5,tgt.y+.5);cx.strokeStyle="rgba(232,200,120,"+(.5+.4*Math.sin(t*6))+")";cx.lineWidth=2;cx.beginPath();cx.moveTo(s.x,s.y-15);cx.lineTo(s.x+30,s.y);cx.lineTo(s.x,s.y+15);cx.lineTo(s.x-30,s.y);cx.closePath();cx.stroke();}
 var L=[],lim=vw+90,i2;
 for(i2=0;i2<objs.length;i2++){var o=objs[i2],sx2=(o.cx-o.cy)*32;if(Math.abs(sx2-cam.x)>lim)continue;var sy2=(o.cx+o.cy)*16;if(sy2<cam.y-vh-60||sy2>cam.y+vh+220)continue;L.push(o);}
 for(i2=0;!simBloq&&i2<GU.length;i2++){var g0=GU[i2];L.push({g:1,o:g0,cx:g0.rx,cy:g0.ry});}
 for(i2=0;!simBloq&&i2<V.length;i2++){var v=V[i2],sxv=(v.rx-v.ry)*32,syv=(v.rx+v.ry)*16;if(Math.abs(sxv-cam.x)<vw&&Math.abs(syv-cam.y)<vh+60)L.push({v:1,o:v,cx:v.rx,cy:v.ry});}
 for(var id in RP){var r=RP[id];if(r.lugar==="oakhaven")L.push({rp:1,o:r,cx:r.x,cy:r.y});}
 L.push({gen:1,cx:GEN.x,cy:GEN.y,light:1});
 L.push({pl:1,cx:P.x,cy:P.y});
 L.sort(function(a,b){return(a.cx+a.cy)-(b.cx+b.cy);});
 L.forEach(function(o){
  if(o.pl)drawChar(PC,P.x,P.y,P.dir,P.mv,t,ME.nombre,P.bub);
  else if(o.gen)drawGeneral(t);
  else if(o.v)drawChar(o.o.c,o.cx,o.cy,o.o.dir,o.o.mv,t+o.o.c,nearV===o.o?o.o.name:null);
  else if(o.g)drawChar(o.o.c,o.cx,o.cy,o.o.dir,o.o.mv,t+o.o.c,"Guardia");
  else if(o.rp)drawChar(o.o.c,o.o.x,o.o.y,o.o.dir,o.o.mv,t+o.o.c,o.o.nombre,o.o.bub);
  else sprite(o,t);});
 var n=noche();
 if(n>0){cx.save();cx.setTransform(1,0,0,1,0,0);cx.fillStyle="rgba(8,14,48,"+(.55*n)+")";cx.fillRect(0,0,w,h);cx.restore();
  cx.setTransform(Z*DPR,0,0,Z*DPR,w/2-cam.x*Z*DPR,h/2-cam.y*Z*DPR);cx.globalCompositeOperation="lighter";cx.globalAlpha=n;
  L.forEach(function(o){if(!(o.light||o.glow||o.win||o.id==="taberna"||o.id==="herreria"||o.i==="forja"))return;var s=pj(o.cx,o.cy),r=o.light?60:o.win?46:80;cx.drawImage(GLOW,s.x-r,s.y-20-r,r*2,r*2);});
  cx.globalAlpha=1;cx.globalCompositeOperation="source-over";}
}
/* ---------- lógica ---------- */
function cell(){return{x:Math.floor(P.x),y:Math.floor(P.y)};}
function ir(x,y){P.want=null;P.enterB=null;P.talkG=false;var d=celdaLibre(x,y);if(!d)return;var p=bfs(cell(),d);if(p){P.path=p;tgt=d;}}
function mover(dt){
 var dx=0,dy=0;
 if(keys.w||keys.arrowup){dx--;dy--;}if(keys.s||keys.arrowdown){dx++;dy++;}if(keys.a||keys.arrowleft){dx--;dy++;}if(keys.d||keys.arrowright){dx++;dy--;}
 if(dx||dy){P.path=[];tgt=null;P.want=null;P.enterB=null;P.talkG=false;P.talkR=0;var l=Math.hypot(dx,dy);dx/=l;dy/=l;}
 else if(P.path.length){var n=P.path[0],tx=n.x+.5-P.x,ty=n.y+.5-P.y,d=Math.hypot(tx,ty);if(d<.1){P.path.shift();if(!P.path.length)tgt=null;}else{dx=tx/d;dy=ty/d;}}
 P.mv=!!(dx||dy);if(!P.mv)return;P.dir=dirOf(dx,dy);
 var st=SPD*(keys.shift?1.6:1)*dt,nx=P.x+dx*st,ny=P.y+dy*st;
 if(!P.path.length){if(blk[I(Math.floor(nx),Math.floor(P.y))])nx=P.x;if(blk[I(Math.floor(nx),Math.floor(ny))])ny=P.y;}
 P.x=Math.max(2.3,Math.min(W-2.3,nx));P.y=Math.max(2.3,Math.min(H-2.3,ny));}
function cerca(){
 near=null;var m=2.6;blds.forEach(function(b){var d=Math.hypot(b.cx-P.x,b.cy-P.y);if(d<m){m=d;near=b;}});
 nearV=null;var mv=9,dgn=Math.hypot(GEN.x-P.x,GEN.y-P.y);if(dgn<2.6){nearV=GEN;mv=dgn;}
 for(var rid in RP){var rr=RP[rid];if(rr.lugar!=="oakhaven")continue;var dr=Math.hypot(rr.x-P.x,rr.y-P.y);if(dr<2.6&&dr<mv){mv=dr;nearV={rpid:+rid,name:rr.nombre};}}
 if(P.talkR){var rt2=RP[P.talkR];if(!rt2)P.talkR=0;else if(Math.hypot(rt2.x-P.x,rt2.y-P.y)<2.6){var id2=P.talkR;P.talkR=0;P.path=[];tgt=null;hablar({rpid:id2,name:rt2.nombre});}}
 if(talk&&talk.rpid){var rt=RP[talk.rpid];if(rt){talk.x=rt.x;talk.y=rt.y;}else cerrar();}
 if(P.talkG&&dgn<2.6){P.talkG=false;P.path=[];tgt=null;hablar(GEN);}
 if(P.enterB&&Math.hypot(P.enterB.cx-P.x,P.enterB.cy-P.y)<2.6){var eb=P.enterB;P.enterB=null;P.path=[];tgt=null;near=eb;vPref=false;abrir();}
 if(talk&&Math.hypot(talk.x-P.x,talk.y-P.y)>3.2)cerrar();
 var bt=$("bEntrar"),db=near?Math.hypot(near.cx-P.x,near.cy-P.y):9;vPref=!!nearV&&mv<db;
 bt.style.display=(near||nearV)?"block":"none";bt.textContent=vPref?"E · Hablar con "+nearV.name:near?"E · Entrar: "+SERV[near.id][0]:"";}
function abrir(){
 if(vPref&&nearV){hablar(nearV);return;}if(!near)return;talk=null;panelGen=false;$("pLst").style.display="";$("pBtns").style.display="none";var id=near.id,S=SERV[id];
 guardaPos();
 if(Oakhaven.onEnter&&Oakhaven.onEnter(id)===false)return;
 $("pTit").textContent=S[0];$("pTxt").textContent=S[1];$("pLst").innerHTML=S[2].map(function(x){return"<li>"+x+"</li>";}).join("");$("panel").style.display="flex";}
$("bEntrar").onclick=abrir;$("pCerrar").onclick=cerrar;
var chat=$("chat");
addEventListener("keydown",function(e){
 if(e.target===chat){if(e.key==="Enter"){var tx=chat.value.trim();if(tx&&ONL.on)envia({t:"chat",texto:tx});chat.value="";chat.blur();}else if(e.key==="Escape")chat.blur();e.stopPropagation();return;}
 var k=e.key.toLowerCase();
 if(panelGen&&$("panel").style.display==="flex"&&(k==="1"||k==="2")&&$("pBtns").children.length===2){GOPS[+k-1]&&elegirGeneral(GOPS[+k-1]);e.preventDefault();return;}
 if(k==="enter"&&ONL.on){chat.focus();e.preventDefault();return;}
 if(k==="e")abrir();else if(k==="escape")cerrar();else if(k==="m")mini.parentNode.classList.toggle("off");
 else if(k==="+"||k==="=")zoom(1.15);else if(k==="-"||k==="_")zoom(1/1.15);else keys[k]=1;});
addEventListener("keyup",function(e){delete keys[e.key.toLowerCase()];});
addEventListener("blur",function(){keys={};});
function zoom(f){Z=Math.max(.55,Math.min(2.2,Z*f));}
cv.addEventListener("wheel",function(e){e.preventDefault();zoom(e.deltaY<0?1.1:1/1.1);},{passive:false});
$("bZp").onclick=function(){zoom(1.2);};$("bZm").onclick=function(){zoom(1/1.2);};$("bMini").onclick=function(){mini.classList.toggle("off");};
mini.addEventListener("pointerdown",function(e){var r=mini.getBoundingClientRect();ir(Math.floor((e.clientX-r.left)/r.width*W),Math.floor((e.clientY-r.top)/r.height*H));e.stopPropagation();});
cv.addEventListener("pointerdown",function(e){
 var r=cv.getBoundingClientRect(),sx=((e.clientX-r.left)-r.width/2)/Z+cam.x,sy=((e.clientY-r.top)-r.height/2)/Z+cam.y;
 var gq=pj(GEN.x,GEN.y);if(Math.abs(sx-gq.x)<26&&sy<gq.y+6&&sy>gq.y-84){irAGeneral();return;}
 var rh=0;for(var rid in RP){var rr=RP[rid];if(rr.lugar!=="oakhaven")continue;var rq=pj(rr.x,rr.y);if(Math.abs(sx-rq.x)<20&&sy<rq.y+6&&sy>rq.y-60)rh=+rid;}
 if(rh){irAJugador(rh);return;}
 var hb=null;blds.forEach(function(b){var im=IMG[b.i],q=pj(b.cx,b.cy);if(im&&Math.abs(sx-q.x)<im.width/2&&sy<q.y+8+(b.dy||0)&&sy>q.y+8+(b.dy||0)-im.height&&(!hb||b.cx+b.cy>hb.cx+hb.cy))hb=b;});
 if(hb){entrarA(hb);return;}
 ir(Math.floor((sy/16+sx/32)/2),Math.floor((sy/16-sx/32)/2));});
function entrarA(b){
 talk=null;if(Math.hypot(b.cx-P.x,b.cy-P.y)<2.6){near=b;vPref=false;abrir();return;}
 var x0=b.fx,y0=b.fy,best=null;
 for(var yy=y0-1;yy<=y0+b.h;yy++)for(var xx=x0-1;xx<=x0+b.w;xx++){
  if(xx>=x0&&xx<x0+b.w&&yy>=y0&&yy<y0+b.h)continue;if(!inb(xx,yy)||blk[I(xx,yy)])continue;
  var p=bfs(cell(),{x:xx,y:yy});if(p&&(!best||p.length<best.p.length))best={p:p,x:xx,y:yy};}
 if(best){P.want=null;P.path=best.p;tgt={x:best.x,y:best.y};P.enterB=b;}}
function resize(){DPR=Math.min(2,devicePixelRatio||1);cv.width=innerWidth*DPR;cv.height=innerHeight*DPR;cx.imageSmoothingEnabled=true;}
addEventListener("resize",resize);resize();
/* ---------- arranque ---------- */
function limpiaBorde(im){
 var w=im.width,h=im.height,c=document.createElement("canvas");c.width=w;c.height=h;
 var g=c.getContext("2d");g.drawImage(im,0,0);var d=g.getImageData(0,0,w,h),p=d.data,i,n;
 function blanco(i){var r=p[i],gg=p[i+1],b=p[i+2],mx=Math.max(r,gg,b),mn=Math.min(r,gg,b);return (r+gg+b)/3>130&&mx-mn<45;}
 function borde(x,y){var j=[[1,0],[-1,0],[0,1],[0,-1]];for(var k=0;k<4;k++){var X=x+j[k][0],Y=y+j[k][1];if(X<0||Y<0||X>=w||Y>=h||p[(Y*w+X)*4+3]<=40)return true;}return false;}
 for(n=0;n<40;n++){var kill=[];
  for(var y=0;y<h;y++)for(var x=0;x<w;x++){i=(y*w+x)*4;if(p[i+3]>0&&borde(x,y)&&blanco(i))kill.push(i);}
  if(!kill.length)break;kill.forEach(function(i){p[i+3]=0;});}
 for(i=3;i<p.length;i+=4)if(p[i]<90)p[i]=0;
 g.putImageData(d,0,0);return c;}
function limpiaSuelo(im){
 var w=im.width,h=im.height,c=document.createElement("canvas");c.width=w;c.height=h;
 var g=c.getContext("2d");g.drawImage(im,0,0);var d=g.getImageData(0,0,w,h),p=d.data,i,n,x,y;
 for(i=3;i<p.length;i+=4)if(p[i]<90)p[i]=0;
 var bad=[],good=[];
 for(i=0;i<w*h;i++){var o=i*4,r=p[o],gg=p[o+1],b=p[o+2],mx=Math.max(r,gg,b),mn=Math.min(r,gg,b);
  if(p[o+3]>0){if((r+gg+b)/3>120&&mx-mn<50)bad[i]=1;else good[i]=1;}}
 for(n=0;n<6;n++){var nw=[];
  for(y=0;y<h;y++)for(x=0;x<w;x++){i=y*w+x;if(!bad[i])continue;var sr=0,sg=0,sb=0,k=0;
   for(var dy=-1;dy<=1;dy++)for(var dx=-1;dx<=1;dx++){var X=x+dx,Y=y+dy;if(X<0||Y<0||X>=w||Y>=h)continue;var j=Y*w+X;if(good[j]){sr+=p[j*4];sg+=p[j*4+1];sb+=p[j*4+2];k++;}}
   if(k)nw.push([i,sr/k,sg/k,sb/k]);}
  if(!nw.length)break;
  nw.forEach(function(q){var o=q[0]*4;p[o]=q[1];p[o+1]=q[2];p[o+2]=q[3];p[o+3]=255;bad[q[0]]=0;good[q[0]]=1;});}
 for(i=0;i<w*h;i++)if(bad[i])p[i*4+3]=0;
 g.putImageData(d,0,0);return c;}

var cargar=[];for(var i=0;i<CHARS.length;i++)if(CHARS_INFO[i].k==="humano")cargar.push(i);
var pend=Object.keys(ASSETS).length+cargar.length;
Object.keys(ASSETS).forEach(function(k){var im=new Image();im.onload=function(){if(/^(t\d|b\d|r\d|f\d|stump|log|mush|fence)$/.test(k)){try{IMG[k]=limpiaBorde(im);}catch(e){}}else if(/^[gd]\d+$/.test(k)){try{IMG[k]=limpiaSuelo(im);}catch(e){}}if(--pend===0)iniciar();};im.src=ASSETS[k][2];IMG[k]=im;});
cargar.forEach(function(i){var im=new Image();im.onload=function(){if(--pend===0)iniciar();};im.src=CHARS[i];CIMG[i]=im;});
function iniciar(){
 $("panel").style.backgroundImage="url("+ASSETS.panel[2]+")";$("cargando").style.display="none";mundoOff=-performance.now();simReiniciar();anunciar(DIST[curDist]);
 addEventListener("message",function(e){var d=e.data;if(d&&d.naradak==="t"){if(!(relojOk&&ONL.on))tmin=(d.dia-1)*1440+d.min;}else if(d&&d.naradak==="online")onlineIniciar();});
 if(ONLINE_Q)onlineIniciar();
 var last=performance.now(),acc=0,ms=0,pt=0;
 (function loop(now){var dt=Math.min(.05,(now-last)/1000);last=now;T+=dt;if(relojOk&&ONL.on)tmin=relojSrv();else tmin+=dt*MIN_S;
  mover(dt);simTick();
  for(var id in RP){var r=RP[id],f=Math.min(1,dt*9),px=r.x,py=r.y;r.x+=(r.tx-r.x)*f;r.y+=(r.ty-r.y)*f;r.mv=Math.hypot(r.x-px,r.y-py)>.002?1:0;if(r.mv&&Math.hypot(r.tx-r.x,r.ty-r.y)>.05)r.dir=dirOf(r.tx-r.x,r.ty-r.y);}
  acc+=dt;if(ONL.on&&acc>=.1){acc=0;if(Math.abs(P.x-(ONL._x||0))>.03||Math.abs(P.y-(ONL._y||0))>.03){ONL._x=P.x;ONL._y=P.y;envia({t:"mover",x:+P.x.toFixed(2),y:+P.y.toFixed(2),dir:["s","a","d","w"][P.dir]});}}
  if((pt+=dt)>1){pt=0;guardaPos();}
  cerca();
  var ci=I(Math.floor(P.x),Math.floor(P.y));if(dist[ci]&&dist[ci]!==curDist){curDist=dist[ci];anunciar(DIST[curDist]);}
  var m=Math.floor(tmin%1440);$("hHora").textContent=(relojOk&&ONL.on?"🌐 ":"")+"Día "+(1+Math.floor(tmin/1440))+" · "+String(Math.floor(m/60)).padStart(2,"0")+":"+String(m%60).padStart(2,"0")+(noche()>.5?" 🌙":" ☀");
  $("hDist").textContent="📍 "+DIST[curDist];
  draw(T);if(!mini.classList.contains("off")&&(ms+=dt)>.08){ms=0;drawMini();}requestAnimationFrame(loop);})(last);
}
})();
