"use strict";
/* THE CHRONICLES OF NARADAK — MÓDULO DE IA DE COMPORTAMIENTOS del Mundo Abierto.
   Lo usan los dos lados: el servidor (server/mundo_sim.js, vía require) y el cliente (tilemap/mundo_mapa.html, global MundoIA,
   solo cuando el cliente simula en local porque el servidor no tiene la simulación).

   1) NAVEGACIÓN (crearNav): ningún monstruo se traba con muros, árboles o esquinas.
      · línea de visión con margen → va recto; si no, A* sobre la cuadrícula (8 direcciones, sin cortar esquinas), suavizado y con presupuesto por tick
      · detección de atascos (no avanza → replanifica, cambia de lado, se aparta de la pared) y movimiento con deslizamiento por ejes
      · si el objetivo es inalcanzable abandona la persecución (sinCamino) en vez de quedarse pegado a la pared
   2) TÁCTICAS de monstruos normales (chase / trasGolpe / ventana), por arquetipo:
      · bruto (Slime, Champiñón, Ent): embiste de frente
      · merodeador (Lobo, Bandido): se reparte en abanico alrededor del jugador (la manada flanquea), le da vueltas mientras recarga y el lobo se lanza en embestida
      · emboscador (Araña): rodea en arco y salta sobre el objetivo
      · escaramuzador (Goblin, Duende): golpea y se retira (golpe y huida)
      · combos: los alfa y los merodeadores encadenan un segundo golpe rápido (el 2.º con telegrafía más corta) y luego quedan expuestos
   3) JEFES (jefe.planear): encadenan habilidades en COMBO: refuerzo → apertura con control (aturdimiento) → ataque principal → remate con robo de vida;
      más largo y rápido cuanto más enfurecido (fases). Esperan a tener combo disponible y, al terminar, quedan expuestos un momento. */
(function(root,fab){var IA=fab();if(typeof module==="object"&&module.exports)module.exports=IA;else root.MundoIA=IA;})(typeof self!=="undefined"?self:this,function(){

/* ------------------------------ AJUSTES (retócalos aquí) ------------------------------ */
var CFG={
 BUDGET:10,            /* búsquedas A* máximas por tick de simulación (reparte la carga cuando hay muchos monstruos) */
 MAX_NODOS:900,        /* nodos máximos expandidos por búsqueda */
 MARGEN:.3,            /* holgura lateral (celdas) al comprobar línea de visión: evita rozar esquinas */
 CARGA:2.7,            /* multiplicador de velocidad en la embestida */
 CARGA_T:.34,          /* duración de la embestida (s) */
 P_COMBO_ALFA:.65,     /* probabilidad de que un alfa encadene un segundo golpe */
 P_COMBO_MERO:.2,      /* idem para merodeadores y emboscadores */
 J_ESPERA:5,           /* el jefe espera hasta N s a que otra habilidad esté lista para formar un combo */
 J_PACIENCIA:9,        /* ...pero no más de N s sin usar habilidades */
 J_RECUP:1,         /* pausa del jefe al terminar un combo (s, ×fase): ventana para contraatacar */
 J_GAP:.12,            /* espera entre los golpes de un combo (s) */
 J_VENT:.8             /* multiplicador de telegrafía en los eslabones del combo (más rápidos) */
};

var DIAG=Math.SQRT2;
function clamp(v,a,b){return v<a?a:v>b?b:v;}

/* ------------------------------ NAVEGACIÓN ------------------------------ */
function crearNav(W,H,libre){
 var N=W*H,stamp=0,seen=new Uint32Array(N),clo=new Uint32Array(N),G=new Float32Array(N),CAME=new Int32Array(N),tickN=0,budget=CFG.BUDGET;
 var hn=[],hf=[];
 function walk(x,y){return x>=0&&y>=0&&x<W&&y<H&&libre(x+.5,y+.5);}
 function hpush(n,f){var i=hn.length;hn.push(n);hf.push(f);while(i>0){var p=(i-1)>>1;if(hf[p]<=f)break;hn[i]=hn[p];hf[i]=hf[p];i=p;}hn[i]=n;hf[i]=f;}
 function hpop(){var top=hn[0],ln=hn.pop(),lf=hf.pop(),n=hn.length;if(n){var i=0;while(true){var c=i*2+1;if(c>=n)break;if(c+1<n&&hf[c+1]<hf[c])c++;if(hf[c]>=lf)break;hn[i]=hn[c];hf[i]=hf[c];i=c;}hn[i]=ln;hf[i]=lf;}return top;}
 function cercana(cx,cy,r){
  for(var k=1;k<=r;k++)for(var b=-k;b<=k;b++)for(var a=-k;a<=k;a++){if(Math.max(Math.abs(a),Math.abs(b))!==k)continue;if(walk(cx+a,cy+b))return{x:cx+a,y:cy+b};}
  return null;}
 /* ¿se puede ir en línea recta de A a B? (con holgura lateral salvo en los extremos) */
 function visible(ax,ay,bx,by){
  var dx=bx-ax,dy=by-ay,d=Math.hypot(dx,dy);if(d<.01)return true;
  var n=Math.max(1,Math.ceil(d/.3)),st=d/n,ox=-dy/d*CFG.MARGEN,oy=dx/d*CFG.MARGEN;
  for(var k=1;k<=n;k++){var t=k/n,x=ax+dx*t,y=ay+dy*t;
   if(!libre(x,y))return false;
   if(k*st>.6&&d-k*st>.6&&(!libre(x+ox,y+oy)||!libre(x-ox,y-oy)))return false;}
  return true;}
 function penal(x,y){return ((!walk(x+1,y))+(!walk(x-1,y))+(!walk(x,y+1))+(!walk(x,y-1)))*.35;}   /* prefiere alejarse de las paredes */
 /* A* → {p:[{x,y}...] (centros de celda, suavizado desde la posición del monstruo), ok:alcanzó la meta} */
 function buscar(m,gx,gy){
  var sx=Math.floor(m.x),sy=Math.floor(m.y);
  if(!walk(sx,sy)){var s0=cercana(sx,sy,3);if(!s0)return{p:null,ok:false};sx=s0.x;sy=s0.y;}
  if(!walk(gx,gy)){var q0=cercana(gx,gy,4);if(q0){gx=q0.x;gy=q0.y;}}
  stamp++;hn.length=0;hf.length=0;
  var S=sy*W+sx,Gl=gy*W+gx;
  function hh(x,y){var a=Math.abs(x-gx),b=Math.abs(y-gy);return Math.max(a,b)+(DIAG-1)*Math.min(a,b);}
  seen[S]=stamp;G[S]=0;CAME[S]=-1;hpush(S,hh(sx,sy));
  var mejor=S,mh=hh(sx,sy),exp=0,ok=false;
  while(hn.length){
   var i=hpop();if(clo[i]===stamp)continue;clo[i]=stamp;
   if(i===Gl){mejor=i;ok=true;break;}
   if(++exp>CFG.MAX_NODOS)break;
   var ix=i%W,iy=(i/W)|0;
   for(var dy=-1;dy<=1;dy++)for(var dx=-1;dx<=1;dx++){
    if(!dx&&!dy)continue;var nx=ix+dx,ny=iy+dy;if(!walk(nx,ny))continue;
    var diag=dx&&dy;if(diag&&(!walk(ix+dx,iy)||!walk(ix,iy+dy)))continue;   /* sin cortar esquinas */
    var j=ny*W+nx;if(clo[j]===stamp)continue;
    var ng=G[i]+(diag?DIAG:1)+penal(nx,ny);
    if(seen[j]!==stamp||ng<G[j]){seen[j]=stamp;G[j]=ng;CAME[j]=i;var hv=hh(nx,ny);hpush(j,ng+hv);if(hv<mh){mh=hv;mejor=j;}}}
  }
  var cel=[];for(var c=mejor;c!==-1&&c!==S;c=CAME[c])cel.push(c);cel.reverse();
  if(!cel.length)return{p:[],ok:ok};
  var pts=cel.map(function(c){return{x:(c%W)+.5,y:((c/W)|0)+.5};});
  /* suavizado (string-pulling) desde la posición actual */
  var out=[],cx=m.x,cy=m.y,a=0;
  while(a<pts.length){var b=Math.min(pts.length-1,a+14);while(b>a&&!visible(cx,cy,pts[b].x,pts[b].y))b--;out.push(pts[b]);cx=pts[b].x;cy=pts[b].y;a=b+1;}
  return{p:out,ok:ok};}
 /* si un monstruo acaba dentro de un obstáculo (empujón, aparición) lo devuelve a la celda libre más cercana */
 function rescate(m){
  if(libre(m.x,m.y))return;
  var c=cercana(Math.floor(m.x),Math.floor(m.y),3);if(c){m.x=c.x+.5;m.y=c.y+.5;}}
 var FP=[0,.5,-.5,1,-1,1.6,-1.6],FN=[0,-.5,.5,-1,1,-1.6,1.6];
 /* un paso hacia (wx,wy): abanico de ángulos (prefiere el lado de m.bias) y, si no, deslizamiento por ejes */
 function paso1(m,wx,wy,sp,dt,n){
  var dx=wx-m.x,dy=wy-m.y,d=Math.hypot(dx,dy);if(d<.02){m.mv=0;return 0;}
  var a0=Math.atan2(dy,dx),st=Math.min(d,sp*dt),angs=m.bias>0?FP:FN;
  if(n&&n.jit>0){n.jit-=dt;a0+=m.bias>0?.45:-.45;}
  for(var k=0;k<angs.length;k++){var a=a0+angs[k],nx=m.x+Math.cos(a)*st,ny=m.y+Math.sin(a)*st;
   if(libre(nx,ny)){m.x=nx;m.y=ny;m.mv=1;if(k)m.bias=angs[k]>0?1:-1;return 1;}}
  var sx=dx/d*st,sy=dy/d*st;
  if(Math.abs(sx)>1e-4&&libre(m.x+sx,m.y)){m.x+=sx;m.mv=1;return 1;}
  if(Math.abs(sy)>1e-4&&libre(m.x,m.y+sy)){m.y+=sy;m.mv=1;return 1;}
  m.mv=0;return 0;}
 /* ir hacia (tx,ty) esquivando obstáculos. Devuelve 1 si avanzó, 0 si no. */
 function paso(m,tx,ty,sp,dt){
  var n=m._n;if(!n)n=m._n={p:null,rt:0,gx:-99,gy:-99,px:m.x,py:m.y,ac:0,sk:0,lt:0,fail:0,lc:0,vis:true,jit:0};
  if(tickN-n.lt>3){n.px=m.x;n.py=m.y;n.ac=0;n.sk=0;n.p=null;n.rt=0;n.lc=0;}   /* reanuda tras una pausa (ataque, aturdimiento...) */
  n.lt=tickN;
  var dx=tx-m.x,dy=ty-m.y,d=Math.hypot(dx,dy);if(d<.05){m.mv=0;return 1;}
  n.ac+=dt;
  if(n.ac>=.45){var mv=Math.hypot(m.x-n.px,m.y-n.py);
   if(d>.6&&mv<sp*n.ac*.3)n.sk++;else n.sk=0;
   n.px=m.x;n.py=m.y;n.ac=0;
   if(n.sk>=2){n.sk=0;n.p=null;n.rt=0;n.lc=0;n.jit=.7;m.bias=m.bias>0?-1:1;rescate(m);}}   /* atasco: replanifica, cambia de lado y se despega */
  var wx=tx,wy=ty,dir=true;
  if(d>1){n.lc-=dt;if(n.lc<=0){n.vis=visible(m.x,m.y,tx,ty);n.lc=.12+Math.random()*.08;}dir=n.vis;}
  if(!dir){
   n.rt-=dt;var gx=Math.floor(tx),gy=Math.floor(ty);
   if(!n.p||n.rt<=0||Math.abs(gx-n.gx)+Math.abs(gy-n.gy)>3){
    if(budget>0){budget--;var r=buscar(m,gx,gy);n.p=r.p;n.gx=gx;n.gy=gy;n.rt=.45+Math.random()*.35;n.fail=r.ok?0:n.fail+1;}
    else n.rt=.08;}
   if(n.p&&n.p.length){
    while(n.p.length&&Math.hypot(n.p[0].x-m.x,n.p[0].y-m.y)<.3)n.p.shift();
    if(n.p.length){wx=n.p[0].x;wy=n.p[0].y;}}
  }else{n.p=null;n.fail=0;}
  return paso1(m,wx,wy,sp,dt,n);}
 /* movimiento libre en una dirección (merodeo, huida): sin A*, con pequeñas desviaciones */
 function mueve(m,ang,sp,dt){
  var st=sp*dt,of=[0,.5,-.5];
  for(var k=0;k<3;k++){var a=ang+of[k],nx=m.x+Math.cos(a)*st,ny=m.y+Math.sin(a)*st;if(libre(nx,ny)){m.x=nx;m.y=ny;m.mv=1;return true;}}
  m.mv=0;return false;}
 function huir(m,tx,ty,sp,dt){
  var a=Math.atan2(m.y-ty,m.x-tx),st=sp*dt,of=m.bias>0?[0,.7,-.7,1.4,-1.4]:[0,-.7,.7,-1.4,1.4];
  for(var k=0;k<5;k++){var b=a+of[k],nx=m.x+Math.cos(b)*st,ny=m.y+Math.sin(b)*st;if(libre(nx,ny)){m.x=nx;m.y=ny;m.mv=1;return true;}}
  m.mv=0;m.ret=0;return false;}   /* acorralado: deja de huir */
 return{paso:paso,mueve:mueve,huir:huir,visible:visible,buscar:buscar,rescate:rescate,libre:libre,
  tick:function(){tickN++;budget=CFG.BUDGET;}};
}

/* ------------------------------ MONSTRUOS NORMALES ------------------------------ */
var ARQ=[[/Lobo/,"merodeador"],[/Bandido/,"merodeador"],[/Ara[ñn]a/,"emboscador"],[/Goblin|Duende/,"escaramuzador"],[/Slime|Champi|Ent /,"bruto"]];
function arq(nb){nb=nb||"";for(var i=0;i<ARQ.length;i++)if(ARQ[i][0].test(nb))return ARQ[i][1];return "bruto";}
/* campos de comportamiento del monstruo (llamar al crearlo) */
function initMon(m,nb){
 m.ar=arq(nb);m.lobo=/Lobo/.test(nb||"");
 m.sl=(Math.random()<.5?-1:1)*(.35+Math.random()*.65);   /* lado/hueco de flanqueo */
 m.ret=0;m.chg=0;m.lcd=Math.random()*2;m.stt=0;m.dbl=0;}
/* reparte a una manada en abanico alrededor del objetivo (se llama al alertarla) */
function slots(lista){var n=lista.length;if(n<2)return;lista.forEach(function(o,i){o.sl=((i/(n-1))*2-1)*.95||.05;});}
/* Persecución táctica. Devuelve true cuando debe empezar un golpe ahora. spd = velocidad ya modificada (aturdimientos, auras...). */
function chase(nav,m,tg,d,dt,spd){
 var dx=tg.x-m.x,dy=tg.y-m.y,ar=m.ar||"bruto",R=m.reach;
 if(m.lcd>0)m.lcd-=dt;if(m.stt>0)m.stt-=dt;
 if(m.ret>0){m.ret-=dt;nav.huir(m,tg.x,tg.y,spd*.95,dt);return false;}      /* golpe y huida */
 if(m.chg>0){m.chg-=dt;if(d>R)nav.paso(m,tg.x,tg.y,spd*CFG.CARGA,dt);else m.mv=0;return d<=R&&m.cd<=0;}   /* embestida */
 if(d<=R){m.mv=0;return m.cd<=0;}
 if(ar==="bruto"){nav.paso(m,tg.x,tg.y,spd,dt);return false;}
 if((ar==="emboscador"||m.lobo)&&m.lcd<=0&&m.cd<=.1&&d>2.1&&d<4.8&&nav.visible(m.x,m.y,tg.x,tg.y)){m.chg=CFG.CARGA_T;m.lcd=3.2+Math.random()*2.6;return false;}
 var anillo=R+1.4;
 if(d>anillo+.6){   /* aproximación en arco: cada miembro de la manada por un lado distinto */
  var k=Math.min(2.4,d*.3)*(m.sl||.05);
  nav.paso(m,tg.x-dy/d*k,tg.y+dx/d*k,spd,dt);
 }else if(m.cd>.3){   /* merodea alrededor mientras recarga */
  if(m.stt<=0){m.stt=1.1+Math.random()*1.4;if(Math.random()<.35)m.bias=m.bias>0?-1:1;}
  var ux=dx/d,uy=dy/d,rad=clamp((d-(R+.55))*.9,-.5,.5),vx=-uy*m.bias*.62+ux*rad,vy=ux*m.bias*.62+uy*rad;
  if(!nav.mueve(m,Math.atan2(vy,vx),spd*.7,dt))m.bias=m.bias>0?-1:1;
 }else nav.paso(m,tg.x,tg.y,spd,dt);
 return false;}
function ventana(m){return m.dbl>0?.26:.42*(m.alfa?.9:1);}
/* tras resolver un golpe: decide el siguiente (combo / retirada) y devuelve el enfriamiento */
function trasGolpe(m){
 var base=(.62*(.85+Math.random()*.35))/(m.spd>3.6?1.15:1);
 if(m.dbl>0){m.dbl=0;if(m.ar==="escaramuzador")m.ret=.6+Math.random()*.4;return base*1.35;}   /* tras el combo, queda expuesto */
 var p=m.alfa?CFG.P_COMBO_ALFA:(m.ar==="merodeador"||m.ar==="emboscador")?CFG.P_COMBO_MERO:0;
 if(p>0&&Math.random()<p){m.dbl=1;return .14;}
 if(m.ar==="escaramuzador")m.ret=.45+Math.random()*.4;
 return base;}
function sinCamino(m){return !!(m._n&&m._n.fail>=5);}
function olvida(m){if(m._n){m._n.p=null;m._n.fail=0;}m.ret=0;m.chg=0;m.dbl=0;}

/* ------------------------------ JEFES: COMBOS ------------------------------ */
/* Devuelve la cadena de habilidades (ids k) que el jefe debe encadenar ahora, o null si conviene esperar.
   m: {jd:{habs}, hcd:{k:cd restante}, vida, vm, buffT, imp}   x: {fase:{i}, d: distancia al objetivo (celdas), U:32, r0:radio de golpe base} */
function planear(m,x){
 var habs=m.jd.habs,pct=m.vida/m.vm,fi=x.fase.i,lis=habs.filter(function(h){return !(m.hcd[h.k]>0);}),
     ata=lis.filter(function(h){return h.m;}),apo=lis.filter(function(h){return !h.m;}),q=[],hayBuff=false,hayCura=false;
 apo.forEach(function(h){
  var cura=h.heal&&!h.df&&!h.shield&&!h.dm;
  if(cura){if(pct<.55&&!hayCura){q.push(h.k);hayCura=true;}}
  else if(!(m.buffT>0)&&!hayBuff){q.push(h.k);hayBuff=true;}});
 if(ata.length){
  var prox=habs.some(function(h){return h.m&&m.hcd[h.k]>0&&m.hcd[h.k]<=CFG.J_ESPERA;});
  if(ata.length===1&&prox&&(m.imp||0)<CFG.J_PACIENCIA)ata=[];   /* espera a tener un combo de 2 */
 }
 if(ata.length){
  var maxA=[2,3,3][fi],ctl=ata.filter(function(h){return h.stun;}).sort(function(a,b){return b.m-a.m;})[0]||null,
      rest=ata.filter(function(h){return h!==ctl;}).sort(function(a,b){return b.m-a.m;}),ord=[];
  if(ctl)ord.push(ctl);
  rest.forEach(function(h){ord.push(h);});
  if(pct<.9){var ro=ord.filter(function(h){return h.robo;})[0];if(ro&&ord.length>1){ord.splice(ord.indexOf(ro),1);ord.push(ro);}}   /* remate con robo de vida */
  ord.slice(0,maxA).forEach(function(h){q.push(h.k);});
  var h1=ord[0],rg1=(x.r0+(h1.r||0))/x.U;
  if(x.d>rg1+1.6)return null;   /* primero se acerca; el combo arranca ya en rango */
 }
 return q.length?q:null;}

return{CFG:CFG,crearNav:crearNav,arq:arq,initMon:initMon,slots:slots,chase:chase,ventana:ventana,trasGolpe:trasGolpe,sinCamino:sinCamino,olvida:olvida,jefe:{planear:planear}};
});
