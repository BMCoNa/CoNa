"use strict";
/* THE CHRONICLES OF NARADAK — Interior del Área de Entrenamiento (2.5D isométrico, sala grande con cámara).
   Zona de Combate (maniquíes) + Zona de Arquería (dianas), un General en cada zona.
   Mensajes -> juego: {naradak:"ready"} · {naradak:"npc",id:...} · {naradak:"exit"} */
(function(){
var W=30,H=22,WH=150,TW=32,TH=16,SPD=3.8,DIVX=15;
var cv=document.getElementById("ent"),cx=cv.getContext("2d"),$=function(i){return document.getElementById(i);};
var IM={},CI=[],DPR=1,Z=1,T=0,CAMX=0,CAMY=0;
var PC=(function(){try{var v=parseInt(localStorage.getItem("naradak_pc"),10);return v>=0&&v<CHARS.length&&CHARS_INFO[v].k==="humano"?v:4;}catch(e){return 4;}})();
var EMB=parent!==window;
function pj(x,y){return{x:(x-y)*TW,y:(x+y)*TH};}
function dirOf(dx,dy){var sx=dx-dy,sy=dx+dy;return Math.abs(sx)>Math.abs(sy)?(sx<0?1:2):(sy>0?0:3);}
/* ---------- Generales (uno por zona) ---------- */
var NP=[
 {id:"roderic",c:80,alt:77,x:8.0,y:16.6,n:"General Roderic",r:"Maestro de Armas · Zona de Combate",verbo:"Demo de Combate",open:1,ico:"⚔",lines:["Guardia alta y pies firmes: el maniquí no devuelve golpes, pero tú sí aprendes.","Golpea siempre al mismo punto. La constancia vale más que la fuerza.","Cuando domines los maniquíes, el Modo Aventura te espera en el Castillo."]},
 {id:"thalia",c:83,alt:78,x:22.6,y:18.2,n:"General Thalia",r:"Maestra de Arqueros · Zona de Arquería",verbo:"Demo de Combate",open:1,ico:"🏹",lines:["Respira, apunta, suelta. La diana no se mueve; el pulso sí.","Las dianas lejanas premian la paciencia.","Un arquero que no practica pierde la puntería."]}
];
(function(){var used={};NP.forEach(function(p){used[p.c]=1;});
 NP.forEach(function(p){p.dir=0;p.cell=[Math.floor(p.x),Math.floor(p.y)];
  if(p.c===PC){var a=p.alt;for(var i=72;i<80;i++){if(i!==PC&&!used[i]){a=i;break;}}used[a]=1;p.c=a;}});})();
/* ---------- colisiones ---------- */
var blk=[];for(var y=0;y<H;y++){blk[y]=[];for(var x=0;x<W;x++)blk[y][x]=0;}
function bl(x0,y0,x1,y1){for(var y=y0;y<=y1;y++)for(var x=x0;x<=x1;x++)if(blk[y]&&x>=0&&x<W)blk[y][x]=1;}
/* ---------- objetos ---------- */
var OBJ=[];
/* k: sprite · x,y: pie del sprite · s: escala · o: {dy,mir,b:[x0,y0,x1,y1] | nb:1 sin colisión} */
function put(k,x,y,s,o){o=o||{};OBJ.push({k:x+y+(o.kd||0),f:function(){spr(k,x,y,s,o.dy,o.mir);}});
 if(!o.nb){var b=o.b||[Math.floor(x),Math.floor(y),Math.floor(x),Math.floor(y)];bl(b[0],b[1],b[2],b[3]);}}
/* --- Zona de Combate (x 1..14): 15 maniquíes en 3 filas --- */
var MQ=["maniqui1","armadura1","maniqui2","espantapajaros","armadura2"];
[3.5,7.5,11.5].forEach(function(yy,r){[2.5,5.0,7.5,10.0,12.5].forEach(function(xx,c){
 var k=MQ[(r*2+c)%MQ.length];put(k,xx,yy,1.3);});});
/* armeros en la pared NO (x=0) */
put("armero1",.85,2.6,1.35,{nb:0,b:[0,2,0,2]});put("armero2",.85,5.6,1.35,{b:[0,5,0,5]});put("armero1",.85,8.2,1.35,{b:[0,8,0,8]});
put("armero1",.85,11.2,1.35,{b:[0,11,0,11]});put("armero2",.85,14.0,1.35,{b:[0,14,0,14]});
/* bloques de práctica, fardos y banco de trabajo */
put("tiro",3.5,5.5,1.2,{});put("tiro",9.0,5.5,1.2,{});put("tiro",6.2,9.5,1.2,{});put("tiro",11.5,9.5,1.2,{});
put("fardo2",13.6,2.6,1.1);put("fardo2",13.6,4.1,1.1);put("paja",13.4,13.4,1.05);put("fardo2",13.6,6.2,1.1);
put("mesa_trab",5.0,15.6,1.3,{b:[4,15,5,15]});put("yunque",6.7,15.4,1.2);
put("banco",11.0,16.4,1.2,{b:[10,16,11,16]});put("barril",12.8,15.8,1.2);put("caja",13.2,17.6,1.1);put("e_barril1",11.9,19.4,.9,{b:[11,19,11,19]});
put("e_banco",5.6,20.4,1.0,{b:[4,20,5,20]});
/* --- Divisoria con puerta (x=15) --- */
[[1.5,0],[4.5,0],[7.5,0]].forEach(function(p){put("e_valla",DIVX+.5,p[0]+.4,1.05,{mir:1,b:[DIVX,Math.floor(p[0]-1.4),DIVX,Math.floor(p[0]+1.4)]});});
[14.5,17.5,20.5].forEach(function(yy){put("e_valla",DIVX+.5,yy+.4,1.05,{mir:1,b:[DIVX,Math.floor(yy-1.4),DIVX,Math.min(H-1,Math.floor(yy+1.4))]});});
put("pilar_farol",DIVX+.5,9.0,.8,{nb:1});put("pilar_farol",DIVX+.5,13.4,.8,{nb:1});
bl(DIVX,9,DIVX,9);bl(DIVX,13,DIVX,13);
/* --- Zona de Arquería (x 16..29): 6 carriles, dianas lejanas y medias --- */
var LN=[17.5,19.5,21.5,23.5,25.5,27.5];
LN.forEach(function(xx,i){
 put("fardo2",xx,1.1,1.15,{nb:0,b:[Math.floor(xx),0,Math.floor(xx),0]});
 put(i%2?"diana2":"diana1",xx,2.3,1.5,{b:[Math.floor(xx),1,Math.floor(xx),2]});
 put(i%2?"diana1":"diana2",xx,8.4,1.45,{b:[Math.floor(xx),8,Math.floor(xx),8]});
 put("fardo2",xx+.05,9.3,.8,{nb:1});
});
/* línea de tiro: bancos, mesas y reposo de arqueros */
put("e_banco",18.5,16.2,1.0,{b:[17,16,18,16]});put("e_banco",26.0,16.2,1.0,{b:[25,16,26,16]});
put("e_mesa",20.6,19.6,1.0,{b:[19,19,21,19]});
put("e_barril1",16.7,19.4,.9,{b:[16,19,16,19]});put("e_caja",28.6,16.2,.85);
put("e_puesto",27.3,20.4,1.0,{b:[26,20,28,20]});put("e_librero",24.9,20.6,.95,{b:[24,20,24,20]});
put("armero2",16.9,16.1,1.3,{b:[16,16,16,16]});
/* faroles en las esquinas del salón */
put("pilar_farol",1.3,20.7,.8,{nb:1});put("pilar_farol",28.8,20.7,.8,{nb:1});
put("pilar_farol",DIVX+.5,1.4,.8,{nb:1});put("pilar_farol",DIVX+.5,20.6,.8,{nb:1});
/* Generales + jugador (ordenados con el resto) */
NP.forEach(function(p){bl(p.cell[0],p.cell[1],p.cell[0],p.cell[1]);OBJ.push({k:p.x+p.y,f:function(){drawChar(p.c,p.x,p.y,p.dir,0,T,0);}});});
OBJ.push({k:0,pl:1});
for(var gy=10;gy<=12;gy++)blk[gy][DIVX]=0;
function bfs(a,b){
 if(b.x<0||b.y<0||b.x>=W||b.y>=H||blk[b.y][b.x])return null;
 var q=[a],prev={},k=function(p){return p.x+","+p.y;};prev[k(a)]=null;
 while(q.length){var c=q.shift();if(c.x===b.x&&c.y===b.y)break;
  [[1,0],[-1,0],[0,1],[0,-1]].forEach(function(d){var n={x:c.x+d[0],y:c.y+d[1]};if(n.x<0||n.y<0||n.x>=W||n.y>=H||blk[n.y][n.x]||(k(n) in prev))return;prev[k(n)]=c;q.push(n);});}
 if(!(k(b) in prev))return null;var path=[],c=b;while(c){path.unshift(c);c=prev[k(c)];}path.shift();return path;
}
/* ---------- jugador ---------- */
var P={x:1.7,y:18.8,dir:0,mv:0,path:[],want:null},keys={},tgt=null,near=null;
function cell(){return{x:Math.max(0,Math.min(W-1,Math.floor(P.x))),y:Math.max(0,Math.min(H-1,Math.floor(P.y)))};}
function drawChar(c,x,y,dir,mv,t,lift){
 var im=CI[c];if(!im)return;var fw=CHARS_INFO[c].w,fh=CHARS_INFO[c].h,s=pj(x,y),f=mv?[1,0,1,2][Math.floor(t*8)%4]:1;
 cx.save();cx.translate(s.x,s.y+4);
 cx.fillStyle="rgba(0,0,0,.3)";cx.beginPath();cx.ellipse(0,-(lift||0),fw>40?13:10,4,0,0,7);cx.fill();
 cx.imageSmoothingEnabled=false;cx.drawImage(im,f*fw,dir*fh,fw,fh,-fw/2,-(fh-3)-(lift||0),fw,fh);cx.restore();
}
function mover(dt){
 var dx=0,dy=0;
 if(keys.w||keys.arrowup){dx--;dy--;}if(keys.s||keys.arrowdown){dx++;dy++;}if(keys.a||keys.arrowleft){dx--;dy++;}if(keys.d||keys.arrowright){dx++;dy--;}
 var manual=!!(dx||dy);
 if(manual){P.path=[];tgt=null;P.want=null;var l=Math.hypot(dx,dy);dx/=l;dy/=l;}
 else if(P.path.length){var n=P.path[0],tx=n.x+.5-P.x,ty=n.y+.5-P.y,d=Math.hypot(tx,ty);if(d<.08){P.path.shift();if(!P.path.length)tgt=null;}else{dx=tx/d;dy=ty/d;}}
 P.mv=!!(dx||dy);if(!P.mv)return;P.dir=dirOf(dx,dy);
 var st=SPD*dt,nx=P.x+dx*st,ny=P.y+dy*st;
 if(manual){
  var cxn=Math.floor(nx),cyo=Math.floor(P.y),cxo=Math.floor(P.x),cyn=Math.floor(ny);
  if(cxn>=0&&cxn<W&&cyo>=0&&cyo<H&&blk[cyo][cxn])nx=P.x;
  if(cxo>=0&&cxo<W&&cyn>=0&&cyn<H&&blk[cyn][Math.floor(nx)])ny=P.y;
 }
 P.x=Math.max(.3,Math.min(W-.3,nx));P.y=Math.max(.3,Math.min(H-.3,ny));
}
/* ---------- cámara ---------- */
function camara(dt,snap){
 var s=pj(P.x,P.y),tx=s.x,ty=s.y-34,vw=cv.width/DPR/Z,vh=cv.height/DPR/Z;
 var x0=-(H*TW),x1=W*TW,y0=-WH,y1=(W+H)*TH+14;
 tx=(x1-x0<=vw)?(x0+x1)/2:Math.max(x0+vw/2,Math.min(x1-vw/2,tx));
 ty=(y1-y0<=vh)?(y0+y1)/2:Math.max(y0+vh/2,Math.min(y1-vh/2,ty));
 var k=snap?1:Math.min(1,dt*6);CAMX+=(tx-CAMX)*k;CAMY+=(ty-CAMY)*k;
}
/* ---------- interacción ---------- */
var DIST=3.0;
function abrir(p){
 if(!p)return;keys={};P.path=[];tgt=null;P.want=null;
 if(p.open){if(EMB)parent.postMessage({naradak:"npc",id:p.id},"*");else toast("Abriría: "+p.verbo);return;}
 p.li=p.li||0;var l=p.lines[p.li%p.lines.length];p.li++;toast(p.n+": «"+l+"»",3800);
}
function salir(){keys={};if(EMB)parent.postMessage({naradak:"exit"},"*");else toast("Salida a la ciudad");}
var _tt=0;function toast(t,ms){var e=$("toast");e.textContent=t;e.style.display="block";clearTimeout(_tt);_tt=setTimeout(function(){e.style.display="none";},ms||1800);}
function cerca(){
 near=null;var m=DIST;NP.forEach(function(p){var d=Math.hypot(p.x-P.x,p.y-P.y);if(d<m){m=d;near=p;}});
 NP.forEach(function(p){if(Math.hypot(p.x-P.x,p.y-P.y)<DIST)p.dir=dirOf(P.x-p.x,P.y-p.y);});
 if(P.want&&Math.hypot(P.want.x-P.x,P.want.y-P.y)<DIST-.05){var w=P.want;P.want=null;abrir(w);return;}
 var b=$("bHab");b.style.display=near?"block":"none";if(near)b.textContent="E · "+near.n+" — "+near.verbo;
 if(P.x<.85&&P.y>17.9&&P.y<19.7){salir();P.x=1.7;P.y=18.8;P.path=[];}
}
function irA(p){
 if(Math.hypot(p.x-P.x,p.y-P.y)<DIST-.05){abrir(p);return;}
 var best=null,c0=cell();
 for(var yy=0;yy<H;yy++)for(var xx=0;xx<W;xx++){
  if(blk[yy][xx])continue;var d=Math.hypot(xx+.5-p.x,yy+.5-p.y);if(d>DIST-.05)continue;
  var pa=bfs(c0,{x:xx,y:yy});if(pa&&(!best||pa.length<best.pa.length))best={pa:pa,x:xx,y:yy};}
 if(best){P.path=best.pa;tgt={x:best.x,y:best.y};P.want=p;}
}
$("bHab").onclick=function(){abrir(near);};
addEventListener("keydown",function(e){var k=e.key.toLowerCase();if(k==="e"||k==="enter"){abrir(near);}else if(k==="escape"){salir();}else{keys[k]=1;if(k.indexOf("arrow")===0)e.preventDefault();}});
addEventListener("keyup",function(e){delete keys[e.key.toLowerCase()];});
addEventListener("blur",function(){keys={};});
cv.addEventListener("pointerdown",function(e){
 var r=cv.getBoundingClientRect(),wx=((e.clientX-r.left)-r.width/2)/Z+CAMX,wy=((e.clientY-r.top)-r.height/2)/Z+CAMY;
 var hit=null,bd=34;NP.forEach(function(p){var q=pj(p.x,p.y),hh=CHARS_INFO[p.c].h/2,d=Math.hypot(wx-q.x,wy-(q.y-hh));if(d<bd){bd=d;hit=p;}});
 if(hit){irA(hit);return;}
 var u=Math.floor((wy/TH+wx/TW)/2),v=Math.floor((wy/TH-wx/TW)/2);
 var pa=bfs(cell(),{x:u,y:v});if(pa){P.want=null;P.path=pa;tgt={x:u,y:v};}
});
/* ---------- capa estática ---------- */
var SX0=-(H*TW)-30,SY0=-WH-40,SW=(W+H)*TW+60,SH=(W+H)*TH+WH+80,STAT=null;
function seed(s){return function(){s|=0;s=s+0x6D2B79F5|0;var t=Math.imul(s^s>>>15,1|s);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296;};}
function banner(g,u0,w,y0,h,col){
 col=col||["#26468c","#17306a"];
 g.fillStyle="#2a170a";g.fillRect(u0-.1,y0-5,w+.2,4);
 g.fillStyle="#c9923c";g.fillRect(u0-.05,y0-3,w+.1,1.2);
 g.beginPath();g.moveTo(u0,y0);g.lineTo(u0+w,y0);g.lineTo(u0+w,y0+h);g.lineTo(u0+w/2,y0+h-12);g.lineTo(u0,y0+h);g.closePath();
 var gd=g.createLinearGradient(0,y0,0,y0+h);gd.addColorStop(0,col[0]);gd.addColorStop(1,col[1]);g.fillStyle=gd;g.fill();
 g.fillStyle="#c9923c";g.fillRect(u0,y0,.035,h-5);g.fillRect(u0+w-.035,y0,.035,h-5);
 g.fillStyle="#e8c46a";g.beginPath();g.ellipse(u0+w/2,y0+h*.36,.2,8,0,0,7);g.fill();
 g.fillStyle=col[1];g.beginPath();g.ellipse(u0+w/2,y0+h*.36,.13,5,0,0,7);g.fill();
 g.fillStyle="#e8c46a";g.fillRect(u0+w/2-.03,y0+h*.36-6,.06,12);g.fillRect(u0+w/2-.12,y0+h*.36-2,.24,1.6);
}
/* ventana de madera con rejilla (como las casas de tu hoja) */
function ventana(g,u0,w,yt,h){
 var yb=yt+h;
 g.fillStyle="#3b2412";g.fillRect(u0-.1,yt-5,w+.2,h+11);
 g.fillStyle="rgba(255,225,170,.25)";g.fillRect(u0-.1,yt-5,w+.2,1);
 var gd=g.createLinearGradient(0,yt,0,yb);gd.addColorStop(0,"#5d7fae");gd.addColorStop(1,"#2c3d5e");g.fillStyle=gd;g.fillRect(u0,yt,w,h);
 g.fillStyle="rgba(190,215,255,.30)";g.fillRect(u0,yt,w,h*.38);
 g.fillStyle="#2a170a";g.fillRect(u0+w/2-.025,yt,.05,h);
 for(var i=1;i<4;i++)g.fillRect(u0,yt+h*i/4-1,w,2.2);
 g.fillStyle="#4a2e16";g.fillRect(u0-.14,yb+3,w+.28,5);g.fillStyle="rgba(255,225,170,.25)";g.fillRect(u0-.14,yb+3,w+.28,1);
}
function construir(){
 var K=2,c=document.createElement("canvas");c.width=SW*K;c.height=SH*K;var g=c.getContext("2d");
 g.scale(K,K);g.translate(-SX0,-SY0);g.imageSmoothingEnabled=true;
 var R=seed(2718);
 /* suelo de tierra apisonada */
 g.save();g.transform(TW,TH,-TW,TH,0,0);
 var palC=["#a78a5c","#9f8257","#b09263","#98794f","#a98c60","#a2845a"],palA=["#a58b5e","#9c8458","#ae9665","#97804f","#a78f62","#9f8858"];
 for(var y=0;y<H;y++)for(var x=0;x<W;x++){
  var arq=x>=DIVX;var pal=arq?palA:palC;
  g.fillStyle=pal[Math.floor(R()*pal.length)];g.fillRect(x,y,1,1);
  if((x+y)%2===0){g.fillStyle="rgba(0,0,0,.035)";g.fillRect(x,y,1,1);}
  for(var n=0;n<5;n++){g.fillStyle=R()<.5?"rgba(60,40,15,"+(.08+R()*.1)+")":"rgba(255,235,190,"+(.05+R()*.08)+")";g.fillRect(x+R(),y+R(),.05+R()*.13,.04+R()*.05);}
  if(R()<.07){g.fillStyle="rgba(70,90,40,.35)";g.fillRect(x+R()*.8,y+R()*.8,.1,.1);}
 }
 /* pasarela de tablones (puerta -> divisoria -> arquería) */
 function tablones(x0,y0,w,h,vert){
  g.fillStyle="#7a5530";g.fillRect(x0,y0,w,h);
  g.strokeStyle="rgba(30,16,6,.55)";g.lineWidth=.04;
  if(vert){for(var i=1;i<w*3;i++){g.beginPath();g.moveTo(x0+i/3,y0);g.lineTo(x0+i/3,y0+h);g.stroke();}}
  else{for(var j=1;j<h*3;j++){g.beginPath();g.moveTo(x0,y0+j/3);g.lineTo(x0+w,y0+j/3);g.stroke();}}
  g.fillStyle="rgba(255,225,170,.12)";g.fillRect(x0,y0,w,.12);
  g.strokeStyle="rgba(30,16,6,.7)";g.lineWidth=.07;g.strokeRect(x0,y0,w,h);
 }
 tablones(0,17.6,3.4,3.4,0);
 tablones(13.2,10,3.6,2.6,0);
 /* círculos de combate (marcas en la tierra) */
 g.strokeStyle="rgba(60,38,14,.5)";g.lineWidth=.07;
 [3.5,7.5,11.5].forEach(function(yy){[2.5,5.0,7.5,10.0,12.5].forEach(function(xx){g.beginPath();g.ellipse(xx,yy,.85,.85,0,0,7);g.stroke();g.fillStyle="rgba(60,38,14,.10)";g.fill();});});
 /* arena de duelo (alfombra de tierra clara delante del General de armas) */
 g.fillStyle="rgba(235,215,170,.28)";g.beginPath();g.ellipse(8,16.6,2.7,1.9,0,0,7);g.fill();
 g.strokeStyle="rgba(120,85,40,.6)";g.lineWidth=.06;g.beginPath();g.ellipse(8,16.6,2.7,1.9,0,0,7);g.stroke();
 /* carriles de arquería */
 LN.forEach(function(xx){
  g.fillStyle="rgba(240,225,185,.16)";g.fillRect(xx-.8,2.8,1.6,12.2);
  g.strokeStyle="rgba(250,240,205,.45)";g.lineWidth=.045;g.setLineDash([.28,.22]);
  g.beginPath();g.moveTo(xx-.8,2.8);g.lineTo(xx-.8,15);g.moveTo(xx+.8,2.8);g.lineTo(xx+.8,15);g.stroke();g.setLineDash([]);
 });
 g.fillStyle="rgba(245,235,205,.7)";g.fillRect(DIVX+1,15.0,W-DIVX-1,.2); /* línea de tiro */
 g.fillStyle="rgba(120,60,20,.55)";g.fillRect(DIVX+1,8.9,W-DIVX-1,.1); /* marca de media distancia */
 g.fillStyle="rgba(120,60,20,.45)";g.fillRect(DIVX+1,3.7,W-DIVX-1,.1);
 g.fillStyle="rgba(120,85,40,.5)";g.beginPath();g.ellipse(22.6,18.2,1.7,1.2,0,0,7);g.fill();
 /* sombra en las paredes */
 var gr=g.createLinearGradient(0,0,0,1.6);gr.addColorStop(0,"rgba(0,0,0,.45)");gr.addColorStop(1,"rgba(0,0,0,0)");g.fillStyle=gr;g.fillRect(0,0,W,1.6);
 var gl=g.createLinearGradient(0,0,1.6,0);gl.addColorStop(0,"rgba(0,0,0,.45)");gl.addColorStop(1,"rgba(0,0,0,0)");g.fillStyle=gl;g.fillRect(0,0,1.6,H);
 /* sombra bajo la divisoria */
 g.fillStyle="rgba(0,0,0,.14)";g.fillRect(DIVX+.15,0,.7,9);g.fillRect(DIVX+.15,13,.7,H-13);
 g.restore();
 /* paredes de entramado: yeso + vigas de madera + zócalo de piedra */
 function pared(len,shade){
  var gp=g.createLinearGradient(0,-WH,0,0);
  gp.addColorStop(0,"rgb("+Math.round(212*shade)+","+Math.round(194*shade)+","+Math.round(156*shade)+")");
  gp.addColorStop(1,"rgb("+Math.round(232*shade)+","+Math.round(216*shade)+","+Math.round(180*shade)+")");
  g.fillStyle=gp;g.fillRect(0,-WH,len,WH);
  for(var i=0;i<140;i++){g.fillStyle="rgba("+(R()<.5?"90,70,40":"255,245,215")+","+(.03+R()*.05)+")";g.fillRect(R()*len,-WH+R()*WH,.1+R()*.35,2+R()*5);}
  /* zócalo de piedra */
  var rows=3,u;
  for(var rw=0;rw<rows;rw++){var yy=-34+rw*10;u=-(rw%2)*.5;
   while(u<len){var bw=.7+R()*.5;g.fillStyle="rgba("+(R()<.5?"0,0,0":"255,240,210")+","+(.05+R()*.07)+")";g.fillRect(Math.max(0,u)+.02,yy+1,Math.min(bw,len-Math.max(0,u))-.04,8);g.fillStyle="rgba(20,16,12,.5)";g.fillRect(Math.max(0,u),yy,.035,10);u+=bw;}}
  var gs=g.createLinearGradient(0,-34,0,0);gs.addColorStop(0,"#8d877b");gs.addColorStop(1,"#6f6a5f");
  g.globalCompositeOperation="multiply";g.fillStyle=gs;g.fillRect(0,-34,len,34);g.globalCompositeOperation="source-over";
  g.fillStyle="rgba(20,16,12,.5)";for(var r2=0;r2<=3;r2++)g.fillRect(0,-34+r2*10,len,1);
  g.fillStyle="#3b2412";g.fillRect(0,-38,len,5);g.fillStyle="rgba(255,210,140,.28)";g.fillRect(0,-38,len,1);
  /* vigas */
  g.fillStyle="#3b2412";g.fillRect(0,-WH,len,12);g.fillStyle="rgba(255,210,140,.2)";g.fillRect(0,-WH,len,1.5);
  g.fillStyle="#2e1a0a";g.fillRect(0,-WH+12,len,3);
  g.fillStyle="#3b2412";g.fillRect(0,-80,len,6);g.fillStyle="rgba(255,210,140,.18)";g.fillRect(0,-80,len,1);
  for(var b=0;b<=len;b+=3){g.fillStyle="#3b2412";g.fillRect(b-.12,-WH,.24,WH-34);g.fillStyle="rgba(255,210,140,.16)";g.fillRect(b-.12,-WH,.04,WH-34);
   if(b<len){ /* tornapuntas */
    g.strokeStyle="#3b2412";g.lineWidth=5;g.beginPath();g.moveTo(b+.12,-80);g.lineTo(b+.9,-110);g.moveTo(b+2.88,-80);g.lineTo(b+2.1,-110);g.stroke();}}
  g.fillStyle="#2e1a0a";g.fillRect(len-.24,-WH,.24,WH-34);
  g.fillStyle="rgba(15,12,10,"+(.16+(1-shade)*.5)+")";g.fillRect(0,-30,len,30);
 }
 /* NE (y=0) */
 g.save();g.transform(TW,TH,0,1,0,0);pared(W,1);
 banner(g,.45,.85,-126,62);
 ventana(g,1.5,.9,-118,44);
 ventana(g,4.5,.9,-118,44);
 banner(g,7.4,.85,-126,62);
 ventana(g,10.5,.9,-118,44);
 ventana(g,13.5,.9,-118,44);
 banner(g,14.55,.9,-126,62);
 ventana(g,16.5,.9,-118,44);
 banner(g,19.0,.85,-126,62);
 ventana(g,22.5,.9,-118,44);
 banner(g,25.5,.85,-126,62);
 ventana(g,27.5,.9,-118,44);
 g.restore();
 /* NW (x=0) */
 g.save();g.transform(TW,-TH,0,1,0,0);g.save();g.translate(-H,0);pared(H,.82);g.restore();
 ventana(g,-2.4,.9,-118,44);
 banner(g,-5.0,.85,-126,62);
 ventana(g,-8.5,.9,-118,44);
 banner(g,-11.0,.85,-126,62);
 ventana(g,-14.0,.9,-118,44);
 banner(g,-16.0,.85,-126,62);
 /* puerta de madera con arco de piedra (salida) */
 (function(){var u0=-19.6,w=1.6,h=104,r=w/2,ry=r*TW;
  function arco(a,c,hh,d){g.beginPath();g.moveTo(a,0);g.lineTo(a,-hh+ry);g.ellipse(a+(c-a)/2,-hh+ry,(c-a)/2,ry+d,0,Math.PI,0);g.lineTo(c,0);g.closePath();}
  arco(u0-.14,u0+w+.14,h+6,4);g.fillStyle="#9d978b";g.fill();
  arco(u0,u0+w,h,0);var gd=g.createLinearGradient(0,-h,0,0);gd.addColorStop(0,"#6b4422");gd.addColorStop(1,"#402912");g.fillStyle=gd;g.fill();
  g.save();arco(u0,u0+w,h,0);g.clip();
  g.fillStyle="rgba(0,0,0,.3)";for(var i=1;i<6;i++)g.fillRect(u0+i*w/6,-h,.03,h);
  g.fillStyle="#2a2a2e";g.fillRect(u0,-h*.62,w,4);g.fillRect(u0,-h*.28,w,4);g.fillRect(u0+w/2-.02,-h,.04,h);
  g.restore();
  g.fillStyle="#c9923c";g.beginPath();g.ellipse(u0+w*.78,-h*.4,.07,2.6,0,0,7);g.fill();
 })();
 g.restore();
 g.fillStyle="#2a170a";g.fillRect(-2,-WH,4,WH);
 /* carteles de zona (placas colgadas, rectas) */
 function placa(wx,wy,txt,col){
  var p=pj(wx,wy),w=156,h=30,x=p.x-w/2,y=p.y-WH+46;
  g.fillStyle="#2a170a";g.fillRect(x-3,y-3,w+6,h+6);
  var gd=g.createLinearGradient(0,y,0,y+h);gd.addColorStop(0,"#8a6032");gd.addColorStop(1,"#6a4620");g.fillStyle=gd;g.fillRect(x,y,w,h);
  g.strokeStyle="#c9923c";g.lineWidth=1.5;g.strokeRect(x+2.5,y+2.5,w-5,h-5);
  g.fillStyle="#2a170a";g.fillRect(x+10,y-16,3,14);g.fillRect(x+w-13,y-16,3,14);
  g.font="700 14px Cinzel,serif";g.textAlign="center";g.textBaseline="middle";g.fillStyle=col;g.fillText(txt,p.x,y+h/2+1);
 }
 placa(7.5,0,"ZONA DE COMBATE","#f3dcae");
 placa(22.5,0,"ZONA DE ARQUERÍA","#f3dcae");
 STAT=c;
}
/* ---------- sprites ---------- */
function spr(k,x,y,s,dy,mir){
 var im=IM[k],p=pj(x,y);if(!im)return;cx.save();cx.translate(p.x,p.y+8+(dy||0));if(mir)cx.scale(-1,1);
 cx.imageSmoothingEnabled=k.charAt(0)==="e"||k==="pilar_farol";
 cx.drawImage(im,-im.width*s/2,-im.height*s,im.width*s,im.height*s);cx.restore();
}
/* ---------- dibujo ---------- */
function etiqueta(txt,x,y,hl){cx.save();cx.font="700 "+(hl?11:10)+"px Cinzel,serif";cx.textAlign="center";cx.lineWidth=3;cx.strokeStyle="rgba(20,12,4,.9)";cx.strokeText(txt,x,y);cx.fillStyle=hl?"#ffe9a8":"#f5e6c0";cx.fillText(txt,x,y);cx.restore();}
function marcadores(t){
 NP.forEach(function(p){
  var s=pj(p.x,p.y),bob=Math.sin(t*3+p.x)*2,hl=near===p,top=CHARS_INFO[p.c].h;
  cx.save();cx.translate(s.x,s.y);
  cx.font="16px serif";cx.textAlign="center";cx.fillText(p.ico,0,-top-8+bob);
  if(hl){etiqueta(p.n,0,-top-24);cx.font="10px Karla,sans-serif";cx.fillStyle="#d4c9b8";cx.lineWidth=3;cx.strokeStyle="rgba(20,12,4,.9)";cx.strokeText(p.r,0,-top-34);cx.fillText(p.r,0,-top-34);}
  cx.restore();
 });
 var d=pj(0,18.8);cx.save();cx.translate(d.x,d.y-122);etiqueta("Salida",0,0,P.x<2.2&&P.y>17.6);cx.restore();
}
function luces(t){
 cx.save();cx.setTransform(1,0,0,1,0,0);cx.fillStyle="rgba(10,14,30,.08)";cx.fillRect(0,0,cv.width,cv.height);cx.restore();
 cx.globalCompositeOperation="lighter";
 var fl=.85+.15*Math.sin(t*9)+.06*Math.sin(t*23);
 function glow(x,y,z,r,a,rgb){var s=pj(x,y),g=cx.createRadialGradient(s.x,s.y-z,2,s.x,s.y-z,r);g.addColorStop(0,"rgba("+rgb+","+(a*fl)+")");g.addColorStop(1,"rgba("+rgb+",0)");cx.fillStyle=g;cx.fillRect(s.x-r,s.y-z-r,r*2,r*2);}
 [[DIVX+.5,9.0],[DIVX+.5,13.4],[1.3,20.7],[28.8,20.7],[DIVX+.5,1.4],[DIVX+.5,20.6]].forEach(function(l){glow(l[0],l[1],78,110,.28,"255,175,70");});
 glow(7.5,9,40,260,.10,"255,225,170");glow(22.5,9,40,260,.10,"255,225,170");
 [[1.9,.5],[5.0,.5],[11.0,.5],[14.0,.5],[17.0,.5],[23.0,.5],[28.0,.5],[.5,2.9],[.5,9.0],[.5,14.5]].forEach(function(w){glow(w[0],w[1],95,80,.10,"150,180,235");});
 cx.globalCompositeOperation="source-over";
}
function draw(t){
 var w=cv.width,h=cv.height;cx.setTransform(1,0,0,1,0,0);cx.fillStyle="#12100c";cx.fillRect(0,0,w,h);
 cx.setTransform(Z*DPR,0,0,Z*DPR,w/2-CAMX*Z*DPR,h/2-CAMY*Z*DPR);
 cx.imageSmoothingEnabled=true;cx.drawImage(STAT,SX0,SY0,SW,SH);
 if(tgt){var s=pj(tgt.x+.5,tgt.y+.5);cx.strokeStyle="rgba(255,235,170,"+(.5+.4*Math.sin(t*6))+")";cx.lineWidth=2;cx.beginPath();cx.moveTo(s.x,s.y-8);cx.lineTo(s.x+16,s.y);cx.lineTo(s.x,s.y+8);cx.lineTo(s.x-16,s.y);cx.closePath();cx.stroke();}
 var L=OBJ.slice();L.forEach(function(o){if(o.pl)o.k=P.x+P.y;});L.sort(function(a,b){return a.k-b.k;});
 L.forEach(function(o){if(o.pl)drawChar(PC,P.x,P.y,P.dir,P.mv,T);else o.f();});
 luces(t);marcadores(t);
}
/* ---------- arranque ---------- */
function resize(){
 DPR=Math.min(2,devicePixelRatio||1);cv.width=innerWidth*DPR;cv.height=innerHeight*DPR;
 Z=Math.max(.75,Math.min(1.5,innerWidth/760));
}
addEventListener("resize",resize);resize();
var keysA=Object.keys(ENTASSETS),pend=keysA.length+CHARS.length;
function ok(){if(--pend===0)iniciar();}
keysA.forEach(function(k){var im=new Image();im.onload=ok;im.src=ENTASSETS[k];IM[k]=im;});
CHARS.forEach(function(d,i){var im=new Image();im.onload=ok;im.src=d;CI[i]=im;});
function iniciar(){
 construir();camara(0,true);
 if(EMB)parent.postMessage({naradak:"ready"},"*");
 var last=performance.now();
 (function loop(now){var dt=Math.min(.05,(now-last)/1000);last=now;T+=dt;
  mover(dt);cerca();camara(dt,false);draw(T);requestAnimationFrame(loop);})(last);
}
})();
