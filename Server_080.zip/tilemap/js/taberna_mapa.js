"use strict";
/* THE CHRONICLES OF NARADAK — Interior de la Taberna (2.5D isométrico).
   Mensajes -> juego: {naradak:"ready"} · {naradak:"npc",id:"barra|exp|rumores|tablon"} · {naradak:"exit"}
   Mensajes <- juego: {naradak:"tb",exp:bool,rum:n,tab:n} */
(function(){
var W=11,H=9,WH=120,TW=32,TH=16,SPD=3.2;
var cv=document.getElementById("tab"),cx=cv.getContext("2d"),$=function(i){return document.getElementById(i);};
var IM={},CI=[],DPR=1,Z=1,T=0;
var PC=(function(){try{var v=parseInt(localStorage.getItem("naradak_pc"),10);return v>=0&&v<CHARS.length&&CHARS_INFO[v].k==="humano"?v:4;}catch(e){return 4;}})();
var EMB=parent!==window;
function pj(x,y){return{x:(x-y)*TW,y:(x+y)*TH};}
function dirOf(dx,dy){var sx=dx-dy,sy=dx+dy;return Math.abs(sx)>Math.abs(sy)?(sx<0?1:2):(sy>0?0:3);}
/* ---------- NPC fijos ---------- */
var NP=[
 {id:"barra",c:8,alt:10,x:7.4,y:.6,n:"Gorm",r:"Tabernero",verbo:"Barra y Escuadrón",ico:"🍺"},
 {id:"exp",c:12,alt:4,x:1.3,y:2.9,n:"Ayla",r:"Guía de expediciones",verbo:"Expediciones",ico:"🧭"},
 {id:"tablon",c:21,alt:22,x:1.3,y:5.6,n:"Pim",r:"Escribano",verbo:"Tablón de encargos",ico:"📋"},
 {id:"rumores",c:19,alt:16,x:8.4,y:8.3,n:"Encapuchado",r:"Mesa del Rincón",verbo:"Rumores",ico:"🕯"}
];
NP.forEach(function(p){p.dir=0;p.cell=[Math.floor(p.x),Math.floor(p.y)];if(p.c===PC)p.c=p.alt;});
var VL=[];
(function(){var used={};NP.forEach(function(p){used[p.c]=1;used[p.alt]=1;});used[PC]=1;var pool=[];
 CHARS_INFO.forEach(function(ci,i){if(ci.k==="humano"&&!used[i])pool.push(i);});
 [[2.5,6.5],[8.5,4.5],[5.5,7.5]].forEach(function(s,n){VL.push({c:pool[(n*7+2)%pool.length],x:s[0],y:s[1],dir:0,mv:0,path:[],wait:.5+n*1.3});});
})();
var BADGE={exp:false,rum:0,tab:0};
/* ---------- colisiones ---------- */
var blk=[];for(var y=0;y<H;y++){blk[y]=[];for(var x=0;x<W;x++)blk[y][x]=0;}
function bl(x0,y0,x1,y1){for(var y=y0;y<=y1;y++)for(var x=x0;x<=x1;x++)if(blk[y]&&x>=0&&x<W)blk[y][x]=1;}
bl(1,0,2,1);bl(3,0,4,0);bl(5,0,9,1);bl(6,2,8,2);bl(0,0,0,1);bl(0,4,0,4);
bl(3,4,4,5);bl(6,5,7,6);
NP.forEach(function(p){blk[p.cell[1]][p.cell[0]]=1;});
function bfs(a,b){
 if(b.x<0||b.y<0||b.x>=W||b.y>=H||blk[b.y][b.x])return null;
 var q=[a],prev={},k=function(p){return p.x+","+p.y;};prev[k(a)]=null;
 while(q.length){var c=q.shift();if(c.x===b.x&&c.y===b.y)break;
  [[1,0],[-1,0],[0,1],[0,-1]].forEach(function(d){var n={x:c.x+d[0],y:c.y+d[1]};if(n.x<0||n.y<0||n.x>=W||n.y>=H||blk[n.y][n.x]||(k(n) in prev))return;prev[k(n)]=c;q.push(n);});}
 if(!(k(b) in prev))return null;var path=[],c=b;while(c){path.unshift(c);c=prev[k(c)];}path.shift();return path;
}
/* ---------- jugador ---------- */
var P={x:1.7,y:7.8,dir:0,mv:0,path:[],want:null},keys={},tgt=null,near=null;
function cell(){return{x:Math.max(0,Math.min(W-1,Math.floor(P.x))),y:Math.max(0,Math.min(H-1,Math.floor(P.y)))};}
function drawChar(c,x,y,dir,mv,t){
 var im=CI[c];if(!im)return;var fw=CHARS_INFO[c].w,fh=CHARS_INFO[c].h,s=pj(x,y),f=mv?[1,0,1,2][Math.floor(t*8)%4]:1;
 cx.save();cx.translate(s.x,s.y+4);
 cx.fillStyle="rgba(0,0,0,.3)";cx.beginPath();cx.ellipse(0,0,10,4,0,0,7);cx.fill();
 cx.imageSmoothingEnabled=false;cx.drawImage(im,f*fw,dir*fh,fw,fh,-fw/2,-(fh-3),fw,fh);cx.restore();
}
function moverV(v,dt){
 if(!v.path.length){v.mv=0;if((v.wait-=dt)>0)return;v.wait=1+Math.random()*3.5;
  var tx=2+Math.floor(Math.random()*(W-3)),ty=1+Math.floor(Math.random()*(H-1));
  var pa=bfs({x:Math.floor(v.x),y:Math.floor(v.y)},{x:tx,y:ty});if(pa&&pa.length<16)v.path=pa;return;}
 var n=v.path[0],ex=n.x+.5-v.x,ey=n.y+.5-v.y,d=Math.hypot(ex,ey);
 if(d<.06){v.path.shift();return;}
 var st=Math.min(d,1.1*dt);v.x+=ex/d*st;v.y+=ey/d*st;v.mv=1;v.dir=dirOf(ex,ey);
}
function mover(dt){
 var dx=0,dy=0;
 if(keys.w||keys.arrowup){dx--;dy--;}if(keys.s||keys.arrowdown){dx++;dy++;}if(keys.a||keys.arrowleft){dx--;dy++;}if(keys.d||keys.arrowright){dx++;dy--;}
 var manual=!!(dx||dy);
 if(manual){P.path=[];tgt=null;P.want=null;var l=Math.hypot(dx,dy);dx/=l;dy/=l;}
 else if(P.path.length){var n=P.path[0],tx=n.x+.5-P.x,ty=n.y+.5-P.y,d=Math.hypot(tx,ty);if(d<.08){P.path.shift();if(!P.path.length)tgt=null;}else{dx=tx/d;dy=ty/d;}}
 P.mv=!!(dx||dy);if(!P.mv)return;P.dir=dirOf(dx,dy);
 var st=SPD*dt,nx=P.x+dx*st,ny=P.y+dy*st;
 if(manual){
  var cxn=Math.floor(nx),cyo=Math.floor(P.y),cxo=Math.floor(P.x),cyn=Math.floor(ny);
  if(cxn>=0&&cxn<W&&cyo>=0&&cyo<H&&blk[cyo][cxn])nx=P.x;
  if(cxo>=0&&cxo<W&&cyn>=0&&cyn<H&&blk[cyn][Math.floor(nx)])ny=P.y;
 }
 P.x=Math.max(.3,Math.min(W-.3,nx));P.y=Math.max(.3,Math.min(H-.3,ny));
}
/* ---------- interacción ---------- */
var DIST=3.0;
function abrir(p){
 if(!p)return;keys={};P.path=[];tgt=null;P.want=null;
 if(EMB)parent.postMessage({naradak:"npc",id:p.id},"*");
 else toast("Abriría: "+p.verbo);
}
function salir(){keys={};if(EMB)parent.postMessage({naradak:"exit"},"*");else toast("Salida a la ciudad");}
var _tt=0;function toast(t){var e=$("toast");e.textContent=t;e.style.display="block";clearTimeout(_tt);_tt=setTimeout(function(){e.style.display="none";},1800);}
function cerca(){
 near=null;var m=DIST;NP.forEach(function(p){var d=Math.hypot(p.x-P.x,p.y-P.y);if(d<m){m=d;near=p;}});
 NP.forEach(function(p){if(Math.hypot(p.x-P.x,p.y-P.y)<DIST)p.dir=dirOf(P.x-p.x,P.y-p.y);});
 if(P.want&&Math.hypot(P.want.x-P.x,P.want.y-P.y)<DIST-.05){var w=P.want;P.want=null;abrir(w);return;}
 var b=$("bHab");b.style.display=near?"block":"none";if(near)b.textContent="E · "+near.n+" — "+near.verbo;
 if(P.x<.85&&P.y>6.9&&P.y<8.7){salir();P.x=1.7;P.y=7.8;P.path=[];}
}
function irA(p){
 if(Math.hypot(p.x-P.x,p.y-P.y)<DIST-.05){abrir(p);return;}
 var best=null,c0=cell();
 for(var yy=0;yy<H;yy++)for(var xx=0;xx<W;xx++){
  if(blk[yy][xx])continue;var d=Math.hypot(xx+.5-p.x,yy+.5-p.y);if(d>DIST-.05)continue;
  var pa=bfs(c0,{x:xx,y:yy});if(pa&&(!best||pa.length<best.pa.length))best={pa:pa,x:xx,y:yy};}
 if(best){P.path=best.pa;tgt={x:best.x,y:best.y};P.want=p;}
}
$("bHab").onclick=function(){abrir(near);};
addEventListener("keydown",function(e){var k=e.key.toLowerCase();if(k==="e"||k==="enter"){abrir(near);}else if(k==="escape"){salir();}else{keys[k]=1;if(k.indexOf("arrow")===0)e.preventDefault();}});
addEventListener("keyup",function(e){delete keys[e.key.toLowerCase()];});
addEventListener("blur",function(){keys={};});
cv.addEventListener("pointerdown",function(e){
 var r=cv.getBoundingClientRect(),wx=((e.clientX-r.left)-r.width/2)/Z+CAMX,wy=((e.clientY-r.top)-r.height/2)/Z+CAMY;
 var hit=null,bd=30;NP.forEach(function(p){var q=pj(p.x,p.y),d=Math.hypot(wx-q.x,wy-(q.y-22));if(d<bd){bd=d;hit=p;}});
 if(hit){irA(hit);return;}
 var u=Math.floor((wy/TH+wx/TW)/2),v=Math.floor((wy/TH-wx/TW)/2);
 var pa=bfs(cell(),{x:u,y:v});if(pa){P.want=null;P.path=pa;tgt={x:u,y:v};}
});
addEventListener("message",function(e){var d=e.data;if(d&&d.naradak==="tb"){BADGE.exp=!!d.exp;BADGE.rum=d.rum|0;BADGE.tab=d.tab|0;}});
/* ---------- capa estática (suelo, paredes, decorado) ---------- */
var CAMX=(W-H)*TW/2,CAMY=((W+H)*TH-WH)/2,SX0=-(H*TW)-30,SY0=-WH-40,SW=(W+H)*TW+60,SH=(W+H)*TH+WH+80,STAT=null;
function seed(s){return function(){s|=0;s=s+0x6D2B79F5|0;var t=Math.imul(s^s>>>15,1|s);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296;};}
function construir(){
 var K=2,c=document.createElement("canvas");c.width=SW*K;c.height=SH*K;var g=c.getContext("2d");
 g.scale(K,K);g.translate(-SX0,-SY0);g.imageSmoothingEnabled=true;
 var R=seed(77),tex=IM.tablones;
 /* suelo */
 g.save();g.transform(TW,TH,-TW,TH,0,0);
 for(var v=0;v<H;v+=1.5)for(var u=0;u<W;u+=4)g.drawImage(tex,u,v,4.03,1.53);
 for(var y=0;y<H;y++)for(var x=0;x<W;x++){
  g.fillStyle="rgba(20,8,0,"+(.22+((x*7+y*13)%5)*.035)+")";g.fillRect(x,y,1,1);
  if((x+y)%2){g.fillStyle="rgba(0,0,0,.07)";g.fillRect(x,y,1,1);}
 }
 g.lineWidth=.02;g.strokeStyle="rgba(0,0,0,.18)";
 for(var i=0;i<=W;i++){g.beginPath();g.moveTo(i,0);g.lineTo(i,H);g.stroke();}
 for(var j=0;j<=H;j++){g.beginPath();g.moveTo(0,j);g.lineTo(W,j);g.stroke();}
 /* alfombra central */
 g.fillStyle="#5b1a1a";g.fillRect(3.3,3.5,4.2,3.2);g.strokeStyle="#c9923c";g.lineWidth=.07;g.strokeRect(3.45,3.65,3.9,2.9);
 g.strokeStyle="rgba(201,146,60,.5)";g.lineWidth=.03;g.strokeRect(3.65,3.85,3.5,2.5);
 g.fillStyle="rgba(201,146,60,.35)";for(var q=0;q<4;q++){g.beginPath();g.arc(4.3+q*.9,5.1,.22,0,7);g.fill();}
 /* felpudo de entrada */
 g.fillStyle="#3d2a14";g.fillRect(.15,7.0,.95,1.7);g.strokeStyle="#c9923c";g.lineWidth=.04;g.strokeRect(.25,7.1,.75,1.5);
 /* sombra al pie de las paredes */
 var gr=g.createLinearGradient(0,0,0,1.4);gr.addColorStop(0,"rgba(0,0,0,.45)");gr.addColorStop(1,"rgba(0,0,0,0)");
 g.fillStyle=gr;g.fillRect(0,0,W,1.4);
 var gl=g.createLinearGradient(0,0,1.4,0);gl.addColorStop(0,"rgba(0,0,0,.45)");gl.addColorStop(1,"rgba(0,0,0,0)");g.fillStyle=gl;g.fillRect(0,0,1.4,H);
 g.restore();
 /* paredes */
 function pared(len,shade){
  var gp=g.createLinearGradient(0,-WH,0,0);gp.addColorStop(0,"rgb("+Math.round(168*shade)+","+Math.round(134*shade)+","+Math.round(92*shade)+")");gp.addColorStop(1,"rgb("+Math.round(206*shade)+","+Math.round(172*shade)+","+Math.round(122*shade)+")");
  g.fillStyle=gp;g.fillRect(0,-WH,len,WH);
  for(var n=0;n<260;n++){g.fillStyle="rgba("+(R()<.5?"60,36,12":"255,230,180")+","+(.03+R()*.05)+")";g.fillRect(R()*len,-WH+R()*WH,.15+R()*.5,2+R()*7);}
  /* zócalo de tablones */
  for(var u=0;u<len;u+=4)g.drawImage(tex,u,-40,4.03,40);
  g.fillStyle="rgba(15,6,0,"+(.30+(1-shade)*.5)+")";g.fillRect(0,-40,len,40);
  g.fillStyle="#2e1a0a";g.fillRect(0,-43,len,4);g.fillStyle="rgba(255,210,140,.25)";g.fillRect(0,-43,len,1);
  g.fillStyle="#2a170a";g.fillRect(0,-4,len,4);
  /* vigas */
  g.fillStyle="#3b2412";g.fillRect(0,-WH,len,9);g.fillStyle="rgba(255,210,140,.18)";g.fillRect(0,-WH,len,1.5);
  for(var b=0;b<=len;b+=Math.max(2.5,len/3.5)){g.fillStyle="#3b2412";g.fillRect(b-.12,-WH,.24,WH);g.fillStyle="rgba(255,210,140,.14)";g.fillRect(b-.12,-WH,.04,WH);}
  g.fillStyle="#2e1a0a";g.fillRect(len-.24,-WH,.24,WH);
 }
 /* NE (y=0): x=32u, y=16u+yy */
 g.save();g.transform(TW,TH,0,1,0,0);pared(W,1);
 /* estantes con botellas y barriles tras la barra */
 var bt=IM.botellas,bs=.34,bw=bt.width*bs/TW;
 [[5.3,-58],[5.3,-92]].forEach(function(s){
  g.fillStyle="#3b2412";g.fillRect(s[0]-.15,s[1],bw+.3,3.2);g.fillStyle="rgba(255,210,140,.2)";g.fillRect(s[0]-.15,s[1],bw+.3,.8);
  g.drawImage(bt,s[0],s[1]-bt.height*bs,bw,bt.height*bs);
 });
 var lb=IM.libro,ls=.56;g.drawImage(lb,3.35,-lb.height*ls,lb.width*ls/TW,lb.height*ls);
 /* ventana */
 g.fillStyle="#2a170a";g.fillRect(10.2,-98,.72,52);g.fillStyle="#1d2a3d";g.fillRect(10.27,-92,.58,40);
 g.fillStyle="rgba(140,170,220,.25)";g.fillRect(10.27,-92,.58,16);g.fillStyle="#2a170a";g.fillRect(10.54,-92,.05,40);g.fillRect(10.27,-74,.58,3);
 g.restore();
 /* NW (x=0): u'=-v ; x=32u', y=-16u'+yy */
 g.save();g.transform(TW,-TH,0,1,0,0);g.save();g.translate(-H,0);pared(H,.80);g.restore();
 /* tablón de encargos (v 4.5-6.5) */
 (function(){var u0=-6.55,w=1.9,y0=-98,h=62;
  g.fillStyle="#2a170a";g.fillRect(u0-.1,y0-4,w+.2,h+8);g.fillStyle="#8a6a3c";g.fillRect(u0,y0,w,h);
  g.fillStyle="rgba(0,0,0,.12)";for(var i=0;i<30;i++)g.fillRect(u0+R()*w,y0+R()*h,.06+R()*.1,1);
  for(var i=0;i<8;i++){var px=u0+.1+(i%4)*.44+R()*.06,py=y0+6+Math.floor(i/4)*28+R()*5;g.fillStyle=["#efe3c0","#e6d7a8","#f3ead0"][i%3];g.fillRect(px,py,.3,18+R()*4);g.fillStyle="#a02828";g.fillRect(px+.12,py+1,.06,2.2);g.fillStyle="rgba(60,40,20,.5)";for(var l=0;l<3;l++)g.fillRect(px+.04,py+6+l*4,.22,1);}
 })();
 /* puerta de salida (v 7.1-8.4) */
 (function(){var u0=-8.45,w=1.35,h=84;
  g.fillStyle="#1d1006";g.fillRect(u0-.12,-h-8,w+.24,h+8);
  var gd=g.createLinearGradient(0,-h,0,0);gd.addColorStop(0,"#5a3818");gd.addColorStop(1,"#3a2410");g.fillStyle=gd;g.fillRect(u0,-h,w,h);
  g.fillStyle="rgba(0,0,0,.3)";for(var i=1;i<4;i++)g.fillRect(u0+i*w/4,-h,.03,h);
  g.fillStyle="#1d1006";g.fillRect(u0,-h*.55,w,3);
  g.fillStyle="#c9923c";g.beginPath();g.arc(u0+w*.8,-h*.42,2.4,0,7);g.fill();
  g.fillStyle="#120a04";g.fillRect(u0-.12,-h-8,w+.24,6);
 })();
 g.restore();
 /* arista de la esquina */
 g.fillStyle="#2a170a";g.fillRect(-2,-WH,4,WH);
 STAT=c;
}
/* ---------- objetos ordenados ---------- */
function spr(k,x,y,s,dy,mir){
 var im=IM[k],p=pj(x,y);cx.save();cx.translate(p.x,p.y+8+(dy||0));if(mir)cx.scale(-1,1);
 cx.drawImage(im,-im.width*s/2,-im.height*s,im.width*s,im.height*s);cx.restore();
}
function caja3d(x0,y0,x1,y1,h,cT,cL,cR){
 function P3(x,y,z){var p=pj(x,y);return[p.x,p.y-z];}
 function poly(a,col){cx.beginPath();a.forEach(function(p,i){i?cx.lineTo(p[0],p[1]):cx.moveTo(p[0],p[1]);});cx.closePath();cx.fillStyle=col;cx.fill();}
 poly([P3(x0,y1,0),P3(x1,y1,0),P3(x1,y1,h),P3(x0,y1,h)],cL);
 poly([P3(x1,y0,0),P3(x1,y1,0),P3(x1,y1,h),P3(x1,y0,h)],cR);
 cx.save();cx.beginPath();[P3(x0,y0,h),P3(x1,y0,h),P3(x1,y1,h),P3(x0,y1,h)].forEach(function(p,i){i?cx.lineTo(p[0],p[1]):cx.moveTo(p[0],p[1]);});cx.closePath();cx.clip();
 cx.transform(TW,TH,-TW,TH,0,-h);cx.drawImage(IM.tablones,x0,y0,x1-x0,y1-y0);cx.fillStyle=cT;cx.fillRect(x0,y0,x1-x0,y1-y0);cx.restore();
 cx.strokeStyle="rgba(255,210,140,.35)";cx.lineWidth=1;cx.beginPath();var a=P3(x0,y1,h),b=P3(x1,y1,h),c=P3(x1,y0,h);cx.moveTo(a[0],a[1]);cx.lineTo(b[0],b[1]);cx.lineTo(c[0],c[1]);cx.stroke();
 /* vetas verticales del frente */
 cx.strokeStyle="rgba(0,0,0,.25)";for(var u=x0+.45;u<x1;u+=.45){var s=P3(u,y1,0),e=P3(u,y1,h-2);cx.beginPath();cx.moveTo(s[0],s[1]);cx.lineTo(e[0],e[1]);cx.stroke();}
}
function lista(){
 var L=[];
 L.push({k:3.2,f:function(){spr("chimenea",2,.72,1.15);}});
 L.push({k:3.7,f:function(){spr("barril1",3.1,.62,.42);spr("barril_s1",3.75,.6,.6);}});
 L.push({k:4.6,f:function(){spr("caja",.6,4.55,.5);}});
 L.push({k:8.95,f:function(){
  caja3d(5.4,1.0,9.6,1.9,30,"rgba(40,16,0,.25)","#5a3418","#3d2410");
  spr("jarras",6.4,1.55,.3,-30);spr("jarras",8.4,1.5,.3,-30);spr("velas",9.1,1.5,.2,-30);
 }});
 [6.5,7.7,8.9].forEach(function(x){L.push({k:x+2.55,f:function(){spr("taburete",x,2.55,.5);}});});
 L.push({k:9.1,f:function(){spr("mesaB",4.3,4.8,1.05);}});
 L.push({k:13.5,f:function(){spr("mesaA",7.2,6.3,1.0);}});
 NP.forEach(function(p){L.push({k:p.x+p.y,f:function(){drawChar(p.c,p.x,p.y,p.dir,0,T);}});});
 L.push({k:0,pl:1});
 VL.forEach(function(v){L.push({k:0,vl:v});});
 return L;
}
var OBJ=null;
/* ---------- dibujo ---------- */
function etiqueta(txt,x,y,hl){cx.save();cx.font="700 "+(hl?11:10)+"px Cinzel,serif";cx.textAlign="center";cx.lineWidth=3;cx.strokeStyle="rgba(20,12,4,.9)";cx.strokeText(txt,x,y);cx.fillStyle=hl?"#ffe9a8":"#f5e6c0";cx.fillText(txt,x,y);cx.restore();}
function marcadores(t){
 NP.forEach(function(p){
  var s=pj(p.x,p.y),bob=Math.sin(t*3+p.x)*2,hl=near===p;
  cx.save();cx.translate(s.x,s.y);
  cx.font="16px serif";cx.textAlign="center";cx.fillText(p.ico,0,-58+bob);
  var b=p.id==="exp"?(BADGE.exp?"✔":""):p.id==="rumores"?(BADGE.rum||""):p.id==="tablon"?(BADGE.tab||""):"";
  if(b!==""){cx.fillStyle=p.id==="exp"?"#4f9a62":"#a83232";cx.beginPath();cx.arc(11,-68+bob,7,0,7);cx.fill();cx.fillStyle="#fff";cx.font="700 9px Karla,sans-serif";cx.fillText(String(b),11,-65+bob);}
  if(hl){etiqueta(p.n,0,-74);cx.font="10px Karla,sans-serif";cx.fillStyle="#d4c9b8";cx.lineWidth=3;cx.strokeStyle="rgba(20,12,4,.9)";cx.strokeText(p.r,0,-84);cx.fillText(p.r,0,-84);}
  cx.restore();
 });
 /* cartel de salida */
 var d=pj(0,7.8);cx.save();cx.translate(d.x,d.y-96);etiqueta("Salida",0,0,P.x<2.2&&P.y>6.6);cx.restore();
}
function luces(t){
 cx.save();cx.setTransform(1,0,0,1,0,0);cx.fillStyle="rgba(24,10,0,.22)";cx.fillRect(0,0,cv.width,cv.height);cx.restore();
 cx.globalCompositeOperation="lighter";
 var fl=.85+.15*Math.sin(t*9)+.06*Math.sin(t*23);
 function glow(x,y,z,r,a,rgb){var s=pj(x,y),g=cx.createRadialGradient(s.x,s.y-z,2,s.x,s.y-z,r);g.addColorStop(0,"rgba("+rgb+","+(a*fl)+")");g.addColorStop(1,"rgba("+rgb+",0)");cx.fillStyle=g;cx.fillRect(s.x-r,s.y-z-r,r*2,r*2);}
 glow(2,1.4,30,170,.5,"255,150,50");
 glow(7.4,1.5,50,120,.22,"255,190,90");glow(9.1,1.5,40,60,.3,"255,190,90");
 glow(4.3,4.8,40,90,.18,"255,190,90");glow(7.2,6.3,30,80,.14,"255,190,90");
 glow(.3,7.8,70,90,.2,"255,170,70");glow(10.5,.6,60,80,.12,"140,170,230");
 cx.globalCompositeOperation="source-over";
}
function draw(t){
 var w=cv.width,h=cv.height;cx.setTransform(1,0,0,1,0,0);cx.fillStyle="#12100c";cx.fillRect(0,0,w,h);
 cx.setTransform(Z*DPR,0,0,Z*DPR,w/2-CAMX*Z*DPR,h/2-CAMY*Z*DPR);
 cx.imageSmoothingEnabled=true;cx.drawImage(STAT,SX0,SY0,SW,SH);
 if(tgt){var s=pj(tgt.x+.5,tgt.y+.5);cx.strokeStyle="rgba(232,200,120,"+(.5+.4*Math.sin(t*6))+")";cx.lineWidth=2;cx.beginPath();cx.moveTo(s.x,s.y-8);cx.lineTo(s.x+16,s.y);cx.lineTo(s.x,s.y+8);cx.lineTo(s.x-16,s.y);cx.closePath();cx.stroke();}
 var L=OBJ.slice();L.forEach(function(o){if(o.pl)o.k=P.x+P.y;else if(o.vl)o.k=o.vl.x+o.vl.y;});L.sort(function(a,b){return a.k-b.k;});
 L.forEach(function(o){if(o.pl)drawChar(PC,P.x,P.y,P.dir,P.mv,T);else if(o.vl)drawChar(o.vl.c,o.vl.x,o.vl.y,o.vl.dir,o.vl.mv,T+o.vl.c);else o.f();});
 luces(t);marcadores(t);
}
/* ---------- arranque ---------- */
function resize(){
 DPR=Math.min(2,devicePixelRatio||1);cv.width=innerWidth*DPR;cv.height=innerHeight*DPR;
 var aw=innerWidth-12,ah=innerHeight-110,rw=(W+H)*TW+30,rh=(W+H)*TH+WH+30;
 Z=Math.max(.45,Math.min(aw/rw,ah/rh,1.7));
}
addEventListener("resize",resize);resize();
var keysA=Object.keys(TABASSETS),pend=keysA.length+CHARS.length;
function ok(){if(--pend===0)iniciar();}
keysA.forEach(function(k){var im=new Image();im.onload=ok;im.src=TABASSETS[k];IM[k]=im;});
CHARS.forEach(function(d,i){var im=new Image();im.onload=ok;im.src=d;CI[i]=im;});
function iniciar(){
 construir();OBJ=lista();
 if(EMB)parent.postMessage({naradak:"ready"},"*");
 var last=performance.now();
 (function loop(now){var dt=Math.min(.05,(now-last)/1000);last=now;T+=dt;
  mover(dt);VL.forEach(function(v){moverV(v,dt);});cerca();draw(T);requestAnimationFrame(loop);})(last);
}
})();
