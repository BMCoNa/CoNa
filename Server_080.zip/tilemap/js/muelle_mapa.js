"use strict";
/* THE CHRONICLES OF NARADAK — Interior del Muelle (2.5D isométrico).
   Solo personajes por ahora (sin oferta). Mensajes -> juego: {naradak:"ready"} · {naradak:"exit"} */
(function(){
var W=13,H=10,WH=120,TW=32,TH=16,SPD=3.6;
var cv=document.getElementById("mue"),cx=cv.getContext("2d"),$=function(i){return document.getElementById(i);};
var IM={},CI=[],DPR=1,Z=1,T=0,CAMX=0,CAMY=0;
var PC=(function(){try{var v=parseInt(localStorage.getItem("naradak_pc"),10);return v>=0&&v<CHARS.length&&CHARS_INFO[v].k==="humano"?v:4;}catch(e){return 4;}})();
var EMB=parent!==window;
function pj(x,y){return{x:(x-y)*TW,y:(x+y)*TH};}
function dirOf(dx,dy){var sx=dx-dy,sy=dx+dy;return Math.abs(sx)>Math.abs(sy)?(sx<0?1:2):(sy>0?0:3);}
/* ---------- personajes fijos (solo conversación) ---------- */
var NP=[
 {id:"capitan",c:27,alt:50,x:9.4,y:3.7,n:"Capitán Marek",r:"Maestre del puerto",verbo:"Hablar",ico:"⚓",lines:["Cada barca que zarpa del lago vuelve con su historia.","El muelle es viejo, pero aguanta mejor que muchos muros.","Si ves una luz sobre el agua de noche, no la sigas."]},
 {id:"orlan",c:8,alt:36,x:3.5,y:4.6,n:"Viejo Orlan",r:"Pescador",verbo:"Hablar",ico:"🎣",lines:["Llevo cuarenta años en este lago y aún no he pescado dos días iguales.","El pez grande siempre pica cuando ya estás recogiendo.","Con la niebla de la mañana, los peces suben a la superficie."]},
 {id:"tessa",c:28,alt:12,x:10.5,y:7.6,n:"Tessa",r:"Marinera",verbo:"Hablar",ico:"🛶",lines:["La barca aguanta tres pasajeros, cuatro si no llevan botas.","Remar contra el viento te enseña paciencia.","Algún día cruzaré el lago hasta la orilla del este."]},
 {id:"brugo",c:2,alt:39,x:2.4,y:2.3,n:"Brugo",r:"Estibador",verbo:"Hablar",ico:"📦",lines:["Cajas, barriles, cajas... y otra vez barriles.","Si algo pesa mucho, es que lo trajo el Gremio.","Esta pila no se mueve sola, aunque a veces lo parezca."]},
 {id:"nilda",c:3,alt:18,x:11.2,y:4.9,n:"Nilda",r:"Redera",verbo:"Hablar",ico:"🕸",lines:["Una red bien tejida dura más que un reino.","Los nudos se aprenden con las manos, no con la cabeza.","Si encuentras un agujero en la red, avísame antes que al pez."]}
];
(function(){var used={};NP.forEach(function(p){used[p.c]=1;});
 NP.forEach(function(p){p.dir=0;p.cell=[Math.floor(p.x),Math.floor(p.y)];
  if(p.c===PC){used[p.alt]=1;p.c=p.alt;}});})();
/* ---------- colisiones ---------- */
var blk=[];for(var y=0;y<H;y++){blk[y]=[];for(var x=0;x<W;x++)blk[y][x]=0;}
function bl(x0,y0,x1,y1){for(var y=y0;y<=y1;y++)for(var x=x0;x<=x1;x++)if(blk[y]&&x>=0&&x<W)blk[y][x]=1;}
bl(4,0,5,0);bl(11,0,11,1);bl(12,2,12,3);bl(0,0,1,1);
bl(6,3,7,3);bl(6,7,8,8);bl(0,6,0,6);
NP.forEach(function(p){blk[p.cell[1]][p.cell[0]]=1;});
function bfs(a,b){
 if(b.x<0||b.y<0||b.x>=W||b.y>=H||blk[b.y][b.x])return null;
 var q=[a],prev={},k=function(p){return p.x+","+p.y;};prev[k(a)]=null;
 while(q.length){var c=q.shift();if(c.x===b.x&&c.y===b.y)break;
  [[1,0],[-1,0],[0,1],[0,-1]].forEach(function(d){var n={x:c.x+d[0],y:c.y+d[1]};if(n.x<0||n.y<0||n.x>=W||n.y>=H||blk[n.y][n.x]||(k(n) in prev))return;prev[k(n)]=c;q.push(n);});}
 if(!(k(b) in prev))return null;var path=[],c=b;while(c){path.unshift(c);c=prev[k(c)];}path.shift();return path;
}
/* ---------- jugador ---------- */
var P={x:1.7,y:7.9,dir:0,mv:0,path:[],want:null},keys={},tgt=null,near=null;
function cell(){return{x:Math.max(0,Math.min(W-1,Math.floor(P.x))),y:Math.max(0,Math.min(H-1,Math.floor(P.y)))};}
function drawChar(c,x,y,dir,mv,t,lift){
 var im=CI[c];if(!im)return;var fw=CHARS_INFO[c].w,fh=CHARS_INFO[c].h,s=pj(x,y),f=mv?[1,0,1,2][Math.floor(t*8)%4]:1;
 cx.save();cx.translate(s.x,s.y+4);
 cx.fillStyle="rgba(0,0,0,.3)";cx.beginPath();cx.ellipse(0,-(lift||0),fw>40?13:10,4,0,0,7);cx.fill();
 cx.imageSmoothingEnabled=false;cx.drawImage(im,f*fw,dir*fh,fw,fh,-fw/2,-(fh-3)-(lift||0),fw,fh);cx.restore();
}
function mover(dt){
 var dx=0,dy=0;
 if(keys.w||keys.arrowup){dx--;dy--;}if(keys.s||keys.arrowdown){dx++;dy++;}if(keys.a||keys.arrowleft){dx--;dy++;}if(keys.d||keys.arrowright){dx++;dy--;}
 var manual=!!(dx||dy);
 if(manual){P.path=[];tgt=null;P.want=null;var l=Math.hypot(dx,dy);dx/=l;dy/=l;}
 else if(P.path.length){var n=P.path[0],tx=n.x+.5-P.x,ty=n.y+.5-P.y,d=Math.hypot(tx,ty);if(d<.08){P.path.shift();if(!P.path.length)tgt=null;}else{dx=tx/d;dy=ty/d;}}
 P.mv=!!(dx||dy);if(!P.mv)return;P.dir=dirOf(dx,dy);
 var st=SPD*dt,nx=P.x+dx*st,ny=P.y+dy*st;
 if(manual){
  var cxn=Math.floor(nx),cyo=Math.floor(P.y),cxo=Math.floor(P.x),cyn=Math.floor(ny);
  if(cxn>=0&&cxn<W&&cyo>=0&&cyo<H&&blk[cyo][cxn])nx=P.x;
  if(cxo>=0&&cxo<W&&cyn>=0&&cyn<H&&blk[cyn][Math.floor(nx)])ny=P.y;
 }
 P.x=Math.max(.3,Math.min(W-.3,nx));P.y=Math.max(.3,Math.min(H-.3,ny));
}
/* ---------- cámara ---------- */
function camara(dt,snap){
 var s=pj(P.x,P.y),tx=s.x,ty=s.y-30,vw=cv.width/DPR/Z,vh=cv.height/DPR/Z;
 var x0=-(H*TW),x1=W*TW,y0=-WH,y1=(W+H)*TH+14;
 tx=(x1-x0<=vw)?(x0+x1)/2:Math.max(x0+vw/2,Math.min(x1-vw/2,tx));
 ty=(y1-y0<=vh)?(y0+y1)/2:Math.max(y0+vh/2,Math.min(y1-vh/2,ty));
 var k=snap?1:Math.min(1,dt*6);CAMX+=(tx-CAMX)*k;CAMY+=(ty-CAMY)*k;
}
/* ---------- interacción ---------- */
var DIST=2.8;
function abrir(p){
 if(!p)return;keys={};P.path=[];tgt=null;P.want=null;
 if(p.id==="capitan"&&EMB){
  if(_zarpa)return;_zarpa=true;toast(p.n+": «Suba a bordo. Zarpamos hacia Oakhaven.»",2600);
  setTimeout(function(){_zarpa=false;parent.postMessage({naradak:"npc",id:"capitan"},"*");},900);return;
 }
 p.li=p.li||0;var l=p.lines[p.li%p.lines.length];p.li++;toast(p.n+": «"+l+"»",3800);
}
var _zarpa=false;
function salir(){keys={};if(EMB)parent.postMessage({naradak:"exit"},"*");else toast("Salida a la ciudad");}
var _tt=0;function toast(t,ms){var e=$("toast");e.textContent=t;e.style.display="block";clearTimeout(_tt);_tt=setTimeout(function(){e.style.display="none";},ms||1800);}
function cerca(){
 near=null;var m=DIST;NP.forEach(function(p){var d=Math.hypot(p.x-P.x,p.y-P.y);if(d<m){m=d;near=p;}});
 NP.forEach(function(p){if(Math.hypot(p.x-P.x,p.y-P.y)<DIST)p.dir=dirOf(P.x-p.x,P.y-p.y);});
 if(P.want&&Math.hypot(P.want.x-P.x,P.want.y-P.y)<DIST-.05){var w=P.want;P.want=null;abrir(w);return;}
 var b=$("bHab");b.style.display=near?"block":"none";if(near)b.textContent="E · "+near.n+" — "+near.verbo;
 if(P.x<.85&&P.y>7.1&&P.y<8.9){salir();P.x=1.7;P.y=7.9;P.path=[];}
}
function irA(p){
 if(Math.hypot(p.x-P.x,p.y-P.y)<DIST-.05){abrir(p);return;}
 var best=null,c0=cell();
 for(var yy=0;yy<H;yy++)for(var xx=0;xx<W;xx++){
  if(blk[yy][xx])continue;var d=Math.hypot(xx+.5-p.x,yy+.5-p.y);if(d>DIST-.05)continue;
  var pa=bfs(c0,{x:xx,y:yy});if(pa&&(!best||pa.length<best.pa.length))best={pa:pa,x:xx,y:yy};}
 if(best){P.path=best.pa;tgt={x:best.x,y:best.y};P.want=p;}
}
$("bHab").onclick=function(){abrir(near);};
addEventListener("keydown",function(e){var k=e.key.toLowerCase();if(k==="e"||k==="enter"){abrir(near);}else if(k==="escape"){salir();}else{keys[k]=1;if(k.indexOf("arrow")===0)e.preventDefault();}});
addEventListener("keyup",function(e){delete keys[e.key.toLowerCase()];});
addEventListener("blur",function(){keys={};});
cv.addEventListener("pointerdown",function(e){
 var r=cv.getBoundingClientRect(),wx=((e.clientX-r.left)-r.width/2)/Z+CAMX,wy=((e.clientY-r.top)-r.height/2)/Z+CAMY;
 var hit=null,bd=34;NP.forEach(function(p){var q=pj(p.x,p.y),hh=CHARS_INFO[p.c].h/2+(p.lift||0),d=Math.hypot(wx-q.x,wy-(q.y-hh));if(d<bd){bd=d;hit=p;}});
 if(hit){irA(hit);return;}
 var u=Math.floor((wy/TH+wx/TW)/2),v=Math.floor((wy/TH-wx/TW)/2);
 var pa=bfs(cell(),{x:u,y:v});if(pa){P.want=null;P.path=pa;tgt={x:u,y:v};}
});

/* ---------- capa estática ---------- */
var SX0=-(H*TW)-30,SY0=-WH-40,SW=(W+H)*TW+60,SH=(W+H)*TH+WH+80,STAT=null;
function seed(s){return function(){s|=0;s=s+0x6D2B79F5|0;var t=Math.imul(s^s>>>15,1|s);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296;};}
function ventana(g,u0,w,yt,h){
 g.fillStyle="#3b2412";g.fillRect(u0-.12,yt-5,w+.24,h+10);
 var gd=g.createLinearGradient(0,yt,0,yt+h);gd.addColorStop(0,"#9fd0e6");gd.addColorStop(1,"#4f8fae");g.fillStyle=gd;g.fillRect(u0,yt,w,h);
 g.fillStyle="rgba(255,255,255,.35)";g.beginPath();g.moveTo(u0,yt+h*.55);g.lineTo(u0+w,yt+h*.4);g.lineTo(u0+w,yt+h*.55);g.lineTo(u0,yt+h*.7);g.fill();
 g.fillStyle="#3b2412";g.fillRect(u0+w/2-.025,yt,.05,h);g.fillRect(u0,yt+h/2-1.5,w,3);
 g.fillStyle="#52331a";g.fillRect(u0-.16,yt+h+4,w+.32,5);
}
function ojo(g,u0,yt){g.fillStyle="#3b2412";g.beginPath();g.ellipse(u0,yt,.3,13,0,0,7);g.fill();g.fillStyle="#7fb8d4";g.beginPath();g.ellipse(u0,yt,.22,9,0,0,7);g.fill();g.fillStyle="#3b2412";g.fillRect(u0-.02,yt-9,.04,18);g.fillRect(u0-.22,yt-1,.44,2);}
function construir(){
 var K=2,c=document.createElement("canvas");c.width=SW*K;c.height=SH*K;var g=c.getContext("2d");
 g.scale(K,K);g.translate(-SX0,-SY0);g.imageSmoothingEnabled=true;
 var R=seed(77);
 g.save();g.transform(TW,TH,-TW,TH,0,0);
 var pal=["#8a5c2e","#946432","#7e5428","#9a6b38","#85582b"];
 for(var y=0;y<H;y++)for(var x=0;x<W;x++){
  g.fillStyle=pal[Math.floor(R()*pal.length)];g.fillRect(x,y,1,1);
  for(var q=1;q<3;q++){g.fillStyle="rgba(30,14,4,.32)";g.fillRect(x,y+q/3,1,.035);}
  g.fillStyle="rgba(30,14,4,.5)";var o=R()*.8+.1;g.fillRect(x+o,y+((x*3+y)%3)/3,.04,1/3);
  g.fillStyle="rgba(255,225,170,"+(.03+R()*.05)+")";g.fillRect(x,y,1,.33);
 }
 g.strokeStyle="rgba(25,10,2,.5)";g.lineWidth=.04;
 for(var i=0;i<=W;i++){g.beginPath();g.moveTo(i,0);g.lineTo(i,H);g.stroke();}
 for(var j=0;j<=H;j++){g.beginPath();g.moveTo(0,j);g.lineTo(W,j);g.stroke();}
 g.fillStyle="#2f5e86";g.fillRect(3.1,5.2,5.8,3.7);g.strokeStyle="#c9a45c";g.lineWidth=.07;g.strokeRect(3.25,5.35,5.5,3.4);   /* alfombra azul bajo el bote */
 g.fillStyle="#2f5e86";g.fillRect(.15,7.1,2.4,1.5);
 var gr=g.createLinearGradient(0,0,0,1.4);gr.addColorStop(0,"rgba(0,0,0,.4)");gr.addColorStop(1,"rgba(0,0,0,0)");g.fillStyle=gr;g.fillRect(0,0,W,1.4);
 var gl=g.createLinearGradient(0,0,1.4,0);gl.addColorStop(0,"rgba(0,0,0,.4)");gl.addColorStop(1,"rgba(0,0,0,0)");g.fillStyle=gl;g.fillRect(0,0,1.4,H);
 g.restore();
 function pared(len,sh){
  var gp=g.createLinearGradient(0,-WH,0,0);gp.addColorStop(0,"rgb("+Math.round(232*sh)+","+Math.round(218*sh)+","+Math.round(186*sh)+")");gp.addColorStop(1,"rgb("+Math.round(206*sh)+","+Math.round(188*sh)+","+Math.round(150*sh)+")");
  g.fillStyle=gp;g.fillRect(0,-WH,len,WH);
  for(var n=0;n<90;n++){g.fillStyle="rgba(90,60,20,"+(R()*.05)+")";g.fillRect(R()*len,-WH+R()*(WH-40),.2+R()*.5,2+R()*3);}
  g.fillStyle="#4a2d14";g.fillRect(0,-WH,len,9);g.fillStyle="rgba(255,210,140,.2)";g.fillRect(0,-WH,len,1.5);
  g.fillRect(0,-WH+44,len,4);g.fillStyle="#3b2412";g.fillRect(0,-WH+90,len,4);
  for(var b=0;b<=len;b+=3){g.fillStyle="#4a2d14";g.fillRect(b-.07,-WH,.14,WH);}
  g.fillStyle="#4a2d14";g.fillRect(len-.14,-WH,.14,WH);
  g.fillStyle="#6a4222";g.fillRect(0,-34,len,34);   /* zócalo de tablones */
  g.fillStyle="rgba(20,8,0,.45)";for(var u=0;u<len;u+=.5)g.fillRect(u,-34,.03,34);
  g.fillStyle="#3b2412";g.fillRect(0,-36,len,3);g.fillStyle="rgba(255,210,140,.25)";g.fillRect(0,-36,len,1);
  g.fillStyle="rgba(15,8,2,"+(.22+(1-sh)*.3)+")";g.fillRect(0,-WH,len,WH);
 }
 g.save();g.transform(TW,TH,0,1,0,0);pared(W,1);
 ventana(g,5.4,1.2,-95,46);ventana(g,9.0,1.2,-95,46);ojo(g,1.4,-70);
 g.restore();
 g.save();g.transform(TW,-TH,0,1,0,0);g.save();g.translate(-H,0);pared(H,.82);g.restore();
 ventana(g,-3.2,1.1,-95,46);ventana(g,-6.2,1.1,-95,46);
 (function(){var u0=-8.9,w=1.5,h=94;g.fillStyle="#2c1a0a";g.fillRect(u0-.12,-h-6,w+.24,h+6);
  var gd=g.createLinearGradient(0,-h,0,0);gd.addColorStop(0,"#6e4522");gd.addColorStop(1,"#4a2d14");g.fillStyle=gd;g.fillRect(u0,-h,w,h);
  g.fillStyle="rgba(0,0,0,.28)";for(var i=1;i<5;i++)g.fillRect(u0+i*w/5,-h,.03,h);
  g.fillStyle="#26241f";g.fillRect(u0,-h*.7,w,4);g.fillRect(u0,-h*.3,w,4);
  g.fillStyle="#d7b25a";g.fillRect(u0+w*.78,-h*.45-3,.08,6);})();
 g.restore();
 g.fillStyle="#2c1a0a";g.fillRect(-2,-WH,4,WH);
 STAT=c;
}
function spr(k,x,y,s,dy,mir){
 var im=IM[k],p=pj(x,y);cx.save();cx.translate(p.x,p.y+8+(dy||0));if(mir)cx.scale(-1,1);
 cx.drawImage(im,-im.width*s/2,-im.height*s,im.width*s,im.height*s);cx.restore();
}
function lista(){
 var L=[];
 function S(x,y,k,s,dy,m){L.push({k:x+y,f:function(){spr(k,x,y,s,dy,m);}});}
 S(2.6,.4,"red2",1.0,-18);S(7.6,.35,"red1",1.0,-30);
 S(4.9,.95,"cajon",1.0);
 S(11.7,1.5,"grua",1.0);
 S(.9,.95,"caja",1.0);S(1.9,.9,"caja2",1.0);S(.9,1.9,"caja2",.9);
 S(12.5,2.5,"barril",1.0);S(12.5,3.7,"barril2",1.0);S(12.5,4.7,"barril",.9);
 S(6.9,3.55,"mesa_azul",1.0);
 S(7.2,8.6,"bote",1.0,10);
 S(11.8,8.6,"cuerda",1.0);S(.7,5.9,"baul",.8,0,1);
 S(9.2,1.2,"farolpez",1.0);S(11.6,6.4,"balde",1.0);S(5.6,5.0,"poste",1.0);
 NP.forEach(function(p){L.push({k:p.x+p.y,f:function(){drawChar(p.c,p.x,p.y,p.dir,0,T);}});});
 L.push({k:0,pl:1});return L;
}
var OBJ=null;
function etiqueta(txt,x,y,hl){cx.save();cx.font="700 "+(hl?11:10)+"px Cinzel,serif";cx.textAlign="center";cx.lineWidth=3;cx.strokeStyle="rgba(20,12,4,.9)";cx.strokeText(txt,x,y);cx.fillStyle=hl?"#ffe9a8":"#f5e6c0";cx.fillText(txt,x,y);cx.restore();}
function marcadores(t){
 NP.forEach(function(p){
  var s=pj(p.x,p.y),bob=Math.sin(t*3+p.x)*2,hl=near===p,top=CHARS_INFO[p.c].h;
  cx.save();cx.translate(s.x,s.y);cx.font="15px serif";cx.textAlign="center";cx.fillText(p.ico,0,-top-6+bob);
  if(hl){etiqueta(p.n,0,-top-22);cx.font="10px Karla,sans-serif";cx.fillStyle="#d4c9b8";cx.lineWidth=3;cx.strokeStyle="rgba(20,12,4,.9)";cx.strokeText(p.r,0,-top-32);cx.fillText(p.r,0,-top-32);}
  cx.restore();});
 var d=pj(0,8);cx.save();cx.translate(d.x,d.y-104);etiqueta("Salida",0,0,P.x<2.2&&P.y>7);cx.restore();
}
function luces(t){
 cx.globalCompositeOperation="lighter";var fl=.9+.1*Math.sin(t*7);
 function glow(x,y,z,r,a,rgb){var s=pj(x,y),g=cx.createRadialGradient(s.x,s.y-z,2,s.x,s.y-z,r);g.addColorStop(0,"rgba("+rgb+","+(a*fl)+")");g.addColorStop(1,"rgba("+rgb+",0)");cx.fillStyle=g;cx.fillRect(s.x-r,s.y-z-r,r*2,r*2);}
 glow(9.2,1.3,60,120,.35,"255,190,90");glow(6.6,.5,70,110,.14,"170,210,255");glow(9.6,.5,70,110,.14,"170,210,255");
 glow(.5,4.4,70,100,.12,"170,210,255");glow(.5,8.5,70,100,.12,"170,210,255");
 cx.globalCompositeOperation="source-over";
}
function draw(t){
 var w=cv.width,h=cv.height;cx.setTransform(1,0,0,1,0,0);cx.fillStyle="#12100c";cx.fillRect(0,0,w,h);
 cx.setTransform(Z*DPR,0,0,Z*DPR,w/2-CAMX*Z*DPR,h/2-CAMY*Z*DPR);
 cx.imageSmoothingEnabled=true;cx.drawImage(STAT,SX0,SY0,SW,SH);
 if(tgt){var s=pj(tgt.x+.5,tgt.y+.5);cx.strokeStyle="rgba(232,200,120,"+(.5+.4*Math.sin(t*6))+")";cx.lineWidth=2;cx.beginPath();cx.moveTo(s.x,s.y-8);cx.lineTo(s.x+16,s.y);cx.lineTo(s.x,s.y+8);cx.lineTo(s.x-16,s.y);cx.closePath();cx.stroke();}
 var L=OBJ.slice();L.forEach(function(o){if(o.pl)o.k=P.x+P.y;});L.sort(function(a,b){return a.k-b.k;});
 L.forEach(function(o){if(o.pl)drawChar(PC,P.x,P.y,P.dir,P.mv,T);else o.f();});
 luces(t);marcadores(t);
}
function resize(){DPR=Math.min(2,devicePixelRatio||1);cv.width=innerWidth*DPR;cv.height=innerHeight*DPR;Z=Math.max(.85,Math.min(1.6,innerWidth/640));}
addEventListener("resize",resize);resize();
var keysA=Object.keys(MUASSETS),pend=keysA.length+CHARS.length;
function ok(){if(--pend===0)iniciar();}
keysA.forEach(function(k){var im=new Image();im.onload=ok;im.src=MUASSETS[k];IM[k]=im;});
CHARS.forEach(function(d,i){var im=new Image();im.onload=ok;im.src=d;CI[i]=im;});
function iniciar(){
 construir();OBJ=lista();camara(0,true);
 if(EMB)parent.postMessage({naradak:"ready"},"*");
 var last=performance.now();
 (function loop(now){var dt=Math.min(.05,(now-last)/1000);last=now;T+=dt;mover(dt);cerca();camara(dt,false);draw(T);requestAnimationFrame(loop);})(last);
}
})();
