"use strict";
/* PERSONAJE — interfaz compartida por Oakhaven y el Mundo Abierto.
   Centro: tu personaje con las casillas de equipamiento alrededor (también vacías); al tocar una casilla se ve el detalle del objeto.
   Derecha: inventario en tabla de 8 casillas de ancho (equipo de la bolsa, consumibles y materiales).
   Izquierda: tus stats (nivel, vida, recurso, ataque, defensa, atributos y combate).
   Lee los datos del juego principal (window.parent: G.j, calcStats, derivados...). Atajo: tecla I. */
var PersonajePanel=(function(){
 var P={},ov=null,abierto=false,opts={},selTipo="",selClave="",tm=0,sigInv="",avCache={};
 var SLOTS_IZQ=[["arma","Arma","⚔"],["pecho","Pecho","🛡"],["piernas","Piernas","👖"]],
     SLOTS_DER=[["accesorio","Accesorio","💍"],["guantes","Guantes","🧤"],["botas","Botas","🥾"]];
 function W(){try{var p=parent&&parent!==window?parent:null;return p&&p.G&&p.G.j&&p.calcStats&&p.derivados&&p.itemIcono?p:null;}catch(e){return null;}}
 function esc(t){return String(t==null?"":t).replace(/[&<>"']/g,function(c){return{"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c];});}
 function vacio(it){return !it||!it.n||it.n==="Ninguno";}
 function ico(Wp,n,fb){return '<img src="../assets/items/'+esc(Wp.itemIcono(n))+'.png" alt="" draggable="false" onerror="this.replaceWith(document.createTextNode(\''+(fb||"📦")+'\'))">';}

 var CSS=
 "#ppOv{position:fixed;inset:0;z-index:1500;display:none;align-items:center;justify-content:center;background:rgba(0,0,0,.62);font-family:Karla,sans-serif;color:#f5e6c0;touch-action:manipulation;user-select:none;-webkit-user-select:none}"+
 "#ppOv.on{display:flex}"+
 "#ppBox{position:relative;box-sizing:border-box;width:min(98vw,920px);max-height:94vh;display:flex;flex-direction:column;background:rgba(24,15,6,.97);border:2px solid #5a4a2a;border-radius:8px;box-shadow:0 8px 32px rgba(0,0,0,.8);padding:10px 12px 12px}"+
 "#ppTit{font-family:Cinzel,serif;font-size:18px;font-weight:700;color:#e8c9a0;text-align:center;margin:0 28px 8px}"+
 "#ppX{position:absolute;top:4px;right:6px;background:none;border:0;color:#e8c9a0;font-size:24px;line-height:1;cursor:pointer;padding:4px 8px}"+
 "#ppMain{display:flex;gap:10px;align-items:stretch;min-height:0;flex:1;overflow:hidden}"+
 ".ppCol{box-sizing:border-box;background:rgba(0,0,0,.28);border:1px solid #3a2a14;border-radius:6px;padding:8px;overflow:auto;min-height:0}"+
 "#ppSt{flex:0 0 min(210px,26vw)}#ppCe{flex:0 0 auto;display:flex;flex-direction:column;align-items:center;gap:8px}#ppIn{flex:1 1 auto;min-width:0}"+
 ".ppH{font-family:Cinzel,serif;font-size:13px;color:#e8c9a0;margin:0 0 6px;display:flex;justify-content:space-between;gap:6px}"+
 ".ppH small{font:600 11px Karla,sans-serif;color:#b8a888}"+
 ".ppNm{font-family:Cinzel,serif;font-size:15px;color:#f3dca8;line-height:1.2}"+
 ".ppSub{font-size:11px;color:#b8a888;margin-bottom:6px}"+
 ".ppBr{position:relative;height:13px;margin:3px 0;background:#1a120a;border:1px solid #3a2a14;border-radius:3px;overflow:hidden}"+
 ".ppBr i{position:absolute;left:0;top:0;bottom:0;background:#4f9a46}.ppBr.mp i{background:#3a78d0}.ppBr.xp i{background:#b08a2a}"+
 ".ppBr u{position:absolute;inset:0;text-decoration:none;font-size:10px;font-weight:700;text-align:center;line-height:13px;color:#fff;text-shadow:1px 1px 1px #000;white-space:nowrap}"+
 ".ppRow{display:flex;justify-content:space-between;gap:8px;font-size:12px;padding:2px 0;border-bottom:1px dashed rgba(232,201,160,.12)}"+
 ".ppRow b{color:#fff}.ppRow span{color:#d4c4a0}.ppRow em{font-style:normal;color:#7ab88a;font-size:10px}"+
 ".ppSec{font-family:Cinzel,serif;font-size:11px;color:#c9923c;margin:8px 0 2px;letter-spacing:.06em}"+
 "#ppFig{display:flex;align-items:center;gap:8px}"+
 ".ppSl{display:flex;flex-direction:column;gap:8px}"+
 ".ppS,.ppC{position:relative;box-sizing:border-box;padding:0;border:2px solid #5a4a2a;border-radius:6px;background:rgba(40,26,10,.88);cursor:pointer;color:#fff;display:flex;align-items:center;justify-content:center;font-size:20px;overflow:hidden}"+
 ".ppS{width:var(--ps,50px);height:var(--ps,50px)}.ppC{width:100%;aspect-ratio:1/1;font-size:16px}"+
 ".ppS img,.ppC img{width:84%;height:84%;object-fit:contain;image-rendering:pixelated;pointer-events:none}"+
 ".ppS.vac{opacity:.5;border-style:dashed}.ppS.vac span{opacity:.55;filter:grayscale(1)}"+
 ".ppS.sel,.ppC.sel{border-color:#ffd24a;box-shadow:0 0 8px rgba(255,210,74,.55)}"+
 ".ppS small{position:absolute;left:0;right:0;bottom:0;font:700 8px Karla,sans-serif;text-align:center;color:#e8c9a0;background:rgba(0,0,0,.55);padding:1px 0}"+
 ".ppS .mj{position:absolute;right:2px;top:0;font:700 10px Karla,sans-serif;color:#ffd24a;text-shadow:1px 1px 1px #000}"+
 "#ppAv{width:110px;height:150px;image-rendering:pixelated}"+
 "#ppDet{box-sizing:border-box;width:100%;max-width:300px;min-height:92px;padding:8px;background:rgba(0,0,0,.35);border:1px solid #3a2a14;border-radius:6px;font-size:12px;line-height:1.45;color:#d4c4a0}"+
 "#ppDet b.t{display:block;font-family:Cinzel,serif;font-size:14px;color:#f3dca8}"+
 "#ppDet .dim{color:#9a8c72}"+
 "#ppGrid{display:grid;grid-template-columns:repeat(8,minmax(0,40px));gap:4px;justify-content:center}"+
 ".ppC.vac{opacity:.35;cursor:default}"+
 ".ppC s{position:absolute;right:2px;bottom:0;font:700 11px Karla,sans-serif;text-decoration:none;text-shadow:1px 1px 2px #000,0 0 3px #000}"+
 ".ppC.eqp{border-color:#8a6ab0}"+
 "@media (max-width:760px){#ppBox{max-height:96vh}#ppMain{flex-direction:column;overflow:auto}.ppCol{overflow:visible;flex:0 0 auto!important}#ppCe{order:-1}}";

 function montar(){
  if(ov)return;
  var st=document.createElement("style");st.textContent=CSS;document.head.appendChild(st);
  ov=document.createElement("div");ov.id="ppOv";
  ov.innerHTML='<div id="ppBox"><button id="ppX" title="Cerrar (Esc / I)">✕</button><div id="ppTit">Personaje</div>'+
   '<div id="ppMain"><div class="ppCol" id="ppSt"></div><div class="ppCol" id="ppCe"><div id="ppFig"><div class="ppSl" id="ppSL"></div><canvas id="ppAv" width="110" height="150"></canvas><div class="ppSl" id="ppSR"></div></div><div id="ppDet"></div></div><div class="ppCol" id="ppIn"></div></div></div>';
  document.body.appendChild(ov);
  ov.addEventListener("pointerdown",function(e){e.stopPropagation();if(e.target===ov)P.cerrar();});
  ["click","pointerup","touchstart","wheel"].forEach(function(ev){ov.addEventListener(ev,function(e){e.stopPropagation();});});
  document.getElementById("ppX").onclick=P.cerrar;
  ov.addEventListener("click",function(e){
   var b=e.target.closest("[data-tp]");if(!b)return;
   selTipo=b.getAttribute("data-tp");selClave=b.getAttribute("data-k");pintarSel();
  });
 }

 /* ---- stats (izquierda) ---- */
 function filaS(l,v,x){return '<div class="ppRow"><span>'+l+'</span><b>'+v+(x?' <em>'+x+'</em>':'')+'</b></div>';}
 function pintaStats(Wp,j){
  var st=Wp.calcStats(j),D=Wp.derivados(j),A=D.A,cl=(Wp.CLASES&&Wp.CLASES[j.clase])||{},lv=opts.live?opts.live():null;
  var hp=Math.max(0,Math.ceil(lv&&lv.hp!=null?lv.hp:j.vida||0)),hpM=Math.max(1,lv&&lv.max?lv.max:st.vidaMax),mp=Math.max(0,Math.floor(lv&&lv.mp!=null?lv.mp:j.recurso||0)),mpM=Math.max(1,lv&&lv.mpMax?lv.mpMax:st.recursoMax);
  var need=j.nivel*100,xpTxt=j.nivel>=(Wp.NIVEL_MAX||100)?"Nivel máximo · Fama "+(j.fama||0):(j.xp||0)+" / "+need+" XP",xpP=j.nivel>=(Wp.NIVEL_MAX||100)?100:Math.min(100,(j.xp||0)/need*100);
  var tit="";try{tit=Wp.tituloJ?Wp.tituloJ(j):"";}catch(e){}
  var h='<div class="ppNm">'+esc(j.nombre)+'</div><div class="ppSub">'+esc(j.clase)+' · Nv '+j.nivel+(tit?' · '+esc(tit):'')+'</div>';
  h+='<div class="ppBr"><i style="width:'+Math.min(100,hp/hpM*100)+'%"></i><u>♥ '+hp+' / '+hpM+'</u></div>';
  h+='<div class="ppBr mp"><i style="width:'+Math.min(100,mp/mpM*100)+'%"></i><u>'+esc(j.recursoNombre||"Recurso")+' '+mp+' / '+mpM+'</u></div>';
  h+='<div class="ppBr xp"><i style="width:'+xpP+'%"></i><u>'+xpTxt+'</u></div>';
  h+='<div class="ppSec">COMBATE</div>';
  h+=filaS("Ataque",st.atkMin+" – "+st.atkMax)+filaS("Defensa",st.def);
  h+=filaS("Golpe",Math.floor(D.probGolpe)+"%")+filaS("Esquiva",(Math.floor(D.probEsq*10)/10)+"%");
  h+=filaS("Crítico",Math.min(60,(cl.crit||0)+D.critB)+"% (x"+D.critMult.toFixed(2)+")");
  h+=filaS("Red. física",D.redFis)+filaS("Red. mágica",D.redMag)+filaS("Potencia","x"+D.potencia.toFixed(2))+filaS("Iniciativa",D.iniciativa);
  h+='<div class="ppSec">ATRIBUTOS</div>';
  Wp.ATTR_KEYS.forEach(function(k){var g=A.g[k];h+='<div class="ppRow" title="'+esc(Wp.ATTR_DESC[k])+'"><span>'+Wp.ATTR_NOMBRE[k]+'</span><b>'+A.t[k]+(g?' <em>(+'+g+')</em>':'')+'</b></div>';});
  h+='<div class="ppSec">OTROS</div>';
  h+=filaS("Oro","💰 "+(j.oro||0))+filaS("Piso",j.piso||1);
  document.getElementById("ppSt").innerHTML='<div class="ppH">Stats</div>'+h;
 }

 /* ---- personaje + casillas de equipo (centro) ---- */
 function slotHTML(Wp,j,s){
  var it=j.equipo&&j.equipo[s[0]],v=vacio(it);
  return '<button class="ppS'+(v?' vac':'')+(selTipo==="s"&&selClave===s[0]?' sel':'')+'" data-tp="s" data-k="'+s[0]+'" title="'+s[1]+(v?' (vacío)':': '+esc(it.n))+'">'+
   (v?'<span>'+s[2]+'</span>':ico(Wp,it.n,s[2])+((it.mejora||0)>0?'<i class="mj">+'+it.mejora+'</i>':''))+'<small>'+s[1]+'</small></button>';
 }
 function pintaEquipo(Wp,j){
  document.getElementById("ppSL").innerHTML=SLOTS_IZQ.map(function(s){return slotHTML(Wp,j,s);}).join("");
  document.getElementById("ppSR").innerHTML=SLOTS_DER.map(function(s){return slotHTML(Wp,j,s);}).join("");
 }
 function pintaAvatar(j){
  var cv=document.getElementById("ppAv"),g=cv.getContext("2d"),i=-1;
  if(j.avatar!=null&&j.avatar>=0)i=j.avatar;else{try{i=parseInt(localStorage.getItem("naradak_pc"),10);}catch(e){}}
  if(typeof CHARS==="undefined"||typeof CHARS_INFO==="undefined"||!(i>=0)||!CHARS[i]||!CHARS_INFO[i]){i=4;}
  g.clearRect(0,0,cv.width,cv.height);if(typeof CHARS==="undefined"||!CHARS[i])return;
  var d=CHARS_INFO[i];g.imageSmoothingEnabled=false;
  function dib(im){g.clearRect(0,0,cv.width,cv.height);var k=Math.min(cv.width/d.w,cv.height/d.h),w=d.w*k,h=d.h*k;g.drawImage(im,d.w,0,d.w,d.h,(cv.width-w)/2,cv.height-h,w,h);}
  var im=avCache[i];
  if(!im){im=new Image();im.onload=function(){dib(im);};avCache[i]=im;im.src=CHARS[i];}
  if(im.complete&&im.naturalWidth)dib(im);
 }

 /* ---- inventario (derecha) ---- */
 function entradas(Wp,j){
  var L=[],k;
  try{(j.bolsaEq||[]).forEach(function(it,n){L.push({tp:"e",k:"b"+n,n:it.n,it:it,c:1});});}catch(e){}
  try{if(Wp.profEst)(Wp.profEst(j).equipo||[]).forEach(function(it,n){L.push({tp:"e",k:"p"+n,n:it.n,it:it,c:1});});}catch(e){}
  var inv=j.inventario||{},cons=[],mats=[];
  Object.keys(inv).forEach(function(n){if(!(inv[n]>0))return;var esM=true;try{esM=Wp.esMaterial(n);}catch(e){}(esM?mats:cons).push(n);});
  cons.sort(function(a,b){return a.localeCompare(b,"es");});mats.sort(function(a,b){return a.localeCompare(b,"es");});
  cons.forEach(function(n){L.push({tp:"c",k:n,n:n,c:inv[n]});});
  mats.forEach(function(n){L.push({tp:"m",k:n,n:n,c:inv[n]});});
  return L;
 }
 function pintaInv(Wp,j){
  var L=entradas(Wp,j),tot=Math.max(40,Math.ceil(L.length/8)*8),h='<div class="ppH">Inventario <small>'+L.length+' objeto(s)</small></div><div id="ppGrid">';
  for(var i=0;i<tot;i++){
   var e=L[i];
   if(!e){h+='<div class="ppC vac"></div>';continue;}
   h+='<button class="ppC'+(e.tp==="e"?' eqp':'')+(selTipo===e.tp&&selClave===e.k?' sel':'')+'" data-tp="'+e.tp+'" data-k="'+esc(e.k)+'" title="'+esc(e.n)+'">'+ico(Wp,e.n)+(e.c>1?'<s>'+e.c+'</s>':'')+'</button>';
  }
  document.getElementById("ppIn").innerHTML=h+'</div>';
 }

 /* ---- detalle de lo tocado ---- */
 function lineasEq(Wp,j,it){
  var o=[];if(it.atk)o.push("ATK +"+it.atk);if(it.def)o.push("DEF +"+it.def);if(it.vida)o.push("VIDA +"+it.vida);if(it.recurso)o.push((j.recursoNombre||"Recurso")+" +"+it.recurso);
  try{var a=Wp.attrTxt(Wp.itemAttr(it));if(a)o.push(a);}catch(e){}
  return o;
 }
 function detEq(Wp,j,it,etiqueta){
  var h='<b class="t">'+esc(it.n)+'</b><span class="dim">'+esc(etiqueta)+(it.nivel?' · Nv '+it.nivel:'')+(it.rareza?' · '+esc(it.rareza):'')+((it.mejora||0)>0?' · Mejora +'+it.mejora:'')+(it.clase?' · '+esc(it.clase):'')+'</span><br>';
  var l=lineasEq(Wp,j,it);h+=l.length?l.map(esc).join("<br>"):'<span class="dim">Sin bonificaciones</span>';
  try{h+='<br><span class="dim">Valor de venta: '+Wp.precioVentaEquipo(it)+' oro</span>';}catch(e){}
  return h;
 }
 function pintaDetalle(Wp,j){
  var d=document.getElementById("ppDet"),h='<span class="dim">Toca una casilla de equipo u objeto para ver sus datos.</span>';
  if(selTipo==="s"){
   var s=SLOTS_IZQ.concat(SLOTS_DER).filter(function(x){return x[0]===selClave;})[0],it=j.equipo&&j.equipo[selClave];
   if(s)h=vacio(it)?'<b class="t">'+s[1]+'</b><span class="dim">Casilla vacía. Compra o forja equipo para esta ranura.</span>':detEq(Wp,j,it,s[1]);
  }else if(selTipo==="e"){
   var arr=selClave.charAt(0)==="b"?(j.bolsaEq||[]):((Wp.profEst&&Wp.profEst(j).equipo)||[]),it2=arr[+selClave.slice(1)];
   if(it2)h=detEq(Wp,j,it2,"Equipo en la bolsa");
  }else if(selTipo==="c"||selTipo==="m"){
   var c=(j.inventario||{})[selClave]||0;
   h='<b class="t">'+esc(selClave)+' ×'+c+'</b>';
   if(selTipo==="c"){
    var po=(Wp.POCIONES||[]).filter(function(p){return p.n===selClave;})[0];
    h+='<span class="dim">Consumible</span><br>'+(po?esc(po.desc||""):'');
    try{h+='<br><span class="dim">Valor de venta: '+Wp.precioVentaConsumible(selClave)+' oro c/u</span>';}catch(e){}
   }else{
    h+='<span class="dim">Material</span><br>';
    try{h+=esc(Wp.infoMaterial(selClave));}catch(e){}
    try{h+='<br><span class="dim">Valor de venta: '+Wp.precioMaterial(selClave)+' oro c/u</span>';}catch(e){}
   }
  }
  d.innerHTML=h;
 }
 function pintarSel(){var Wp=W();if(!Wp)return;var j=Wp.G.j;pintaEquipo(Wp,j);pintaInv(Wp,j);pintaDetalle(Wp,j);}

 function firma(j){try{return JSON.stringify([j.equipo,j.inventario,(j.bolsaEq||[]).length]);}catch(e){return Math.random();}}
 function pintarTodo(){
  var Wp=W(),box=document.getElementById("ppBox");
  if(!Wp){
   ["ppSt","ppIn"].forEach(function(i){document.getElementById(i).innerHTML="";});
   document.getElementById("ppSL").innerHTML=document.getElementById("ppSR").innerHTML="";
   document.getElementById("ppDet").innerHTML='<span class="dim">El panel del personaje solo está disponible al jugar desde el juego principal.</span>';return;
  }
  var j=Wp.G.j;document.getElementById("ppTit").textContent="Personaje";
  pintaStats(Wp,j);pintaAvatar(j);sigInv=firma(j);pintaEquipo(Wp,j);pintaInv(Wp,j);pintaDetalle(Wp,j);
 }
 function tick(){
  if(!abierto)return;var Wp=W();if(!Wp)return;var j=Wp.G.j;
  pintaStats(Wp,j);
  var f=firma(j);if(f!==sigInv){sigInv=f;pintaEquipo(Wp,j);pintaInv(Wp,j);pintaDetalle(Wp,j);}
 }
 P.abrir=function(){montar();if(abierto)return;abierto=true;selTipo=selClave="";ov.classList.add("on");pintarTodo();clearInterval(tm);tm=setInterval(tick,500);};
 P.cerrar=function(){abierto=false;clearInterval(tm);if(ov)ov.classList.remove("on");};
 P.alternar=function(){abierto?P.cerrar():P.abrir();};
 P.abierto=function(){return abierto;};
 /* init({boton:"id", live:fn}) — live() puede devolver {hp,max,mp,mpMax} en directo */
 P.init=function(o){
  opts=o||{};var b=opts.boton&&document.getElementById(opts.boton);
  if(b){b.addEventListener("pointerdown",function(e){e.preventDefault();e.stopPropagation();});b.addEventListener("click",function(e){e.stopPropagation();P.alternar();});}
  /* tecla I abre/cierra; con el panel abierto no se mueve al personaje con el teclado */
  window.addEventListener("keydown",function(e){
   var t=e.target,esc_=t&&(t.tagName==="INPUT"||t.tagName==="TEXTAREA");
   if(esc_)return;
   var k=(e.key||"").toLowerCase();
   if(k==="i"&&!e.ctrlKey&&!e.metaKey&&!e.altKey){e.preventDefault();e.stopPropagation();if(!e.repeat)P.alternar();return;}
   if(abierto){if(k==="escape")P.cerrar();e.stopPropagation();}
  },true);
 };
 return P;
})();
