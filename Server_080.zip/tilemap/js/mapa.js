"use strict";
/* THE CHRONICLES OF NARADAK — Mapa isométrico 2.5D (demo). Requiere assets.js */
var NaradakMapa={onEnter:null};
(function(){
var W=45,H=30,TW=64,TH=32,SPD=3.4,MIN_S=5.6,IMG={},cv=document.getElementById("mapa"),cx=cv.getContext("2d");
var $=function(i){return document.getElementById(i);};
var SERV={
 tienda:["Tienda","Armas, armaduras y pociones para tu clase.",["⚔ Armas","🛡 Armaduras","🧪 Pociones"]],
 gremio:["Gremio de Aventureros","Campana de misiones, rangos y recompensas.",["📜 Misiones (7 grupos)","🏅 Rangos del gremio","🔔 Campana"]],
 herreria:["Herrería","Forja armas y armaduras con recetas Raras a Legendarias.",["🔨 Forjar arma","🛠 Forjar armadura","📖 Recetas"]],
 alquimista:["Alquimista","Pociones y elixires con ingredientes recolectados.",["⚗ Pociones","🌿 Ingredientes","📖 Recetas"]],
 hospital:["Hospital","Recupera vida y cura maldiciones.",["❤ Curación","☠ Quitar maldición"]],
 castillo:["Castillo","Modo Aventura: rejuega pisos anteriores. Mazmorra Infinita: oleadas sin fin por oro y materiales.",["⚔ Modo Aventura","∞ Mazmorra Infinita"]],
 muelle:["Muelle","Embarcadero del lago: pescadores, estibadores y marineros.",["🎣 Pescadores","⚓ Maestre del puerto","🛶 Barqueros"]],
 entrenamiento:["Área de Entrenamiento","Zona de Combate con maniquíes y Zona de Arquería con dianas. Un General en cada zona.",["⚔ Zona de Combate","🏹 Zona de Arquería"]],
 taberna:["Taberna","Escuadrón, rumores, tablón de encargos y expediciones.",["🍺 Escuadrón","🗣 Rumores","📌 Tablón","🧭 Expediciones"]]};
/* ---------- utilidades ---------- */
function rng(s){return function(){s|=0;s=s+0x6D2B79F5|0;var t=Math.imul(s^s>>>15,1|s);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296;};}
var R=rng(2026);function ri(n){return Math.floor(R()*n);}
/* ---------- mapa ---------- */
/* Rediseño según boceto a mano alzada (cuadrícula 45x30). Coordenadas del boceto -> celdas: g(sx,sy) */
var blk=[],road=[],tiles=[],objs=[],ores=[],blds=[],zone=[],dep=[],flip=[],clear=[],allB=[];
/* zone: 0 pasto · 1 bosque · 2 agua · 3 arena */
for(var y=0;y<H;y++){blk[y]=[];road[y]=[];tiles[y]=[];zone[y]=[];dep[y]=[];flip[y]=[];clear[y]=[];for(var x=0;x<W;x++){blk[y][x]=0;road[y][x]=0;zone[y][x]=0;dep[y][x]=0;flip[y][x]=0;clear[y][x]=0;}}
function g(sx,sy){return[(sx-65)/42.7,(sy-30)/41];}
function G(a){return a.map(function(p){return g(p[0],p[1]);});}
function rect(x0,y0,x1,y1,f){for(var y=y0;y<=y1;y++)for(var x=x0;x<=x1;x++)if(x>=0&&y>=0&&x<W&&y<H)f(x,y);}
function inPoly(px,py,P){var c=false;for(var i=0,j=P.length-1;i<P.length;j=i++){var a=P[i],b=P[j];if((a[1]>py)!==(b[1]>py)&&px<(b[0]-a[0])*(py-a[1])/(b[1]-a[1])+a[0])c=!c;}return c;}
function chaikin(p,n){while(n--){var q=[p[0]];for(var i=0;i<p.length-1;i++){var a=p[i],b=p[i+1];q.push([.75*a[0]+.25*b[0],.75*a[1]+.25*b[1]],[.25*a[0]+.75*b[0],.25*a[1]+.75*b[1]]);}q.push(p[p.length-1]);p=q;}return p;}
function dseg(px,py,a,b){var dx=b[0]-a[0],dy=b[1]-a[1],l=dx*dx+dy*dy,t=l?Math.max(0,Math.min(1,((px-a[0])*dx+(py-a[1])*dy)/l)):0;return Math.hypot(px-a[0]-t*dx,py-a[1]-t*dy);}
function stroke(pts,r,f){for(var y=0;y<H;y++)for(var x=0;x<W;x++){var m=99;for(var i=0;i<pts.length-1;i++)m=Math.min(m,dseg(x+.5,y+.5,pts[i],pts[i+1]));if(m<=r)f(x,y);}}
/* lago (abajo al centro) */
var LAGO=G([[435,1300],[435,1262],[470,1240],[540,1170],[640,1110],[760,1050],[870,985],[950,950],[1050,950],[1150,965],[1240,990],[1290,1035],[1380,1110],[1450,1170],[1530,1230],[1590,1262],[1600,1300]]);
/* bosques (4 esquinas del boceto) */
var BOSQ=[
 G([[0,0],[725,0],[730,50],[735,100],[700,170],[640,230],[600,310],[550,360],[470,420],[380,460],[300,500],[230,540],[130,590],[0,615]]),
 G([[1190,0],[2100,0],[2100,830],[1985,820],[1960,800],[1880,770],[1800,720],[1720,680],[1640,640],[1580,590],[1540,520],[1500,490],[1495,400],[1525,330],[1530,260],[1480,210],[1400,180],[1300,150],[1215,90]]),
 G([[0,1010],[200,935],[330,885],[410,868],[450,900],[500,970],[545,1040],[568,1085],[520,1140],[470,1205],[440,1262],[440,1300],[0,1300]]),
 G([[1385,740],[1300,790],[1265,860],[1265,925],[1285,1000],[1330,1045],[1400,1110],[1480,1170],[1560,1240],[1590,1300],[2100,1300],[2100,880],[1960,880],[1700,790]])];
for(var y=0;y<H;y++)for(var x=0;x<W;x++){var cx0=x+.5,cy0=y+.5;
 if(inPoly(cx0,cy0,LAGO)){zone[y][x]=2;blk[y][x]=1;}
 else for(var k=0;k<4;k++)if(inPoly(cx0,cy0,BOSQ[k]))zone[y][x]=1;}
/* caminos: avenida del castillo, calle principal curva y callejón al este */
var CURVA=chaikin(G([[-60,1000],[40,985],[250,915],[480,765],[700,700],[960,655],[1250,655],[1500,690],[1750,760],[1990,855],[2100,885]]),2);
stroke([[21,5.5],[21,23]],1.1,function(x,y){road[y][x]=1;});
stroke(CURVA,1.1,function(x,y){road[y][x]=1;});
stroke([[22,9],[30.2,9]],1.0,function(x,y){road[y][x]=1;});
stroke([[21,5.5],[26,5.5]],0.55,function(x,y){road[y][x]=1;}); /* sendero al Área de Entrenamiento */
for(var y=0;y<H;y++)for(var x=0;x<W;x++)if(zone[y][x]===2)road[y][x]=0;
/* profundidad del agua y orilla de arena */
(function(){var q=[],d=[];for(var y=0;y<H;y++){d[y]=[];for(var x=0;x<W;x++){d[y][x]=zone[y][x]===2?99:0;if(!d[y][x])q.push([x,y]);}}
 while(q.length){var c=q.shift();[[1,0],[-1,0],[0,1],[0,-1]].forEach(function(v){var X=c[0]+v[0],Y=c[1]+v[1];if(X<0||Y<0||X>=W||Y>=H)return;if(d[Y][X]>d[c[1]][c[0]]+1){d[Y][X]=d[c[1]][c[0]]+1;q.push([X,Y]);}});}
 for(var y=0;y<H;y++)for(var x=0;x<W;x++)dep[y][x]=d[y][x];
 })();
/* anillo de arbolado en el borde del mapa (oculta el vacío) */
for(var y=0;y<H;y++)for(var x=0;x<W;x++)if(Math.min(x,y,W-1-x,H-1-y)<2&&zone[y][x]===0&&!road[y][x])zone[y][x]=1;
/* orilla: casilla de tierra junto al agua -> loseta con acantilado según los lados con agua */
var shore=[];for(var y=0;y<H;y++){shore[y]=[];for(var x=0;x<W;x++)shore[y][x]=0;}
function aw(x,y){return x>=0&&y>=0&&x<W&&y<H&&zone[y][x]===2;}
var SHN={SE:4,SW:4,S:4,E:1,W:1,NE:1,NW:1,dE:2,dW:2};
function orilla(x,y){var ne=aw(x,y-1),se=aw(x+1,y),sw=aw(x,y+1),nw=aw(x-1,y),k=null;
 if(se&&sw)k="S";else if(ne&&se)k="E";else if(nw&&sw)k="W";else if(se)k="SE";else if(sw)k="SW";else if(ne)k="NE";else if(nw)k="NW";
 else if(aw(x+1,y-1))k="dE";else if(aw(x-1,y+1))k="dW";
 if(!k)return null;return "sh_"+k+((x*7+y*13)%SHN[k]);}
/* suelo */
for(var y=0;y<H;y++)for(var x=0;x<W;x++){var z=zone[y][x],pv=false;
 if(road[y][x]){pv=(Math.abs(x+.5-21)<=4.6&&Math.abs(y+.5-15.2)<=2.8)||((x===20||x===21)&&y>=5&&y<=10);}
 tiles[y][x]=z===2?(dep[y][x]<=2?"wa":"wb"):pv?"p"+ri(5):road[y][x]?"e"+ri(3):"g"+(R()<.55?ri(3):ri(16));
 if(z!==2&&!road[y][x]){var o=orilla(x,y);if(o){tiles[y][x]=o;shore[y][x]=1;}}
 if(pv&&R()<.25)tiles[y][x]="p"+(5+ri(3));}
function put(n,x,y,w,h,o){o=o||{};o.i=n;o.cx=x+w/2;o.cy=y+h/2;objs.push(o);rect(x,y,x+w-1,y+h-1,function(a,b){blk[b][a]=1;});return o;}
function bld(id,x,y){var o=put(id,x,y,2,2,{lab:SERV[id][0],id:id,w:2,h:2});blds.push(o);allB.push(o);return o;}
function deco(n,x,y,w,h,o){o=o||{};o.glow=1;var r=put(n,x,y,w,h,o);allB.push(r);return r;}
/* edificios con servicio: posiciones del boceto */
var _c=put("castillo",19,2,4,3,{lab:"Castillo",id:"castillo",w:4,h:3});blds.push(_c);allB.push(_c);
bld("gremio",18,7);bld("hospital",31,7);
var _e=put("entrenamiento",24,2,3,3,{lab:"Entrenar",id:"entrenamiento",w:3,h:3,glow:1});blds.push(_e);allB.push(_e);
bld("tienda",17,13);bld("taberna",22,12);
bld("herreria",18,17);bld("alquimista",22,17);
/* casas y torre solo de adorno (boceto) */
deco("dh_paja",22,6,2,2);deco("dh_verde",25,6,2,2);deco("dh_azul",28,12,2,2);deco("dh_turq",26,16,2,2);
deco("torre",10,15,2,2);
/* extras decorativos en los alrededores */
function hueco(x,y,w,h){for(var b=-1;b<=h;b++)for(var a=-1;a<=w;a++){var X=x+a,Y=y+b;if(X<0||Y<0||X>=W||Y>=H||blk[Y][X]||road[Y][X]||shore[Y][X]||zone[Y][X]===2)return false;}return true;}
function extra(n,tx,ty,w,h,lim){lim=lim||4;for(var r=0;r<=lim;r++)for(var b=-r;b<=r;b++)for(var a=-r;a<=r;a++){if(Math.max(Math.abs(a),Math.abs(b))!==r)continue;var x=tx+a,y=ty+b;
  if(hueco(x,y,w,h)){deco(n,x,y,w,h);rect(x-2,y-2,x+w+1,y+h+1,function(c,d){clear[d][c]=1;});return true;}}return false;}
extra("molino",4,15,2,2);extra("capilla",33,12,2,2);extra("cabana1",13,12,2,2);
function claro(n,tx,ty,w,h){rect(tx-2,ty-2,tx+w+1,ty+h+1,function(c,d){if(!blk[d][c]&&zone[d][c]===1)zone[d][c]=0;});extra(n,tx,ty,w,h,1);}
claro("cabana2",5,25,2,2);claro("torre2",6,5,2,2);claro("cabana1",38,6,2,2);
/* mercado, forja, mesa y faroles */
function suelto(n,x,y,o){if(x>=0&&y>=0&&x<W&&y<H&&!blk[y][x]&&!road[y][x]&&zone[y][x]!==2)put(n,x,y,1,1,o||{});}
suelto("puesto1",25,11);suelto("puesto2",27,10);suelto("puesto3",24,19);suelto("forja",16,19);suelto("mesa",26,20);
[[19,14],[22,16],[19,20],[24,13],[19,5],[22,5],[24,10],[29,10],[21,21]].forEach(function(p){suelto("farol",p[0],p[1],{light:1});});
/* muelle en el lago: pasarela de tablones desde el camino y casa del embarcadero */
var pier=[];for(var y=0;y<H;y++){pier[y]=[];for(var x=0;x<W;x++)pier[y][x]=0;}
for(var y=22;y<=25;y++)for(var x=20;x<=21;x++){pier[y][x]=1;tiles[y][x]="pier";blk[y][x]=0;}
var _mu=put("muelle",19,26,4,3,{lab:"Muelle",id:"muelle",w:4,h:3,dy:22});blds.push(_mu);allB.push(_mu);
[22.55,24.55].forEach(function(yy){objs.push({i:"mu_poste",cx:20.12,cy:yy,dy:-6});objs.push({i:"mu_poste",cx:21.88,cy:yy,dy:-6});});
objs.push({i:"mu_farolpez",cx:19.5,cy:22.9,light:1});
put("mu_bote",23,24,1,1,{dy:6});put("mu_cajas",19,21,1,1,{});put("mu_barril",22,21,1,1,{});
function libre(x,y,m){m=m||0;for(var b=-m;b<=m;b++)for(var a=-m;a<=m;a++){var X=x+a,Y=y+b;if(X<0||Y<0||X>=W||Y>=H||blk[Y][X]||road[Y][X]||shore[Y][X]||zone[Y][X]!==0)return false;}return true;}
/* pueblo: vegetación suelta (más escasa en el centro) */
for(var n=0;n<520;n++){
 var x=ri(W),y=ri(H);if(!libre(x,y,0))continue;
 var near=false;allB.forEach(function(b){if(Math.abs(b.cx-x-.5)<2.4&&Math.abs(b.cy-y-.5)<2.4)near=true;});if(near)continue;
 var p=R();
 if(p<.12)put("t"+ri(10),x,y,1,1,{sw:1});
 else if(p<.3)put("b"+ri(5),x,y,1,1,{sw:1});
 else if(p<.4)put("r"+ri(4),x,y,1,1,{});
 else if(p<.46)put(["stump","log","mush","fence"][ri(4)],x,y,1,1,{});
 else if(p<.85){objs.push({i:"f"+ri(2),cx:x+.5,cy:y+.5,sw:1});}
}
/* bosques densos */
for(var y=0;y<H;y++)for(var x=0;x<W;x++){
 if(zone[y][x]!==1||blk[y][x]||road[y][x]||clear[y][x]||shore[y][x])continue;
 var p=R();
 if(p<.56)put("t"+ri(10),x,y,1,1,{sw:1});
 else if(p<.68)put("b"+ri(5),x,y,1,1,{sw:1});
 else if(p<.73)put("r"+ri(4),x,y,1,1,{});
 else if(p<.77)put(["stump","log","mush"][ri(3)],x,y,1,1,{});
 else if(p<.85)objs.push({i:"f"+ri(2),cx:x+.5,cy:y+.5,sw:1});}
/* juncos en el agua poco profunda */
for(var y=0;y<H;y++)for(var x=0;x<W;x++){if(zone[y][x]===2&&dep[y][x]===1&&!pier[y][x]&&R()<.22)objs.push({i:"junco",cx:x+.5,cy:y+.5,sw:1});
 else if(shore[y][x]&&!blk[y][x]&&R()<.06)put("r"+ri(4),x,y,1,1,{});}
var got=0;
var ORES_ACTIVO=false; /* minerales recogibles inhabilitados: poner true para reactivarlos */
if(!ORES_ACTIVO){var _hm=$("hMin");if(_hm)_hm.style.display="none";}
for(var n=0;ORES_ACTIVO&&n<60&&ores.length<7;n++){var x=ri(W),y=ri(H);if(libre(x,y,0)&&!(x>17&&x<25&&y>11&&y<19))ores.push({i:"ore"+ri(4),cx:x+.5,cy:y+.5,ph:R()*6});}
/* ---------- pathfinding ---------- */
function bfs(a,b){
 if(b.x<0||b.y<0||b.x>=W||b.y>=H||blk[b.y][b.x])return null;
 var q=[a],prev={},k=function(p){return p.x+","+p.y;};prev[k(a)]=null;
 while(q.length){var c=q.shift();if(c.x===b.x&&c.y===b.y)break;
  [[1,0],[-1,0],[0,1],[0,-1]].forEach(function(d){var n={x:c.x+d[0],y:c.y+d[1]};if(n.x<0||n.y<0||n.x>=W||n.y>=H||blk[n.y][n.x]||(k(n) in prev))return;prev[k(n)]=c;q.push(n);});}
 if(!(k(b) in prev))return null;var path=[],c=b;while(c){path.unshift(c);c=prev[k(c)];}path.shift();return path;
}
/* ---------- jugador ---------- */
var P={x:21,y:17.5,fx:1,dir:0,want:null,mv:0,path:[]},cam={x:0,y:0},T=0,tmin=8*60,Z=1.15,near=null,keys={};
function pj(x,y){return{x:(x-y)*TW/2,y:(x+y)*TH/2};}
cam=pj(P.x,P.y);
/* ---------- personajes (hojas RPG Maker 32x48; filas: 0 abajo,1 izq,2 der,3 arriba) ---------- */
var EMB=/[?&]embed=1/.test(location.search),CIMG=[],PC=(function(){try{var v=parseInt(localStorage.getItem("naradak_pc"),10);return v>=0&&v<CHARS.length&&CHARS_INFO[v].k==="humano"?v:4;}catch(e){return 4;}})(),V=[],talk=null,nearV=null,vPref=false;
var NOM=["Aldric","Berta","Tomás","Lina","Rurik","Mira","Dani","Selka","Hugo","Elsa","Bruno","Nora","Gael","Irene","Otto","Vera","Lucas","Alma","Fabio","Zoe","Marco","Clara","Iván","Petra"];
var DLG=["¡Buen día, aventurero! Naradak nunca duerme.","La Herrería forja armas legendarias, pero piden materiales raros.","Cuidado al caer la noche: las luciérnagas guían, pero los lobos acechan.","El Gremio paga bien por limpiar las cuevas del norte.","Mi abuela juraba que el castillo guarda un tesoro.","La Taberna tiene los mejores rumores del reino.","Si te hieren, el Hospital te cura... y hasta quita maldiciones.","El Alquimista compra hongos. No preguntes para qué. 🍄","Hoy el mercado está tranquilo, aprovecha para comprar pociones.","Un héroe como tú le hace falta a Naradak.","¿Buscas misiones? Mira el tablón de la Taberna."];
function dirOf(dx,dy){var sx=dx-dy,sy=dx+dy;return Math.abs(sx)>Math.abs(sy)?(sx<0?1:2):(sy>0?0:3);}
function drawChar(c,x,y,dir,mv,t,lab){
 var im=CIMG[c];if(!im)return;var fw=CHARS_INFO[c].w,fh=CHARS_INFO[c].h,s=pj(x,y),f=mv?[1,0,1,2][Math.floor(t*8)%4]:1;
 cx.save();cx.translate(s.x,s.y+4);
 cx.fillStyle="rgba(0,0,0,.3)";cx.beginPath();cx.ellipse(0,0,10,4,0,0,7);cx.fill();
 cx.imageSmoothingEnabled=false;cx.drawImage(im,f*fw,dir*fh,fw,fh,-fw/2,-(fh-3),fw,fh);
 if(lab){cx.font="700 10px Cinzel,serif";cx.textAlign="center";cx.lineWidth=3;cx.strokeStyle="rgba(20,12,4,.85)";cx.strokeText(lab,0,-50);cx.fillStyle="#f5e6c0";cx.fillText(lab,0,-50);}
 cx.restore();}
function drawPlayer(t){drawChar(PC,P.x,P.y,P.dir,P.mv,t);}
function spawnV(){V=[];var pool=[],cand=aldea();for(var i=0;i<CHARS.length;i++)if(i!==PC&&CHARS_INFO[i].k==="humano")pool.push(i);
 for(var n=0;n<14&&pool.length;n++){var c=pool.splice(ri(pool.length),1)[0],x,y,k=0;
  do{var q=cand[ri(cand.length)];x=q[0];y=q[1];k++;}while(k<1);
  V.push({c:c,x:x+.5,y:y+.5,hx:x,hy:y,dir:0,mv:0,path:[],wait:R()*3,name:NOM[c%NOM.length],lines:[DLG[(c*5)%12],DLG[(c*5+3)%12],DLG[(c*5+7)%12]],li:0});}}
function aldea(){/* celdas alcanzables desde el jugador, dentro del pueblo (no bosque ni agua) */
 var seen={},q=[[Math.floor(P.x),Math.floor(P.y)]],out=[];seen[q[0][0]+","+q[0][1]]=1;
 while(q.length){var c=q.shift();if(c[0]>=6&&c[0]<=40&&c[1]>=4&&c[1]<=23&&zone[c[1]][c[0]]!==1&&zone[c[1]][c[0]]!==2)out.push(c);
  [[1,0],[-1,0],[0,1],[0,-1]].forEach(function(d){var X=c[0]+d[0],Y=c[1]+d[1];if(X<0||Y<0||X>=W||Y>=H||blk[Y][X]||seen[X+","+Y])return;seen[X+","+Y]=1;q.push([X,Y]);});}
 return out.length?out:[[Math.floor(P.x),Math.floor(P.y)]];}
function moverV(v,dt){
 if(talk===v){v.mv=0;v.dir=dirOf(P.x-v.x,P.y-v.y);return;}
 if(!v.path.length){v.mv=0;if((v.wait-=dt)>0)return;v.wait=1.5+R()*4;
  var tx=Math.max(1,Math.min(W-2,v.hx+ri(11)-5)),ty=Math.max(1,Math.min(H-2,v.hy+ri(11)-5));
  var p=bfs({x:Math.floor(v.x),y:Math.floor(v.y)},{x:tx,y:ty});if(p&&p.length<14)v.path=p;return;}
 var n=v.path[0],ex=n.x+.5-v.x,ey=n.y+.5-v.y,d=Math.hypot(ex,ey);
 if(d<.06){v.path.shift();return;}
 var st=Math.min(d,1.15*dt);v.x+=ex/d*st;v.y+=ey/d*st;v.mv=1;v.dir=dirOf(ex,ey);}
function hablar(v){var same=talk===v&&$("panel").style.display==="flex";if(same)v.li++;talk=v;v.dir=dirOf(P.x-v.x,P.y-v.y);
 $("pTit").textContent=v.name;$("pTxt").textContent="“"+v.lines[v.li%3]+"”";$("pLst").innerHTML="<li>E · seguir hablando &nbsp;|&nbsp; Esc · cerrar</li>";$("panel").style.display="flex";}
function cerrar(){talk=null;$("panel").style.display="none";}
/* ---------- render ---------- */
function noche(){var h=(tmin/60)%24;return h<5||h>=21?1:h<7?(7-h)/2:h>=19?(h-19)/2:0;}
function sprite(o,t){
 var im=IMG[o.i];if(!im)return;var s=pj(o.cx,o.cy);cx.save();cx.translate(s.x,s.y+8+(o.dy||0));
 if(o.sw)cx.transform(1,0,Math.sin(t*1.6+o.cx*.7)*.035,1,0,0);
 cx.drawImage(im,-im.width/2,-im.height);cx.restore();
 if(o.lab){var b=IMG.banner,d=near===o,w=96,h=42;cx.save();cx.globalAlpha=d?1:.82;
  cx.drawImage(b,s.x-w/2,s.y+8-im.height-h+8-(d?3:0),w,h);cx.fillStyle="#3a2410";cx.font="700 "+(d?11:10)+"px Cinzel,serif";cx.textAlign="center";cx.fillText(o.lab.split(" ")[0],s.x,s.y+8-im.height-h/2+13-(d?3:0));cx.restore();}
}
function draw(t){
 var w=cv.width,h=cv.height;cx.setTransform(1,0,0,1,0,0);cx.fillStyle="#101a0c";cx.fillRect(0,0,w,h);
 var c=pj(P.x,P.y);cam.x+=(c.x-cam.x)*.12;cam.y+=(c.y-cam.y)*.12;
 cx.setTransform(Z*DPR,0,0,Z*DPR,w/2-cam.x*Z*DPR,h/2-cam.y*Z*DPR);
 var vw=w/DPR/Z/2+80,vh=h/DPR/Z/2+80;
 for(var y=0;y<H;y++)for(var x=0;x<W;x++){var s=pj(x+.5,y+.5);if(Math.abs(s.x-cam.x)>vw||Math.abs(s.y-cam.y)>vh)continue;var k=tiles[y][x],c0=k.charAt(0),im;
  if(k==="pier"){var wi=IMG["wa"+(Math.floor(t*1.5+x*.37+y*.23)%3)];if(wi)cx.drawImage(wi,s.x-35,s.y-14);
   cx.fillStyle="#2e1b0d";cx.beginPath();cx.moveTo(s.x-32,s.y-4);cx.lineTo(s.x,s.y+12);cx.lineTo(s.x+32,s.y-4);cx.lineTo(s.x+32,s.y+2);cx.lineTo(s.x,s.y+18);cx.lineTo(s.x-32,s.y+2);cx.closePath();cx.fill();
   cx.fillStyle="#936230";cx.beginPath();cx.moveTo(s.x,s.y-20);cx.lineTo(s.x+32,s.y-4);cx.lineTo(s.x,s.y+12);cx.lineTo(s.x-32,s.y-4);cx.closePath();cx.fill();
   for(var q=0;q<4;q++){var f0=q/4,f1=(q+1)/4;cx.fillStyle=q%2?"rgba(60,30,8,.16)":"rgba(255,210,150,.08)";
    cx.beginPath();cx.moveTo(s.x-32*f0,s.y-20+16*f0);cx.lineTo(s.x+32-32*f0,s.y-4+16*f0);cx.lineTo(s.x+32-32*f1,s.y-4+16*f1);cx.lineTo(s.x-32*f1,s.y-20+16*f1);cx.closePath();cx.fill();
    cx.strokeStyle="rgba(35,18,6,.55)";cx.lineWidth=1.2;cx.beginPath();cx.moveTo(s.x-32*f1,s.y-20+16*f1);cx.lineTo(s.x+32-32*f1,s.y-4+16*f1);cx.stroke();}
   continue;}
  if(c0==="w"){im=IMG[k+(Math.floor(t*1.5+x*.37+y*.23)%3)];if(im)cx.drawImage(im,s.x-35,s.y-14);continue;}
  im=IMG[k];if(!im)continue;
  if(c0==="g"||c0==="d"){cx.drawImage(im,s.x-im.width/2,s.y-16);continue;}
  if(c0==="s"&&k.charAt(1)==="h"){cx.drawImage(im,s.x-34,s.y+4-39);continue;}
  cx.drawImage(im,s.x-33,s.y-13);}
 if(tgt){var s=pj(tgt.x+.5,tgt.y+.5);cx.strokeStyle="rgba(232,200,120,"+(.5+.4*Math.sin(t*6))+")";cx.lineWidth=2;cx.beginPath();cx.moveTo(s.x,s.y-15);cx.lineTo(s.x+30,s.y);cx.lineTo(s.x,s.y+15);cx.lineTo(s.x-30,s.y);cx.closePath();cx.stroke();}
 var vis=function(o){var s=pj(o.cx,o.cy);return Math.abs(s.x-cam.x)<vw+90&&s.y>cam.y-vh-60&&s.y<cam.y+vh+220;};
 var L=objs.filter(vis).concat(ores.map(function(o){return{ore:1,o:o,cx:o.cx,cy:o.cy};}),V.map(function(v){return{v:1,o:v,cx:v.x,cy:v.y};}),[{pl:1,cx:P.x,cy:P.y}]);
 L.sort(function(a,b){return(a.cx+a.cy)-(b.cx+b.cy);});
 L.forEach(function(o){
  if(o.pl)drawPlayer(t);
  else if(o.v)drawChar(o.o.c,o.o.x,o.o.y,o.o.dir,o.o.mv,t+o.o.c,nearV===o.o?o.o.name:null);
  else if(o.ore){var s=pj(o.cx,o.cy),im=IMG[o.o.i],bb=Math.sin(t*2.2+o.o.ph)*3;cx.fillStyle="rgba(0,0,0,.3)";cx.beginPath();cx.ellipse(s.x,s.y+4,9,3.5,0,0,7);cx.fill();cx.drawImage(im,s.x-im.width/2,s.y-im.height-4-bb);}
  else sprite(o,t);});
 var n=noche();
 if(n>0){cx.save();cx.setTransform(1,0,0,1,0,0);cx.fillStyle="rgba(8,14,48,"+(.55*n)+")";cx.fillRect(0,0,w,h);cx.restore();
  cx.setTransform(Z*DPR,0,0,Z*DPR,w/2-cam.x*Z*DPR,h/2-cam.y*Z*DPR);cx.globalCompositeOperation="lighter";
  objs.forEach(function(o){if(o.light||o.glow||o.i==="taberna"||o.i==="forja"||o.i==="herreria"||o.i==="muelle"){var s=pj(o.cx,o.cy),r=o.light?70:o.glow?80:95,g=cx.createRadialGradient(s.x,s.y-20,2,s.x,s.y-20,r);g.addColorStop(0,"rgba(255,170,60,"+(.5*n)+")");g.addColorStop(1,"rgba(255,170,60,0)");cx.fillStyle=g;cx.fillRect(s.x-r,s.y-20-r,r*2,r*2);}});
  FF.forEach(function(f){var a=(.5+.5*Math.sin(t*2+f.p))*n,x=P.x+f.dx+Math.sin(t*.4+f.p)*2,y=P.y+f.dy+Math.cos(t*.5+f.p)*2,s=pj(x,y);cx.fillStyle="rgba(220,255,120,"+a+")";cx.beginPath();cx.arc(s.x,s.y-10-Math.sin(t+f.p)*6,2.2,0,7);cx.fill();});
  cx.globalCompositeOperation="source-over";}
}
var FF=[];for(var i=0;i<36;i++)FF.push({dx:(R()-.5)*18,dy:(R()-.5)*18,p:R()*9});
/* ---------- lógica ---------- */
var tgt=null,DPR=1;
function cell(){return{x:Math.floor(P.x),y:Math.floor(P.y)};}
function ir(x,y){P.want=null;P.enterB=null;var p=bfs(cell(),{x:x,y:y});if(p){P.path=p;tgt={x:x,y:y};}}
function mover(dt){
 var dx=0,dy=0;
 if(keys.w||keys.arrowup){dx--;dy--;}if(keys.s||keys.arrowdown){dx++;dy++;}if(keys.a||keys.arrowleft){dx--;dy++;}if(keys.d||keys.arrowright){dx++;dy--;}
 if(dx||dy){P.path=[];tgt=null;P.want=null;P.enterB=null;var l=Math.hypot(dx,dy);dx/=l;dy/=l;}
 else if(P.path.length){var n=P.path[0],tx=n.x+.5-P.x,ty=n.y+.5-P.y,d=Math.hypot(tx,ty);if(d<.08){P.path.shift();if(!P.path.length)tgt=null;}else{dx=tx/d;dy=ty/d;}}
 P.mv=!!(dx||dy);if(!P.mv)return;P.dir=dirOf(dx,dy);
 var st=SPD*dt,nx=P.x+dx*st,ny=P.y+dy*st;
 if(!blk[Math.floor(P.y)]||blk[Math.floor(P.y)][Math.floor(nx)]===1&&!P.path.length)nx=P.x;
 if(blk[Math.floor(ny)]&&blk[Math.floor(ny)][Math.floor(nx)]===1&&!P.path.length)ny=P.y;
 nx=Math.max(.3,Math.min(W-.3,nx));ny=Math.max(.3,Math.min(H-.3,ny));
 P.x=nx;P.y=ny;if(dx-dy!==0)P.fx=(dx-dy)>0?1:-1;
}
function cerca(){
 near=null;var m=2.6;blds.forEach(function(b){var d=Math.hypot(b.cx-P.x,b.cy-P.y);if(d<m){m=d;near=b;}});
 nearV=null;var mv=1.8;V.forEach(function(v){var d=Math.hypot(v.x-P.x,v.y-P.y);if(d<mv){mv=d;nearV=v;}});
 if(P.enterB&&Math.hypot(P.enterB.cx-P.x,P.enterB.cy-P.y)<2.6){var eb=P.enterB;P.enterB=null;P.path=[];tgt=null;near=eb;vPref=false;abrir();}
 if(P.want&&Math.hypot(P.want.x-P.x,P.want.y-P.y)<1.6){hablar(P.want);P.want=null;}
 if(talk&&Math.hypot(talk.x-P.x,talk.y-P.y)>3.2)cerrar();
 var bt=$("bEntrar"),db=near?Math.hypot(near.cx-P.x,near.cy-P.y):9;vPref=!!nearV&&mv<db;
 bt.style.display=(near||nearV)?"block":"none";bt.textContent=vPref?"E · Hablar con "+nearV.name:near?"E · Entrar: "+SERV[near.id][0]:"";
 for(var i=ores.length-1;i>=0;i--)if(Math.hypot(ores[i].cx-P.x,ores[i].cy-P.y)<.7){ores.splice(i,1);got++;$("hMin").textContent="⛏ "+got;}
}
function abrir(){
 if(vPref&&nearV){hablar(nearV);return;}if(!near)return;talk=null;var id=near.id,S=SERV[id];
 if(NaradakMapa.onEnter&&NaradakMapa.onEnter(id)===false)return;
 $("pTit").textContent=S[0];$("pTxt").textContent=S[1];$("pLst").innerHTML=S[2].map(function(x){return"<li>"+x+"</li>";}).join("");$("panel").style.display="flex";
}
$("bEntrar").onclick=abrir;$("pCerrar").onclick=cerrar;
addEventListener("keydown",function(e){var k=e.key.toLowerCase();if(k==="e")abrir();else if(k==="escape")cerrar();else keys[k]=1;});
addEventListener("keyup",function(e){delete keys[e.key.toLowerCase()];});
cv.addEventListener("pointerdown",function(e){
 var r=cv.getBoundingClientRect(),sx=((e.clientX-r.left)-r.width/2)/Z+cam.x,sy=((e.clientY-r.top)-r.height/2)/Z+cam.y;
 var hit=null;V.forEach(function(v){var q=pj(v.x,v.y);if(Math.hypot(sx-q.x,sy-(q.y-20))<24)hit=v;});
 if(hit){if(Math.hypot(hit.x-P.x,hit.y-P.y)<1.6)hablar(hit);else{ir(Math.floor(hit.x),Math.floor(hit.y));P.want=hit;}return;}
 var hb=null;blds.forEach(function(b){var im=IMG[b.i],q=pj(b.cx,b.cy);if(im&&Math.abs(sx-q.x)<im.width/2&&sy<q.y+8&&sy>q.y+8-im.height&&(!hb||b.cx+b.cy>hb.cx+hb.cy))hb=b;});
 if(hb){entrarA(hb);return;}
 ir(Math.floor((sy/16+sx/32)/2),Math.floor((sy/16-sx/32)/2));
});
function entrarA(b){
 talk=null;if(Math.hypot(b.cx-P.x,b.cy-P.y)<2.6){near=b;vPref=false;abrir();return;}
 var x0=Math.round(b.cx-b.w/2),y0=Math.round(b.cy-b.h/2),best=null;
 for(var yy=y0-1;yy<=y0+b.h;yy++)for(var xx=x0-1;xx<=x0+b.w;xx++){
  if(xx>=x0&&xx<x0+b.w&&yy>=y0&&yy<y0+b.h)continue;
  var p=bfs(cell(),{x:xx,y:yy});if(p&&(!best||p.length<best.p.length))best={p:p,x:xx,y:yy};}
 if(best){P.want=null;P.path=best.p;tgt={x:best.x,y:best.y};P.enterB=b;}
}
function resize(){DPR=Math.min(2,devicePixelRatio||1);cv.width=innerWidth*DPR;cv.height=innerHeight*DPR;cx.imageSmoothingEnabled=true;Z=innerWidth<600?1.05:1.3;}
addEventListener("resize",resize);resize();
/* ---------- arranque ---------- */
var pend=Object.keys(ASSETS).length+CHARS.length;
function limpiaBorde(im){
 var w=im.width,h=im.height,c=document.createElement("canvas");c.width=w;c.height=h;
 var g=c.getContext("2d");g.drawImage(im,0,0);var d=g.getImageData(0,0,w,h),p=d.data,i,n;
 function blanco(i){var r=p[i],gg=p[i+1],b=p[i+2],mx=Math.max(r,gg,b),mn=Math.min(r,gg,b);return (r+gg+b)/3>130&&mx-mn<45;}
 function borde(x,y){var j=[[1,0],[-1,0],[0,1],[0,-1]];for(var k=0;k<4;k++){var X=x+j[k][0],Y=y+j[k][1];if(X<0||Y<0||X>=w||Y>=h||p[(Y*w+X)*4+3]<=40)return true;}return false;}
 for(n=0;n<40;n++){var kill=[];
  for(var y=0;y<h;y++)for(var x=0;x<w;x++){i=(y*w+x)*4;if(p[i+3]>0&&borde(x,y)&&blanco(i))kill.push(i);}
  if(!kill.length)break;kill.forEach(function(i){p[i+3]=0;});}
 for(i=3;i<p.length;i+=4)if(p[i]<90)p[i]=0;
 g.putImageData(d,0,0);return c;}
function limpiaSuelo(im){
 var w=im.width,h=im.height,c=document.createElement("canvas");c.width=w;c.height=h;
 var g=c.getContext("2d");g.drawImage(im,0,0);var d=g.getImageData(0,0,w,h),p=d.data,i,n,x,y;
 for(i=3;i<p.length;i+=4)if(p[i]<90)p[i]=0;
 var bad=[],good=[];
 for(i=0;i<w*h;i++){var o=i*4,r=p[o],gg=p[o+1],b=p[o+2],mx=Math.max(r,gg,b),mn=Math.min(r,gg,b);
  if(p[o+3]>0){if((r+gg+b)/3>120&&mx-mn<50)bad[i]=1;else good[i]=1;}}
 for(n=0;n<6;n++){var nw=[];
  for(y=0;y<h;y++)for(x=0;x<w;x++){i=y*w+x;if(!bad[i])continue;var sr=0,sg=0,sb=0,k=0;
   for(var dy=-1;dy<=1;dy++)for(var dx=-1;dx<=1;dx++){var X=x+dx,Y=y+dy;if(X<0||Y<0||X>=w||Y>=h)continue;var j=Y*w+X;if(good[j]){sr+=p[j*4];sg+=p[j*4+1];sb+=p[j*4+2];k++;}}
   if(k)nw.push([i,sr/k,sg/k,sb/k]);}
  if(!nw.length)break;
  nw.forEach(function(q){var o=q[0]*4;p[o]=q[1];p[o+1]=q[2];p[o+2]=q[3];p[o+3]=255;bad[q[0]]=0;good[q[0]]=1;});}
 for(i=0;i<w*h;i++)if(bad[i])p[i*4+3]=0;
 g.putImageData(d,0,0);return c;}
Object.keys(ASSETS).forEach(function(k){var im=new Image();im.onload=function(){if(/^(t\d|b\d|r\d|f\d|stump|log|mush|fence)$/.test(k)){try{IMG[k]=limpiaBorde(im);}catch(e){}}else if(/^[gd]\d+$/.test(k)){try{IMG[k]=limpiaSuelo(im);}catch(e){}}if(--pend===0)iniciar();};im.src=ASSETS[k][2];IMG[k]=im;});
CHARS.forEach(function(d,i){var im=new Image();im.onload=function(){if(--pend===0)iniciar();};im.src=d;CIMG[i]=im;});
function iniciar(){
 $("panel").style.backgroundImage="url("+ASSETS.panel[2]+")";$("intro").style.backgroundImage="url("+ASSETS.perg[2]+")";$("intro").style.display="flex";
 /* El personaje se elige al crear la partida (naradak_pc); aquí ya no hay selector */
 $("intro").style.display="none";spawnV();
 addEventListener("message",function(e){var d=e.data;if(d&&d.naradak==="t"){tmin=(d.dia-1)*1440+d.min;}});
 var last=performance.now();
 (function loop(now){var dt=Math.min(.05,(now-last)/1000);last=now;T+=dt;tmin+=dt*MIN_S;
  mover(dt);V.forEach(function(v){moverV(v,dt);});cerca();var m=Math.floor(tmin%1440);$("hHora").textContent="Día "+(1+Math.floor(tmin/1440))+" · "+String(Math.floor(m/60)).padStart(2,"0")+":"+String(m%60).padStart(2,"0")+(noche()>.5?" 🌙":" ☀");
  draw(T);requestAnimationFrame(loop);})(last);
}
})();
