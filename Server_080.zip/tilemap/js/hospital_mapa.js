"use strict";
/* THE CHRONICLES OF NARADAK — Interior del Hospital (2.5D isométrico).
   Mensajes -> juego: {naradak:"ready"} · {naradak:"npc",id:"campana|rango|vender|profesion"} · {naradak:"exit"} */
(function(){
var W=12,H=9,WH=120,TW=32,TH=16,SPD=3.2;
var cv=document.getElementById("gre"),cx=cv.getContext("2d"),$=function(i){return document.getElementById(i);};
var IM={},CI=[],DPR=1,Z=1,T=0;
var PC=(function(){try{var v=parseInt(localStorage.getItem("naradak_pc"),10);return v>=0&&v<CHARS.length&&CHARS_INFO[v].k==="humano"?v:4;}catch(e){return 4;}})();
var EMB=parent!==window;
function pj(x,y){return{x:(x-y)*TW,y:(x+y)*TH};}
function dirOf(dx,dy){var sx=dx-dy,sy=dx+dy;return Math.abs(sx)>Math.abs(sy)?(sx<0?1:2):(sy>0?0:3);}
/* ---------- NPC fijos ---------- */
var NP=[
 {id:"sanar",c:16,alt:0,x:3.6,y:3.0,n:"Dr. Alaric",r:"Médico",verbo:"Sanar heridas",ico:"❤"},
 {id:"recurso",c:3,alt:23,x:8.2,y:.55,n:"Lyra",r:"Boticaria",verbo:"Reponer recurso",ico:"✦"},
 {id:"purga",c:1,alt:9,x:10.4,y:3.6,n:"Madre Elara",r:"Sacerdotisa",verbo:"Purgar maldiciones",ico:"☠"}
];
var DEC=[{c:12,x:5.3,y:6.1,dir:1},{c:10,x:7.0,y:6.1,dir:2}];
NP.forEach(function(p){p.dir=0;p.cell=[Math.floor(p.x),Math.floor(p.y)];if(p.c===PC)p.c=p.alt;});
DEC.forEach(function(p){if(p.c===PC)p.c=6;});
/* ---------- colisiones ---------- */
var blk=[];for(var y=0;y<H;y++){blk[y]=[];for(var x=0;x<W;x++)blk[y][x]=0;}
function bl(x0,y0,x1,y1){for(var y=y0;y<=y1;y++)for(var x=x0;x<=x1;x++)if(blk[y]&&x>=0&&x<W)blk[y][x]=1;}
bl(1,0,1,1);bl(3,0,3,1);bl(5,0,5,1);bl(7,1,10,1);bl(11,3,11,4);bl(5,6,6,6);bl(0,3,0,4);bl(10,5,10,5);bl(11,7,11,7);bl(8,3,8,3);
NP.forEach(function(p){blk[p.cell[1]][p.cell[0]]=1;});DEC.forEach(function(p){blk[Math.floor(p.y)][Math.floor(p.x)]=1;});
function bfs(a,b){
 if(b.x<0||b.y<0||b.x>=W||b.y>=H||blk[b.y][b.x])return null;
 var q=[a],prev={},k=function(p){return p.x+","+p.y;};prev[k(a)]=null;
 while(q.length){var c=q.shift();if(c.x===b.x&&c.y===b.y)break;
  [[1,0],[-1,0],[0,1],[0,-1]].forEach(function(d){var n={x:c.x+d[0],y:c.y+d[1]};if(n.x<0||n.y<0||n.x>=W||n.y>=H||blk[n.y][n.x]||(k(n) in prev))return;prev[k(n)]=c;q.push(n);});}
 if(!(k(b) in prev))return null;var path=[],c=b;while(c){path.unshift(c);c=prev[k(c)];}path.shift();return path;
}
/* ---------- jugador ---------- */
var P={x:1.7,y:7.8,dir:0,mv:0,path:[],want:null},keys={},tgt=null,near=null;
function cell(){return{x:Math.max(0,Math.min(W-1,Math.floor(P.x))),y:Math.max(0,Math.min(H-1,Math.floor(P.y)))};}
function drawChar(c,x,y,dir,mv,t){
 var im=CI[c];if(!im)return;var fw=CHARS_INFO[c].w,fh=CHARS_INFO[c].h,s=pj(x,y),f=mv?[1,0,1,2][Math.floor(t*8)%4]:1;
 cx.save();cx.translate(s.x,s.y+4);
 cx.fillStyle="rgba(0,0,0,.3)";cx.beginPath();cx.ellipse(0,0,10,4,0,0,7);cx.fill();
 cx.imageSmoothingEnabled=false;cx.drawImage(im,f*fw,dir*fh,fw,fh,-fw/2,-(fh-3),fw,fh);cx.restore();
}
function mover(dt){
 var dx=0,dy=0;
 if(keys.w||keys.arrowup){dx--;dy--;}if(keys.s||keys.arrowdown){dx++;dy++;}if(keys.a||keys.arrowleft){dx--;dy++;}if(keys.d||keys.arrowright){dx++;dy--;}
 var manual=!!(dx||dy);
 if(manual){P.path=[];tgt=null;P.want=null;var l=Math.hypot(dx,dy);dx/=l;dy/=l;}
 else if(P.path.length){var n=P.path[0],tx=n.x+.5-P.x,ty=n.y+.5-P.y,d=Math.hypot(tx,ty);if(d<.08){P.path.shift();if(!P.path.length)tgt=null;}else{dx=tx/d;dy=ty/d;}}
 P.mv=!!(dx||dy);if(!P.mv)return;P.dir=dirOf(dx,dy);
 var st=SPD*dt,nx=P.x+dx*st,ny=P.y+dy*st;
 if(manual){
  var cxn=Math.floor(nx),cyo=Math.floor(P.y),cxo=Math.floor(P.x),cyn=Math.floor(ny);
  if(cxn>=0&&cxn<W&&cyo>=0&&cyo<H&&blk[cyo][cxn])nx=P.x;
  if(cxo>=0&&cxo<W&&cyn>=0&&cyn<H&&blk[cyn][Math.floor(nx)])ny=P.y;
 }
 P.x=Math.max(.3,Math.min(W-.3,nx));P.y=Math.max(.3,Math.min(H-.3,ny));
}
/* ---------- interacción ---------- */
var DIST=3.0;
function abrir(p){
 if(!p)return;keys={};P.path=[];tgt=null;P.want=null;
 if(EMB)parent.postMessage({naradak:"npc",id:p.id},"*");
 else toast("Abriría: "+p.verbo);
}
function salir(){keys={};if(EMB)parent.postMessage({naradak:"exit"},"*");else toast("Salida a la ciudad");}
var _tt=0;function toast(t){var e=$("toast");e.textContent=t;e.style.display="block";clearTimeout(_tt);_tt=setTimeout(function(){e.style.display="none";},1800);}
function cerca(){
 near=null;var m=DIST;NP.forEach(function(p){var d=Math.hypot(p.x-P.x,p.y-P.y);if(d<m){m=d;near=p;}});
 NP.forEach(function(p){if(Math.hypot(p.x-P.x,p.y-P.y)<DIST)p.dir=dirOf(P.x-p.x,P.y-p.y);});
 if(P.want&&Math.hypot(P.want.x-P.x,P.want.y-P.y)<DIST-.05){var w=P.want;P.want=null;abrir(w);return;}
 var b=$("bHab");b.style.display=near?"block":"none";if(near)b.textContent="E · "+near.n+" — "+near.verbo;
 if(P.x<.85&&P.y>6.9&&P.y<8.7){salir();P.x=1.7;P.y=7.8;P.path=[];}
}
function irA(p){
 if(Math.hypot(p.x-P.x,p.y-P.y)<DIST-.05){abrir(p);return;}
 var best=null,c0=cell();
 for(var yy=0;yy<H;yy++)for(var xx=0;xx<W;xx++){
  if(blk[yy][xx])continue;var d=Math.hypot(xx+.5-p.x,yy+.5-p.y);if(d>DIST-.05)continue;
  var pa=bfs(c0,{x:xx,y:yy});if(pa&&(!best||pa.length<best.pa.length))best={pa:pa,x:xx,y:yy};}
 if(best){P.path=best.pa;tgt={x:best.x,y:best.y};P.want=p;}
}
$("bHab").onclick=function(){abrir(near);};
addEventListener("keydown",function(e){var k=e.key.toLowerCase();if(k==="e"||k==="enter"){abrir(near);}else if(k==="escape"){salir();}else{keys[k]=1;if(k.indexOf("arrow")===0)e.preventDefault();}});
addEventListener("keyup",function(e){delete keys[e.key.toLowerCase()];});
addEventListener("blur",function(){keys={};});
cv.addEventListener("pointerdown",function(e){
 var r=cv.getBoundingClientRect(),wx=((e.clientX-r.left)-r.width/2)/Z+CAMX,wy=((e.clientY-r.top)-r.height/2)/Z+CAMY;
 var hit=null,bd=30;NP.forEach(function(p){var q=pj(p.x,p.y),d=Math.hypot(wx-q.x,wy-(q.y-22));if(d<bd){bd=d;hit=p;}});
 if(hit){irA(hit);return;}
 var u=Math.floor((wy/TH+wx/TW)/2),v=Math.floor((wy/TH-wx/TW)/2);
 var pa=bfs(cell(),{x:u,y:v});if(pa){P.want=null;P.path=pa;tgt={x:u,y:v};}
});
/* ---------- capa estática (suelo, paredes, decorado) ---------- */
var CAMX=(W-H)*TW/2,CAMY=((W+H)*TH-WH)/2,SX0=-(H*TW)-30,SY0=-WH-40,SW=(W+H)*TW+60,SH=(W+H)*TH+WH+80,STAT=null;
function seed(s){return function(){s|=0;s=s+0x6D2B79F5|0;var t=Math.imul(s^s>>>15,1|s);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296;};}
function cruz(g,cx0,y0,sz,col){g.fillStyle=col;g.fillRect(cx0-.07*sz,y0,.14*sz,sz*18);g.fillRect(cx0-.22*sz,y0+sz*5,.44*sz,sz*5);}
function construir(){
 var K=2,c=document.createElement("canvas");c.width=SW*K;c.height=SH*K;var g=c.getContext("2d");
 g.scale(K,K);g.translate(-SX0,-SY0);g.imageSmoothingEnabled=true;
 var R=seed(33);
 /* suelo de losas claras */
 g.save();g.transform(TW,TH,-TW,TH,0,0);
 var pal=["#9a9384","#a29b8b","#908a7c","#9c9686","#a59e8c","#88826f"];
 for(var y=0;y<H;y++)for(var x=0;x<W;x++){
  g.fillStyle=pal[Math.floor(R()*pal.length)];g.fillRect(x,y,1,1);
  var cut=.3+R()*.4,hz=R()<.5;g.fillStyle="rgba(0,0,0,.22)";
  if(hz)g.fillRect(x,y+cut,1,.04);else g.fillRect(x+cut,y,.04,1);
  g.fillStyle="rgba(255,250,230,"+(.04+R()*.05)+")";g.fillRect(x+.05,y+.05,.9,.4);
 }
 g.strokeStyle="rgba(30,25,18,.4)";g.lineWidth=.04;
 for(var i=0;i<=W;i++){g.beginPath();g.moveTo(i,0);g.lineTo(i,H);g.stroke();}
 for(var j=0;j<=H;j++){g.beginPath();g.moveTo(0,j);g.lineTo(W,j);g.stroke();}
 /* alfombra con cruz de sanación */
 g.fillStyle="#e8e2d0";g.fillRect(3.2,3.9,5.0,2.4);g.strokeStyle="#6a9a78";g.lineWidth=.08;g.strokeRect(3.3,4.0,4.8,2.2);
 g.fillStyle="#4f8a62";g.fillRect(5.45,4.35,.5,1.5);g.fillRect(4.95,4.85,1.5,.5);
 /* alfombra del mostrador y del altar */
 g.fillStyle="#2f5a44";g.fillRect(7.3,1.9,3.4,.9);g.strokeStyle="#d8c690";g.lineWidth=.04;g.strokeRect(7.4,2.0,3.2,.7);
 g.fillStyle="#d8d0e0";g.beginPath();g.ellipse(10.4,3.9,.9,.6,0,0,7);g.fill();g.strokeStyle="#7a5aa0";g.lineWidth=.05;g.stroke();
 /* felpudo */
 g.fillStyle="#3a3a2c";g.fillRect(.15,7.0,.95,1.7);g.strokeStyle="#d8c690";g.lineWidth=.04;g.strokeRect(.25,7.1,.75,1.5);
 var gr=g.createLinearGradient(0,0,0,1.4);gr.addColorStop(0,"rgba(0,0,0,.4)");gr.addColorStop(1,"rgba(0,0,0,0)");g.fillStyle=gr;g.fillRect(0,0,W,1.4);
 var gl=g.createLinearGradient(0,0,1.4,0);gl.addColorStop(0,"rgba(0,0,0,.4)");gl.addColorStop(1,"rgba(0,0,0,0)");g.fillStyle=gl;g.fillRect(0,0,1.4,H);
 g.restore();
 /* paredes de yeso con vigas */
 function pared(len,shade){
  var gp=g.createLinearGradient(0,-WH,0,0);gp.addColorStop(0,"rgb("+Math.round(196*shade)+","+Math.round(188*shade)+","+Math.round(166*shade)+")");gp.addColorStop(1,"rgb("+Math.round(226*shade)+","+Math.round(218*shade)+","+Math.round(194*shade)+")");
  g.fillStyle=gp;g.fillRect(0,-WH,len,WH);
  for(var n=0;n<60;n++){g.fillStyle="rgba(90,70,40,"+(.03+R()*.05)+")";g.fillRect(R()*len,-WH+R()*(WH-40),.1+R()*.3,1+R()*2);}
  g.fillStyle="rgba(60,90,70,.55)";g.fillRect(0,-40,len,40);
  g.fillStyle="rgba(255,255,255,.12)";for(var k=0;k<len;k+=.5)g.fillRect(k,-40,.02,40);
  g.fillStyle="#3b2412";g.fillRect(0,-43,len,4);g.fillStyle="rgba(255,230,170,.25)";g.fillRect(0,-43,len,1);
  g.fillStyle="#2a170a";g.fillRect(0,-4,len,4);
  g.fillStyle="#3b2412";g.fillRect(0,-WH,len,9);g.fillStyle="rgba(255,230,170,.2)";g.fillRect(0,-WH,len,1.5);
  for(var b=0;b<=len;b+=Math.max(2.5,len/4)){g.fillStyle="#3b2412";g.fillRect(b-.12,-WH,.24,WH);g.fillStyle="rgba(255,230,170,.16)";g.fillRect(b-.12,-WH,.04,WH);}
  g.fillStyle="#2e1a0a";g.fillRect(len-.24,-WH,.24,WH);
 }
 g.save();g.transform(TW,TH,0,1,0,0);pared(W,1);
 /* cruces de sanación sobre las camas */
 [1.6,3.6,5.6].forEach(function(u){g.fillStyle="#2a170a";g.fillRect(u-.45,-100,.9,34);g.fillStyle="#f1ecdc";g.fillRect(u-.4,-97,.8,28);cruz(g,u,-94,1.0,"#4f8a62");});
 /* estantes de medicinas en la pared (decoración) */
 g.fillStyle="#2a170a";g.fillRect(7.0,-90,3.8,3);
 for(var i=0;i<9;i++){var cu=7.15+i*.4;g.fillStyle=["#5aa0c8","#a8d070","#d06a6a","#e0c060","#9a70c8"][i%5];g.fillRect(cu,-90-9-(i%3)*2,.18,9+(i%3)*2);}
 /* ventana alta con luz */
 g.fillStyle="#2a170a";g.fillRect(11.05,-98,.7,50);g.fillStyle="#bcd4e8";g.fillRect(11.12,-92,.56,38);
 g.fillStyle="rgba(255,255,255,.35)";g.fillRect(11.12,-92,.56,15);g.fillStyle="#2a170a";g.fillRect(11.38,-92,.05,38);g.fillRect(11.12,-74,.56,3);
 g.restore();
 g.save();g.transform(TW,-TH,0,1,0,0);g.save();g.translate(-H,0);pared(H,.84);g.restore();
 [-2.2,-5.2].forEach(function(u){g.fillStyle="#2a170a";g.fillRect(u-.45,-100,.9,34);g.fillStyle="#f1ecdc";g.fillRect(u-.4,-97,.8,28);cruz(g,u,-94,1.0,"#4f8a62");});
 (function(){var u0=-8.45,w=1.35,h=84;
  g.fillStyle="#1d1006";g.fillRect(u0-.12,-h-8,w+.24,h+8);
  var gd=g.createLinearGradient(0,-h,0,0);gd.addColorStop(0,"#6a4a22");gd.addColorStop(1,"#463018");g.fillStyle=gd;g.fillRect(u0,-h,w,h);
  g.fillStyle="rgba(0,0,0,.3)";for(var i=1;i<4;i++)g.fillRect(u0+i*w/4,-h,.03,h);
  g.fillStyle="#f1ecdc";g.fillRect(u0+w*.5-.04,-h*.8,.08,22);g.fillRect(u0+w*.5-.17,-h*.8+7,.34,.08*8);
  g.fillStyle="#c9923c";g.beginPath();g.ellipse(u0+w*.8,-h*.42,.07,2.4,0,0,7);g.fill();
  g.fillStyle="#120a04";g.fillRect(u0-.12,-h-8,w+.24,6);
 })();
 g.restore();
 g.fillStyle="#2a170a";g.fillRect(-2,-WH,4,WH);
 STAT=c;
}
function spr(k,x,y,s,dy,mir){
 var im=IM[k],p=pj(x,y);cx.save();cx.translate(p.x,p.y+8+(dy||0));if(mir)cx.scale(-1,1);
 cx.drawImage(im,-im.width*s/2,-im.height*s,im.width*s,im.height*s);cx.restore();
}
function caja3d(x0,y0,x1,y1,h,cT,cL,cR){
 function P3(x,y,z){var p=pj(x,y);return[p.x,p.y-z];}
 function poly(a,col){cx.beginPath();a.forEach(function(p,i){i?cx.lineTo(p[0],p[1]):cx.moveTo(p[0],p[1]);});cx.closePath();cx.fillStyle=col;cx.fill();}
 poly([P3(x0,y1,0),P3(x1,y1,0),P3(x1,y1,h),P3(x0,y1,h)],cL);
 poly([P3(x1,y0,0),P3(x1,y1,0),P3(x1,y1,h),P3(x1,y0,h)],cR);
 poly([P3(x0,y0,h),P3(x1,y0,h),P3(x1,y1,h),P3(x0,y1,h)],cT);
 cx.strokeStyle="rgba(255,230,170,.45)";cx.lineWidth=1;cx.beginPath();var a=P3(x0,y1,h),b=P3(x1,y1,h),c=P3(x1,y0,h);cx.moveTo(a[0],a[1]);cx.lineTo(b[0],b[1]);cx.lineTo(c[0],c[1]);cx.stroke();
}
function lista(){
 var L=[];
 L.push({k:1.9,f:function(){spr("cama",1.6,1.5,1.45);}});
 L.push({k:3.9,f:function(){spr("cama",3.6,1.5,1.45);}});
 L.push({k:5.9,f:function(){spr("cama",5.6,1.5,1.45);}});
 L.push({k:9.9,f:function(){caja3d(7.0,1.0,10.7,1.85,28,"#7a5a34","#5a3f20","#3e2a14");
  spr("mesa_al",9.7,1.6,.8,-28);spr("jarra",10.3,1.5,.9,-28);}});
 L.push({k:6.5,f:function(){spr("estante",6.4,.7,1.4);}});
 L.push({k:11,f:function(){spr("estante2",11.3,.8,1.4);}});
 L.push({k:6.0,f:function(){spr("mesita",1.2,5.0,1.2);spr("balde",1.0,4.0,1.3);}});
 L.push({k:12.0,f:function(){spr("cesta",6.4,4.9,1.1);}});
 L.push({k:14.6,f:function(){spr("mesa_al",11.3,3.7,1.1);spr("anto_p",10.6,3.0,1.3);}});
 L.push({k:15.6,f:function(){spr("anto_p",9.8,4.6,1.3);spr("bandera",11.45,6.0,1.25);}});
 L.push({k:12.2,f:function(){spr("banco",5.9,6.6,1.15);}});
 L.push({k:14.4,f:function(){spr("sacos",11.2,8.0,1.0);spr("plantas",10.4,8.3,1.2);}});
 L.push({k:11.5,f:function(){spr("taburete",8.8,3.6,1.1);}});
 L.push({k:6.9,f:function(){spr("farol",.9,2.3,1.0);}});
 NP.forEach(function(p){L.push({k:p.x+p.y,f:function(){drawChar(p.c,p.x,p.y,p.dir,0,T);}});});
 DEC.forEach(function(p){L.push({k:p.x+p.y,f:function(){drawChar(p.c,p.x,p.y,p.dir,0,T);}});});
 L.push({k:0,pl:1});
 return L;
}
var OBJ=null;
/* ---------- dibujo ---------- */
function etiqueta(txt,x,y,hl){cx.save();cx.font="700 "+(hl?11:10)+"px Cinzel,serif";cx.textAlign="center";cx.lineWidth=3;cx.strokeStyle="rgba(20,12,4,.9)";cx.strokeText(txt,x,y);cx.fillStyle=hl?"#ffe9a8":"#f5e6c0";cx.fillText(txt,x,y);cx.restore();}
function marcadores(t){
 NP.forEach(function(p){
  var s=pj(p.x,p.y),bob=Math.sin(t*3+p.x)*2,hl=near===p;
  cx.save();cx.translate(s.x,s.y);
  cx.font="16px serif";cx.textAlign="center";cx.fillText(p.ico,0,-58+bob);
  if(hl){etiqueta(p.n,0,-74);cx.font="10px Karla,sans-serif";cx.fillStyle="#d4c9b8";cx.lineWidth=3;cx.strokeStyle="rgba(20,12,4,.9)";cx.strokeText(p.r,0,-84);cx.fillText(p.r,0,-84);}
  cx.restore();
 });
 var d=pj(0,7.8);cx.save();cx.translate(d.x,d.y-96);etiqueta("Salida",0,0,P.x<2.2&&P.y>6.6);cx.restore();
}
function luces(t){
 cx.save();cx.setTransform(1,0,0,1,0,0);cx.fillStyle="rgba(20,30,40,.10)";cx.fillRect(0,0,cv.width,cv.height);cx.restore();
 cx.globalCompositeOperation="lighter";
 var fl=.9+.1*Math.sin(t*7)+.04*Math.sin(t*19);
 function glow(x,y,z,r,a,rgb){var s=pj(x,y),g=cx.createRadialGradient(s.x,s.y-z,2,s.x,s.y-z,r);g.addColorStop(0,"rgba("+rgb+","+(a*fl)+")");g.addColorStop(1,"rgba("+rgb+",0)");cx.fillStyle=g;cx.fillRect(s.x-r,s.y-z-r,r*2,r*2);}
 glow(11.4,.6,60,120,.25,"200,225,255");
 glow(10.6,3.0,36,70,.35,"210,170,255");glow(9.8,4.6,36,70,.3,"210,170,255");glow(11.3,3.7,30,60,.25,"190,140,255");
 glow(8.6,1.5,40,110,.2,"255,225,150");glow(.9,2.3,40,80,.25,"255,200,110");glow(.3,7.8,70,90,.2,"255,200,120");
 glow(5.5,4.9,30,150,.12,"150,230,170");
 cx.globalCompositeOperation="source-over";
}
function draw(t){
 var w=cv.width,h=cv.height;cx.setTransform(1,0,0,1,0,0);cx.fillStyle="#12100c";cx.fillRect(0,0,w,h);
 cx.setTransform(Z*DPR,0,0,Z*DPR,w/2-CAMX*Z*DPR,h/2-CAMY*Z*DPR);
 cx.imageSmoothingEnabled=true;cx.drawImage(STAT,SX0,SY0,SW,SH);
 if(tgt){var s=pj(tgt.x+.5,tgt.y+.5);cx.strokeStyle="rgba(232,200,120,"+(.5+.4*Math.sin(t*6))+")";cx.lineWidth=2;cx.beginPath();cx.moveTo(s.x,s.y-8);cx.lineTo(s.x+16,s.y);cx.lineTo(s.x,s.y+8);cx.lineTo(s.x-16,s.y);cx.closePath();cx.stroke();}
 var L=OBJ.slice();L.forEach(function(o){if(o.pl)o.k=P.x+P.y;});L.sort(function(a,b){return a.k-b.k;});
 L.forEach(function(o){if(o.pl)drawChar(PC,P.x,P.y,P.dir,P.mv,T);else o.f();});
 luces(t);marcadores(t);
}
/* ---------- arranque ---------- */
function resize(){
 DPR=Math.min(2,devicePixelRatio||1);cv.width=innerWidth*DPR;cv.height=innerHeight*DPR;
 var aw=innerWidth-12,ah=innerHeight-110,rw=(W+H)*TW+30,rh=(W+H)*TH+WH+30;
 Z=Math.max(.45,Math.min(aw/rw,ah/rh,1.7));
}
addEventListener("resize",resize);resize();
var keysA=Object.keys(HOSASSETS),pend=keysA.length+CHARS.length;
function ok(){if(--pend===0)iniciar();}
keysA.forEach(function(k){var im=new Image();im.onload=ok;im.src=HOSASSETS[k];IM[k]=im;});
CHARS.forEach(function(d,i){var im=new Image();im.onload=ok;im.src=d;CI[i]=im;});
function iniciar(){
 construir();OBJ=lista();
 if(EMB)parent.postMessage({naradak:"ready"},"*");
 var last=performance.now();
 (function loop(now){var dt=Math.min(.05,(now-last)/1000);last=now;T+=dt;
  mover(dt);cerca();draw(T);requestAnimationFrame(loop);})(last);
}
})();
