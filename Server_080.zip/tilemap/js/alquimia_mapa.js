"use strict";
/* THE CHRONICLES OF NARADAK — Interior del Alquimista (2.5D isométrico).
   Mensajes -> juego: {naradak:"ready"} · {naradak:"npc",id:"campana|rango|vender|profesion"} · {naradak:"exit"} */
(function(){
var W=12,H=9,WH=120,TW=32,TH=16,SPD=3.2;
var cv=document.getElementById("gre"),cx=cv.getContext("2d"),$=function(i){return document.getElementById(i);};
var IM={},CI=[],DPR=1,Z=1,T=0;
var PC=(function(){try{var v=parseInt(localStorage.getItem("naradak_pc"),10);return v>=0&&v<CHARS.length&&CHARS_INFO[v].k==="humano"?v:4;}catch(e){return 4;}})();
var EMB=parent!==window;
function pj(x,y){return{x:(x-y)*TW,y:(x+y)*TH};}
function dirOf(dx,dy){var sx=dx-dy,sy=dx+dy;return Math.abs(sx)>Math.abs(sy)?(sx<0?1:2):(sy>0?0:3);}
/* ---------- NPC fijos ---------- */
var NP=[
 {id:"craftear",c:13,alt:5,x:3.8,y:.55,n:"Maestra Veyra",r:"Alquimista",verbo:"Craftear pociones",ico:"⚗"},
 {id:"transmutar",c:19,alt:2,x:7.9,y:5.1,n:"Ilan",r:"Transmutador",verbo:"Transmutar materiales",ico:"✨"}
];
var DEC=[];
NP.forEach(function(p){p.dir=0;p.cell=[Math.floor(p.x),Math.floor(p.y)];if(p.c===PC)p.c=p.alt;});
/* ---------- colisiones ---------- */
var blk=[];for(var y=0;y<H;y++){blk[y]=[];for(var x=0;x<W;x++)blk[y][x]=0;}
function bl(x0,y0,x1,y1){for(var y=y0;y<=y1;y++)for(var x=x0;x<=x1;x++)if(blk[y]&&x>=0&&x<W)blk[y][x]=1;}
bl(2,1,5,1);bl(6,0,6,0);bl(1,0,1,0);bl(9,0,9,0);bl(7,2,7,2);bl(6,4,6,4);bl(9,4,9,4);bl(6,6,6,6);bl(9,6,9,6);bl(11,3,11,6);bl(0,4,0,4);bl(2,7,3,7);
NP.forEach(function(p){blk[p.cell[1]][p.cell[0]]=1;});
function bfs(a,b){
 if(b.x<0||b.y<0||b.x>=W||b.y>=H||blk[b.y][b.x])return null;
 var q=[a],prev={},k=function(p){return p.x+","+p.y;};prev[k(a)]=null;
 while(q.length){var c=q.shift();if(c.x===b.x&&c.y===b.y)break;
  [[1,0],[-1,0],[0,1],[0,-1]].forEach(function(d){var n={x:c.x+d[0],y:c.y+d[1]};if(n.x<0||n.y<0||n.x>=W||n.y>=H||blk[n.y][n.x]||(k(n) in prev))return;prev[k(n)]=c;q.push(n);});}
 if(!(k(b) in prev))return null;var path=[],c=b;while(c){path.unshift(c);c=prev[k(c)];}path.shift();return path;
}
/* ---------- jugador ---------- */
var P={x:1.7,y:7.8,dir:0,mv:0,path:[],want:null},keys={},tgt=null,near=null;
function cell(){return{x:Math.max(0,Math.min(W-1,Math.floor(P.x))),y:Math.max(0,Math.min(H-1,Math.floor(P.y)))};}
function drawChar(c,x,y,dir,mv,t){
 var im=CI[c];if(!im)return;var fw=CHARS_INFO[c].w,fh=CHARS_INFO[c].h,s=pj(x,y),f=mv?[1,0,1,2][Math.floor(t*8)%4]:1;
 cx.save();cx.translate(s.x,s.y+4);
 cx.fillStyle="rgba(0,0,0,.3)";cx.beginPath();cx.ellipse(0,0,10,4,0,0,7);cx.fill();
 cx.imageSmoothingEnabled=false;cx.drawImage(im,f*fw,dir*fh,fw,fh,-fw/2,-(fh-3),fw,fh);cx.restore();
}
function mover(dt){
 var dx=0,dy=0;
 if(keys.w||keys.arrowup){dx--;dy--;}if(keys.s||keys.arrowdown){dx++;dy++;}if(keys.a||keys.arrowleft){dx--;dy++;}if(keys.d||keys.arrowright){dx++;dy--;}
 var manual=!!(dx||dy);
 if(manual){P.path=[];tgt=null;P.want=null;var l=Math.hypot(dx,dy);dx/=l;dy/=l;}
 else if(P.path.length){var n=P.path[0],tx=n.x+.5-P.x,ty=n.y+.5-P.y,d=Math.hypot(tx,ty);if(d<.08){P.path.shift();if(!P.path.length)tgt=null;}else{dx=tx/d;dy=ty/d;}}
 P.mv=!!(dx||dy);if(!P.mv)return;P.dir=dirOf(dx,dy);
 var st=SPD*dt,nx=P.x+dx*st,ny=P.y+dy*st;
 if(manual){
  var cxn=Math.floor(nx),cyo=Math.floor(P.y),cxo=Math.floor(P.x),cyn=Math.floor(ny);
  if(cxn>=0&&cxn<W&&cyo>=0&&cyo<H&&blk[cyo][cxn])nx=P.x;
  if(cxo>=0&&cxo<W&&cyn>=0&&cyn<H&&blk[cyn][Math.floor(nx)])ny=P.y;
 }
 P.x=Math.max(.3,Math.min(W-.3,nx));P.y=Math.max(.3,Math.min(H-.3,ny));
}
/* ---------- interacción ---------- */
var DIST=3.0;
function abrir(p){
 if(!p)return;keys={};P.path=[];tgt=null;P.want=null;
 if(EMB)parent.postMessage({naradak:"npc",id:p.id},"*");
 else toast("Abriría: "+p.verbo);
}
function salir(){keys={};if(EMB)parent.postMessage({naradak:"exit"},"*");else toast("Salida a la ciudad");}
var _tt=0;function toast(t){var e=$("toast");e.textContent=t;e.style.display="block";clearTimeout(_tt);_tt=setTimeout(function(){e.style.display="none";},1800);}
function cerca(){
 near=null;var m=DIST;NP.forEach(function(p){var d=Math.hypot(p.x-P.x,p.y-P.y);if(d<m){m=d;near=p;}});
 NP.forEach(function(p){if(Math.hypot(p.x-P.x,p.y-P.y)<DIST)p.dir=dirOf(P.x-p.x,P.y-p.y);});
 if(P.want&&Math.hypot(P.want.x-P.x,P.want.y-P.y)<DIST-.05){var w=P.want;P.want=null;abrir(w);return;}
 var b=$("bHab");b.style.display=near?"block":"none";if(near)b.textContent="E · "+near.n+" — "+near.verbo;
 if(P.x<.85&&P.y>6.9&&P.y<8.7){salir();P.x=1.7;P.y=7.8;P.path=[];}
}
function irA(p){
 if(Math.hypot(p.x-P.x,p.y-P.y)<DIST-.05){abrir(p);return;}
 var best=null,c0=cell();
 for(var yy=0;yy<H;yy++)for(var xx=0;xx<W;xx++){
  if(blk[yy][xx])continue;var d=Math.hypot(xx+.5-p.x,yy+.5-p.y);if(d>DIST-.05)continue;
  var pa=bfs(c0,{x:xx,y:yy});if(pa&&(!best||pa.length<best.pa.length))best={pa:pa,x:xx,y:yy};}
 if(best){P.path=best.pa;tgt={x:best.x,y:best.y};P.want=p;}
}
$("bHab").onclick=function(){abrir(near);};
addEventListener("keydown",function(e){var k=e.key.toLowerCase();if(k==="e"||k==="enter"){abrir(near);}else if(k==="escape"){salir();}else{keys[k]=1;if(k.indexOf("arrow")===0)e.preventDefault();}});
addEventListener("keyup",function(e){delete keys[e.key.toLowerCase()];});
addEventListener("blur",function(){keys={};});
cv.addEventListener("pointerdown",function(e){
 var r=cv.getBoundingClientRect(),wx=((e.clientX-r.left)-r.width/2)/Z+CAMX,wy=((e.clientY-r.top)-r.height/2)/Z+CAMY;
 var hit=null,bd=30;NP.forEach(function(p){var q=pj(p.x,p.y),d=Math.hypot(wx-q.x,wy-(q.y-22));if(d<bd){bd=d;hit=p;}});
 if(hit){irA(hit);return;}
 var u=Math.floor((wy/TH+wx/TW)/2),v=Math.floor((wy/TH-wx/TW)/2);
 var pa=bfs(cell(),{x:u,y:v});if(pa){P.want=null;P.path=pa;tgt={x:u,y:v};}
});
/* ---------- capa estática (suelo, paredes, decorado) ---------- */
var CAMX=(W-H)*TW/2,CAMY=((W+H)*TH-WH)/2,SX0=-(H*TW)-30,SY0=-WH-40,SW=(W+H)*TW+60,SH=(W+H)*TH+WH+80,STAT=null;
function seed(s){return function(){s|=0;s=s+0x6D2B79F5|0;var t=Math.imul(s^s>>>15,1|s);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296;};}
function construir(){
 var K=2,c=document.createElement("canvas");c.width=SW*K;c.height=SH*K;var g=c.getContext("2d");
 g.scale(K,K);g.translate(-SX0,-SY0);g.imageSmoothingEnabled=true;
 var R=seed(77);
 g.save();g.transform(TW,TH,-TW,TH,0,0);
 var pal=["#4a4658","#54506a","#403c4e","#4e4a60","#585270","#3a3648"];
 for(var y=0;y<H;y++)for(var x=0;x<W;x++){
  g.fillStyle=pal[Math.floor(R()*pal.length)];g.fillRect(x,y,1,1);
  var cut=.3+R()*.4,hz=R()<.5;g.fillStyle="rgba(0,0,0,.32)";
  if(hz)g.fillRect(x,y+cut,1,.045);else g.fillRect(x+cut,y,.045,1);
  g.fillStyle="rgba(220,200,255,"+(.02+R()*.04)+")";g.fillRect(x+.05,y+.05,.9,.4);
  for(var n=0;n<3;n++){g.fillStyle="rgba(0,0,0,"+(.05+R()*.08)+")";g.fillRect(x+R(),y+R(),.06+R()*.12,.04);}
 }
 g.strokeStyle="rgba(10,8,16,.55)";g.lineWidth=.05;
 for(var i=0;i<=W;i++){g.beginPath();g.moveTo(i,0);g.lineTo(i,H);g.stroke();}
 for(var j=0;j<=H;j++){g.beginPath();g.moveTo(0,j);g.lineTo(W,j);g.stroke();}
 /* círculo de transmutación */
 var cxm=7.9,cym=5.2;
 g.strokeStyle="#9a7ae0";g.lineWidth=.07;g.beginPath();g.arc(cxm,cym,1.55,0,7);g.stroke();
 g.lineWidth=.035;g.beginPath();g.arc(cxm,cym,1.3,0,7);g.stroke();
 g.beginPath();for(var k=0;k<5;k++){var a=k*4*Math.PI/5-Math.PI/2;g[k?"lineTo":"moveTo"](cxm+Math.cos(a)*1.3,cym+Math.sin(a)*1.3);}g.closePath();g.stroke();
 g.fillStyle="rgba(170,130,255,.9)";for(var k=0;k<12;k++){var a=k*Math.PI/6;g.fillRect(cxm+Math.cos(a)*1.43-.04,cym+Math.sin(a)*1.43-.04,.08,.08);}
 var gc=g.createRadialGradient(cxm,cym,.1,cxm,cym,1.6);gc.addColorStop(0,"rgba(150,110,255,.25)");gc.addColorStop(1,"rgba(150,110,255,0)");g.fillStyle=gc;g.fillRect(cxm-2,cym-2,4,4);
 /* alfombra del mostrador */
 g.fillStyle="#2a2050";g.fillRect(2.4,1.9,3.0,.9);g.strokeStyle="#c9a2f0";g.lineWidth=.04;g.strokeRect(2.5,2.0,2.8,.7);
 /* derrames de pociones */
 [[2.2,3.6,"90,200,120"],[10.0,2.4,"120,150,255"],[4.6,5.6,"200,90,140"]].forEach(function(q){g.fillStyle="rgba("+q[2]+",.22)";g.beginPath();g.ellipse(q[0],q[1],.45,.25,0,0,7);g.fill();});
 g.fillStyle="#2a2a38";g.fillRect(.15,7.0,.95,1.7);g.strokeStyle="#9a7ae0";g.lineWidth=.04;g.strokeRect(.25,7.1,.75,1.5);
 var gr=g.createLinearGradient(0,0,0,1.4);gr.addColorStop(0,"rgba(0,0,0,.5)");gr.addColorStop(1,"rgba(0,0,0,0)");g.fillStyle=gr;g.fillRect(0,0,W,1.4);
 var gl=g.createLinearGradient(0,0,1.4,0);gl.addColorStop(0,"rgba(0,0,0,.5)");gl.addColorStop(1,"rgba(0,0,0,0)");g.fillStyle=gl;g.fillRect(0,0,1.4,H);
 g.restore();
 function frascos(u0,w,y0){g.fillStyle="#2a170a";g.fillRect(u0-.05,y0,w+.1,3);
  for(var i=0;i<Math.floor(w/.38);i++){var cu=u0+.15+i*.38,hh=8+(i%3)*3;g.fillStyle=["#5aa0c8","#a8d070","#d06a6a","#e0c060","#9a70c8"][i%5];g.fillRect(cu,y0-hh,.17,hh);g.fillStyle="rgba(255,255,255,.35)";g.fillRect(cu+.03,y0-hh+1,.04,hh-3);}}
 function pared(len,shade){
  var gp=g.createLinearGradient(0,-WH,0,0);gp.addColorStop(0,"rgb("+Math.round(70*shade)+","+Math.round(70*shade)+","+Math.round(96*shade)+")");gp.addColorStop(1,"rgb("+Math.round(108*shade)+","+Math.round(104*shade)+","+Math.round(132*shade)+")");
  g.fillStyle=gp;g.fillRect(0,-WH,len,WH);
  for(var row=0;row<9;row++){
   var yy=-WH+row*13,off=(row%2)*.5,u=-off;
   while(u<len){var bw=.7+R()*.5;
    g.fillStyle="rgba("+(R()<.55?"0,0,0":"220,210,255")+","+(.04+R()*.07)+")";g.fillRect(Math.max(0,u)+.02,yy+1,Math.min(bw,len-Math.max(0,u))-.04,11);
    g.fillStyle="rgba(14,12,22,.5)";g.fillRect(Math.max(0,u),yy,.035,13);u+=bw;}
   g.fillStyle="rgba(14,12,22,.5)";g.fillRect(0,yy,len,1);
  }
  var sg=g.createLinearGradient(0,-WH,0,-30);sg.addColorStop(0,"rgba(0,0,0,.5)");sg.addColorStop(1,"rgba(0,0,0,0)");g.fillStyle=sg;g.fillRect(0,-WH,len,WH-30);
  g.fillStyle="rgba(12,10,20,"+(.34+(1-shade)*.4)+")";g.fillRect(0,-40,len,40);
  g.fillStyle="#2e1a0a";g.fillRect(0,-43,len,4);g.fillStyle="rgba(255,210,140,.22)";g.fillRect(0,-43,len,1);
  g.fillStyle="#2a170a";g.fillRect(0,-4,len,4);
  g.fillStyle="#3b2412";g.fillRect(0,-WH,len,9);g.fillStyle="rgba(255,210,140,.16)";g.fillRect(0,-WH,len,1.5);
  for(var b=0;b<=len;b+=Math.max(2.5,len/4)){g.fillStyle="#3b2412";g.fillRect(b-.12,-WH,.24,WH);g.fillStyle="rgba(255,210,140,.12)";g.fillRect(b-.12,-WH,.04,WH);}
  g.fillStyle="#2e1a0a";g.fillRect(len-.24,-WH,.24,WH);
 }
 g.save();g.transform(TW,TH,0,1,0,0);pared(W,1);
 frascos(2.2,3.2,-82);frascos(7.0,2.0,-70);frascos(10.0,1.3,-82);
 /* hierbas colgadas */
 for(var i=0;i<7;i++){var hu=2.4+i*.45;g.fillStyle="#3b2412";g.fillRect(hu,-WH+9,.03,12);g.fillStyle=["#5a8a3a","#7a9a4a","#9a7a3a"][i%3];g.beginPath();g.moveTo(hu-.12,-WH+21);g.lineTo(hu+.15,-WH+21);g.lineTo(hu+.02,-WH+36);g.closePath();g.fill();}
 /* ventana alta */
 g.fillStyle="#2a170a";g.fillRect(11.05,-98,.7,50);g.fillStyle="#1d2440";g.fillRect(11.12,-92,.56,38);
 g.fillStyle="rgba(150,170,255,.3)";g.fillRect(11.12,-92,.56,15);g.fillStyle="#2a170a";g.fillRect(11.38,-92,.05,38);g.fillRect(11.12,-74,.56,3);
 g.restore();
 g.save();g.transform(TW,-TH,0,1,0,0);g.save();g.translate(-H,0);pared(H,.82);g.restore();
 frascos(-6.6,2.0,-76);
 g.fillStyle="#d8c690";g.fillRect(-3.6,-100,.05,20);
 (function(){var u0=-8.45,w=1.35,h=84;
  g.fillStyle="#1d1006";g.fillRect(u0-.12,-h-8,w+.24,h+8);
  var gd=g.createLinearGradient(0,-h,0,0);gd.addColorStop(0,"#5a3818");gd.addColorStop(1,"#3a2410");g.fillStyle=gd;g.fillRect(u0,-h,w,h);
  g.fillStyle="rgba(0,0,0,.3)";for(var i=1;i<4;i++)g.fillRect(u0+i*w/4,-h,.03,h);
  g.fillStyle="#9a7ae0";g.beginPath();g.arc(u0+w*.5,-h*.7,.2,0,7);g.fill();g.fillStyle="#3a2410";g.beginPath();g.arc(u0+w*.5,-h*.7,.11,0,7);g.fill();
  g.fillStyle="#c9923c";g.beginPath();g.ellipse(u0+w*.8,-h*.42,.07,2.4,0,0,7);g.fill();
  g.fillStyle="#120a04";g.fillRect(u0-.12,-h-8,w+.24,6);
 })();
 g.restore();
 g.fillStyle="#2a170a";g.fillRect(-2,-WH,4,WH);
 STAT=c;
}
function spr(k,x,y,s,dy,mir){
 var im=IM[k],p=pj(x,y);cx.save();cx.translate(p.x,p.y+8+(dy||0));if(mir)cx.scale(-1,1);
 cx.drawImage(im,-im.width*s/2,-im.height*s,im.width*s,im.height*s);cx.restore();
}
function caja3d(x0,y0,x1,y1,h,cT,cL,cR){
 function P3(x,y,z){var p=pj(x,y);return[p.x,p.y-z];}
 function poly(a,col){cx.beginPath();a.forEach(function(p,i){i?cx.lineTo(p[0],p[1]):cx.moveTo(p[0],p[1]);});cx.closePath();cx.fillStyle=col;cx.fill();}
 poly([P3(x0,y1,0),P3(x1,y1,0),P3(x1,y1,h),P3(x0,y1,h)],cL);
 poly([P3(x1,y0,0),P3(x1,y1,0),P3(x1,y1,h),P3(x1,y0,h)],cR);
 poly([P3(x0,y0,h),P3(x1,y0,h),P3(x1,y1,h),P3(x0,y1,h)],cT);
 cx.strokeStyle="rgba(255,230,170,.45)";cx.lineWidth=1;cx.beginPath();var a=P3(x0,y1,h),b=P3(x1,y1,h),c=P3(x1,y0,h);cx.moveTo(a[0],a[1]);cx.lineTo(b[0],b[1]);cx.lineTo(c[0],c[1]);cx.stroke();
}
function caldero(x,y,t){
 var p=pj(x,y);cx.save();cx.translate(p.x,p.y+8);
 cx.fillStyle="rgba(0,0,0,.3)";cx.beginPath();cx.ellipse(0,0,17,7,0,0,7);cx.fill();
 cx.fillStyle="#22222a";cx.beginPath();cx.ellipse(0,-14,16,10,0,0,Math.PI);cx.lineTo(-16,-24);cx.lineTo(16,-24);cx.closePath();cx.fill();
 cx.fillStyle="#2c2c36";cx.beginPath();cx.ellipse(0,-14,16,9,0,0,Math.PI);cx.fill();
 cx.fillStyle="#3a3a46";cx.beginPath();cx.ellipse(0,-26,17,7,0,0,7);cx.fill();
 cx.fillStyle="#58d89a";cx.beginPath();cx.ellipse(0,-26,14,5.4,0,0,7);cx.fill();
 for(var i=0;i<4;i++){var ph=(t*.8+i*.27)%1;cx.fillStyle="rgba(190,255,220,"+(1-ph)+")";cx.beginPath();cx.arc(Math.sin(i*3+t)*8,-26-ph*4,1.5+ph*2,0,7);cx.fill();}
 cx.restore();
}
function lista(){
 var L=[];
 L.push({k:1.6,f:function(){spr("estante",1.5,.7,1.4);}});
 L.push({k:9.7,f:function(){spr("estante2",9.6,.7,1.4);}});
 L.push({k:5.9,f:function(){spr("horno",6.5,.85,1.5);}});
 L.push({k:5.9,f:function(){caja3d(2.5,1.0,5.3,1.85,28,"#4a3466","#34224a","#241638");
  spr("mesa_al",2.9,1.6,.9,-28);spr("mesa_al",5.0,1.6,.9,-28,1);}});
 L.push({k:9.6,f:function(){spr("tripode",7.5,2.9,1.2);}});
 L.push({k:9.7,f:function(){caldero(7.5,2.9,T);}});
 L.push({k:10.7,f:function(){spr("brasero",6.9,4.1,1.15);}});
 L.push({k:13.2,f:function(){spr("brasero",9.3,4.1,1.15);}});
 L.push({k:13.3,f:function(){spr("brasero",6.9,6.5,1.15);}});
 L.push({k:15.8,f:function(){spr("brasero",9.3,6.5,1.15);}});
 L.push({k:14.2,f:function(){spr("barril1",11.3,3.5,1.2);spr("barril2",11.35,4.4,1.2);spr("cofre_c",11.2,5.4,1.05);spr("sacos",11.3,6.4,1.0);}});
 L.push({k:4.7,f:function(){spr("plantas",.9,4.6,1.2);}});
 L.push({k:9.3,f:function(){spr("banco_t",2.6,7.6,1.3);spr("cuenco",2.2,7.6,1.0,-22);spr("cuenco",3.1,7.6,1.0,-22);}});
 L.push({k:12.0,f:function(){spr("tina_b",5.0,5.6,1.2);spr("balde",4.2,5.6,1.2);}});
 L.push({k:11.8,f:function(){spr("anto_p",4.8,3.3,1.3);}});
 NP.forEach(function(p){L.push({k:p.x+p.y,f:function(){drawChar(p.c,p.x,p.y,p.dir,0,T);}});});
 L.push({k:0,pl:1});
 return L;
}
var OBJ=null;
/* ---------- dibujo ---------- */
function etiqueta(txt,x,y,hl){cx.save();cx.font="700 "+(hl?11:10)+"px Cinzel,serif";cx.textAlign="center";cx.lineWidth=3;cx.strokeStyle="rgba(20,12,4,.9)";cx.strokeText(txt,x,y);cx.fillStyle=hl?"#ffe9a8":"#f5e6c0";cx.fillText(txt,x,y);cx.restore();}
function marcadores(t){
 NP.forEach(function(p){
  var s=pj(p.x,p.y),bob=Math.sin(t*3+p.x)*2,hl=near===p;
  cx.save();cx.translate(s.x,s.y);
  cx.font="16px serif";cx.textAlign="center";cx.fillText(p.ico,0,-58+bob);
  if(hl){etiqueta(p.n,0,-74);cx.font="10px Karla,sans-serif";cx.fillStyle="#d4c9b8";cx.lineWidth=3;cx.strokeStyle="rgba(20,12,4,.9)";cx.strokeText(p.r,0,-84);cx.fillText(p.r,0,-84);}
  cx.restore();
 });
 var d=pj(0,7.8);cx.save();cx.translate(d.x,d.y-96);etiqueta("Salida",0,0,P.x<2.2&&P.y>6.6);cx.restore();
}
function luces(t){
 cx.save();cx.setTransform(1,0,0,1,0,0);cx.fillStyle="rgba(16,10,40,.22)";cx.fillRect(0,0,cv.width,cv.height);cx.restore();
 cx.globalCompositeOperation="lighter";
 var fl=.88+.12*Math.sin(t*8)+.05*Math.sin(t*21);
 function glow(x,y,z,r,a,rgb){var s=pj(x,y),g=cx.createRadialGradient(s.x,s.y-z,2,s.x,s.y-z,r);g.addColorStop(0,"rgba("+rgb+","+(a*fl)+")");g.addColorStop(1,"rgba("+rgb+",0)");cx.fillStyle=g;cx.fillRect(s.x-r,s.y-z-r,r*2,r*2);}
 glow(7.5,2.9,26,100,.4,"90,255,170");glow(6.5,.9,22,100,.3,"255,130,40");
 [[6.9,4.1],[9.3,4.1],[6.9,6.5],[9.3,6.5]].forEach(function(q){glow(q[0],q[1],24,70,.3,"255,170,70");});
 glow(7.9,5.2,4,150,.25+.1*Math.sin(t*2),"150,110,255");
 glow(4.8,3.3,36,70,.25,"255,200,110");glow(3.8,1.4,40,110,.2,"200,160,255");
 glow(.3,7.8,70,90,.2,"255,170,70");glow(11.4,.6,60,90,.14,"140,150,255");
 for(var i=0;i<12;i++){var ph=(t*.35+i*.083)%1,a=i*2.1+t*.6,r=.4+ph*1.1,s=pj(7.9+Math.cos(a)*r,5.2+Math.sin(a)*r);cx.fillStyle="rgba(190,160,255,"+(1-ph)*.9+")";cx.fillRect(s.x,s.y-ph*50,2,2);}
 cx.globalCompositeOperation="source-over";
}
function draw(t){
 var w=cv.width,h=cv.height;cx.setTransform(1,0,0,1,0,0);cx.fillStyle="#12100c";cx.fillRect(0,0,w,h);
 cx.setTransform(Z*DPR,0,0,Z*DPR,w/2-CAMX*Z*DPR,h/2-CAMY*Z*DPR);
 cx.imageSmoothingEnabled=true;cx.drawImage(STAT,SX0,SY0,SW,SH);
 if(tgt){var s=pj(tgt.x+.5,tgt.y+.5);cx.strokeStyle="rgba(232,200,120,"+(.5+.4*Math.sin(t*6))+")";cx.lineWidth=2;cx.beginPath();cx.moveTo(s.x,s.y-8);cx.lineTo(s.x+16,s.y);cx.lineTo(s.x,s.y+8);cx.lineTo(s.x-16,s.y);cx.closePath();cx.stroke();}
 var L=OBJ.slice();L.forEach(function(o){if(o.pl)o.k=P.x+P.y;});L.sort(function(a,b){return a.k-b.k;});
 L.forEach(function(o){if(o.pl)drawChar(PC,P.x,P.y,P.dir,P.mv,T);else o.f();});
 luces(t);marcadores(t);
}
/* ---------- arranque ---------- */
function resize(){
 DPR=Math.min(2,devicePixelRatio||1);cv.width=innerWidth*DPR;cv.height=innerHeight*DPR;
 var aw=innerWidth-12,ah=innerHeight-110,rw=(W+H)*TW+30,rh=(W+H)*TH+WH+30;
 Z=Math.max(.45,Math.min(aw/rw,ah/rh,1.7));
}
addEventListener("resize",resize);resize();
var keysA=Object.keys(ALQASSETS),pend=keysA.length+CHARS.length;
function ok(){if(--pend===0)iniciar();}
keysA.forEach(function(k){var im=new Image();im.onload=ok;im.src=ALQASSETS[k];IM[k]=im;});
CHARS.forEach(function(d,i){var im=new Image();im.onload=ok;im.src=d;CI[i]=im;});
function iniciar(){
 construir();OBJ=lista();
 if(EMB)parent.postMessage({naradak:"ready"},"*");
 var last=performance.now();
 (function loop(now){var dt=Math.min(.05,(now-last)/1000);last=now;T+=dt;
  mover(dt);cerca();draw(T);requestAnimationFrame(loop);})(last);
}
})();
